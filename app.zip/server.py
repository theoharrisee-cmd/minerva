"""easyDevelopment local server: JSON API + static UI. Standard library only."""
from __future__ import annotations

import base64
import json
import mimetypes
import os
import re
import sys
import threading
import time
import uuid
from copy import deepcopy
from datetime import date, datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from core import comps as comps_mod
from core import epcfile
from core import ppdfile
from core import requirements as requirements_mod
from core import committee, contacts, costs, dd, deck, docs, feed, floorplan, intake, investor as inv, land, outlook, planreg, policy, portfolio, replies, report, scenarios, schemes, typology, waterfall, watch
from core import planning as plan
from core import tax as tax_mod, levies, costplan, listings, sketch as sketch_mod, ask as ask_mod, packs, history, strategy as strategy_mod, compset, programme, funding, brief, data_out, layout, geo as geo_mod, areasearch, assembly, maplayers, datasources, hmlr, marketmix, recheck, places, scrapers, screen, sources, store, suggest, track
from core.appraisal import appraise, sensitivity
from core.config import (ASSUMPTION_SPEC, DEFAULT_ASSUMPTIONS, DEFAULT_MODEL, DEFAULT_WEIGHTS, STAGES, STRATEGIES)
from core.scoring import red_flags, score_site

PASSWORD = os.environ.get("MINERVA_PASSWORD", "")          # set when hosted: everything sits behind this password
HOSTED = bool(PASSWORD) or bool(os.environ.get("MINERVA_HOSTED"))
SECRET = (os.environ.get("MINERVA_SECRET") or PASSWORD or "local").encode()
COOKIE = "easydevelopment_session"
_fails: dict[str, list[float]] = {}

LOGIN_HTML = """<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>easyDevelopment</title>
<style>:root{color-scheme:light dark}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F5F5F4;color:#111;font:15px "Helvetica Neue",Helvetica,Arial,sans-serif}
@media(prefers-color-scheme:dark){body{background:#0C0C0C;color:#F4F4F4}form{background:#161616!important;border-color:#2A2A2A!important}input{background:#0C0C0C!important;color:#F4F4F4!important;border-color:#2A2A2A!important}}
form{background:#fff;border:1px solid #E3E3E0;border-radius:12px;padding:32px;width:min(360px,90vw);box-shadow:0 8px 30px -14px rgba(0,0,0,.2)}
.logo{display:inline-block;border-radius:8px;background:#FF6600;color:#fff;padding:10px 14px;font-weight:800;font-size:18px;letter-spacing:-.03em;margin-bottom:18px}
h1{font-size:20px;margin:0 0 4px}p{margin:0 0 18px;color:#6E6E6E;font-size:13.5px}input{width:100%;box-sizing:border-box;padding:11px 13px;border-radius:8px;border:1px solid #E3E3E0;font:inherit;margin-bottom:12px}
button{width:100%;padding:11px;border:0;border-radius:8px;background:#FF6600;color:#fff;font:inherit;font-weight:700;cursor:pointer}.e{color:#D93025;font-size:13px;margin-bottom:10px}</style></head>
<body><form method="post" action="/login"><div class="logo">easyDevelopment</div><p>Enter your password to continue.</p>__ERR__<input type="password" name="password" placeholder="Password" autofocus required><button>Sign in</button></form></body></html>"""


def _sign(exp: int) -> str:
    import hashlib
    import hmac
    return f"{exp}.{hmac.new(SECRET, str(exp).encode(), hashlib.sha256).hexdigest()}"


def _valid(tok: str) -> bool:
    import hmac
    import time
    try:
        exp, _ = tok.split(".", 1)
        return int(exp) > time.time() and hmac.compare_digest(tok, _sign(int(exp)))
    except Exception:
        return False


ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
UI = ROOT / "ui"
LOCK = threading.RLock()

prof = store.load_profile()
STATE = {
    "sites": store.load_sites(),
    "assumptions": {**DEFAULT_ASSUMPTIONS, **prof.get("assumptions", {})},
    "weights": {**DEFAULT_WEIGHTS, **prof.get("weights", {})},
    "model": prof.get("model", DEFAULT_MODEL),
    "api_key": prof.get("api_key") or os.environ.get("ANTHROPIC_API_KEY", ""),
    "scrape": {"max_pages": 2, "opportunities_only": True, "respect_robots": True, "use_snapshot": True, "ua": "",
               "enabled": [s["id"] for s in scrapers.SOURCES if s.get("verified")], "overrides": {}, **prof.get("scrape", {})},
    "theme": prof.get("theme", "auto"),
    "brand": packs.brand_of(prof.get("brand")),
    "investor": {**inv.DEFAULT_INVESTOR, **prof.get("investor", {})},
    "epc": {"email": "", "key": "", **prof.get("epc", {})},
    "portfolio": [portfolio.clean_scheme(x) for x in (prof["portfolio"] if "portfolio" in prof else portfolio.DEMO_SCHEMES)],
    "org": prof["org"] if "org" in prof else dict(portfolio.DEMO_ORG),
    "alerts": {**watch.DEFAULT_SETTINGS, **prof.get("alerts", {})},
    "data": datasources.merged(prof.get("data")),
    "data_tests": prof.get("data_tests", {}),
    "searches": prof.get("searches", []),
    "views": prof.get("views", []),
    "notif_seen": prof.get("notif_seen", []),
    "onboarded": bool(prof.get("onboarded", bool(prof))),
    "tax_default": {k: v for k, v in (prof.get("tax_default") or {}).items() if k in ("structure", "personal_rate", "associated")},
}
NEWS = {"items": {}, "ts": {}, "running": False, "last": ""}
CHECKS = {"running": False, "last": None}
JOB = scrapers.ScrapeJob()
PLAN_TEXT: dict[str, str] = {}
PLAN_RES: dict[str, dict] = {}


def persist_sites():
    store.save_sites(STATE["sites"])


def persist_profile():
    store.save_profile({"assumptions": STATE["assumptions"], "weights": STATE["weights"], "model": STATE["model"],
                        "api_key": STATE["api_key"], "scrape": STATE["scrape"], "theme": STATE["theme"], "brand": STATE["brand"],
                        "investor": STATE["investor"], "epc": STATE["epc"], "portfolio": STATE["portfolio"], "org": STATE["org"], "alerts": STATE["alerts"],
                        "views": STATE["views"], "onboarded": STATE["onboarded"], "tax_default": STATE["tax_default"], "notif_seen": STATE["notif_seen"][-600:], "data": STATE["data"], "data_tests": STATE["data_tests"], "searches": STATE["searches"]})


def data_state():
    cfg = STATE["data"]
    disc = datasources.discover_pdg()
    have = disc.get("datasets") or {}
    off = set(cfg.get("off") or [])
    srcs = []
    for s in datasources.SOURCES:
        t = STATE["data_tests"].get(s.get("test") or s["id"]) if (s.get("test") or s["kind"] in ("discover",)) else None
        srcs.append({**{k: v for k, v in s.items() if k != "wms"}, "on": (bool((cfg.get("wms") or {}).get(s["id"], {}).get("on") and (cfg.get("wms") or {}).get(s["id"], {}).get("layer")) if s.get("wms") else s["id"] not in off and s.get("default_on", True)), "tested": t, "testable": bool(s.get("test")) or s["kind"] == "discover",
                     "has_wms": bool(s.get("wms")), "wms_cfg": (cfg.get("wms") or {}).get(s["id"])})
    sets = [{**d, "on": d["id"] not in off, "published": (d["id"] in have) if have else None} for d in datasources.PDG_SETS]
    other = sorted(({"id": k, "name": v} for k, v in have.items() if k not in datasources.PDG_BY_ID), key=lambda x: x["id"])
    return {"groups": datasources.GROUPS, "sources": srcs, "pdg": sets, "platform": {"ok": disc.get("ok"), "count": len(have), "when": disc.get("when", ""), "error": disc.get("error", ""), "other": other[:300]},
            "extra_pdg": cfg.get("extra_pdg") or [], "layers": cfg.get("layers") or [],
            "settings": {"planit_contact": cfg.get("planit_contact", ""), "has_hmlr_key": bool(cfg.get("hmlr_key")), "has_ch_key": bool(cfg.get("ch_key")),
                         "title_api": {**{k: v for k, v in (cfg.get("title_api") or {}).items() if k != "key"}, "has_key": bool((cfg.get("title_api") or {}).get("key"))}},
            "hmlr": {**hmlr.meta(), "status": dict(hmlr.STATUS), "diff": hmlr.last_diff()}, "search_filters": [{"key": v[2], "label": v[0]} for v in areasearch.SCREEN.values()]}


def resolve_place(text):
    """Latitude and longitude for a town or city on the built-in list, else a postcode."""
    k = (text or "").strip().lower()
    for p in places.load():
        if p["name"].lower() == k:
            return p["lat"], p["lon"]
    g = scrapers.geocode_text(text or "")
    return (g[0], g[1]) if g else None


def enrich_site(s):
    if s.get("lat") is None:
        raise ValueError("The site needs coordinates: add a postcode")
    pack = datasources.enrich(s, STATE["data"], hmlr_lookup=hmlr.lookup_for_site)
    s["data_pack"] = pack
    s.update(pack["flags"])
    # keep the constraint result the report and risk flags already read
    hits = {}
    for x in pack["items"]:
        if x["status"] == "hit" and x.get("flag"):
            hits[x["flag"]] = {"label": x["label"], "entities": [{"name": e.get("name"), "reference": e.get("reference"), "flood": e.get("flood")} for e in x.get("entities", [])]}
    s["constraints_result"] = {"hits": hits, "errors": pack["errors"], "checked": pack["checked"], "checked_datasets": pack["counts"]["datasets"]}
    if pack.get("title_area_ha") and not s.get("site_ha"):
        s["site_ha_suggested"] = pack["title_area_ha"]
    if (pack.get("geography") or {}).get("district") and not s.get("la"):
        s["la"] = pack["geography"]["district"]
    return pack


def site_by_id(sid):
    return next((s for s in STATE["sites"] if s["id"] == sid), None)


def assumptions_for(site, extra=None):
    fx = {k: v for k, v in (site.get("funding") or {}).items() if k in funding.EXTRA_KEYS}
    return {**STATE["assumptions"], **(site.get("ovr") or {}), **fx, **(extra or {})}


def evaluate(site, strategy=None, extra=None, full=False):
    strat = strategy or site.get("strategy") or "develop_sell"
    try:
        ap = appraise(site, assumptions_for(site, extra), strat)
    except Exception:  # never let one bad record break the dashboard
        ap = None
    flags = red_flags(site)
    slim = None
    if ap:
        keys = ["units", "nsa", "gia", "gdv", "rlv", "rlv_raw", "asking", "profit", "profit_on_gdv", "profit_on_cost", "yield_on_cost",
                "irr_unlevered", "irr_levered", "equity_multiple", "peak_equity", "max_bid", "opening_offer", "walk_away",
                "headroom_vs_asking", "viable", "incomplete", "missing", "target_profit", "profit_basis", "months_land", "noi",
                "land_cost", "land_finance", "build", "contingency", "fees", "s106", "cil", "build_finance", "sales_costs", "total_cost", "net_value",
                "npv_equity", "equity_profit", "debt_fee"]
        slim = {k: ap.get(k) for k in keys}
        if full:
            slim["cashflow"] = ap["cashflow"]
    fit = inv.mandate_fit(site, {"appraisal": slim, "strategy": strat}, STATE["investor"])
    sc = score_site(site, ap, flags, STATE["weights"], fit)
    return {"appraisal": slim, "flags": flags, "score": sc, "strategy": strat, "fit": fit}


def contact_of(site):
    """Agent details merged with firm-level details, always populated with at least a route to the agent."""
    a = dict(site.get("agent") or {})
    fc = contacts.firm_contact(site)
    a.setdefault("firm", fc.get("firm") or site.get("source"))
    for k, dst in (("team_phone", "team_phone"), ("team_email", "team_email"), ("phone", "firm_phone"), ("email", "firm_email"), ("url", "firm_page"), ("team", "team"), ("note", "firm_note")):
        if fc.get(k) and not a.get(dst):
            a[dst] = fc[k]
    a["listing_url"] = site.get("url")
    a["best_phone"] = a.get("phone") or a.get("team_phone") or a.get("firm_phone")
    a["best_email"] = a.get("email") or a.get("team_email") or a.get("firm_email")
    return a


def public_state():
    rows = []
    for s in STATE["sites"]:
        ev = evaluate(s)
        evs = s.get("events", [])
        rows.append({**{k: v for k, v in s.items() if k != "history"}, "_nhist": len(s.get("history") or []), "_ev": ev, "_contact": contact_of(s), "_region": inv.region_of(s), "_ndocs": len(s.get("docs", [])),
                     "_watch": watch.watched(s), "_unseen": sum(1 for e in evs if not e.get("seen")), "_dd": dd.summary(s["dd"]) if s.get("dd") else None,
                     "_events": evs[-30:][::-1] if watch.watched(s) or evs else []})
    return {
        "sites": rows, "stages": STAGES, "strategies": STRATEGIES,
        "assumptions": STATE["assumptions"], "spec": {k: {"default": v[0], "label": v[1], "group": v[2], "step": v[3]} for k, v in ASSUMPTION_SPEC.items()},
        "weights": STATE["weights"], "model": STATE["model"], "has_key": bool(STATE["api_key"]), "theme": STATE["theme"], "brand": STATE["brand"],
        "onboarded": STATE["onboarded"], "tax_default": STATE["tax_default"], "tax_structures": tax_mod.STRUCTURES,
        "scrape": STATE["scrape"], "sources": scrapers.SOURCES, "job": JOB.snapshot(),
        "investor": STATE["investor"], "regions": inv.REGIONS, "excludable": inv.EXCLUDABLE, "tolerance": inv.TOLERANCE,
        "epc": {"email": STATE["epc"]["email"], "has_key": bool(STATE["epc"]["key"]), "file": epcfile.status()}, "ppd": ppdfile.status(), "doc_cats": docs.CATS, "plan_statuses": planreg.STATUSES,
        "outlook": outlook.status(), "hosted": HOSTED, "views": STATE["views"], "reply_kinds": replies.KINDS, "maps": {"key": os.environ.get("PROTOMAPS_KEY", "").strip()},
        "alerts": {**{k: v for k, v in STATE["alerts"].items() if k != "smtp_password"}, "has_password": bool(STATE["alerts"].get("smtp_password")), "running": CHECKS["running"]},
        "dd_statuses": dd.STATUSES, "parcel_status": land.PARCEL_STATUS, "owner_types": land.OWNER_TYPES, "scheme_kinds": schemes.KINDS,
        "port_statuses": portfolio.STATUSES, "cost_footnote": costs.FOOTNOTE,
        "data_filters": [{"key": v[2], "label": v[0]} for v in areasearch.SCREEN.values()], "wf_defaults": waterfall.DEFAULT_TERMS, "cov_defaults": waterfall.DEFAULT_COVENANTS,
    }


def planning_bundle(s):
    planreg.lookup_lpa(s) if s.get("postcode") and not s.get("la") and s.get("_lpa_tried") is None and not s.get("demo_rich") and s.update(_lpa_tried=True) is None else None
    return {"links": planreg.links(s), "timeline": planreg.timeline(s), "read_out": track.add_points(planreg.read_out(s), s.get("track")), "track": s.get("track"), "apps": s.get("planning_history", []),
            "consultees": s.get("consultees", []), "analysis": s.get("planning_analysis"), "docs": s.get("docs", []), "la": s.get("la")}


def _decode_files(files):
    return [(f["name"], base64.b64decode(f["data"])) for f in (files or [])]


def create_from_intake(text, subject="", sender="", files=(), source="Deal intake", received=""):
    parts = [text]
    for name, data in files:
        t = docs.extract_text(name, data)
        if t:
            parts.append(f"\n===== ATTACHMENT: {name} =====\n{t}")
    d = intake.extract("\n".join(parts), STATE["api_key"] or None, STATE["model"], subject, sender)
    site = intake.to_site(d, source)
    site["region"] = inv.region_of(site)
    if received:
        site["received"] = received
    STATE["sites"].append(site)
    docs.add(site, f"Email {subject[:60] or 'enquiry'}.txt", f"From: {sender}\nSubject: {subject}\nDate: {received}\n\n{text}".encode(), category="Email", source="email", date=received[:10] or None)
    for name, data in files:
        docs.add(site, name, data, source="email attachment")
    persist_sites()
    return site


def model_bytes(s, strategy=None):
    import tempfile
    try:
        from core import xlmodel
    except ImportError:
        raise RuntimeError("Excel export needs the openpyxl package (pip3 install openpyxl). The DMG includes it.")
    strat = strategy or s.get("strategy") or "develop_sell"
    s0 = s
    # the workbook follows the standard timing and pro rata drawdown; the Programme and Funding tabs go further
    s = {k: v for k, v in s.items() if k not in ("programme", "funding")}
    a = {k: v for k, v in assumptions_for(s).items() if k not in funding.EXTRA_KEYS}
    ap = appraise(s, a, strat)
    ev = evaluate(s, strat)
    with tempfile.TemporaryDirectory() as td:
        p = str(Path(td) / "m.xlsx")
        xlmodel.build_model(s, a, strat, ap, STATE["investor"] if STATE["investor"].get("active") else None, ev["fit"] if ev["fit"].get("active") else None, p, tax=tax_state(s0, strat), costplan=costplan_state(s0, strat))
        return Path(p).read_bytes()


def full_appraisal(s, strat=None):
    strat = strat or s.get("strategy") or "develop_sell"
    return appraise(s, assumptions_for(s), strat), strat


def structure_of(s, strat=None):
    ap, strat = full_appraisal(s, strat)
    st = s.get("structure") or {}
    A = assumptions_for(s)
    return {"waterfall": waterfall.run([r["levered"] for r in ap["cashflow"]], st.get("terms")), "lender": waterfall.lender(ap, st.get("covenants"), strat, A["finance_rate"], A["mezz_rate"]),
            "terms": waterfall.clean_terms(st.get("terms")), "covenants": {**waterfall.DEFAULT_COVENANTS, **(st.get("covenants") or {})}}


def strategy_state(s, strat=None):
    h = homes_state(s) if (s.get("typology") or s.get("unit_mix")) else None
    return strategy_mod.build(s, s.get("data_pack") or {}, s.get("track"), h["policy"] if h else None, assumptions_for(s))


def compset_state(s):
    if not (s.get("comp_set") or {}).get("sales"):
        return None
    h = homes_state(s) if (s.get("typology") or s.get("unit_mix")) else None
    return compset.state(s, h["typ"] if h else None, h["calc"] if h else None)


def programme_state(s, strat=None):
    ap, strat = full_appraisal(s, strat)
    return programme.state(s, assumptions_for(s), strat, ap, appraise)


def funding_state(s, strat=None):
    ap, strat = full_appraisal(s, strat)
    st = s.get("structure") or {}
    return funding.state(s, assumptions_for(s), strat, ap, appraise, st.get("covenants"))


def set_investor(profile, apply_finance=True):
    p = {**STATE["investor"], **(profile or {})}
    for k, v in inv.DEFAULT_INVESTOR.items():
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            try:
                p[k] = type(v)(p[k]) if p[k] not in (None, "") else v
            except (TypeError, ValueError):
                p[k] = v
    STATE["investor"] = p
    if p.get("active") and apply_finance:
        STATE["assumptions"].update(inv.derived_assumptions(p))
    persist_profile()
    return inv.derived_assumptions(p)


def tax_state(s, strat=None):
    ap, strat = full_appraisal(s, strat)
    return tax_mod.compute(s, ap, strat, STATE["tax_default"])


def levies_state(s):
    return levies.state(s, assumptions_for(s))


def costplan_state(s, strat=None):
    strat = strat or s.get("strategy") or "develop_sell"
    return costplan.state(s, cost_pick(s, strat))


def cost_pick(s, strat=None):
    strat = strat or s.get("strategy") or "develop_sell"
    return costs.pick(s, strat, inv.region_of(s))


def verdict_text(s):
    ev = evaluate(s)
    return committee.verdict(ev["appraisal"], ev["flags"])


def scenarios_of(s, strat=None, only=None):
    """Named scenarios and break-even points. Returns {} when the appraisal is incomplete."""
    strat = strat or s.get("strategy") or "develop_sell"
    A = assumptions_for(s)

    def ap(site, a, st, land_price):
        return appraise(site, a, st, land_price=land_price)
    base = ap(s, A, strat, None)
    if base.get("incomplete"):
        return {"incomplete": True, "missing": base.get("missing"), "list": scenarios.clean(s.get("scenarios") or scenarios.DEFAULTS)}
    lst = scenarios.clean(only if only is not None else (s.get("scenarios") or scenarios.DEFAULTS))
    return {"list": lst, "rows": scenarios.run(s, A, strat, lst, ap), "breakeven": scenarios.breakeven(s, A, strat, ap), "fields": [{"key": f[0], "label": f[1], "unit": f[2], "hint": f[3]} for f in scenarios.FIELDS]}



def homes_basis(s):
    return bool(s.get("typology") or s.get("unit_mix") or s.get("units") or s.get("site_ha"))


def homes_state(s, typ=None):
    """Typology, geometry and policy results for a site. None when there is nothing to base a schedule on."""
    if typ is None:
        typ = s.get("typology") or typology.from_unit_mix(s)
        if typ is None and (s.get("units") or s.get("site_ha")):
            typ = typology.default_typology(s)
    if typ is None:
        return None
    typ = typology.normalise(typ, s)
    calc = typology.analyse(typ, s)
    res = policy.check(typ, calc, s, assumptions_for(s))
    lay = s.get("layout")
    if lay and lay.get("ok") and lay.get("sig") == layout.signature(s, typ):
        res["checks"] = res["checks"] + lay["checks"]
        cnt = {"pass": 0, "warn": 0, "fail": 0, "info": 0}
        for c in res["checks"]:
            cnt[c["status"]] = cnt.get(c["status"], 0) + 1
        res["counts"] = cnt
    return {"typ": typ, "calc": calc, "policy": res, "facts": policy.facts(typ, calc, res, s)}


def homes_payload(s, typ=None):
    h = homes_state(s, typ)
    base = {"library": typology.library(), "presets": [{"key": k, "name": v[0], "text": v[1]} for k, v in typology.PRESETS.items()], "packs": {k: v["label"] for k, v in policy.PACKS.items()},
            "kinds": floorplan.KIND_LABEL, "saved": bool(s.get("typology")), "pack_fields": policy.PACK_FIELDS}
    if not h:
        return {**base, "typology": None}
    calc = h["calc"]
    per = {uid: dict(v) for uid, v in calc["per"].items()}
    for u in h["typ"]["units"]:
        if u["family"] in ("house", "flat"):
            per[u["id"]]["ndss"] = typology.ndss_min(u["beds"], u["persons"], u["storeys"])
    tot = {k: calc[k] for k in ("units", "net_sqm", "gross_sqm", "gross_sqft", "net_sqft", "efficiency", "shared_sqm", "density", "houses", "flats")}
    plate = calc["plate"]
    tot["plate"] = {k: plate[k] for k in ("L", "dt", "db", "net", "gross", "eff", "n")} if plate else None
    tot["blocks"] = calc["alloc"]["n_blocks"]
    tot["stack"] = [{"block": bi + 1, "floors": [{"floor": fi, "units": sum(c.values()), "mix": {uid: c[uid] for uid in c}} for fi, c in enumerate(fl)]} for bi, fl in enumerate(calc["alloc"]["blocks"][:4])]
    return {**base, "typology": h["typ"], "per": per, "totals": tot, "policy": h["policy"], "facts": h["facts"], "assumed_source": h["typ"].get("source")}


def suggest_state(s):
    A = assumptions_for(s)
    pack = s.get("data_pack") or {}
    strat = s.get("strategy") or "develop_sell"
    items = suggest.with_state(suggest.rules(s, pack, s.get("track"), A), s)
    try:
        base = appraise(s, A, strat)
    except Exception:
        base = {"incomplete": True}
    for it in items:
        if base.get("incomplete") or it["accepted"]:
            it["impact"] = None
            continue
        try:
            ap = appraise(s, {**A, **{c["key"]: A.get(c["key"], 0) + c["delta"] for c in it["changes"]}}, strat)
            it["impact"] = round(ap["profit"] - base["profit"]) if not ap.get("incomplete") else None
        except Exception:
            it["impact"] = None
    return {"items": items, "has_pack": bool(pack), "profit": None if base.get("incomplete") else round(base["profit"]),
            "accepted": (s.get("suggest") or {}).get("accepted", {})}


def market_state(s, premium=0.0, h=None):
    h = h or homes_state(s)
    if not h:
        return {"units": [], "evidence": None}
    typ, calc = h["typ"], h["calc"]
    A = assumptions_for(s)
    strat = s.get("strategy") or "develop_sell"
    prices = marketmix.price_units(typ, calc, s, premium)
    compset.override_prices(prices, s, typ, calc)
    rates = marketmix.build_rates(typ, calc, s, strat, inv.region_of(s), A["build_psf"])
    ev = marketmix.evidence(s)
    per = {u["id"]: u for u in typ["units"]}
    rows = []
    for p in prices:
        r = next((x for x in rates if x["id"] == p["id"]), {})
        u = per[p["id"]]
        rows.append({**p, "build_psf": r.get("build_psf"), "build_class": r.get("class"), "current_value": u.get("sale_value"), "current_build": u.get("build_psf"), "auto_price": u.get("auto_price"), "auto_build": u.get("auto_build"),
                     "gia_sqft": calc["per"][p["id"]]["gia_sqft"], "count": u["count"]})
    return {"units": rows, "evidence": {"sector": ev["sector"], "n": ev["n"], "months": ev["months"], "overall_psf": ev["overall_psf"]}, "assumed_build": A["build_psf"], "region": inv.region_of(s) or "England"}


def plan_svg(s, typ, unit_id, kind="unit"):
    h = homes_state(s, typ)
    if not h:
        return ""
    typ, calc = h["typ"], h["calc"]
    colours = {u["id"]: floorplan.TYPE_COLOURS[i % len(floorplan.TYPE_COLOURS)] for i, u in enumerate(typ["units"])}
    if kind == "thumbs":
        out = {}
        for u in typ["units"]:
            if u["count"]:
                prims, box = floorplan.unit_sheet(u, calc["geoms"][u["id"]])
                out[u["id"]] = floorplan.to_svg(prims, box, 20, 340)
        return out
    if kind == "block":
        if not calc["plate"]:
            return ""
        title = f"Typical floor, {calc['plate']['n']} homes, {calc['plate']['eff']:.0%} net to gross"
        prims, box = floorplan.draw_plate(calc["plate"], calc["geoms"], colours, title)
        return floorplan.to_svg(prims, box, 34, 900)
    if kind == "plots":
        houses = [u for u in typ["units"] if u["family"] == "house" and u["count"]]
        if not houses:
            return ""
        prims, box = floorplan.plots_strip(houses, calc["geoms"], colours)
        return floorplan.to_svg(prims, box, 24, 900)
    u = next((x for x in typ["units"] if x["id"] == unit_id), None)
    if not u:
        return ""
    prims, box = floorplan.unit_sheet(u, calc["geoms"][u["id"]])
    return floorplan.to_svg(prims, box, 46, 1100)


def site_pack(s, strategy=None):
    strat = strategy or s.get("strategy") or "develop_sell"
    ev = evaluate(s, strat, full=True)
    a = assumptions_for(s)
    ap, _ = full_appraisal(s, strat)
    metric = "profit_on_gdv" if strat == "develop_sell" else "profit_on_cost"
    ykey = "sales_psf" if strat in ("develop_sell", "value_add") else "exit_yield"
    xkey = "build_psf" if strat != "value_add" else "refurb_psf"
    steps = [-0.15, -0.10, -0.05, 0, 0.05, 0.10, 0.15]
    sens = {**sensitivity(s, a, xkey, steps, ykey, steps, metric, strat), "xlabel": ASSUMPTION_SPEC[xkey][1], "ylabel": ASSUMPTION_SPEC[ykey][1]}
    items = s.get("dd") or []
    incomplete = (ev["appraisal"] or {}).get("incomplete")
    return {"site": s, "ev": ev, "full": ap, "planning": planning_bundle(s), "structure": structure_of(s, strat) if not incomplete else {},
            "dd": {"items": items, "summary": dd.summary(items)} if items else {}, "investor": STATE["investor"], "assumptions": a, "strategies": STRATEGIES, "sens": sens,
            "cost_benchmark": cost_pick(s, strat), "contact": contact_of(s), "scheme_comps": s.get("scheme_map"), "scenarios": scenarios_of(s, strat) if not incomplete else {},
            "constraints": s.get("constraints_result") or {}, "homes": homes_state(s) if (s.get("typology") or s.get("unit_mix")) else None,
            "data": data_out.bundle(s, str(store.DATA / "maps")), "layout": s.get("layout") if (s.get("layout") or {}).get("ok") else None,
            "programme": programme_state(s, strat) if programme.active(s) else None,
            "funding": funding_state(s, strat) if not incomplete else None, "strategy": strategy_state(s, strat),
            "compset": compset_state(s), "tax": tax_state(s, strat) if not incomplete else None,
            "costplan": costplan_state(s, strat) if (s.get("costplan") or {}).get("applied") else None, "sketch": sketch_mod.state(s)["items"] or None, "history": [h for h in history.timeline(s) if h["kind"] == "version"][:8] if len(s.get("history") or []) > 1 else None}


def _opts(s, kind):
    return ((s.get("pack_opts") or {}).get(kind)) or {}


def committee_bytes(s, strategy=None, opts=None):
    return packs.arrange_docx(committee.build(site_pack(s, strategy)), opts if opts is not None else _opts(s, "committee"), STATE["brand"])


def brief_bytes(s, strategy=None, opts=None):
    return packs.arrange_docx(brief.build(site_pack(s, strategy)), opts if opts is not None else _opts(s, "brief"), STATE["brand"])


def deck_bytes(s, strategy=None, opts=None):
    return packs.arrange_pptx(deck.build(site_pack(s, strategy)), opts if opts is not None else _opts(s, "deck"), STATE["brand"])


def report_html(s, strategy=None, opts=None):
    return packs.brand_html(report.render(site_pack(s, strategy), opts if opts is not None else _opts(s, "report")), STATE["brand"])


def pack_state(s, kind, strategy=None, opts=None):
    """Sections of a pack in their current order, plus a preview of what would be exported."""
    opts = packs.clean_opts(opts if opts is not None else _opts(s, kind))
    pk = site_pack(s, strategy)
    if kind == "report":
        secs = report.render(pk, opts, list_only=True)
        html_ = packs.brand_html(report.render(pk, opts), STATE["brand"])
        return {"kind": kind, "sections": secs, "html": html_, "opts": opts}
    builders = {"committee": (committee.build, packs.docx_sections, packs.arrange_docx, packs.docx_outline),
                "brief": (brief.build, packs.docx_sections, packs.arrange_docx, packs.docx_outline),
                "deck": (deck.build, packs.pptx_sections, packs.arrange_pptx, packs.pptx_outline)}
    build, sections, arrange, outline = builders[kind]
    raw = build(pk)
    out = arrange(raw, opts, STATE["brand"])
    return {"kind": kind, "sections": sections(raw, opts), "outline": outline(out), "opts": opts}


def log_changes(s, d):
    """Record notable edits against a shortlisted site."""
    if not watch.watched(s):
        return
    for k, label in (("stage", "Stage"), ("planning_status", "Planning status"), ("asking_price", "Asking price")):
        if k in d and d[k] != s.get(k):
            old, new = s.get(k), d[k]
            fmt = (lambda x: f"£{x:,.0f}" if isinstance(x, (int, float)) else str(x)) if k == "asking_price" else str
            watch.note_change(s, "activity", f"{label} changed", f"{fmt(old)} to {fmt(new)}", "important" if k != "stage" else "info")


def save_download(name: str, data: bytes):
    out = Path(os.environ.get("MINERVA_DOWNLOADS") or (Path.home() / "Downloads"))
    out.mkdir(parents=True, exist_ok=True)
    p = out / name
    stem, ext = p.stem, p.suffix
    n = 1
    while p.exists():
        p = out / f"{stem}_v{n}{ext}"
        n += 1
    p.write_bytes(data)
    if not os.environ.get("MINERVA_NO_OPEN"):
        import webbrowser
        webbrowser.open(p.as_uri())
    return {"path": str(p), "name": p.name}


def news_targets():
    ts = [x for x in STATE["sites"] if x.get("lat") is not None and not x.get("demo") and x.get("stage") != "Rejected"]
    ts.sort(key=lambda x: (not watch.watched(x)))
    return [{"id": x["id"], "name": x.get("name", ""), "lat": x["lat"], "lon": x["lon"]} for x in ts[:20]]


def refresh_news_async(force=False):
    if NEWS["running"]:
        return False
    targets = [t for t in news_targets() if force or time.time() - NEWS["ts"].get(t["id"], 0) > 12 * 3600]
    if not targets:
        return False
    NEWS["running"] = True

    def work():
        try:
            for t in targets:
                try:
                    NEWS["items"][t["id"]] = feed.fetch_nearby(t, cfg=STATE["data"])
                except Exception:
                    NEWS["items"].setdefault(t["id"], [])
                NEWS["ts"][t["id"]] = time.time()
            NEWS["last"] = watch.now()
        finally:
            NEWS["running"] = False

    threading.Thread(target=work, daemon=True).start()
    return True


def run_checks_async():
    if CHECKS["running"]:
        return False
    CHECKS["running"] = True

    def work():
        try:
            with LOCK:
                targets = [x for x in STATE["sites"] if watch.watched(x)]
            found = 0
            for x in targets:
                with LOCK:
                    found += len(watch.check_site(x))
                    if recheck.due(x):
                        found += len(recheck.run(x, STATE["data"]))
                    persist_sites()
            with LOCK:
                cfg = STATE["alerts"]
                cfg["last_run"] = watch.now()
                emailed, err = 0, ""
                if cfg.get("enabled") and cfg.get("smtp_host") and cfg.get("to"):
                    items = watch.pending(STATE["sites"], cfg.get("digest_min_level", "info"))
                    if items:
                        subject, text, body = watch.build_digest(items)
                        try:
                            watch.send_email(cfg, subject, text, body)
                            for _, e in items:
                                e["sent"] = True
                            emailed = len(items)
                            cfg["last_sent"] = watch.now()
                            cfg["last_error"] = ""
                        except Exception as e:
                            cfg["last_error"] = str(e)[:200]
                persist_sites()
                persist_profile()
                CHECKS["last"] = {"new_events": found, "emailed": emailed, "error": cfg.get("last_error", "")}
        finally:
            CHECKS["running"] = False

    threading.Thread(target=work, daemon=True).start()
    return True


hmlr.WATCH = lambda: [p for s in STATE["sites"] if watch.watched(s) for p in recheck._postcodes(s)]

_SCHED = None


def start_scheduler():
    global _SCHED
    if _SCHED is None:
        _SCHED = watch.Scheduler(run_checks_async, lambda: STATE["alerts"])
        _SCHED.start()
    return _SCHED


# ------------------------------------------------------------------ routes

def _site_id_of(body):
    if not isinstance(body, dict):
        return None
    if body.get("id"):
        return body["id"]
    site = body.get("site")
    return site.get("id") if isinstance(site, dict) else None


def api(method: str, path: str, q: dict, body: dict):
    """Every saved change to a site's inputs leaves a version behind, so changes can be compared later."""
    track_hist = method == "POST" and path not in ("/api/appraise",) and not path.startswith(("/api/history", "/api/ask")) and not path.endswith(("/get", "/status", "/run"))
    sid = _site_id_of(body) if track_hist else None
    if sid:
        with LOCK:
            s0 = site_by_id(sid)
            if s0 is not None:
                try:
                    history.ensure(s0, evaluate)
                except Exception:
                    pass
    out = _api(method, path, q, body)
    if sid:
        with LOCK:
            s1 = site_by_id(sid)
            if s1 is not None and not (isinstance(out, tuple) and out[1] >= 400):
                try:
                    if history.record(s1, history.label_for(path), evaluate):
                        persist_sites()
                except Exception:
                    pass
    return out


def _api(method: str, path: str, q: dict, body: dict):
    with LOCK:
        if method == "GET" and path == "/api/state":
            return public_state()
        if method == "GET" and path == "/api/job":
            return JOB.snapshot()
        if method == "POST" and path == "/api/appraise":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "not found"}, 404
            extra = body.get("assumptions") or {}
            s = {**s, **{k: extra[k] for k in ("sales_psf", "rent_psf") if k in extra}}  # site-level values win in the engine
            strat = body.get("strategy")
            ev = evaluate(s, strat, extra, full=True)
            metric = "profit_on_gdv" if ev["strategy"] == "develop_sell" else "profit_on_cost"
            ykey = "sales_psf" if ev["strategy"] in ("develop_sell", "value_add") else "exit_yield"
            xkey = "build_psf" if ev["strategy"] != "value_add" else "refurb_psf"
            steps = [-0.15, -0.10, -0.05, 0, 0.05, 0.10, 0.15]
            sens = sensitivity(s, assumptions_for(s, extra), xkey, steps, ykey, steps, metric, ev["strategy"])
            ev["sens"] = {**sens, "xkey": xkey, "ykey": ykey, "xlabel": ASSUMPTION_SPEC[xkey][1], "ylabel": ASSUMPTION_SPEC[ykey][1]}
            ev["planning"] = planning_bundle(s)
            ev["contact"] = contact_of(s)
            ev["costs"] = cost_pick(s, ev["strategy"])
            return ev
        if method == "POST" and path == "/api/site":
            d = body["site"]
            s = site_by_id(d.get("id"))
            if s:
                log_changes(s, d)
                s.update(d)
            else:
                d["id"] = d.get("id") or f"manual-{uuid.uuid4().hex[:6]}"
                d.setdefault("stage", "Sourced")
                d.setdefault("strategy", "develop_sell")
                if d.get("lat") is None and (d.get("postcode") or d.get("address")):
                    g = scrapers.geocode_text(f"{d.get('postcode','')} {d.get('address','')}")
                    if g:
                        d["lat"], d["lon"], d["geo_precision"] = g
                STATE["sites"].append(d)
                s = d
            if s.get("postcode") and (s.get("lat") is None or body.get("regeocode")):
                g = scrapers.geocode_text(s["postcode"])
                if g:
                    s["lat"], s["lon"], s["geo_precision"] = g
            persist_sites()
            return {"ok": True, "id": s["id"]}
        if method == "POST" and path == "/api/site/delete":
            STATE["sites"] = [s for s in STATE["sites"] if s["id"] != body["id"]]
            persist_sites()
            return {"ok": True}
        if method == "POST" and path == "/api/open":
            import webbrowser
            if str(body.get("url", "")).startswith(("http://", "https://", "mailto:")):
                webbrowser.open(body["url"])
            return {"ok": True}
        if method == "POST" and path == "/api/model/save":
            s = site_by_id(body["id"])
            data = model_bytes(s, body.get("strategy"))
            return save_download(re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "deal")).strip("_")[:40] + "_committee_paper.docx", data)
        if method == "POST" and path == "/api/clear-demo":
            STATE["sites"] = [s for s in STATE["sites"] if not s.get("demo")]
            STATE["portfolio"] = [x for x in STATE["portfolio"] if not x.get("demo")]
            if STATE["org"].get("demo"):
                STATE["org"] = {}
            persist_sites()
            persist_profile()
            return {"ok": True}
        if method == "POST" and path == "/api/settings":
            for k in ("assumptions", "weights", "scrape"):
                if k in body:
                    STATE[k].update(body[k])
            for k in ("model", "theme"):
                if k in body:
                    STATE[k] = body[k]
            if "api_key" in body and body["api_key"] is not None:
                STATE["api_key"] = body["api_key"]
            persist_profile()
            return {"ok": True}
        if method == "POST" and path == "/api/settings/reset":
            STATE["assumptions"] = dict(DEFAULT_ASSUMPTIONS)
            STATE["weights"] = dict(DEFAULT_WEIGHTS)
            persist_profile()
            return {"ok": True}
        if method == "POST" and path == "/api/scrape":
            ids = body.get("sources") or STATE["scrape"]["enabled"]
            ok = JOB.start(ids, STATE["sites"], persist_sites, STATE["scrape"], keep=lambda r: inv.search_filter(STATE["investor"], r))
            return {"started": ok}
        if method == "POST" and path == "/api/import":
            try:
                rows = sources.parse_csv(body["text"]) if body["kind"] == "csv" else sources.parse_alert_text(body["text"])
            except Exception as e:
                return {"error": str(e)}, 400
            have = {s["id"] for s in STATE["sites"]}
            new = [r for r in rows if r["id"] not in have]
            STATE["sites"].extend(new)
            persist_sites()
            return {"added": len(new), "found": len(rows)}
        if method == "POST" and path == "/api/brownfield":
            g = scrapers.geocode_text(body["postcode"])
            if not g:
                return {"error": "Could not geocode that postcode"}, 400
            try:
                rows = sources.fetch_brownfield(g[0], g[1], float(body.get("radius", 10)))
            except Exception as e:
                return {"error": f"Open data request failed: {e}"}, 502
            have = {s["id"] for s in STATE["sites"]}
            new = [r for r in rows if r["id"] not in have]
            STATE["sites"].extend(new)
            persist_sites()
            return {"added": len(new), "found": len(rows)}
        if method == "GET" and path == "/api/data/state":
            return data_state()
        if method == "GET" and path == "/api/requirements":
            return requirements_mod.load()
        if method == "POST" and path == "/api/data/settings":
            cfg = STATE["data"]
            for k in ("off", "extra_pdg", "layers", "wms", "planit_contact"):
                if k in body:
                    cfg[k] = body[k]
            for k in ("hmlr_key", "ch_key"):
                if body.get(k):
                    cfg[k] = body[k].strip()
                if body.get(k + "_clear"):
                    cfg[k] = ""
            if "title_api" in body:
                ta = {**(cfg.get("title_api") or {}), **{k: v for k, v in body["title_api"].items() if k != "key"}}
                if body["title_api"].get("key"):
                    ta["key"] = body["title_api"]["key"]
                cfg["title_api"] = ta
            persist_profile()
            return data_state()
        if method == "POST" and path == "/api/data/test":
            sid = body["id"]
            res = datasources.test(sid, STATE["data"])
            res["when"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
            STATE["data_tests"][sid] = res
            persist_profile()
            return res
        if method == "POST" and path == "/api/data/testall":
            res = datasources.test_all(STATE["data"])
            now = datetime.now(timezone.utc).isoformat(timespec="minutes")
            for sid, r in res.items():
                r["when"] = now
                STATE["data_tests"][sid] = r
            persist_profile()
            return {"results": res}
        if method == "POST" and path == "/api/data/layer_test":
            return datasources.layer_check(body["layer"], 51.5074, -0.1278)
        if method == "POST" and path == "/api/data/discover":
            d = datasources.discover_pdg(force=True)
            return data_state() | {"discovered": d.get("ok")}
        if method == "POST" and path == "/api/data/wms_layers":
            try:
                return {"layers": datasources.wms_layers(datasources.SRC_BY_ID[body["id"]]["wms"] if body.get("id") in datasources.SRC_BY_ID else body["url"])}
            except Exception as e:
                return {"error": f"Could not read the layer list: {e}"}, 502
        if method == "POST" and path == "/api/data/layer_layers":
            try:
                return {"layers": datasources.wms_layers(body["url"])}
            except Exception as e:
                return {"error": f"Could not read the layer list: {e}"}, 502
        if method == "POST" and path == "/api/data/enrich":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            try:
                pack = enrich_site(s)
            except ValueError as e:
                return {"error": str(e)}, 400
            persist_sites()
            return pack
        if method == "POST" and path == "/api/hmlr/load":
            kind = body.get("kind")
            try:
                if kind == "api":
                    if not STATE["data"].get("hmlr_key"):
                        return {"error": "Add your HM Land Registry API key first"}, 400
                    ok = hmlr.start_api_fetch(STATE["data"]["hmlr_key"], tuple(body.get("datasets") or ("ccod", "ocod")))
                    return {"started": ok}
                if kind == "path":
                    d, n = hmlr.load_path(body["path"], body.get("dataset"))
                else:
                    f = (body.get("files") or [None])[0]
                    if not f:
                        return {"error": "Choose a CCOD or OCOD file (CSV or ZIP)"}, 400
                    d, n = hmlr.load_bytes(base64.b64decode(f["data"]), f["name"], body.get("dataset"))
            except Exception as e:
                return {"error": str(e)}, 400
            return {"dataset": d, "rows": n, **hmlr.meta()}
        if method == "GET" and path == "/api/hmlr/status":
            return {**hmlr.meta(), "status": dict(hmlr.STATUS)}
        if method == "POST" and path == "/api/hmlr/search":
            q_, by = (body.get("q") or "").strip(), body.get("by") or "postcode"
            if not q_:
                return {"rows": []}
            if not hmlr.meta()["rows"]:
                return {"rows": [], "empty": True}
            fn = {"postcode": hmlr.by_postcode, "proprietor": hmlr.by_proprietor, "title": hmlr.by_title, "company": hmlr.by_company, "outward": hmlr.by_outward}.get(by, hmlr.by_postcode)
            return {"rows": fn(q_)[:300]}
        if method == "POST" and path == "/api/hmlr/portfolio":
            return {"rows": hmlr.portfolio_of(body.get("name", ""))}
        if method == "POST" and path == "/api/hmlr/company":
            if not STATE["data"].get("ch_key"):
                return {"error": "Add a Companies House API key in Data sources"}, 400
            try:
                return hmlr.company(body["no"], STATE["data"]["ch_key"])
            except Exception as e:
                return {"error": f"Companies House: {e}"}, 502
        if method == "POST" and path == "/api/hmlr/custom":
            try:
                return hmlr.custom_title_lookup(STATE["data"], body.get("title", ""), body.get("postcode", ""), body.get("address", ""))
            except Exception as e:
                return {"error": str(e)}, 502
        if method == "POST" and path == "/api/hmlr/oc1":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            text = body.get("text") or ""
            for name, data in _decode_files(body.get("files")):
                try:
                    text += "\n" + (hmlr.pdf_text(data) if name.lower().endswith(".pdf") else data.decode("utf-8", "ignore"))
                except Exception as e:
                    return {"error": f"Could not read {name}: {e}"}, 400
                docs.add(s, name, data, category="Title and legal") if name.lower().endswith(".pdf") and "Title and legal" in docs.CATS else None
            parsed = hmlr.parse_oc1(text)
            if not parsed["title"] and not parsed["proprietors"]:
                return {"error": "No title number or proprietor found. Is this an official copy of the register (OC1)? A scanned PDF has no text to read."}, 400
            res = hmlr.oc1_to_site(s, parsed)
            persist_sites()
            return {"parsed": parsed, **res}
        if method == "POST" and path == "/api/places/search":
            return places.search(body)
        if method == "GET" and path == "/api/places/info":
            return {"count": len(places.load()), "source": places.source(), "modes": places.MODES}
        if method == "POST" and path == "/api/places/import":
            try:
                return {"count": places.import_csv(body.get("text", ""))}
            except Exception as e:
                return {"error": str(e)}, 400
        if method == "POST" and path == "/api/places/reset":
            places.reset()
            return {"count": len(places.load())}
        if method == "POST" and path == "/api/places/route":
            try:
                return {"minutes": round(places.osrm_minutes(tuple(body["a"]), tuple(body["b"]), body.get("mode") or "drive"))}
            except Exception as e:
                return {"error": f"Routing service: {e}"}, 502
        if method == "GET" and path == "/api/searches":
            return {"items": STATE["searches"]}
        if method == "POST" and path == "/api/searches/save":
            it = {"id": body.get("id") or "sv-" + uuid.uuid4().hex[:6], "name": (body.get("name") or "Saved search")[:60], "kind": body.get("kind") or "area", "criteria": body.get("criteria") or {}, "saved": datetime.now(timezone.utc).isoformat(timespec="minutes")}
            STATE["searches"] = [x for x in STATE["searches"] if x["id"] != it["id"]] + [it]
            persist_profile()
            return {"items": STATE["searches"]}
        if method == "POST" and path == "/api/searches/delete":
            STATE["searches"] = [x for x in STATE["searches"] if x["id"] != body.get("id")]
            persist_profile()
            return {"items": STATE["searches"]}
        if method == "POST" and path == "/api/search/start":
            c = dict(body)
            if c.get("place"):
                g = resolve_place(c["place"])
                if not g:
                    return {"error": "Could not find that place. Use a full postcode or the name of a town or city on the list."}, 400
                c["lat"], c["lon"] = g
            if c.get("lat") is None or c.get("lon") is None:
                return {"error": "Give a postcode or click the map to set the centre"}, 400
            return {"started": areasearch.start(c, STATE["data"], hmlr.lookup_for_site), "lat": c["lat"], "lon": c["lon"]}
        if method == "POST" and path == "/api/search/geocode":
            g = resolve_place(body.get("place", ""))
            if not g:
                return {"error": "Could not find that place. Use a full postcode or the name of a town or city on the list."}, 400
            return {"lat": g[0], "lon": g[1]}
        if method == "GET" and path == "/api/search/status":
            j = areasearch.JOB
            return {"running": j["running"], "step": j["step"], "done": j["done"], "total": j["total"], "error": j["error"], "result": None if j["running"] else j["result"]}
        if method == "GET" and path == "/api/map/layers":
            return {"layers": [{"id": k, "label": v["label"], "colour": v["colour"]} for k, v in maplayers.LAYERS.items()]}
        if method == "POST" and path == "/api/map/layer":
            try:
                return maplayers.features(body.get("dataset", ""), [float(x) for x in body["bbox"]])
            except ValueError as e:
                return {"error": str(e)}, 400
            except Exception as e:
                return {"error": f"Layer unavailable: {str(e)[:100]}"}, 502
        if method == "POST" and path == "/api/site/boundary":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            ring = body.get("ring")
            if not ring:
                s.pop("boundary", None)
                persist_sites()
                return {"boundary": None}
            ring = [[float(x), float(y)] for x, y in ring]
            if len(ring) < 3:
                return {"error": "A boundary needs at least three points"}, 400
            if ring[0] == ring[-1]:
                ring = ring[:-1]
            lat0, lon0 = sum(p[1] for p in ring) / len(ring), sum(p[0] for p in ring) / len(ring)
            xy = geo_mod.ring_to_xy([tuple(p) for p in ring], lat0, lon0)
            m2 = geo_mod.area_m2(xy)
            if m2 < 50 or m2 > 5e7:
                return {"error": "That boundary is too small or too large to be a site"}, 400
            s["boundary"] = {"ring": ring, "area_ha": round(m2 / 1e4, 3), "drawn": date.today().isoformat()}
            s.pop("layout", None)
            if body.get("apply_area"):
                s["site_ha"] = s["boundary"]["area_ha"]
            if s.get("lat") is None or body.get("set_centre"):
                s["lat"], s["lon"] = round(lat0, 6), round(lon0, 6)
            persist_sites()
            return {"boundary": s["boundary"], "site_ha": s.get("site_ha")}
        if method == "POST" and path in ("/api/pack/get", "/api/pack/save"):
            s = site_by_id(body["id"])
            kind = body.get("kind")
            if not s or kind not in packs.KINDS:
                return {"error": "Site or pack not found"}, 404
            opts = packs.clean_opts(body.get("opts")) if "opts" in body else None
            if path.endswith("save"):
                s.setdefault("pack_opts", {})[kind] = opts or {"order": [], "off": []}
                persist_sites()
            try:
                return pack_state(s, kind, body.get("strategy"), opts)
            except ImportError as e:
                return {"error": f"This pack needs a package that is not installed: {e}"}, 400
        if method == "POST" and path == "/api/brand/save":
            STATE["brand"] = packs.brand_of(body)
            persist_profile()
            return {"brand": STATE["brand"]}
        if method == "POST" and path in ("/api/history/get", "/api/history/diff"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            hist = s.get("history") or []
            if path.endswith("get"):
                return {"timeline": history.timeline(s), "versions": [{"index": i, "t": h["t"], "label": h["label"], "profit": h["headline"].get("profit")} for i, h in enumerate(hist)]}

            def snap(ref):
                if ref == "now" or ref is None:
                    return {"t": history.now(), "label": "Now", "inputs": history.inputs_of(s), "headline": history.headline(evaluate(s))}
                i = int(ref)
                if not 0 <= i < len(hist):
                    raise ValueError("Version not found")
                return hist[i]
            try:
                a, b = snap(body.get("a") if body.get("a") is not None else max(0, len(hist) - 1)), snap(body.get("b", "now"))
            except (ValueError, TypeError) as e:
                return {"error": str(e)}, 400

            def profit_of(inp):
                st = {k: v for k, v in s.items() if k not in history.KEYS and k != "history"}
                st.update(deepcopy(inp))
                try:
                    return appraise(st, assumptions_for(st), st.get("strategy") or "develop_sell")["profit"]
                except Exception:
                    return None
            return history.diff(s, a, b, profit_of, {k: v[1] for k, v in ASSUMPTION_SPEC.items()})
        if method == "POST" and path in ("/api/strategy/get", "/api/strategy/apply"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            st = strategy_state(s)
            if path.endswith("apply"):
                if not st["timeline"]["total_months"]:
                    return {"error": "Consent is already in place, so there is no planning period to set"}, 400
                s["programme"] = programme.clean({**(s.get("programme") or {}), "planning_months": st["timeline"]["total_months"]})
                persist_sites()
                st = strategy_state(s)
                st["applied"] = True
            return st
        if method == "POST" and path in ("/api/programme/get", "/api/programme/save"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            if path.endswith("save"):
                if body.get("clear"):
                    s.pop("programme", None)
                else:
                    s["programme"] = programme.clean(body.get("programme")) or {}
                    if not s["programme"]:
                        s.pop("programme")
                persist_sites()
            return programme_state(s)
        if method == "POST" and path in ("/api/funding/get", "/api/funding/save"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            if path.endswith("save"):
                try:
                    ovr, extra = funding.clean(body.get("terms"))
                except (ValueError, TypeError) as e:
                    return {"error": str(e)}, 400
                s.setdefault("ovr", {}).update(ovr)
                s.setdefault("funding", {}).update(extra)
                persist_sites()
            return funding_state(s)
        if method == "POST" and path in ("/api/tax/get", "/api/tax/save"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            if path.endswith("save"):
                try:
                    s.setdefault("tax", {}).update(tax_mod.clean(body.get("tax")))
                except (ValueError, TypeError) as e:
                    return {"error": str(e)}, 400
                persist_sites()
            return tax_state(s)
        if method == "POST" and path in ("/api/levies/get", "/api/levies/find", "/api/levies/read", "/api/levies/apply", "/api/levies/clear"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            try:
                if path.endswith("/find"):
                    levies.find_and_read(s)
                elif path.endswith("/read"):
                    levies.read_source(s, (body.get("url") or "").strip(), body.get("label") or "")
                elif path.endswith("/apply"):
                    val = float(body["value"])
                    if body["key"] == "cil_psf":
                        val = val * (1 + float(body.get("index_pct") or 0) / 100)
                        m = levies.mayoral(s.get("la") or "") if body.get("mayoral") else None
                        if m:
                            val += m["rate_sqft"]
                        if body.get("relief"):
                            val *= 1 - float(assumptions_for(s).get("affordable_pct", 0))
                    levies.apply(s, body["key"], round(val, 4), {"source": body.get("source") or "", "note": body.get("note") or "", **({"mayoral": True} if body.get("mayoral") and levies.mayoral(s.get("la") or "") else {})})
                elif path.endswith("/clear"):
                    levies.clear(s, body["key"], STATE["assumptions"])
            except (ValueError, KeyError, TypeError) as e:
                return {"error": str(e) or "That figure could not be used"}, 400
            except Exception as e:
                return {"error": f"Could not read that: {e}"}, 502
            persist_sites()
            return levies_state(s)
        if method == "POST" and path in ("/api/costplan/get", "/api/costplan/read", "/api/costplan/save", "/api/costplan/apply", "/api/costplan/clear"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            try:
                if path.endswith("/read"):
                    keep = store.DATA / "costplans"
                    keep.mkdir(exist_ok=True)
                    fp = keep / (re.sub(r"[^A-Za-z0-9_-]", "_", s["id"])[:80] + ".bin")
                    if body.get("data"):
                        raw, fname = base64.b64decode(body["data"]), body.get("name") or "plan.xlsx"
                        if len(raw) <= 8_000_000:
                            fp.write_bytes(raw)
                    elif fp.exists() and (s.get("costplan") or {}).get("file"):
                        raw, fname = fp.read_bytes(), s["costplan"]["file"]
                    else:
                        return {"error": "Upload the file again to choose another sheet"}, 400
                    costplan.ingest(s, raw, fname, body.get("sheet"))
                elif path.endswith("/save"):
                    costplan.review(s, body.get("rows"), body.get("area_sqft"))
                elif path.endswith("/apply"):
                    costplan.review(s, body.get("rows"), body.get("area_sqft")) if body.get("rows") else None
                    costplan.apply(s, STATE["assumptions"])
                elif path.endswith("/clear"):
                    costplan.clear(s)
            except ImportError:
                return {"error": "Reading Excel needs the openpyxl package (pip3 install openpyxl). The DMG includes it."}, 500
            except (ValueError, KeyError) as e:
                return {"error": str(e)}, 400
            except Exception as e:
                return {"error": f"Could not read that file: {e}"}, 400
            persist_sites()
            return costplan_state(s)
        if method == "POST" and path in ("/api/sketch/get", "/api/sketch/save"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            if path.endswith("save"):
                sketch_mod.save(s, body.get("items"))
                persist_sites()
            return sketch_mod.state(s)
        if method == "POST" and path == "/api/listings/alerts":
            st = outlook.status()
            demo = bool(body.get("demo")) or not st["connected"]
            try:
                msgs = outlook.demo_alerts() if demo else outlook.list_alerts(int(body.get("days", 30)))
                cards, seen = [], set()
                for m in msgs[:25]:
                    html = outlook.demo_html(m["id"]) if demo else outlook.get_message_html(m["id"])
                    for c in listings.parse_alert(html):
                        key = f"{c['source']}-{c['id']}"
                        if key in seen:
                            continue
                        seen.add(key)
                        cards.append({**c, "known": site_by_id(key) is not None, "email": {"subject": m["subject"], "date": m["date"]}})
            except Exception as e:
                return {"error": str(e)}, 502
            return {"demo": demo, "messages": len(msgs), "cards": cards}
        if method == "POST" and path == "/api/listings/add":
            added, skipped = [], 0
            for c in (body.get("items") or [])[:30]:
                try:
                    site = listings.to_site(c)
                except (KeyError, TypeError):
                    continue
                if site_by_id(site["id"]):
                    skipped += 1
                    continue
                site["region"] = inv.region_of(site)
                if body.get("demo"):
                    site["demo"] = True
                STATE["sites"].append(site)
                added.append(site["id"])
            persist_sites()
            return {"added": added, "skipped": skipped}
        if method == "POST" and path == "/api/listings/paste":
            try:
                site = listings.from_paste((body.get("url") or "").strip(), body.get("text") or "")
            except ValueError as e:
                return {"error": str(e)}, 400
            if site_by_id(site["id"]):
                return {"error": "That listing is already on your list", "id": site["id"]}, 409
            site["region"] = inv.region_of(site)
            STATE["sites"].append(site)
            persist_sites()
            return {"id": site["id"], "missing": site.get("intake_missing", [])}
        if method == "POST" and path == "/api/onboard":
            if body.get("profile"):
                set_investor(body["profile"], True)
            if body.get("tax"):
                STATE["tax_default"] = {k: v for k, v in tax_mod.clean(body["tax"]).items() if k in ("structure", "personal_rate", "associated")}
            if body.get("brand"):
                STATE["brand"] = packs.brand_of(body["brand"])
            STATE["onboarded"] = True
            persist_profile()
            return {"ok": True}
        if method == "POST" and path in ("/api/layout/run", "/api/layout/get"):
            s = site_by_id(body["id"])
            if not s or s.get("lat") is None:
                return {"error": "Add a postcode so the site can be located"}, 400
            h = homes_state(s)
            if not h:
                return {"error": "Set up the homes schedule first"}, 400
            lay = s.get("layout")
            if path.endswith("run") or not lay:
                if path.endswith("get"):
                    return {"ok": False, "none": True}
                pk = policy.pack_for(h["typ"])
                lay = layout.run(s, h["typ"], h["calc"], pk, body.get("params"))
                if lay.get("ok"):
                    lay["sig"] = layout.signature(s, h["typ"])
                    lay["ran"] = date.today().isoformat()
                    s["layout"] = lay
                    persist_sites()
                else:
                    return lay
            colours = {u["id"]: floorplan.TYPE_COLOURS[i % len(floorplan.TYPE_COLOURS)] for i, u in enumerate(h["typ"]["units"])}
            # the saved layout names types by id; map by name if ids changed
            names = {u["name"]: c for u, c in zip(h["typ"]["units"], colours.values())}
            cm = {tid: names.get(v["name"], "#FF6600") for tid, v in lay["by_type"].items()}
            return {**{k: v for k, v in lay.items() if k != "shapes"}, "svg": layout.to_svg(lay, cm), "current": lay.get("sig") == layout.signature(s, h["typ"])}
        if method == "POST" and path == "/api/layout/apply":
            s = site_by_id(body["id"])
            lay = s.get("layout") if s else None
            if not lay or not lay.get("ok"):
                return {"error": "Run the layout test first"}, 400
            h = homes_state(s)
            typ = h["typ"]
            byname = {v["name"]: v["laid"] for v in lay["by_type"].values()}
            for u in typ["units"]:
                if u["family"] == "house" and u["name"] in byname:
                    u["count"] = byname[u["name"]]
            if body.get("parking"):
                typ["site"]["parking"] = lay["parking_plot"] + lay["parking_street"]
            typology.apply_to_site(s, typ)
            s["layout"]["sig"] = layout.signature(s, typology.normalise(s["typology"], s))
            persist_sites()
            return {"units": s.get("units"), **homes_payload(s)}
        if method == "POST" and path == "/api/recheck":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            if not watch.watched(s):
                return {"error": "Add the site to your shortlist first"}, 400
            (s.get("watch") or {}).setdefault("deep", {})
            evs = recheck.run(s, STATE["data"])
            persist_sites()
            return {"events": len(evs), "last": s["watch"]["deep"]["last"], "errors": s["watch"]["deep"]["errors"], "first": not evs and len(s.get("events", [])) > 0}
        if method == "POST" and path == "/api/assembly/get":
            s = site_by_id(body["id"])
            if not s or s.get("lat") is None:
                return {"error": "Add a postcode so the site can be located"}, 400
            if body.get("refresh") or not s.get("assembly"):
                s["assembly"] = assembly.build(s, STATE["data"], int(body.get("radius_m") or 250))
                persist_sites()
            return s["assembly"]
        if method == "POST" and path == "/api/assembly/add":
            s = site_by_id(body["id"])
            a = s.get("assembly") if s else None
            if not a:
                return {"error": "Build the land map first"}, 400
            n = assembly.to_parcels(s, a, body.get("refs") or [], body.get("owners") or {})
            persist_sites()
            return {"added": n, "parcels": s.get("parcels", [])}
        if method == "GET" and path == "/api/hmlr/changes":
            pcs = [p for s in STATE["sites"] if watch.watched(s) for p in recheck._postcodes(s)]
            return {"last": hmlr.last_diff(), "changes": hmlr.changes_for(pcs)}
        if method == "POST" and path == "/api/search/screen":
            res = areasearch.JOB.get("result") or {}
            cands = res.get("candidates") or []
            if not cands:
                return {"error": "Run a search first"}, 400
            strat = body.get("strategy") or "develop_sell"
            ok = screen.start(cands, strat, STATE["assumptions"], STATE["investor"], STATE["sites"], int(body.get("limit") or 25))
            return {"started": ok}
        if method == "GET" and path == "/api/search/screen/status":
            j = screen.JOB
            return {"running": j["running"], "done": j["done"], "total": j["total"], "error": j["error"], "results": j["results"]}
        if method == "POST" and path == "/api/search/mandate":
            p = STATE["investor"]
            if not p.get("active"):
                return {"error": "Switch on your investor profile first"}, 400
            return screen.mandate_criteria(p)
        if method == "POST" and path == "/api/search/add":
            res = areasearch.JOB.get("result") or {}
            byid = {c["id"]: c for c in res.get("candidates", [])}
            have = {s["id"] for s in STATE["sites"]}
            added = []
            for cid in body.get("ids", []):
                c = byid.get(cid)
                if c and cid not in have:
                    s = areasearch.to_site(c, body.get("strategy") or "develop_sell")
                    s["search_why"] = c.get("why", [])
                    STATE["sites"].append(s)
                    added.append(s["id"])
            persist_sites()
            return {"added": added}
        if method == "POST" and path == "/api/constraints":
            s = site_by_id(body["id"])
            if not s or s.get("lat") is None:
                return {"error": "Site needs coordinates: add a postcode"}, 400
            pack = enrich_site(s)
            persist_sites()
            return s["constraints_result"] | {"pack": pack}
        if method == "POST" and path == "/api/planning/analyse":
            s = site_by_id(body["id"])
            for name, data in _decode_files(body.get("files")):
                docs.add(s, name, data)
            if not s.get("docs"):
                return {"error": "Add documents to the vault first"}, 400
            text = docs.all_text(s, body.get("doc_ids") or None)
            res = plan.analyse(text, s, STATE["api_key"] or None, STATE["model"])
            res["analysed"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
            res["n_docs"] = len(body.get("doc_ids") or s["docs"])
            s["planning_analysis"] = res
            persist_sites()
            return res
        if method == "POST" and path == "/api/planning/get":
            s = site_by_id(body["id"])
            persist_sites()
            return planning_bundle(s)
        if method == "POST" and path == "/api/planning/apply":
            s = site_by_id(body["id"])
            res = s.get("planning_analysis")
            if not res:
                return {"error": "No analysis yet"}, 400
            plan.apply_to_site(s, res)
            ovr = dict(s.get("ovr") or {})
            cs = res.get("cost_signals") or {}
            if cs.get("affordable_pct"):
                v = float(cs["affordable_pct"])
                ovr["affordable_pct"] = v / 100 if v > 1 else v
            for k in ("s106_per_unit", "cil_psf"):
                if cs.get(k):
                    ovr[k] = float(cs[k])
            ps = res.get("programme_signals") or {}
            if ps.get("months_to_consent"):
                ovr["planning_months"] = float(ps["months_to_consent"])
            s["ovr"] = ovr
            persist_sites()
            return {"ok": True}
        if method == "POST" and path == "/api/ask":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            q = (body.get("q") or "").strip()
            if not q:
                return {"error": "Type a question"}, 400
            ev = evaluate(s)
            h = homes_state(s) if (s.get("typology") or s.get("unit_mix")) else None
            return ask_mod.answer(s, q, ev, h, lambda d: docs.text_of(s, d), STATE["api_key"] or None, STATE["model"], body.get("history"))
        if method == "POST" and path == "/api/planning/ask":
            if not STATE["api_key"]:
                return {"error": "Add an Anthropic API key in Settings to ask questions of the documents"}, 400
            s = site_by_id(body["id"])
            try:
                ans = plan.answer_question(docs.all_text(s), body["q"] + "\n\nCite documents as [doc:ID] using the id in each DOCUMENT header.", STATE["api_key"], STATE["model"], body.get("history"))
            except Exception as e:
                return {"error": str(e)}, 502
            return {"answer": ans}
        if method == "POST" and path == "/api/planning/entry":
            s = site_by_id(body["id"])
            lst = s.setdefault({"app": "planning_history", "consultee": "consultees", "key": "key_dates"}[body["kind"]], [])
            if body["op"] == "delete":
                if 0 <= body["index"] < len(lst):
                    lst.pop(body["index"])
            else:
                e = body["entry"]
                if body["kind"] == "app":
                    e["key_points"] = [x.strip() for x in str(e.get("key_points", "")).split("\n") if x.strip()] if isinstance(e.get("key_points"), str) else e.get("key_points", [])
                    e.setdefault("docs", [])
                if body.get("index") is None:
                    lst.append(e)
                else:
                    lst[body["index"]].update(e)
            watch.note_change(s, "activity", "Planning record updated", {"app": "Application", "consultee": "Consultee response", "key": "Key date"}[body["kind"]] + (" removed" if body["op"] == "delete" else " saved"), "info")
            persist_sites()
            return planning_bundle(s)
        if method == "POST" and path == "/api/docs/upload":
            s = site_by_id(body["id"])
            added = [docs.add(s, n, d, category=body.get("category") or None) for n, d in _decode_files(body.get("files"))]
            for r in added:
                watch.note_change(s, "activity", f"Document added: {r['name']}", r["category"])
            persist_sites()
            return {"added": added}
        if method == "POST" and path == "/api/docs/update":
            s = site_by_id(body["id"])
            for d in s.get("docs", []):
                if d["id"] == body["doc"]:
                    d.update({k: body[k] for k in ("category", "title", "date") if k in body})
            persist_sites()
            return {"ok": True}
        if method == "POST" and path == "/api/docs/save":
            s = site_by_id(body["id"])
            d = next(x for x in s["docs"] if x["id"] == body["doc"])
            out = Path(os.environ.get("MINERVA_DOWNLOADS") or (Path.home() / "Downloads"))
            out.mkdir(parents=True, exist_ok=True)
            p = out / d["name"]
            n = 1
            while p.exists():
                p = out / f"{Path(d['name']).stem}_{n}{Path(d['name']).suffix}"
                n += 1
            p.write_bytes(docs.path_of(s, d).read_bytes())
            if not os.environ.get("MINERVA_NO_OPEN"):
                import webbrowser
                webbrowser.open(p.as_uri())
            return {"path": str(p), "name": p.name}
        if method == "POST" and path == "/api/docs/delete":
            s = site_by_id(body["id"])
            docs.remove(s, body["doc"])
            persist_sites()
            return {"ok": True}
        if method == "POST" and path == "/api/investor":
            derived = set_investor(body.get("profile", {}), body.get("apply_finance", True))
            return {"ok": True, "derived": derived}
        if method == "POST" and path == "/api/site/contact":
            s = site_by_id(body["id"])
            contacts.enrich(s)
            persist_sites()
            return contact_of(s)
        if method == "POST" and path == "/api/site/enquiry":
            s = site_by_id(body["id"])
            s2 = {**s, "agent": contact_of(s)}
            return contacts.enquiry_draft(s2, STATE["investor"])
        if method == "POST" and path == "/api/deal/intake":
            files = _decode_files(body.get("files"))
            text, subject, sender, received = body.get("text", ""), body.get("subject", ""), body.get("sender", ""), body.get("received", "")
            if body.get("eml"):
                m = intake.parse_eml(base64.b64decode(body["eml"]))
                text, subject, sender, received = m["text"], m["subject"], m["from"], m["date"]
                files = list(files) + m["attachments"]
            if not (text.strip() or files):
                return {"error": "Paste some text or add a file"}, 400
            site = create_from_intake(text, subject, sender, files, body.get("source") or "Deal intake", received)
            return {"id": site["id"], "missing": site.get("intake_missing", []), "engine": site.get("intake_engine")}
        if method == "POST" and path == "/api/comps":
            s = site_by_id(body["id"])
            if s.get("demo_rich"):
                return {"demo": True, "sales": [], "summary": None, "evidence": s.get("comps", []), "message": "Illustrative deal: the evidence below is fictional. Real deals pull HM Land Registry sales."}
            res = comps_mod.fetch(s, int(body.get("months", 24)), STATE["epc"]["email"], STATE["epc"]["key"])
            if "error" not in res:
                s["land_registry"] = {k: res[k] for k in ("sector", "summary", "fetched", "epc_note")}
                res["months"] = int(body.get("months", 24))
                try:
                    compset.ingest(s, res)
                except Exception:
                    pass  # the map is a bonus; the sales list still works
                persist_sites()
            return res
        if method == "POST" and path in ("/api/compset/get", "/api/compset/save"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            if path.endswith("save") and s.get("comp_set"):
                cs = s["comp_set"]
                if "adj" in body:
                    cs["adj"] = {**(cs.get("adj") or {}), **compset.clean_adj(body["adj"])}
                if body.get("reset"):
                    cs["adj"], cs["off"] = {}, []
                if body.get("toggle"):
                    off = set(cs.get("off") or [])
                    off ^= {body["toggle"]}
                    cs["off"] = sorted(off)
                persist_sites()
            h = homes_state(s) if (s.get("typology") or s.get("unit_mix")) else None
            return compset.state(s, h["typ"] if h else None, h["calc"] if h else None)
        if method == "POST" and path == "/api/comps/apply":
            s = site_by_id(body["id"])
            s["sales_psf"] = float(body["psf"])
            persist_sites()
            return {"ok": True}
        if method == "POST" and path == "/api/epcfile/load":
            try:
                if body.get("path"):
                    return epcfile.load_path(body["path"])
                f = (body.get("files") or [None])[0]
                if not f:
                    return {"error": "Choose the certificates CSV or ZIP from the bulk download"}, 400
                return epcfile.load_bytes(base64.b64decode(f["data"]), f["name"])
            except Exception as e:
                return {"error": str(e)}, 400
        if method == "POST" and path == "/api/epcfile/clear":
            epcfile.clear()
            return epcfile.status()
        if method == "GET" and path == "/api/epcfile/status":
            return epcfile.status()
        if method == "POST" and path == "/api/ppdfile/load":
            try:
                if body.get("path"):
                    return ppdfile.load_path(body["path"])
                f = (body.get("files") or [None])[0]
                if not f:
                    return {"error": "Choose a Price Paid Data CSV file (a single year is usually enough)"}, 400
                return ppdfile.load_bytes(base64.b64decode(f["data"]), f["name"])
            except Exception as e:
                return {"error": str(e)}, 400
        if method == "POST" and path == "/api/ppdfile/clear":
            ppdfile.clear()
            return ppdfile.status()
        if method == "GET" and path == "/api/ppdfile/status":
            return ppdfile.status()
        if method == "POST" and path == "/api/settings/epc":
            STATE["epc"] = {"email": body.get("email", ""), "key": body.get("key") or STATE["epc"]["key"]}
            persist_profile()
            return {"ok": True}
        if method == "POST" and path == "/api/demo/restore":
            have = {x["id"] for x in STATE["sites"]}
            new = [d for d in store.rich_demo_deals() if d["id"] not in have]
            STATE["sites"] = new + STATE["sites"]
            persist_sites()
            return {"added": len(new)}
        # ---- Outlook
        if method == "POST" and path == "/api/outlook/configure":
            outlook.configure(body.get("client_id", ""), body.get("tenant", "common"))
            return outlook.status()
        if method == "POST" and path == "/api/outlook/connect":
            try:
                return outlook.start_device_flow()
            except Exception as e:
                return {"error": str(e)}, 400
        if method == "POST" and path == "/api/outlook/poll":
            try:
                return outlook.poll_device_flow()
            except Exception as e:
                return {"error": str(e)}, 502
        if method == "POST" and path == "/api/outlook/disconnect":
            outlook.disconnect()
            return outlook.status()
        if method == "POST" and path == "/api/outlook/list":
            st = outlook.status()
            if body.get("demo") or not st["connected"]:
                return {"demo": True, "messages": outlook.demo_list()}
            try:
                return {"demo": False, "messages": outlook.list_messages(int(body.get("days", 30)), 60, body.get("q", ""))}
            except Exception as e:
                return {"error": str(e)}, 502
        if method == "POST" and path == "/api/outlook/import":
            try:
                m = outlook.demo_get(body["mid"]) if body.get("demo") else outlook.get_message(body["mid"])
            except Exception as e:
                return {"error": str(e)}, 502
            site = create_from_intake(m["text"], m["subject"], m["from"], m["attachments"], "Outlook" if not body.get("demo") else "Outlook (demo mailbox)", m["date"])
            site["outlook_id"] = body["mid"]
            if body.get("demo"):
                site["demo"] = True
            persist_sites()
            return {"id": site["id"], "missing": site.get("intake_missing", [])}
        # ---- v0.4: shortlist and alerts
        if method == "POST" and path == "/api/site/watch":
            s = site_by_id(body["id"])
            if body.get("on", True):
                watch.start(s)
            else:
                watch.stop(s)
                watch.add_event(s, "shortlist", "Removed from shortlist", "", "info")
            persist_sites()
            return {"ok": True, "on": watch.watched(s)}
        if method == "POST" and path == "/api/watch/seen":
            for x in STATE["sites"]:
                if body.get("id") in (None, x["id"]):
                    for e in x.get("events", []):
                        e["seen"] = True
            persist_sites()
            return {"ok": True}
        if method == "POST" and path == "/api/alerts/settings":
            cur = STATE["alerts"]
            new = {k: body[k] for k in watch.DEFAULT_SETTINGS if k in body and k not in ("last_run", "last_sent", "last_error")}
            if not new.get("smtp_password"):
                new.pop("smtp_password", None)
            for k in ("interval_hours", "smtp_port"):
                if k in new:
                    try:
                        new[k] = float(new[k]) if k == "interval_hours" else int(new[k])
                    except (TypeError, ValueError):
                        new.pop(k)
            cur.update(new)
            persist_profile()
            return {"ok": True}
        if method == "POST" and path == "/api/alerts/test":
            try:
                watch.send_email(STATE["alerts"], "easyDevelopment: test email", "This is a test. Alerts on your shortlist will arrive at this address.",
                                 "<div style='font-family:Helvetica,Arial,sans-serif'><b>easyDevelopment</b><p>This is a test. Alerts on your shortlist will arrive at this address.</p></div>")
            except Exception as e:
                return {"error": f"Could not send: {e}"}, 400
            return {"ok": True}
        if method == "POST" and path == "/api/alerts/run":
            return {"started": run_checks_async()}
        if method == "GET" and path == "/api/alerts/status":
            return {"running": CHECKS["running"], "last": CHECKS["last"], "last_run": STATE["alerts"].get("last_run"), "last_sent": STATE["alerts"].get("last_sent"), "error": STATE["alerts"].get("last_error", "")}
        # ---- v0.4: structure (waterfall and lender)
        if method == "POST" and path == "/api/structure":
            s = site_by_id(body["id"])
            if "terms" in body or "covenants" in body:
                st = s.setdefault("structure", {})
                if "terms" in body:
                    st["terms"] = waterfall.clean_terms(body["terms"])
                if "covenants" in body:
                    st["covenants"] = {k: float(v) for k, v in body["covenants"].items() if k in waterfall.DEFAULT_COVENANTS and v not in (None, "")}
                if body.get("save"):
                    persist_sites()
            res = structure_of(s, body.get("strategy"))
            ap, _ = full_appraisal(s, body.get("strategy"))
            res["incomplete"] = ap.get("incomplete")
            res["peak_equity"] = ap["peak_equity"]
            return res
        # ---- v0.4: due diligence
        if method == "POST" and path == "/api/dd/get":
            s = site_by_id(body["id"])
            if not s.get("dd"):
                s["dd"] = dd.seed(s)
                persist_sites()
            return {"items": s["dd"], "summary": dd.summary(s["dd"])}
        if method == "POST" and path == "/api/dd/save":
            s = site_by_id(body["id"])
            before = {i["id"]: i["status"] for i in s.get("dd", [])}
            s["dd"] = dd.clean(body["items"])
            for i in s["dd"]:
                if before.get(i["id"]) not in (None, i["status"]) and i["status"] in ("Done", "Issue"):
                    watch.note_change(s, "activity", f"Diligence: {i['item']}", i["status"], "important" if i["status"] == "Issue" else "info")
            persist_sites()
            return {"items": s["dd"], "summary": dd.summary(s["dd"])}
        # ---- v0.4: cost benchmarks
        if method == "POST" and path == "/api/costs":
            s = site_by_id(body["id"]) if body.get("id") else None
            reg = body.get("region") or (inv.region_of(s) if s else None)
            return {"table": costs.table(reg), "pick": cost_pick(s, body.get("strategy")) if s else None, "footnote": costs.FOOTNOTE, "region": reg}
        # ---- v0.4: committee paper
        if method == "POST" and path == "/api/committee/save":
            s = site_by_id(body["id"])
            try:
                data = committee_bytes(s, body.get("strategy"))
            except ImportError:
                return {"error": "The committee paper needs the python-docx package (pip3 install python-docx). The DMG includes it."}, 500
            out = Path(os.environ.get("MINERVA_DOWNLOADS") or (Path.home() / "Downloads"))
            out.mkdir(parents=True, exist_ok=True)
            name = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "deal")).strip("_")[:40] + "_committee_paper.docx"
            p = out / name
            n = 1
            while p.exists():
                p = out / f"{name[:-5]}_v{n}.docx"
                n += 1
            p.write_bytes(data)
            if not os.environ.get("MINERVA_NO_OPEN"):
                import webbrowser
                webbrowser.open(p.as_uri())
            return {"path": str(p), "name": p.name}
        if method == "POST" and path == "/api/brief/save":
            s = site_by_id(body["id"])
            data = brief_bytes(s, body.get("strategy"))
            name = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "site")).strip("_")[:40] + "_site_brief.docx"
            return save_download(name, data)
        if method == "POST" and path == "/api/docx/save":
            s = site_by_id(body["id"])
            kind, strat = body.get("kind"), body.get("strategy")
            if not s or kind not in ("termsheet", "strategy"):
                return {"error": "Nothing to save"}, 400
            if kind == "termsheet":
                data, suffix = funding.termsheet(site_pack(s, strat), funding_state(s, strat)), "finance_request"
            else:
                data, suffix = strategy_mod.docx({"site": s}, strategy_state(s)), "planning_strategy"
            return save_download(re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "site")).strip("_")[:40] + f"_{suffix}.docx", data)
        # ---- v0.6: typology, floorplans, policy checks
        if method == "POST" and path == "/api/track/get":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            tr = s.get("track")
            stale = not tr or (date.today() - date.fromisoformat(tr.get("fetched", "2000-01-01"))).days > 30
            if s.get("lat") is None:
                return {"error": "Add a postcode so the site can be located"}, 400
            if body.get("refresh") or stale:
                try:
                    tr = track.fetch(s, STATE["data"], years=5, radius_km=float(body.get("radius_km") or 8))
                except Exception as e:
                    return {"error": f"Could not read PlanIt: {e}"}, 502
                if tr.get("ok"):
                    s["track"] = tr
                    persist_sites()
            return tr or {"ok": False, "error": "No record"}
        if method == "POST" and path == "/api/suggest/get":
            s = site_by_id(body["id"])
            return suggest_state(s) if s else ({"error": "Site not found"}, 404)
        if method == "POST" and path in ("/api/suggest/apply", "/api/suggest/revert"):
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            base = {**STATE["assumptions"]}
            if path.endswith("apply"):
                it = next((x for x in suggest.rules(s, s.get("data_pack") or {}, s.get("track"), assumptions_for(s)) if x["id"] == body["rule"]), None)
                if not it:
                    return {"error": "That suggestion no longer applies"}, 400
                suggest.apply(s, it, base)
            else:
                suggest.revert(s, body["rule"], base)
            persist_sites()
            return suggest_state(s)
        if method == "POST" and path == "/api/homes/market":
            s = site_by_id(body["id"])
            return market_state(s, float(body.get("premium") or 0)) if s else ({"error": "Site not found"}, 404)
        if method == "POST" and path == "/api/homes/market/apply":
            s = site_by_id(body["id"])
            if not s:
                return {"error": "Site not found"}, 404
            h = homes_state(s)
            if not h:
                return {"error": "Set up the homes schedule first"}, 400
            st = market_state(s, float(body.get("premium") or 0), h)
            typ = h["typ"]
            prices = [{"id": u["id"], "sale_value": u["sale_value"]} for u in st["units"] if u.get("sale_value")]
            rates = [{"id": u["id"], "build_psf": u["build_psf"]} for u in st["units"] if u.get("build_psf")]
            n = marketmix.apply(typ, prices, rates, body.get("what") or "both", bool(body.get("overwrite")))
            typology.apply_to_site(s, typ)
            persist_sites()
            return {"changed": n, **homes_payload(s)}
        if method == "POST" and path == "/api/typology/get":
            return homes_payload(site_by_id(body["id"]), body.get("typology"))
        if method == "POST" and path == "/api/typology/preset":
            s = site_by_id(body["id"])
            typ = typology.default_typology(s, body.get("preset"), int(body.get("units") or 0) or None)
            return homes_payload(s, typ)
        if method == "POST" and path == "/api/typology/unit":
            s = site_by_id(body["id"])
            u = typology.new_unit(body["key"], int(body.get("count") or 1))
            return {"unit": u}
        if method == "POST" and path == "/api/typology/plan":
            s = site_by_id(body["id"])
            r = plan_svg(s, body.get("typology"), body.get("unit"), body.get("kind", "unit"))
            return {"thumbs": r} if isinstance(r, dict) else {"svg": r}
        if method == "POST" and path == "/api/typology/save":
            s = site_by_id(body["id"])
            calc = typology.apply_to_site(s, body["typology"])
            watch.note_change(s, "activity", "Homes schedule saved", f"{calc['units']} homes, {calc['gross_sqft']:,.0f} sq ft gross", "info") if watch.watched(s) else None
            persist_sites()
            return homes_payload(s)
        if method == "POST" and path == "/api/typology/reset":
            s = site_by_id(body["id"])
            s.pop("typology", None)
            persist_sites()
            return homes_payload(s)
        # ---- v0.5: scenarios, replies, feed, news, saved views, exports
        if method == "POST" and path == "/api/scenarios":
            s = site_by_id(body["id"])
            strat = body.get("strategy") or s.get("strategy") or "develop_sell"
            if "scenarios" in body:
                lst = scenarios.clean(body["scenarios"])
                if body.get("save"):
                    s["scenarios"] = lst
                    persist_sites()
                return scenarios_of(s, strat, only=lst)
            return scenarios_of(s, strat)
        if method == "POST" and path == "/api/replies":
            s = site_by_id(body["id"])
            op = body.get("op", "draft")
            if op == "list":
                return {"items": s.get("replies", [])[::-1], "kinds": replies.KINDS}
            if op == "save":
                r = {k: body["reply"].get(k) for k in ("kind", "subject", "body", "incoming", "topics", "ref")}
                r.update(id=uuid.uuid4().hex[:8], saved=datetime.now(timezone.utc).isoformat(timespec="minutes"))
                s.setdefault("replies", []).append(r)
                del s["replies"][:-40]
                watch.note_change(s, "activity", "Reply drafted", r.get("subject") or "", "info")
                persist_sites()
                return {"ok": True, "id": r["id"]}
            if op == "delete":
                s["replies"] = [x for x in s.get("replies", []) if x.get("id") != body.get("rid")]
                persist_sites()
                return {"ok": True}
            text = str(body.get("text") or "").strip()
            if not text and body.get("kind") != "s106":
                return {"error": "Paste the message you are replying to"}, 400
            h = homes_state(s) if homes_basis(s) else None
            d = replies.draft(body.get("kind", "officer"), text, s, STATE["investor"], body.get("tone", "measured"), body.get("topics") or [], STATE["api_key"] or None, STATE["model"], scheme=(h or {}).get("facts"))
            d["deadline"] = replies.deadline_flag(text)
            return d
        if method == "GET" and path == "/api/feed":
            items = feed.notifications(STATE["sites"], STATE["portfolio"], set(STATE["notif_seen"]))
            return {"items": items[:60], "unseen": sum(1 for i in items if not i["seen"])}
        if method == "POST" and path == "/api/feed/seen":
            ids = set(body.get("ids") or [])
            items = feed.notifications(STATE["sites"], STATE["portfolio"], set(STATE["notif_seen"]))
            for i in items:
                if body.get("all") or i["id"] in ids:
                    if i["id"].startswith("ev:"):
                        for x in STATE["sites"]:
                            for e in x.get("events", []):
                                if "ev:" + e["id"] == i["id"]:
                                    e["seen"] = True
                    elif i["id"] not in STATE["notif_seen"]:
                        STATE["notif_seen"].append(i["id"])
            del STATE["notif_seen"][:-600]
            persist_sites()
            persist_profile()
            return {"ok": True}
        if method == "GET" and path == "/api/news":
            targets = news_targets()
            stale = any(time.time() - NEWS["ts"].get(t["id"], 0) > 12 * 3600 for t in targets)
            if stale and not q.get("nofetch"):
                refresh_news_async()
            return {"items": feed.merge(STATE["sites"], NEWS["items"]), "refreshing": NEWS["running"], "last": NEWS["last"], "live_sites": len(targets)}
        if method == "POST" and path == "/api/news/refresh":
            return {"started": refresh_news_async(force=True)}
        if method == "POST" and path == "/api/views":
            if body.get("op") == "delete":
                STATE["views"] = [v for v in STATE["views"] if v.get("id") != body.get("vid")]
            else:
                v = body["view"]
                v = {"id": v.get("id") or uuid.uuid4().hex[:6], "name": str(v.get("name") or "Saved view").strip()[:40], "filters": v.get("filters") or {}}
                STATE["views"] = [x for x in STATE["views"] if x.get("id") != v["id"]] + [v]
            STATE["views"] = STATE["views"][-20:]
            persist_profile()
            return {"views": STATE["views"]}
        if method == "POST" and path == "/api/deck/save":
            s = site_by_id(body["id"])
            try:
                data = deck_bytes(s, body.get("strategy"))
            except ImportError:
                return {"error": "The investor deck needs the python-pptx package (pip3 install python-pptx). The DMG includes it."}, 500
            return save_download(re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "deal")).strip("_")[:40] + "_investor_deck.pptx", data)
        # ---- v0.4: portfolio and organisation
        if method == "GET" and path == "/api/portfolio":
            pipe = []
            for x in STATE["sites"]:
                if x.get("stage") in ("Offer", "Acquired") and not x.get("demo"):
                    a = evaluate(x)["appraisal"]
                    if a and not a.get("incomplete"):
                        pipe.append({"id": x["id"], "name": x["name"], "stage": x["stage"], "peak_equity": a["peak_equity"], "total_cost": a["total_cost"], "gdv": a["gdv"]})
            return {"schemes": STATE["portfolio"], "org": STATE["org"], "summary": portfolio.summary(STATE["portfolio"], STATE["investor"], pipe, STATE["org"]), "pipeline": pipe,
                    "statuses": portfolio.STATUSES, "strategies": portfolio.STRATS}
        if method == "POST" and path == "/api/portfolio/save":
            d = portfolio.clean_scheme(body["scheme"])
            d["region"] = d["region"] or inv.region_of({"postcode": d["location"], "address": d["location"], "name": d["name"]}) or ""
            g = scrapers.geocode_text(d["location"]) if d["location"] and not body["scheme"].get("lat") else None
            if body["scheme"].get("lat") is not None:
                d["lat"], d["lon"] = body["scheme"]["lat"], body["scheme"]["lon"]
            elif g:
                d["lat"], d["lon"] = g[0], g[1]
            for i, x in enumerate(STATE["portfolio"]):
                if x["id"] == d["id"]:
                    d.setdefault("lat", x.get("lat"))
                    d.setdefault("lon", x.get("lon"))
                    STATE["portfolio"][i] = d
                    break
            else:
                STATE["portfolio"].append(d)
            persist_profile()
            return {"ok": True, "id": d["id"]}
        if method == "POST" and path == "/api/portfolio/delete":
            STATE["portfolio"] = [x for x in STATE["portfolio"] if x["id"] != body["id"]]
            persist_profile()
            return {"ok": True}
        if method == "POST" and path == "/api/portfolio/import":
            try:
                data = base64.b64decode(body["data"])
                res = portfolio.interpret(data, STATE["api_key"] or None, STATE["model"])
            except ImportError:
                return {"error": "Reading Excel needs the openpyxl package (pip3 install openpyxl). The DMG includes it."}, 500
            except Exception as e:
                return {"error": f"Could not read that workbook: {e}"}, 400
            res["file"] = body.get("name", "")
            return res
        if method == "POST" and path == "/api/portfolio/commit":
            added = updated = 0
            by_name = {x["name"].strip().lower(): i for i, x in enumerate(STATE["portfolio"])}
            for raw in body.get("schemes") or []:
                d = portfolio.clean_scheme({**raw, "id": None})
                d["region"] = d["region"] or inv.region_of({"postcode": d["location"], "address": d["location"], "name": d["name"]}) or ""
                key = d["name"].strip().lower()
                if not key:
                    continue
                if key in by_name:
                    d["id"] = STATE["portfolio"][by_name[key]]["id"]
                    STATE["portfolio"][by_name[key]] = {**STATE["portfolio"][by_name[key]], **{k: v for k, v in d.items() if v not in (None, "")}}
                    updated += 1
                else:
                    STATE["portfolio"].append(d)
                    by_name[key] = len(STATE["portfolio"]) - 1
                    added += 1
            org = STATE["org"]
            if body.get("balance_sheet"):
                org["balance_sheet"] = {k: v for k, v in body["balance_sheet"].items() if v not in (None, "")}
            if body.get("cashflow"):
                org["cashflow"] = body["cashflow"]
            org["imported"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
            org["file"] = body.get("file", "")
            persist_profile()
            return {"added": added, "updated": updated}
        if method == "POST" and path == "/api/org/clear":
            STATE["org"] = {}
            persist_profile()
            return {"ok": True}
        # ---- v0.4: comparable schemes
        if method == "POST" and path == "/api/schemes/map":
            s = site_by_id(body["id"])
            radius = float(body.get("radius", 3))
            sales, apps, notes = None, [], []
            geo = {}
            if body.get("fetch") and not s.get("demo_rich") and s.get("postcode"):
                r = comps_mod.fetch(s, int(body.get("months", 24)), STATE["epc"]["email"], STATE["epc"]["key"])
                if "error" in r:
                    notes.append(r["error"])
                else:
                    sales = r["sales"]
                    geo = schemes.geocode_postcodes([x["postcode"] for x in sales if x.get("new_build")])
                if s.get("lat") is not None:
                    try:
                        apps = schemes.nearby_applications(s["lat"], s["lon"], min(radius, 3))
                        if not apps:
                            notes.append("No applications came back from planning.data.gov.uk. Not every council publishes there.")
                    except Exception as e:
                        notes.append(f"Planning data request failed: {str(e)[:100]}")
            if body.get("fetch") and not s.get("demo_rich"):
                s["scheme_ext"] = ((schemes.built_from_sales(sales, geo) if sales else []) + apps)[:200]
            ext = s.get("scheme_ext", [])
            manual = [m for m in s.get("scheme_comps", [])]
            own = [x for x in STATE["portfolio"] if x.get("lat") is not None]
            res = schemes.assemble(s, None, {}, manual, STATE["sites"], own, ext, radius)
            res["notes"] = notes
            res["fetched"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
            s["scheme_map"] = {"items": res["items"][:40], "summary": res["summary"], "fetched": res["fetched"]}
            persist_sites()
            return res
        if method == "POST" and path == "/api/schemes/save":
            s = site_by_id(body["id"])
            d = body["scheme"]
            geo = {}
            if d.get("postcode") and d.get("lat") in (None, ""):
                g = scrapers.geocode_text(d["postcode"])
                if g:
                    geo = {str(d["postcode"]).strip().upper(): (g[0], g[1])}
            m = schemes.clean_manual(d, geo)
            lst = s.setdefault("scheme_comps", [])
            for i, x in enumerate(lst):
                if x["id"] == m["id"]:
                    lst[i] = m
                    break
            else:
                lst.append(m)
            persist_sites()
            return {"ok": True, "scheme": m}
        if method == "POST" and path == "/api/schemes/delete":
            s = site_by_id(body["id"])
            s["scheme_comps"] = [x for x in s.get("scheme_comps", []) if x["id"] != body["scheme_id"]]
            persist_sites()
            return {"ok": True}
        # ---- v0.4: land assembly
        if method == "POST" and path == "/api/land/save":
            s = site_by_id(body["id"])
            s["parcels"] = [land.clean_parcel(p) for p in body["parcels"]]
            persist_sites()
            return {"parcels": s["parcels"], "summary": land.summary(s)}
        if method == "POST" and path == "/api/land/get":
            s = site_by_id(body["id"])
            return {"parcels": s.get("parcels", []), "summary": land.summary(s)}
        if method == "POST" and path == "/api/land/letter":
            s = site_by_id(body["id"])
            p = next(x for x in s.get("parcels", []) if x["id"] == body["parcel_id"])
            return land.letter(s, p, STATE["investor"])
        if method == "GET" and path == "/api/land/all":
            rows = []
            for x in STATE["sites"]:
                for p in x.get("parcels", []):
                    rows.append({**p, "site_id": x["id"], "site_name": x["name"]})
            return {"parcels": rows}
    return {"error": "not found"}, 404


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, data: bytes, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _authed(self) -> bool:
        if not PASSWORD:
            return True
        from http.cookies import SimpleCookie
        c = SimpleCookie(self.headers.get("Cookie") or "")
        return COOKIE in c and _valid(c[COOKIE].value)

    def _login(self, u, method):
        import hmac
        import time
        from urllib.parse import parse_qs as pq
        ip = (self.headers.get("X-Forwarded-For") or self.client_address[0]).split(",")[0].strip()
        if method == "GET":
            return self._send(200, LOGIN_HTML.replace("__ERR__", "").encode(), "text/html; charset=utf-8")
        n = int(self.headers.get("Content-Length") or 0)
        pw = (pq(self.rfile.read(n).decode()).get("password") or [""])[0]
        recent = [t for t in _fails.get(ip, []) if t > time.time() - 600]
        if len(recent) >= 8:
            return self._send(429, LOGIN_HTML.replace("__ERR__", '<div class="e">Too many attempts. Try again in a few minutes.</div>').encode(), "text/html; charset=utf-8")
        if hmac.compare_digest(pw.encode(), PASSWORD.encode()):
            tok = _sign(int(time.time()) + 30 * 86400)
            secure = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
            self.send_response(303)
            self.send_header("Set-Cookie", f"{COOKIE}={tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age={30 * 86400}{secure}")
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        _fails[ip] = recent + [time.time()]
        time.sleep(1)
        return self._send(401, LOGIN_HTML.replace("__ERR__", '<div class="e">Incorrect password.</div>').encode(), "text/html; charset=utf-8")

    def _handle(self, method):
        u = urlparse(self.path)
        if u.path == "/healthz":
            return self._send(200, b"ok", "text/plain")
        if u.path == "/login":
            return self._login(u, method)
        if u.path == "/logout":
            self.send_response(303)
            self.send_header("Set-Cookie", f"{COOKIE}=; Path=/; Max-Age=0")
            self.send_header("Location", "/login")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if not self._authed():
            if u.path.startswith("/api/"):
                return self._send(401, b'{"error":"Signed out. Reload the page to sign in."}')
            self.send_response(303)
            self.send_header("Location", "/login")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if u.path.startswith("/api/"):
            body = {}
            if method == "POST":
                n = int(self.headers.get("Content-Length") or 0)
                if n:
                    try:
                        body = json.loads(self.rfile.read(n))
                    except Exception:
                        return self._send(400, b'{"error":"bad json"}')
            try:
                res = api(method, u.path, parse_qs(u.query), body)
            except ValueError as e:
                res = ({"error": str(e) or "That value could not be used"}, 400)
            except KeyError as e:
                res = ({"error": f"The request is missing {e}. Reload the page and try again."}, 400)
            except (AttributeError, TypeError) as e:
                if "NoneType" in str(e):
                    res = ({"error": "That site or record was not found. It may have been deleted. Reload the page."}, 404)
                else:
                    res = ({"error": f"{type(e).__name__}: {e}"}, 500)
            except Exception as e:
                res = ({"error": f"{type(e).__name__}: {e}"}, 500)
            code = 200
            if isinstance(res, tuple):
                res, code = res
            return self._send(code, json.dumps(res, default=str).encode())
        if u.path.startswith("/docs/"):
            try:
                _, _, sid, did = u.path.split("/", 3)
                s = site_by_id(sid)
                d = next(x for x in s["docs"] if x["id"] == did.split("/")[0])
                p = docs.path_of(s, d)
                ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
                if p.suffix.lower() in (".eml", ".txt", ".md"):
                    ctype = "text/plain; charset=utf-8"
                self.send_response(200)
                data = p.read_bytes()
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Disposition", f'{"attachment" if "dl=1" in u.query else "inline"}; filename="{p.name}"')
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception:
                return self._send(404, b"Document not found", "text/plain")
        if u.path.startswith("/download/strategy/"):
            try:
                sid = u.path.rsplit("/", 1)[1].removesuffix(".docx")
                with LOCK:
                    s = site_by_id(sid)
                    data = strategy_mod.docx({"site": s}, strategy_state(s))
                fn = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "site"))[:40] + "_planning_strategy.docx"
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._send(500, f"Could not build the strategy: {e}".encode(), "text/plain")
        if u.path.startswith("/download/termsheet/"):
            try:
                sid = u.path.rsplit("/", 1)[1].removesuffix(".docx")
                with LOCK:
                    s = site_by_id(sid)
                    strat = (parse_qs(u.query).get("strategy") or [None])[0]
                    data = funding.termsheet(site_pack(s, strat), funding_state(s, strat))
                fn = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "site"))[:40] + "_finance_request.docx"
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._send(500, f"Could not build the finance request: {e}".encode(), "text/plain")
        if u.path.startswith("/download/brief/"):
            try:
                sid = u.path.rsplit("/", 1)[1].removesuffix(".docx")
                with LOCK:
                    s = site_by_id(sid)
                    data = brief_bytes(s, (parse_qs(u.query).get("strategy") or [None])[0])
                fn = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "site"))[:40] + "_site_brief.docx"
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._send(500, f"Could not build the brief: {e}".encode(), "text/plain")
        if u.path.startswith("/download/committee/"):
            try:
                sid = u.path.rsplit("/", 1)[1].removesuffix(".docx")
                with LOCK:
                    s = site_by_id(sid)
                    data = committee_bytes(s, (parse_qs(u.query).get("strategy") or [None])[0])
                fn = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "deal"))[:40] + "_committee_paper.docx"
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._send(500, f"Could not build the committee paper: {e}".encode(), "text/plain")
        if u.path.startswith("/download/deck/"):
            try:
                sid = u.path.rsplit("/", 1)[1].removesuffix(".pptx")
                with LOCK:
                    s = site_by_id(sid)
                    data = deck_bytes(s, (parse_qs(u.query).get("strategy") or [None])[0])
                fn = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "deal"))[:40] + "_investor_deck.pptx"
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.presentationml.presentation")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._send(500, f"Could not build the deck: {e}".encode(), "text/plain")
        if u.path.startswith("/report/"):
            try:
                sid = u.path.rsplit("/", 1)[1]
                with LOCK:
                    s = site_by_id(sid)
                    html_ = report_html(s, (parse_qs(u.query).get("strategy") or [None])[0])
                return self._send(200, html_.encode(), "text/html; charset=utf-8")
            except Exception as e:
                return self._send(500, f"Could not build the report: {e}".encode(), "text/plain")
        if u.path.startswith("/download/model/"):
            try:
                sid = u.path.rsplit("/", 1)[1].removesuffix(".xlsx")
                with LOCK:
                    s = site_by_id(sid)
                    data = model_bytes(s, (parse_qs(u.query).get("strategy") or [None])[0])
                fn = re.sub(r"[^A-Za-z0-9]+", "_", s.get("name", "deal"))[:40] + "_model.xlsx"
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                return self._send(500, f"Could not build the model: {e}".encode(), "text/plain")
        rel = u.path.lstrip("/") or "index.html"
        f = (UI / rel).resolve()
        if not str(f).startswith(str(UI.resolve())) or not f.is_file():
            f = UI / "index.html"
        ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
        self._send(200, f.read_bytes(), ctype + ("; charset=utf-8" if ctype.startswith("text") or "javascript" in ctype else ""))

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")


def make_server(port: int = 0, host: str = "127.0.0.1") -> ThreadingHTTPServer:
    return ThreadingHTTPServer((host, port), Handler)
