# Which functions need an API, a key or an account

Last checked against the code for version 0.9, including an overnight hardening pass. "Verified" means I read a real response from that service during development. My working environment has no direct internet access, so anything not marked verified has been tested against fixtures only. One service, HM Land Registry's sold-price endpoint, was reachable through a separate web-fetch tool during the overnight pass and is marked "tested live" below; that access was not available for the other services in this list, which remain untested against a live response.

## Needs a key or account you must obtain

| Function | What it needs | Without it | Notes |
|---|---|---|---|
| Reading emails, listing alerts, deal emails | Microsoft Entra app (client id) for Outlook via Microsoft Graph, signed in by device code | Demo mailbox with fictional emails | Free to register. Not run against a live mailbox. |
| Ask, planning document analysis, reply drafting, intake from emails, portfolio interpretation | Anthropic API key (Settings, or the ANTHROPIC_API_KEY environment variable) | Rule-based fallbacks for intake and portfolio. Ask, reply drafts and document analysis give a reduced result. | Paid per use. |
| Owner lookup by company (Companies House) | Companies House API key | Link to the public register only | Free. |
| Company ownership index (CCOD and OCOD) | HM Land Registry Use land and property data licence and key | Feature off | Free with registration. Large files. |
| Energy Performance Certificates in comparables | The old EPC API (epc.opendatacommunities.org) was retired in May 2026. Download a council's certificates file from get-energy-performance-data.communities.gov.uk and load it in Settings. The new service also has a developer API, but I could not read its specification, so the app does not call it. | Comparables without £ per sq ft | Free. File import is built and tested on files in the old column layout and common variants. |
| Paid title provider | Your own provider, URL, header and key | Feature off | Per your contract. |
| Vector map tiles in the browser | Protomaps key (PROTOMAPS_KEY) | Falls back to plain tiles or the schematic map | Free tier available. |

## No key, but needs internet access from the server

| Function | Service | Status |
|---|---|---|
| Postcode to coordinates, council, ward | postcodes.io | Verified (response fields match) |
| Council CIL charging schedules | planning.data.gov.uk dataset files (community-infrastructure-levy-schedule) | Verified (dataset name and columns) |
| Planning constraints, brownfield register, conservation areas | planning.data.gov.uk | Dataset names not all re-verified |
| Nearby planning applications, track record, planning news, area search | PlanIt | See the robots note below. Not verified live |
| Comparable sold prices, new build clusters | HM Land Registry Price Paid Data (SPARQL) | Tested live: the endpoint answers vocabulary queries but returned HTTP 400 on every real query tried (pricePaid, postcode; a plain scan, a FILTER and a VALUES-pinned exact postcode all failed the same way, so this is not one bad query, the whole dataset seems unreachable this way). Comparables fall back to it only if no Price Paid Data file is loaded (see below), and it is expected to keep failing. |
| Comparable sold prices, no key needed either way | HM Land Registry Price Paid Data, bulk CSV file | Verified reachable (a yearly file is a few hundred MB at most). Download a year from the [yearly file page](https://www.gov.uk/government/statistical-data-sets/price-paid-data-yearly-file) and load it in Settings; comparables use it first, ahead of the SPARQL endpoint above. |
| House price index | HM Land Registry UKHPI | Not verified live |
| Flood warnings | Environment Agency flood monitoring | Not verified live |
| Census and labour market | Nomis | Not verified live |
| Amenities, transport nodes | OpenStreetMap Overpass, NaPTAN | Not verified live |
| Drive times | OSRM public server | Not verified live. The public server has fair use limits |
| Map images in reports | CARTO basemap tiles (fallback to a grid if blocked) | Not verified live |
| Reading a council document or policy page | Any public URL you give, PDF or page, respecting robots.txt | Fixtures only |
| Agent listings pages | Agents' own sites, respecting robots.txt | Fixtures only |

## Cannot be done by API (and how it is handled)

| Function | Why | Handling |
|---|---|---|
| Rightmove and Zoopla listings | No public feed. Their terms forbid scraping. | Saved-search alert emails read through Outlook, or a pasted link with copied text. |
| Title register and official copies | Paid, per-document | Upload OC1, or use a paid provider account. |
| Business rates, broadband, electricity network capacity | No open lookup | Deep links to the official checkers. |

## Note on PlanIt
PlanIt's robots.txt disallows /api/applics/ for general crawlers. The API is documented for programmatic use, and the app identifies itself with a user agent that can carry your contact address (Data sources, "PlanIt contact"). Set that. If PlanIt objects, the fallback is the planning.data.gov.uk planning application datasets, which cover fewer councils.
