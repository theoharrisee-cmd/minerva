# Putting easyDevelopment on the web

This gives you a private web address (for example https://easydevelopment-yourname.onrender.com) that works in any browser, protected by a password you choose. No Terminal is needed. It uses Render, which builds the app from a GitHub folder.

## 1. Put the files on GitHub (5 minutes)

1. Create a free account at github.com and press **New repository**. Name it `minerva`, set it to **Private**, and press Create.
2. On the empty repository page, choose **uploading an existing file**.
3. Unzip `minerva-v0.5-web.zip`, open the `minerva` folder, select everything inside it and drag it onto the GitHub page. Press **Commit changes**.

## 2. Deploy on Render (5 minutes)

1. Create an account at render.com and sign in with GitHub.
2. Press **New**, then **Blueprint**, and choose your `minerva` repository. Render reads `render.yaml` and fills in everything.
3. When asked for **MINERVA_PASSWORD**, type the password you want to sign in with. Use something long. Anyone with the address and the password can see your deals.
4. Press **Apply**. The first build takes a few minutes. When it says Live, open the address shown at the top of the service page and sign in.

The blueprint uses Render's paid Starter plan with a 1 GB disk. Check the current price on Render's pricing page. The disk is what keeps your sites, documents, mandate, API keys and Outlook connection when the service restarts.

## Free option, with a catch

On Render's free plan there is no disk, so everything you add is lost whenever the service restarts or sleeps, and it sleeps after about 15 minutes idle. That is fine for a demo, since the illustrative deals reload each time, but not for real deals. To use it: press **New**, then **Web Service**, choose the repository, set **Runtime** to Docker, add the environment variable `MINERVA_PASSWORD`, and pick the Free instance type.

## After it is live

* **Claude key.** Add it in Settings, or set `ANTHROPIC_API_KEY` in Render's Environment tab.
* **Outlook.** Works the same as on the Mac. In Inbox, paste your Azure client ID and sign in with the code shown.
* **Map.** For the Protomaps vector map, add an environment variable `PROTOMAPS_KEY` in Render with your key and redeploy. The browser loads the MapLibre library from cdn.jsdelivr.net, so the page needs internet access. Restrict the key to your Render address in the Protomaps dashboard, since browsers can see it. Without a key the app uses the standard tile map.
* **Sign out.** Bottom left of the app.
* **Updating.** Upload new files to GitHub and Render redeploys itself. If you deploy from `Dockerfile` and `app.zip`, replace both files and choose Manual Deploy, then Clear build cache and deploy.
* **Email alerts.** Add your SMTP details on the Shortlist page. Checks only run while the service is awake.
* **Listing refreshes.** Agent websites are more likely to block a cloud server than your own computer. If a source shows Blocked, the bundled snapshot listings are shown instead.
* **Password wall.** The app refuses to start without `MINERVA_PASSWORD`. Anything you can reach without signing in is limited to a health check that returns "ok".

## Other hosts

The included `Dockerfile` works on any Docker host (Fly.io, Railway, a small VPS). Set `MINERVA_PASSWORD`, mount a persistent volume at `/data`, and expose port 8080.

## Version 0.9 notes

* `API_REQUIREMENTS.md` lists every function that needs a key, an account or internet access, and what happens without it. The same list is also a page in the app itself (Requirements, in the left rail), read from that file directly so the two cannot disagree.
* The "Test every connection" button lives in the top bar of every screen (the small circled-tick icon). Run it first after deploying: it shows which live services the host can actually reach.
* Overnight testing found the live Land Registry sold-price SPARQL service answers vocabulary queries but errors on every real query tried against the transaction data itself, so it cannot be relied on. As a working alternative, Settings takes a Price Paid Data CSV (a year at a time, from the government's yearly file download, a few hundred MB at most) and comparables use it first when one is loaded.
* Stamp duty can be worked out on residential rates plus the surcharge, as well as non-residential rates, from the Tax tab.

* New files: `ui/v10.js`, `ui/v11.js` and `core/tax.py`, `levies.py`, `costplan.py`, `listings.py`, `sketch.py`, `requirements.py` and `ppdfile.py`. If you upload to GitHub, upload the whole folder. If you deploy from `Dockerfile` and `app.zip`, replace both with exactly those names, then Manual Deploy with Clear build cache.
* Levies and council documents are fetched from the server, so the host needs outbound HTTPS. The fetch respects robots.txt.
* Listing alerts need Outlook connected on the Deal emails page. Without it the demo alerts are shown.
* The first-run setup guide appears when the profile is empty, so a new deployment shows it once.

## Version 0.8 notes

* New files: `ui/v09.js` and `core/programme.py`, `funding.py`, `compset.py`, `strategy.py`, `history.py` and `packs.py`. If you upload to GitHub, upload the whole folder. If you deploy from `Dockerfile` and `app.zip`, replace both with exactly those names, then Manual Deploy with Clear build cache.
* Comparables call postcodes.io once per postcode and cache the result. If it is blocked, sales still appear in the table but not on the map.
* Change history is stored with each site, capped at 60 versions.

## Version 0.7 notes

* New files: `ui/v08.js`, `ui/geomap.js` and several modules under `core/`. If you upload to GitHub, upload the whole folder. If you deploy from `Dockerfile` and `app.zip`, replace both with exact names, then Manual Deploy with Clear build cache.
* Register diffs and map images are stored under /data (`maps` folder, extra tables in the register index).
* Static map images fetch tiles from the network and fall back to a grid if blocked.

## Version 0.6 notes

* Pillow is now in requirements.txt (unit plans in the committee paper). The Dockerfile installs it with the other requirements.
* Ownership data (CCOD and OCOD) is stored in an SQLite index under the data folder (/data on Render). The full files are large, so allow a few hundred megabytes on the disk.
* Keys for HM Land Registry, Companies House and any paid title provider are set on the Data sources page and stored in the profile on the disk. They are not in environment variables.
* Aptos is not bundled. It renders where Microsoft 365 fonts are installed on the viewing device and falls back to Segoe UI, Calibri or Arial elsewhere.
