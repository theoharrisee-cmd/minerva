"""v0.7: data-driven appraisal suggestions, market pricing by type, planning track record and the rest of the v0.7 features."""
import json, os, pathlib, sys, tempfile, threading, urllib.request
from datetime import date

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="ed-test7-")
os.environ.update(MINERVA_HOME=TMP, MINERVA_NO_OPEN="1", MINERVA_DOWNLOADS=TMP + "/dl")

import server  # noqa: E402
from core import layout, maplayers, areasearch, assembly, datasources as ds, hmlr, marketmix, recheck, screen, suggest, track, typology, watch  # noqa: E402

httpd = server.make_server(0)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{httpd.server_address[1]}"
SID = "rich-millpond"


def post(p, b=None):
    r = urllib.request.Request(B + p, data=json.dumps(b or {}).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        return json.loads(urllib.request.urlopen(r, timeout=60).read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


def get(p):
    return json.loads(urllib.request.urlopen(B + p, timeout=60).read())


def raw(p):
    r = urllib.request.urlopen(B + p, timeout=90)
    return r.read(), r.headers


def site():
    return server.site_by_id(SID)


TODAY = date(2026, 9, 21)


def fake_planit(lat, lon, radius, cfg, app_state=None, app_size=None, start_date=None, pg_sz=100, pg=1, sort=None):
    if pg > 1:
        return []
    rows = []
    if app_state == "Permitted" and app_size == "Large":
        for i in range(9):
            rows.append({"ref": f"P/{i}", "address": f"{i} Mill Lane", "description": f"Erection of {20 + i} dwellings with access", "submitted": f"202{1 + i % 4}-02-01", "decided": f"202{1 + i % 4}-08-01", "distance_km": 0.5 + i * 0.3, "url": "https://x/" + str(i), "lpa": "Testshire"})
    if app_state == "Rejected" and app_size == "Large":
        for i in range(3):
            rows.append({"ref": f"R/{i}", "address": f"{i} Field Rd", "description": "Residential development of 40 homes", "submitted": "2023-01-10", "decided": "2023-09-10", "distance_km": 1.0 + i, "url": "https://x/r" + str(i), "lpa": "Testshire"})
    if app_state == "Permitted" and app_size == "Medium":
        rows.append({"ref": "M/1", "address": "Barn", "description": "Conversion to 4 dwellings", "submitted": "2024-01-01", "decided": "2024-03-01", "distance_km": 2, "url": "u", "lpa": "Testshire"})
    return rows


# ---------------------------------------------------------------- track

def test_track_record():
    s = site()
    tr = track.fetch(s, {}, planit=fake_planit, today=TODAY)
    assert tr["ok"] and tr["approved"] == 9 and tr["refused"] == 3
    assert abs(tr["approval_rate"] - 0.75) < 1e-9
    assert 150 < tr["median_days"] < 220 and tr["by_year"]
    assert tr["precedents"] and tr["precedents"][0]["distance_km"] <= tr["precedents"][-1]["distance_km"]
    assert len(tr["refused_nearby"]) == 3 and "reasons" in tr["note"]
    out = track.add_points({"points": []}, tr)
    assert "9 of 12" in out["points"][0]["text"] and out["points"][0]["level"] == "Medium"
    assert "Comparable schemes approved" in track.facts(tr)["precedent_sentence"]


def test_track_route_uses_cache_and_errors():
    s = site()
    server.track.ds.planit = fake_planit
    try:
        a = post("/api/track/get", {"id": SID, "refresh": True})
        assert a.get("ok") and site()["track"]["approved"] == 9
        b = post("/api/track/get", {"id": SID})
        assert b["fetched"] == a["fetched"]
    finally:
        server.track.ds.planit = __import__("core.datasources", fromlist=["x"]).planit


# ---------------------------------------------------------------- suggestions

PACK = {"items": [{"id": "flood-risk-zone", "status": "hit", "label": "FZ3"}, {"id": "conservation-area", "status": "hit", "label": "Conservation area"}],
        "flags": {"flood_zone": "3"}}


def test_suggest_rules_and_apply_revert():
    s = site()
    a = server.assumptions_for(s)
    items = suggest.rules(s, PACK, None, a)
    ids = {i["id"] for i in items}
    assert {"flood3", "heritage"} <= ids
    s["data_pack"] = PACK
    server.persist_sites()
    st = post("/api/suggest/get", {"id": SID})
    f3 = next(i for i in st["items"] if i["id"] == "flood3")
    assert f3["impact"] is None or f3["impact"] < 0
    before = post("/api/suggest/get", {"id": SID})["profit"]
    st = post("/api/suggest/apply", {"id": SID, "rule": "flood3"})
    assert "flood3" in st["accepted"] and site()["ovr"]["external_pct"] > server.assumptions_for({**site(), "ovr": {}})["external_pct"] - 1e-9
    if before is not None:
        assert st["profit"] < before
    st = post("/api/suggest/revert", {"id": SID, "rule": "flood3"})
    assert "flood3" not in st["accepted"]
    assert st["profit"] == before


# ---------------------------------------------------------------- market by type

def test_market_pricing_and_build_rates():
    s = site()
    row = lambda ty, n, pr, psf: {"type": ty, "count": n, "median_price": pr, "median_psf": psf, "psf_n": n}
    s["land_registry"] = {"sector": "XX1 1", "months": 24, "fetched": "2026-09-01", "epc_note": "", "summary": {"n": 40, "new_build_n": 2, "median_psf": 380, "median_psf_flats": 420, "by_type": [
        row("Detached", 8, 520000, 400), row("Semi-detached", 12, 350000, 380), row("Terraced", 10, 290000, 370), row("Flat / maisonette", 10, 210000, 420)]}}
    server.persist_sites()
    st = post("/api/homes/market", {"id": SID})
    assert st["units"], st
    assert all(u["build_psf"] for u in st["units"])
    assert any(u["grade"] in ("high", "medium") for u in st["units"])
    p = post("/api/homes/market/apply", {"id": SID, "what": "both", "overwrite": True})
    assert p["changed"] > 0
    ev = post("/api/homes/market", {"id": SID})
    assert all(u["current_value"] for u in ev["units"] if u["sale_value"])
    prem = post("/api/homes/market", {"id": SID, "premium": 10})
    base = post("/api/homes/market", {"id": SID})
    a = next(u for u in base["units"] if u["sale_value"]); b = next(u for u in prem["units"] if u["id"] == a["id"])
    assert b["sale_value"] > a["sale_value"]


def test_weighted_build_psf():
    mix = [{"nsa_sqft": 1000, "count": 2, "build_psf": 200}, {"nsa_sqft": 500, "count": 2, "build_psf": 300}]
    assert abs(marketmix.weighted_build_psf(mix, 250) - (2000 * 200 + 1000 * 300) / 3000) < 1e-6


def test_reply_uses_precedent():
    from core import replies
    s = dict(site()); s["track"] = track.fetch(s, {}, planit=fake_planit, today=TODAY)
    d = replies.draft("officer", "Please explain the principle of development and local plan policy.", s, {"name": "A", "firm": "B"})
    assert "Comparable schemes approved nearby" in d["body"]
    s["track"] = None
    assert "Comparable schemes" not in replies.draft("officer", "Please explain the principle of development.", s, {})["body"]


# ---------------------------------------------------------------- screening the search result

SQUARE = "POLYGON((-0.13 51.50,-0.12 51.50,-0.12 51.52,-0.13 51.52,-0.13 51.50))"


def fake(url, headers, text):
    if "dataset.json" in url:
        return {"datasets": [{"dataset": x["id"], "name": x["label"]} for x in ds.PDG_SETS]}
    if "entity.json" in url and "dataset=green-belt" in url:
        return {"entities": [{"entity": 9, "name": "Green Belt", "reference": "GB1", "geometry": SQUARE}]}
    if "entity.json" in url and "dataset=brownfield-land" in url:
        return {"entities": [{"entity": 1, "name": "Depot", "reference": "BF1", "point": "POINT(-0.1278 51.5074)", "hectares": "1.2", "maximum-net-dwellings": "60", "site-address": "1 Depot Road"},
                             {"entity": 2, "name": "Yard", "reference": "BF2", "point": "POINT(-0.1350 51.5300)", "hectares": "0.8", "maximum-net-dwellings": "30"}]}
    if "entity.json" in url:
        return {"entities": []}
    if "postcodes.io" in url:
        return {"result": [{"postcode": "SW1A 2AA", "admin_district": "Westminster", "region": "London", "codes": {}}]}
    if "ukhpi" in url:
        return {"result": {"primaryTopic": {"averagePrice": 640000, "averagePriceDetached": 1100000, "averagePriceSemiDetached": 800000, "averagePriceTerraced": 700000, "averagePriceFlatMaisonette": 500000, "percentageAnnualChange": 1.5}}}
    if "planit.org.uk" in url:
        return {"records": []}
    raise RuntimeError("unexpected url " + url)


def wait(path, key="running"):
    import time
    for _ in range(100):
        s = get(path)
        if not s[key]:
            return s
        time.sleep(0.15)
    return s


def test_screen_search_results():
    ds._get_override = fake
    try:
        assert post("/api/search/start", {"place": "London", "radius_km": 3, "sources": ["brownfield"], "exclude": []})["started"]
        st = wait("/api/search/status")
        assert st["result"]["count"] >= 1
        assert post("/api/search/screen", {"strategy": "develop_sell"})["started"]
        r = wait("/api/search/screen/status")
        got = [x for x in r["results"].values() if x["ok"]]
        assert got, r
        d = next(x for x in got if x["units"] >= 40)
        assert d["rlv_per_ha"] and d["rlv"] > 0 and d["region"] == "London"
                # a constraint that carries an allowance lowers the residual
        gb = next(c for c in st["result"]["candidates"] if any(h["key"] == "green_belt" for h in c["constraints"]))
        base = server.STATE["assumptions"]
        clean = dict(gb, constraints=[])
        a = screen.screen_one(gb, "develop_sell", base)
        b = screen.screen_one(clean, "develop_sell", base)
        assert a["ok"] and b["ok"] and a["rlv"] < b["rlv"] and "Green Belt" in a["allowances"]
    finally:
        ds._get_override = None


def test_mandate_context():
    p = dict(server.STATE["investor"], active=True, regions=["South East", "London"], min_units=20, max_units=200, exclusions=["green_belt"], planning_tolerance="Consented")
    m = screen.mandate_criteria(p)
    assert m["criteria"]["min_units"] == 20 and "green_belt" in m["criteria"]["exclude"] and m["criteria"]["consented"] == "yes" and len(m["regions"]) == 2
    live = [{"stage": "Sourced", "postcode": "RG1 1AA", "strategy": "develop_sell"}] * 4 + [{"stage": "Sourced", "postcode": "M1 1AA", "strategy": "btr"}]
    c = screen.concentration(live, "South East", 50, "develop_sell")
    assert c["n_region"] == 4 and "already in South East" in c["text"]
    assert screen.concentration(live[:2], "South East", 50, "develop_sell") is None


# ---------------------------------------------------------------- ownership, assembly and register changes

HEAD = '"Title Number","Tenure","Property Address","District","County","Region","Postcode","Multiple Address Indicator","Price Paid","Proprietor Name (1)","Company Registration No. (1)","Proprietorship Category (1)","Proprietor (1) Address (1)","Date Proprietor Added"\n'


def ccod(rows):
    return HEAD + "".join('"%s","Freehold","%s","WOKINGHAM","WOKINGHAM","SOUTH EAST","%s","N","","%s","%s","Limited Company","1 High St","01-01-2020"\n' % r for r in rows)


OLD = [("BK1", "Land at Mill Lane", "RG40 3QT", "MILLPOND HOLDINGS LIMITED", "01234567"), ("BK2", "Land north of Mill Lane", "RG40 3QT", "MILLPOND HOLDINGS LIMITED", "01234567"),
       ("BK3", "Yard, Mill Lane", "RG40 3QU", "MILLPOND HOLDINGS LIMITED", "01234567"), ("BK4", "1 Pond Road", "RG40 3QU", "ACME PROPERTY LLP", "OC123456"), ("BK5", "Gone Farm", "RG40 3QT", "OLD FARMS LIMITED", "0000001")]
NEW = [OLD[0], ("BK2", "Land north of Mill Lane", "RG40 3QT", "NEWCO DEVELOPMENTS LIMITED", "09999999"), OLD[2], OLD[3], ("BK6", "Fresh Field", "RG40 3QT", "ACME PROPERTY LLP", "OC123456")]
POLY = "POLYGON((-0.1000 51.5000,-0.0990 51.5000,-0.0990 51.5009,-0.1000 51.5009,-0.1000 51.5000))"
POLY2 = "POLYGON((-0.0990 51.5000,-0.0980 51.5000,-0.0980 51.5009,-0.0990 51.5009,-0.0990 51.5000))"
POLY3 = "POLYGON((-0.0900 51.5100,-0.0890 51.5100,-0.0890 51.5109,-0.0900 51.5109,-0.0900 51.5100))"


def reset_hmlr():
    try:
        os.unlink(hmlr.DB)
    except FileNotFoundError:
        pass


def test_register_diff_and_watch():
    reset_hmlr()
    hmlr.WATCH = lambda: ["RG40 3QT"]
    hmlr.load_bytes(ccod(OLD).encode(), "CCOD_FULL_2026_08.csv")
    assert hmlr.last_diff() is None
    hmlr.load_bytes(ccod(NEW).encode(), "CCOD_FULL_2026_09.csv")
    d = hmlr.last_diff()
    assert d["added"] == 2 and d["removed"] == 2 and d["transferred"] == 1
    ch = {c["title"]: c for c in hmlr.changes_for(["RG40 3QT"])}
    assert ch["BK2"]["kind"] == "Transferred" and "MILLPOND" in ch["BK2"]["old"] and "NEWCO" in ch["BK2"]["new"]
    assert ch["BK6"]["kind"] == "New title" and ch["BK5"]["kind"] == "Left the register"
    assert "BK3" not in ch and hmlr.changes_for(["RG40 3QU"]) == []
    hmlr.WATCH = lambda: []


def test_assembly_polygons_owners_groups_and_distress():
    s = {"id": "a1", "lat": 51.5004, "lon": -0.0995, "postcode": "RG40 3QT", "address": "Land at Mill Lane, Wokingham",
         "boundary": {"ring": [(-0.0998, 51.5002), (-0.0992, 51.5002), (-0.0992, 51.5007), (-0.0998, 51.5007)]}}
    reset_hmlr()
    hmlr.load_bytes(ccod(OLD).encode(), "CCOD_FULL_2026_08.csv")
    fetch = lambda dsid, b, limit: [{"reference": "T-A", "geometry": POLY}, {"reference": "T-B", "geometry": POLY2}, {"reference": "T-C", "geometry": POLY3}]
    co = lambda no: {"name": "MILLPOND HOLDINGS LIMITED", "status": "liquidation", "accounts_overdue": True, "created": "2025-05-01", "sic": [], "has_charges": True,
                     "charges": [{"status": "outstanding", "created": "2026-01-10", "entitled": "Northbank plc"}, {"status": "outstanding", "created": "2026-03-01", "entitled": "Northbank plc"}]}
    a = assembly.build(s, {"ch_key": "x"}, 250, fetch, hmlr.by_postcode, ["RG40 3QT", "RG40 3QU"], co)
    p = {x["ref"]: x for x in a["polygons"]}
    assert p["T-A"]["under_site"] and p["T-A"]["adjoins"] and not p["T-B"]["adjoins"] and p["T-B"]["distance_m"] < 40
    assert a["polygons"][0]["ref"] == "T-A" and a["under_site_ha"] and 0.5 < a["under_site_ha"] < 1.0
    g = a["owners"]["groups"][0]
    assert g["proprietor"].startswith("MILLPOND") and g["nearby"] == 3 and g["assembler"] is True and g["total"] == 3
    assert any(x["level"] == "High" and "liquidation" in x["text"] for x in g["distress"]) and any("charges registered" in x["text"] for x in g["distress"])
    assert a["owners"]["titles"][0]["same_postcode"] and "confirm" in a["caveat"]
    assert assembly.to_parcels(s, a, ["T-A", "T-B"], {"T-A": {"proprietor": "MILLPOND HOLDINGS LIMITED", "company_no": "01234567", "title": "BK1"}}) == 2
    assert s["parcels"][0]["owner"].startswith("MILLPOND") and assembly.to_parcels(s, a, ["T-A"]) == 0
    assert not p["T-C"]["adjoins"] and p["T-C"]["distance_m"] > 1000


def test_assembly_route():
    ds._get_override = lambda url, headers, text: ({"entities": [{"reference": "T-A", "geometry": POLY}]} if "entity.json" in url else {"result": [{"postcode": "RG40 3QT"}]})
    try:
        r = post("/api/assembly/get", {"id": SID, "refresh": True})
        assert r["polygons"] and "notes" in r
        a = post("/api/assembly/add", {"id": SID, "refs": ["T-A"]})
        assert a["added"] == 1
    finally:
        ds._get_override = None


def test_monthly_recheck_events():
    s = {"id": "w1", "name": "Watch", "lat": 51.5, "lon": -0.1, "postcode": "RG40 3QT", "stage": "Sourced", "data_pack": {"geography": {"district": "Wokingham"}}}
    reset_hmlr()
    watch.start(s)
    calls = {"hpi": {"month": "2026-07", "avg": 500000, "annual": 2.0}, "flood": False, "rows": []}
    flood = lambda lat, lon: [{"id": "ea-warnings", "status": "hit" if calls["flood"] else "clear", "value": "1 active", "detail": "Flood alert: River Loddon"}]
    planit = lambda lat, lon, r, cfg, **kw: calls["rows"]
    hpi = lambda d: calls["hpi"]
    assert recheck.due(s)
    assert recheck.run(s, {}, planit=planit, flood=flood, hpi=hpi, tracker=lambda *a, **k: {"ok": False}) == []     # baseline
    assert not recheck.due(s) and recheck.due(s, date(2026, 12, 1))
    calls.update(flood=True, hpi={"month": "2026-08", "avg": 515000, "annual": 3.4}, rows=[{"ref": "26/1", "address": "Land at Mill Lane", "description": "Erection of 42 dwellings", "size": "Large"}])
    hmlr.WATCH = lambda: ["RG40 3QT"]
    hmlr.load_bytes(ccod(OLD).encode(), "CCOD_FULL_2026_10.csv")
    hmlr.load_bytes(ccod(NEW).encode(), "CCOD_FULL_2026_11.csv")
    ev = recheck.run(s, {}, planit=planit, flood=flood, hpi=hpi, tracker=lambda *a, **k: {"ok": False})
    kinds = {e["kind"] for e in ev}
    assert {"flood", "planning_nearby", "index", "title_change"} <= kinds, kinds
    assert any("42" in e["detail"] for e in ev if e["kind"] == "planning_nearby")
    again = recheck.run(s, {}, planit=planit, flood=flood, hpi=hpi, tracker=lambda *a, **k: {"ok": False})
    assert not [e for e in again if e["kind"] in ("flood", "planning_nearby", "index")]
    hmlr.WATCH = lambda: []
    r = post("/api/recheck", {"id": SID})
    assert "error" in r


# ---------------------------------------------------------------- map layers and boundary

def test_map_layer_and_boundary():
    ds._get_override = lambda url, headers, text: {"entities": [{"reference": "T-A", "geometry": POLY}, {"name": "Depot", "point": "POINT(-0.1 51.5)"}]}
    try:
        r = post("/api/map/layer", {"dataset": "title-boundary", "bbox": [-0.101, 51.499, -0.097, 51.502]})
        assert [f["t"] for f in r["features"]] == ["poly", "pt"] and len(r["features"][0]["ring"]) >= 4
        assert post("/api/map/layer", {"dataset": "title-boundary", "bbox": [-0.5, 51.0, 0.5, 52.0]})["too_wide"]
        assert "error" in post("/api/map/layer", {"dataset": "nonsense", "bbox": [0, 0, 1, 1]})
    finally:
        ds._get_override = None
    ring = [[-0.1000, 51.5000], [-0.0990, 51.5000], [-0.0990, 51.5009], [-0.1000, 51.5009], [-0.1000, 51.5000]]
    r = post("/api/site/boundary", {"id": SID, "ring": ring, "apply_area": True})
    assert 0.6 < r["boundary"]["area_ha"] < 0.9 and site()["site_ha"] == r["boundary"]["area_ha"]
    assert "error" in post("/api/site/boundary", {"id": SID, "ring": ring[:2]})
    assert post("/api/site/boundary", {"id": SID, "ring": None})["boundary"] is None


# ---------------------------------------------------------------- layout test

def test_layout_capacity_checks_and_apply():
    ring = [[-0.1010, 51.4995], [-0.0995, 51.4995], [-0.0995, 51.5010], [-0.1010, 51.5010]]
    assert post("/api/site/boundary", {"id": SID, "ring": ring, "apply_area": True})["boundary"]["area_ha"] > 1
    r = post("/api/layout/run", {"id": SID})
    if not r.get("ok"):
        post("/api/typology/preset", {"id": SID, "preset": "suburban_houses", "units": 40})
        post("/api/typology/save", {"id": SID, "typology": post("/api/typology/get", {"id": SID})["typology"]})
        r = post("/api/layout/run", {"id": SID})
    assert r["ok"] and r["homes"] > 10 and r["svg"].startswith("<svg") and "rx=" not in r["svg"]
    assert r["min_garden_m"] >= 10.0 and (r["min_back_to_back_m"] is None or r["min_back_to_back_m"] >= 21.0 - 0.1)
    ids = {c["id"] for c in r["checks"]}
    assert {"l_garden_len", "l_garden_area", "l_parking", "l_open"} <= ids
    h = post("/api/typology/get", {"id": SID})
    assert any(c["id"] == "l_parking" for c in h["policy"]["checks"])
    a = post("/api/layout/apply", {"id": SID, "parking": True})
    assert a["totals"]["units"] >= r["wanted"] or a["totals"]["units"] > 0
    assert post("/api/layout/get", {"id": SID})["current"]
    site().pop("boundary", None)
    tiny = {"lat": 51.5, "lon": -0.1, "boundary": {"ring": [[-0.1, 51.5], [-0.09995, 51.5], [-0.09995, 51.50004]]}}
    typ = typology.normalise(typology.default_typology({"units": 10, "site_ha": 0.3}, preset="suburban_houses"), {})
    res = layout.run(tiny, typ, typology.analyse(typ, {}), __import__("core.policy", fromlist=["x"]).pack_for(typ))
    assert not res["ok"] and "small" in res["error"]
    from core import policy as _pol
    assert not layout.run({"lat": 51.5, "lon": -0.1}, typ, typology.analyse(typ, {}), _pol.pack_for(typ))["ok"]


# ---------------------------------------------------------------- data in outputs

def test_outputs_carry_site_data():
    import io, zipfile
    s = site()
    s["data_pack"] = {"checked": "2026-09-20T10:00", "items": [
        {"group": "Environment and risk", "id": "flood-risk-zone", "label": "Flood zone 3", "status": "hit", "value": "Zone 3", "detail": "River Loddon", "source": "Environment Agency"},
        {"group": "Planning and policy", "id": "conservation-area", "label": "Conservation area", "status": "clear", "value": "Clear", "source": "planning.data.gov.uk"},
        {"group": "Infrastructure and access", "id": "osm-rail", "label": "Nearest station", "status": "info", "value": "620 m, Wokingham", "source": "OpenStreetMap"}],
        "planit": [{"ref": "26/1", "address": "Land at Mill Lane", "description": "Erection of 42 dwellings", "state": "Pending", "submitted": "2026-08-01", "distance_km": 0.3}], "geography": {"district": "Wokingham"}, "hpi": {}, "flags": {}}
    s["track"] = track.fetch(s, {}, planit=fake_planit, today=TODAY)
    s["title_register"] = {"title": "BK1", "tenure": "Freehold", "class": "Absolute", "price": 1250000, "price_date": "2019", "proprietors": [{"name": "MILLPOND HOLDINGS LIMITED", "company_no": "01234567"}], "charges": [{"chargee": "NORTHBANK PLC", "date": "2021"}], "restrictions": [], "covenants": ["x"], "notices": []}
    pack = server.site_pack(s)
    d = pack["data"]
    assert d["constraints"][1][0] == "Flood zone 3" and "Conservation area" in d["constraints_line"] and d["map"][:4] == b"\x89PNG"
    assert any("MILLPOND" in r[1] for r in d["ownership"]) and d["applications"][1][0] == "26/1" and any("9 of 12" in x for x in d["record_lines"]) and d["access"][1][0] == "Nearest station"
    html = server.report_html(s)
    assert "Site data" in html and "Flood zone 3" in html and "MILLPOND" in html and "data:image/png" in html
    z = zipfile.ZipFile(io.BytesIO(server.committee_bytes(s)))
    assert "Flood zone 3" in z.read("word/document.xml").decode() and any(n.startswith("word/media/") for n in z.namelist())
    from pptx import Presentation
    prs = Presentation(io.BytesIO(server.deck_bytes(s)))
    alltext = " ".join(sh.text_frame.text for sl in prs.slides for sh in sl.shapes if sh.has_text_frame) + " ".join(c.text for sl in prs.slides for sh in sl.shapes if sh.has_table for r in sh.table.rows for c in r.cells)
    assert "Site and constraints" in alltext and "Flood zone 3" in alltext
    data, hdr = raw(f"/download/brief/{SID}.docx")
    zb = zipfile.ZipFile(io.BytesIO(data))
    txt = zb.read("word/document.xml").decode()
    assert "Site brief" in txt and "Flood zone 3" in txt and "MILLPOND" in txt and "26/1" in txt and "Nearest station" in txt and "docx" in hdr["Content-Disposition"]
    assert post("/api/brief/save", {"id": SID})["name"].endswith("_site_brief.docx")
    for k in ("data_pack", "track", "title_register", "assembly"):
        s.pop(k, None)
    assert not server.site_pack(s)["data"]


# ---------------------------------------------------------------- ask this deal

def test_ask_this_deal():
    from core import ask
    s = dict(site())
    s["track"] = track.fetch(s, {}, planit=fake_planit, today=TODAY)
    s["data_pack"] = {"items": [{"id": "flood-risk-zone", "group": "Environment and risk", "label": "Flood zone 3", "status": "hit", "value": "Zone 3", "detail": "River Loddon", "source": "Environment Agency"}]}
    s["docs"] = [{"id": "d1", "name": "Transport statement.txt", "category": "Transport"}]
    text = {"d1": "The site access is from Mill Lane with a 5.5 m carriageway and 2 m footways. Visibility splays of 2.4 by 43 m are achievable.\n\nTrip generation is forecast at 28 two-way trips in the peak hour."}
    r = ask.answer(s, "What visibility splays does the access have?", None, None, lambda d: text[d["id"]])
    assert r["mode"] == "search" and "2.4 by 43" in r["answer"] and r["sources"][0]["label"].startswith("Document")
    r = ask.answer(s, "Is the site in a flood zone?", None, None, lambda d: text[d["id"]])
    assert "Flood zone 3" in r["answer"]
    r = ask.answer(s, "What is the approval rate nearby?", None, None, None)
    assert "approved" in r["answer"]
    seen = {}

    def fake_claude(key, model, system, msgs, n):
        seen["p"] = msgs[-1]["content"]
        import re as _re
        pid = _re.search(r"\[(P\d+)\] \(Document[^\n]*Mill Lane", msgs[-1]["content"]).group(1)
        seen["pid"] = pid
        return f"The access is from Mill Lane [{pid}]."
    r = ask.answer(s, "Where is the access?", None, None, lambda d: text[d["id"]], "key", "m", None, fake_claude)
    assert r["mode"] == "claude" and "Mill Lane" in seen["p"] and [x["id"] for x in r["sources"]] == [seen["pid"]]
    assert ask.answer({"name": "x"}, "zzz qqq", None, None, None)["mode"] == "none"
    assert "error" in post("/api/ask", {"id": SID, "q": ""})
    assert post("/api/ask", {"id": SID, "q": "What is the planning status?"})["answer"]


if __name__ == "__main__":
    fails = 0
    for n, f in sorted(globals().items()):
        if n.startswith("test_"):
            try:
                f(); print("ok  ", n)
            except Exception as e:
                import traceback; traceback.print_exc(); fails += 1; print("FAIL", n, e)
    sys.exit(1 if fails else 0)
