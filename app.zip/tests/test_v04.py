"""v0.4: waterfall, lender tests, costs, diligence, portfolio import, watch and alerts, land, comparable schemes, committee paper, style."""
import base64, io, json, os, pathlib, re, sys, tempfile, threading, urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="ed-test4-")
os.environ.update(MINERVA_HOME=TMP, MINERVA_NO_OPEN="1", MINERVA_DOWNLOADS=TMP + "/dl")

from core import committee, costs, dd, demo_deals, land, portfolio, schemes, waterfall, watch  # noqa: E402
from core.appraisal import appraise  # noqa: E402


def sample_workbook() -> bytes:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Portfolio"
    ws.append(["Company portfolio schedule"])
    ws.append([])
    ws.append(["Scheme", "Location", "Type", "Status", "Units", "GDV (£m)", "Total cost (£m)", "Equity committed (£m)", "Equity invested (£m)", "Facility (£m)", "Drawn (£m)", "Interest rate", "Maturity"])
    ws.append(["Ashfield Court", "Nottingham NG1", "BTR", "On site", 110, 31.5, 24.0, 7.0, 5.5, 15.0, 11.0, 0.081, "2028-05-31"])
    ws.append(["Meadow Row", "Bristol BS3", "Build to sell", "Complete, selling", 48, 19.2, 14.1, 4.2, 4.2, 9.0, 5.5, "8.4%", "2027-02-28"])
    ws.append(["Total", "", "", "", 158, 50.7, 38.1, 11.2, 9.7, 24, 16.5, "", ""])
    bs = wb.create_sheet("Balance sheet")
    bs.append(["Balance sheet (£000)", "30 Jun 2025", "30 Jun 2026"])
    for r in [("Cash at bank", 2100, 3400), ("Work in progress", 40000, 52000), ("Debtors", 900, 1200), ("Total assets", 43000, 56600), ("Creditors", 3000, 4100), ("Bank loans", 24000, 33000), ("Total liabilities", 27000, 37100), ("Net assets", 16000, 19500)]:
        bs.append(list(r))
    cf = wb.create_sheet("Cashflow")
    cf.append(["£", "Q1 2026", "Q2 2026", "Q3 2026", "Q4 2026"])
    cf.append(["Receipts", 4000000, 6000000, 3000000, 8000000])
    cf.append(["Payments", 5500000, 4500000, 5200000, 4000000])
    cf.append(["Net cash flow", -1500000, 1500000, -2200000, 4000000])
    cf.append(["Closing cash", 1900000, 3400000, 1200000, 5200000])
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def test_waterfall_conserves_and_orders():
    flows = [-100] + [0] * 11 + [150]
    r = waterfall.run(flows, {"sponsor_coinvest": 10, "tiers": [{"hurdle": 8, "promote": 20}, {"hurdle": 15, "promote": 30}]})
    assert abs(r["investor"]["profit"] + r["sponsor"]["profit"] - 50) < 1e-6
    assert abs(r["promote"] - 11.725) < 1e-6
    assert r["sponsor"]["irr"] > r["total"]["irr"] > r["investor"]["irr"]
    # no promote when returns stay under the first hurdle
    low = waterfall.run([-100] + [0] * 11 + [105], {"sponsor_coinvest": 10})
    assert low["promote"] == 0
    # loss case
    loss = waterfall.run([-100, 0, 80], {"sponsor_coinvest": 10})
    assert loss["promote"] == 0 and abs(loss["total"]["profit"] + 20) < 1e-9


def test_lender_tests():
    d = demo_deals.DEALS[1]
    ap = appraise(d, {}, d["strategy"])
    L = waterfall.lender(ap, None, d["strategy"])
    m = L["metrics"]
    assert 0 < m["senior_ltc"] < 100 and abs(m["senior"] - ap["senior_peak"]) < 1e-6
    tight = waterfall.lender(ap, {"max_senior_ltc": 10}, d["strategy"])
    assert not tight["pass_all"] and any(not t["ok"] for t in tight["tests"])
    btr = demo_deals.DEALS[0]
    Lb = waterfall.lender(appraise(btr, {}, "btr"), None, "btr")
    assert Lb["metrics"]["icr"] is not None and Lb["metrics"]["debt_yield"] is not None


def test_costs_asterisk_and_regions():
    t = costs.table("London")
    base = costs.table(None)
    assert t[0]["mid"] > base[0]["mid"]
    p = costs.pick({"unit_mix": [{"type": "2 bed flat", "count": 10}]}, "develop_sell", "North West")
    assert p["key"] == "flats" and "Indicative" in p["footnote"]
    assert costs.pick({"listed": True}, "value_add", None)["key"] == "refurb_heavy"


def test_dd_seed_and_summary():
    s = {"planning_status": "Consented", "contamination": True, "docs": [{"category": "Decision notice", "name": "d.pdf"}], "site_ha": 2}
    items = dd.seed(s)
    by = {i["item"]: i for i in items}
    assert by["Phase 2 intrusive investigation"]["status"] == "Not started"
    assert by["Planning history and decision notices collected"]["status"] == "Done"
    assert by["Pre-application meeting held or scheduled"]["status"] == "Not applicable"
    items[0]["status"] = "Issue"
    sm = dd.summary(items)
    assert sm["issues"] == 1 and 0 < sm["pct"] < 100


def test_portfolio_import_heuristic():
    r = portfolio.interpret(sample_workbook(), None)
    assert r["engine"] == "name matching"
    names = {s["name"] for s in r["schemes"]}
    assert names == {"Ashfield Court", "Meadow Row"}          # totals row excluded
    a = next(s for s in r["schemes"] if s["name"] == "Ashfield Court")
    assert a["gdv"] == 31_500_000 and a["strategy"] == "btr" and a["debt_drawn"] == 11_000_000 and abs(a["debt_rate"] - 0.081) < 1e-9
    m = next(s for s in r["schemes"] if s["name"] == "Meadow Row")
    assert m["strategy"] == "develop_sell" and abs(m["debt_rate"] - 0.084) < 1e-9
    assert r["balance_sheet"]["cash"] == 3_400_000 and r["balance_sheet"]["borrowings"] == 33_000_000   # sheet header says £000
    assert len(r["cashflow"]) == 4 and r["cashflow"][3]["closing"] == 5_200_000


def test_portfolio_summary():
    sc = [portfolio.clean_scheme(x) for x in portfolio.DEMO_SCHEMES]
    sm = portfolio.summary(sc, {"fund_size": 100, "equity_available": 20}, [{"peak_equity": 3e6}], portfolio.DEMO_ORG)
    assert sm["n_live"] == 4 and abs(sm["debt_drawn"] - 39e6) < 1
    assert abs(sm["equity_to_come"] - (12.5 + 9 - 9.1 - 2.2) * 1e6) < 1
    assert abs(sm["headroom"] - (20e6 - sm["equity_to_come"] - 3e6)) < 1


def test_watch_events_and_digest():
    s = {"id": "w1", "name": "Test Land", "address": "Somewhere", "url": "https://x.example/p", "listing": True, "asking_price": 2_000_000, "lat": 51.0, "lon": -1.0,
         "key_dates": [{"date": "2026-09-25", "event": "Offers by"}], "planning_history": []}
    watch.start(s)
    pages = iter([
        "<html><body>Guide price £2,000,000. Freehold land.</body></html>",
        "<html><body>Guide price £1,850,000. Under offer.</body></html>",
    ])
    js = iter([{"entities": []}, {"entities": [{"reference": "26/0001/FUL", "description": "40 dwellings", "decision": "approved"}]}])
    from datetime import date
    fetch = lambda url, **k: next(pages)
    getj = lambda url, **k: next(js)
    first = watch.check_site(s, fetch, getj, date(2026, 9, 21))
    assert [e["kind"] for e in first] == ["date"]                      # prime run: only the date warning
    second = watch.check_site(s, fetch, getj, date(2026, 9, 21))
    kinds = sorted(e["kind"] for e in second)
    assert kinds == ["listing_status", "planning_new", "price_change"], kinds
    # dedupe: same state again adds nothing
    pages2 = iter(["<html>Guide price £1,850,000. Under offer.</html>"])
    assert watch.check_site(s, lambda u, **k: next(pages2), lambda u, **k: {"entities": [{"reference": "26/0001/FUL", "description": "40 dwellings", "decision": "approved"}]}, date(2026, 9, 21)) == []
    items = watch.pending([s])
    subj, text, html = watch.build_digest(items)
    assert "shortlisted site" in subj and "under offer" in text and "£1,850,000" in text


def test_send_email_mock_and_run_all():
    sent = []

    class Fake:
        def __init__(self, host, port): self.host, self.port = host, port
        def starttls(self, context=None): sent.append("tls")
        def login(self, u, p): sent.append(("login", u))
        def send_message(self, m): sent.append(("msg", m["To"], m["Subject"]))
        def quit(self): pass

    s = {"id": "w2", "name": "Mock", "address": "x", "asking_price": 1e6, "key_dates": [{"date": "2026-09-23", "event": "Bid deadline"}]}
    watch.start(s)
    cfg = {**watch.DEFAULT_SETTINGS, "enabled": True, "to": "me@example.com", "smtp_host": "smtp.example.com", "smtp_user": "u", "smtp_password": "p"}
    res = watch.run_all([s], cfg, fetch=lambda *a, **k: "", get_json=lambda *a, **k: {"entities": []}, smtp_factory=Fake)
    assert res["emailed"] >= 1 and ("login", "u") in sent and any(x[0] == "msg" for x in sent if isinstance(x, tuple))
    assert all(e["sent"] for e in s["events"])
    cfg2 = {**cfg, "smtp_host": ""}
    try:
        watch.send_email(cfg2, "s", "t")
        raise AssertionError("should fail without SMTP host")
    except ValueError:
        pass


def test_land_and_letter():
    site = {"name": "Test", "site_ha": 5, "parcels": [land.clean_parcel(p) for p in [
        {"ref": "A", "area_ha": 3, "status": "Option signed", "offer": 3e6}, {"ref": "B", "area_ha": 1, "status": "In talks", "ask": 1.2e6, "ransom": True, "next_date": "2020-01-01"}, {"ref": "C", "area_ha": 1, "status": "Declined"}]]}
    sm = land.summary(site)
    assert abs(sm["secured_pct"] - 60) < 1e-9 and sm["ransom"] == 1 and sm["overdue"] == 1 and sm["declined"] == 1
    L = land.letter(site, {"owner": "Mrs Hill", "address": "Long Field"}, {"name": "A Developer", "firm": "Firm Ltd"})
    assert "Dear Mrs Hill" in L["body"] and "Firm Ltd" in L["body"]


def test_schemes_assemble():
    site = {"id": "s", "lat": 51.4, "lon": -0.85}
    sales = [{"new_build": True, "postcode": "RG40 3AA", "price": 400000, "psf": 450, "type": "Flat / maisonette", "street": "High St", "date": "2026-01-02"}] * 3
    geo = {"RG40 3AA": (51.401, -0.851)}
    manual = [schemes.clean_manual({"name": "Manual", "kind": "Consented", "units": 100, "site_ha": 2, "lat": 51.41, "lon": -0.86})]
    r = schemes.assemble(site, sales, geo, manual, [], [], [], 3)
    assert r["summary"]["n"] == 2 and manual[0]["density"] == 50.0
    far = schemes.clean_manual({"name": "Far", "lat": 55, "lon": -3})
    assert schemes.assemble(site, None, {}, [far], [], [], [], 3)["summary"]["n"] == 0
    apps = schemes.nearby_applications(51.4, -0.85, 2, get_json=lambda u, **k: {"entities": [{"entity": 7, "reference": "26/1", "description": "Erection of 24 dwellings", "point": "POINT (-0.851 51.401)", "decision": "Approved"}]})
    assert apps[0]["kind"] == "Consented" and apps[0]["units"] == 24


def test_committee_paper_builds():
    from docx import Document
    import server
    s = server.site_by_id("rich-millpond")
    data = server.committee_bytes(s)
    d = Document(io.BytesIO(data))
    text = "\n".join(p.text for p in d.paragraphs) + "\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)
    for needle in ("Investment committee paper", "Key risks", "Funding requirement", "Due diligence", "Indicative only", "Mill Pond Meadows"):
        assert needle in text, needle
    assert "*" in text


def _serve():
    import server
    httpd = server.make_server(0)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{httpd.server_address[1]}"

    def call(path, body=None):
        req = urllib.request.Request(base + path, data=None if body is None else json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="GET" if body is None else "POST")
        try:
            with urllib.request.urlopen(req) as f:
                return json.loads(f.read())
        except urllib.error.HTTPError as e:
            return {"_status": e.code, **json.loads(e.read() or b"{}")}
    return base, call


def test_api_v04():
    base, call = _serve()
    st = call("/api/state")
    assert st["cost_footnote"].startswith("* Indicative")
    assert any(s["id"] == "rich-millpond" for s in st["sites"])
    p = call("/api/portfolio")
    assert p["summary"]["n"] == 4                                             # illustrative schemes seeded
    # import, then commit
    res = call("/api/portfolio/import", {"data": base64.b64encode(sample_workbook()).decode(), "name": "org.xlsx"})
    assert len(res["schemes"]) == 2
    cm = call("/api/portfolio/commit", {"schemes": res["schemes"], "balance_sheet": res["balance_sheet"], "cashflow": res["cashflow"], "file": "org.xlsx"})
    assert cm["added"] == 2
    assert call("/api/portfolio")["summary"]["n"] == 6
    assert call("/api/portfolio/commit", {"schemes": res["schemes"]})["updated"] == 2     # upsert by name
    # structure
    stx = call("/api/structure", {"id": "rich-millpond", "terms": {"sponsor_coinvest": 20, "tiers": [{"hurdle": 10, "promote": 25}]}, "save": True})
    assert stx["terms"]["sponsor_coinvest"] == 20 and stx["waterfall"]["investor"]["invested"] > 0
    assert call("/api/structure", {"id": "rich-millpond"})["terms"]["sponsor_coinvest"] == 20      # persisted
    # dd
    d = call("/api/dd/get", {"id": "rich-millpond"})
    items = d["items"]
    items[0]["status"] = "Done"
    d2 = call("/api/dd/save", {"id": "rich-millpond", "items": items})
    assert d2["summary"]["done"] >= 1
    # watch + events
    assert call("/api/site/watch", {"id": "rich-millpond", "on": True})["on"] is True
    call("/api/site", {"site": {"id": "rich-millpond", "stage": "Screened"}})
    ev = [s for s in call("/api/state")["sites"] if s["id"] == "rich-millpond"][0]
    assert ev["_watch"] and any("Stage changed" in e["title"] for e in ev["_events"])
    # alerts settings hide password
    call("/api/alerts/settings", {"to": "a@b.com", "smtp_host": "h", "smtp_password": "secret", "interval_hours": 3})
    al = call("/api/state")["alerts"]
    assert al["has_password"] and "smtp_password" not in al and al["interval_hours"] == 3
    call("/api/alerts/settings", {"smtp_password": ""})
    assert call("/api/state")["alerts"]["has_password"]                       # empty string keeps the saved password
    bad = call("/api/alerts/test", {})
    assert bad.get("_status") == 400
    # land + letter
    lr = call("/api/land/get", {"id": "rich-millpond"})
    assert lr["summary"]["n"] == 3
    letter = call("/api/land/letter", {"id": "rich-millpond", "parcel_id": "pcl-mp2"})
    assert "Aldridge" in letter["body"]
    # schemes map without network (demo deal)
    m = call("/api/schemes/map", {"id": "rich-millpond", "radius": 3})
    assert m["summary"]["n"] >= 3
    sv = call("/api/schemes/save", {"id": "rich-millpond", "scheme": {"name": "Mine", "kind": "Built", "units": 10, "lat": 51.405, "lon": -0.86}})
    assert sv["ok"]
    assert call("/api/schemes/map", {"id": "rich-millpond", "radius": 3})["summary"]["n"] >= 4
    # costs
    c = call("/api/costs", {"id": "rich-harbour"})
    assert c["pick"]["key"].startswith("refurb")
    # committee download
    with urllib.request.urlopen(base + "/download/committee/rich-kingsfield.docx") as f:
        assert f.read(2) == b"PK"


BANNED = [r"\bdelve\b", r"\btapestry\b", r"\bseamless(ly)?\b", r"\bleverag(e|es|ing)\b", r"\brobust\b", r"\bunlock(s|ing)?\b", r"\belevate\b", r"\bstreamline\b", r"game[- ]chang", r"cutting[- ]edge",
          r"in today's", r"it'?s worth noting", r"\bnavigate the\b", r"\blandscape of\b", r"\btestament\b", r"\bjourney\b", r"\bempower", r"\bholistic\b", r"\bsynerg", r"\butili[sz]e\b", r"\bfurthermore\b",
          r"\bmoreover\b", r"\bnot just\b", r"more than just", r"here'?s the catch", r"let'?s dive", r"\bcrucial\b", r"\bpivotal\b", r"\bvibrant\b", r"\bbeacon\b", r"\bharness", r"\brealm\b", r"\bplethora\b",
          r"\bever-evolving\b", r"\bfoster(s|ing)?\b", r"\bunderscore(s|d)?\b", r"\bshowcase\b", r"\bat the end of the day\b", r"\bdive into\b", r"\bsleek\b", r"\bpowerful\b", r"\bgame changer\b"]


def test_style_no_tropes_or_em_dashes():
    files = [*(ROOT / "ui").glob("*.js"), *(ROOT / "ui").glob("*.html"), *(ROOT / "core").glob("*.py"), ROOT / "server.py", ROOT / "README.md", ROOT / "DEPLOY.md"]
    bad = []
    for f in files:
        txt = f.read_text()
        if "—" in txt:
            bad.append((f.name, "em dash"))
        for rx in BANNED:
            for m in re.finditer(rx, txt, re.I):
                if f.name == "test_v04.py":
                    continue
                bad.append((f.name, m.group(0)))
    assert not bad, bad[:30]
    # "not X, it is Y" constructions
    pat = re.compile(r"\b(?:is|are|it's|this is) not (?:just |only |merely )?[^.,;]{1,40}(?:,| but| it is| it's|;) (?:it'?s|it is|but)\b", re.I)
    hits = [(f.name, m.group(0)) for f in files for m in pat.finditer(f.read_text())]
    assert not hits, hits[:20]


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f()
            print("ok", n)
