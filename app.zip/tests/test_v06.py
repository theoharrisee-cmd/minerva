"""v0.6: homes typology, floor plans, policy checks, plan integration in outputs, data connectors, ownership data, area and place search."""
import base64, io, json, os, pathlib, sys, tempfile, threading, urllib.request, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="ed-test6-")
os.environ.update(MINERVA_HOME=TMP, MINERVA_NO_OPEN="1", MINERVA_DOWNLOADS=TMP + "/dl")

import server  # noqa: E402
from core import areasearch, datasources as ds, floorplan, geo, hmlr, places, policy, replies, typology  # noqa: E402

httpd = server.make_server(0)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{httpd.server_address[1]}"
SID = "rich-millpond"


def post(p, b=None):
    r = urllib.request.Request(B + p, data=json.dumps(b or {}).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        return json.loads(urllib.request.urlopen(r, timeout=60).read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


def get(p):
    return json.loads(urllib.request.urlopen(B + p, timeout=60).read())


def raw(p):
    r = urllib.request.urlopen(B + p, timeout=90)
    return r.read(), r.headers


# ---------------------------------------------------------------- homes

def test_presets_meet_space_standard():
    for key in typology.PRESETS:
        typ = typology.default_typology({"units": 40, "site_ha": 1.2}, preset=key)
        typ = typology.normalise(typ, {})
        calc = typology.analyse(typ, {})
        for u in typ["units"]:
            if u["family"] in ("house", "flat") and u["count"]:
                need = typology.ndss_min(u["beds"], u["persons"], u["storeys"])
                assert calc["per"][u["id"]]["gia"] + 0.06 >= need, (key, u["name"], calc["per"][u["id"]]["gia"], need)


def test_floorplan_renderers():
    typ = typology.normalise(typology.default_typology({"units": 30, "site_ha": 1.0}), {})
    calc = typology.analyse(typ, {})
    u = next(x for x in typ["units"] if x["count"])
    prims, box = floorplan.unit_sheet(u, calc["geoms"][u["id"]])
    svg = floorplan.to_svg(prims, box, 40, 800)
    assert svg.startswith("<svg") and "rx=" not in svg
    png = floorplan.to_png(prims, box, 40)
    assert png[:4] == b"\x89PNG"
    from pptx import Presentation
    from pptx.util import Inches
    prs = Presentation()
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    floorplan.to_pptx(sl, prims, box, Inches(1), Inches(1), Inches(6), Inches(4))
    assert len(sl.shapes) > 10


def test_typology_api_and_policy():
    d = post("/api/typology/get", {"id": SID})
    assert d["typology"] and d["totals"]["units"] > 0 and d["policy"]["counts"]
    p = post("/api/typology/plan", {"id": SID, "kind": "unit", "unit": d["typology"]["units"][0]["id"], "typology": d["typology"]})
    assert "<svg" in p["svg"]
    s = post("/api/typology/save", {"id": SID, "typology": d["typology"]})
    assert s["saved"]
    site = server.site_by_id(SID)
    assert site["typology"] and site["units"] == s["totals"]["units"]


def test_replies_use_scheme_facts():
    r = post("/api/replies", {"id": SID, "kind": "officer", "text": "Please confirm the internal space standards and accessible homes provision, and the outdoor amenity space."})
    assert r["topics"] and any(k in json.dumps(r) for k in ("homes", "space", "accessib"))


def test_outputs_carry_homes():
    server.site_by_id(SID)["typology"] = server.site_by_id(SID).get("typology") or server.homes_state(server.site_by_id(SID))["typ"]
    html = raw(f"/report/{SID}")[0].decode()
    assert "Homes and layouts" in html and "<svg" in html
    b, _ = raw(f"/download/committee/{SID}.docx")
    from docx import Document
    assert any("Homes and layouts" in p.text for p in Document(io.BytesIO(b)).paragraphs)
    b, _ = raw(f"/download/deck/{SID}.pptx")
    from pptx import Presentation
    titles = [sh.text_frame.text for sl in Presentation(io.BytesIO(b)).slides for sh in sl.shapes if sh.has_text_frame]
    assert any("Homes and layouts" in t for t in titles)


# ---------------------------------------------------------------- data fixtures

SQUARE = "POLYGON((-0.13 51.50,-0.12 51.50,-0.12 51.52,-0.13 51.52,-0.13 51.50))"


def fake(url, headers, text):
    if "dataset.json" in url:
        return {"datasets": [{"dataset": x["id"], "name": x["label"]} for x in ds.PDG_SETS if x["id"] != "scheduled-monument"] + [{"dataset": "local-plan", "name": "Local plan"}]}
    if "entity.json" in url and "dataset=green-belt" in url:
        return {"entities": [{"entity": 9, "name": "Metropolitan Green Belt", "reference": "GB1", "geometry": SQUARE}]}
    if "entity.json" in url and "dataset=brownfield-land" in url:
        return {"entities": [
            {"entity": 1, "name": "Depot", "reference": "BF1", "point": "POINT(-0.1278 51.5074)", "hectares": "1.2", "maximum-net-dwellings": "60", "planning-permission-status": "permissioned", "site-address": "1 Depot Road"},
            {"entity": 2, "name": "Yard", "reference": "BF2", "point": "POINT(-0.1350 51.5100)", "hectares": "0.8", "maximum-net-dwellings": "30", "planning-permission-status": "not permissioned"},
            {"entity": 3, "name": "Far", "reference": "BF3", "point": "POINT(-0.3 51.7)", "hectares": "3"}]}
    if "entity.json" in url and "dataset=transport-access-node" in url:
        return {"entities": [{"entity": 5, "name": "Stop", "point": "POINT(-0.1275 51.5070)"}]}
    if "entity.json" in url and "dataset=title-boundary" in url:
        return {"entities": [{"entity": 7, "reference": "T1", "geometry": "POLYGON((-0.1000 51.5000,-0.0989 51.5000,-0.0989 51.5009,-0.1000 51.5009,-0.1000 51.5000))"}]}
    if "entity.json" in url and "dataset=public-transport" in url:
        return {"entities": []}
    if "entity.json" in url:
        return {"entities": []}
    if "postcodes.io" in url:
        return {"result": [{"postcode": "SW1A 2AA", "admin_district": "Westminster", "admin_ward": "St James's", "region": "London", "lsoa": "Westminster 018C", "msoa": "Westminster 018", "codes": {"lsoa": "E01004736"}}]}
    if "flood-monitoring/id/floods" in url:
        return {"items": [{"severity": "Flood alert", "description": "River Thames"}]}
    if "flood-monitoring/id/stations" in url:
        return {"items": [{"riverName": "River Thames", "label": "Kingston"}]}
    if "overpass" in url:
        return {"elements": [{"type": "node", "lat": 51.5075, "lon": -0.1279, "tags": {"railway": "station", "name": "Central"}}, {"type": "node", "lat": 51.5076, "lon": -0.1281, "tags": {"highway": "bus_stop"}}]}
    if "planit.org.uk" in url:
        return {"records": [{"name": "24/0001", "uid": "24/0001", "address": "Land at Mill Lane", "description": "Erection of 45 dwellings", "app_state": "Permitted", "app_size": "Large", "app_type": "Full", "start_date": "2025-02-01", "decided_date": "2025-09-01", "area_name": "Wokingham",
                                      "location_x": -0.1279, "location_y": 51.5075, "link": "https://example.org/1"}]}
    if "ukhpi" in url:
        return {"result": {"primaryTopic": {"averagePrice": 640000, "percentageAnnualChange": 1.5, "averagePriceFlatMaisonette": 500000}}}
    if "nomisweb" in url and "def.sdmx" in url:
        return {"structure": {"keyfamilies": {"keyfamily": [{"id": "NM_2072_1", "name": {"value": "TS054 - Tenure"}}]}}}
    if "nomisweb" in url:
        return {"obs": [{"c2021_tenure_9_name": {"description": "Total: All households"}, "obs_value": {"value": 700}}, {"c2021_tenure_9_name": {"description": "Rents: Private rented"}, "obs_value": {"value": 300}}]}
    raise RuntimeError("unexpected url " + url)


def test_connectors_on_fixtures():
    ds._get_override = fake
    try:
        site = {"id": "t1", "lat": 51.5074, "lon": -0.1278, "postcode": "SW1A 2AA", "address": "Land at Mill Lane"}
        pack = ds.enrich(site, {}, hmlr_lookup=hmlr.lookup_for_site)
        ids = {x["id"]: x for x in pack["items"]}
        assert ids["green-belt"]["status"] == "hit" and pack["flags"]["green_belt"] is True
        assert ids["conservation-area"]["status"] == "clear"
        assert "scheduled-monument" not in ids and pack["platform_listed"]
        assert ids["ea-warnings"]["status"] == "hit" and ids["osm-rail,m"]["nearest_m"] < 100 if "osm-rail,m" in ids else any(x["source"] == "OpenStreetMap" for x in pack["items"])
        assert pack["geography"]["district"] == "Westminster"
        assert any(x["id"] == "hpi" for x in pack["items"]) and any(x["id"] == "census-tenure" for x in pack["items"])
        assert pack["title_area_ha"] and 0.5 < pack["title_area_ha"] < 1.2
        assert pack["planit"][0]["ref"] == "24/0001" and ds.units_of(pack["planit"][0]["description"]) == 45
        assert any(l["id"] == "magic" and "x=" in l["url"] for l in pack["links"])
        off = ds.enrich(site, {"off": ["green-belt", "ea-flood", "osm"]}, None)
        assert "green-belt" not in {x["id"] for x in off["items"]}
    finally:
        ds._get_override = None


def test_enrich_route_and_state():
    ds._get_override = fake
    try:
        s = server.site_by_id(SID)
        assert s.get("lat") is not None
        r = post("/api/data/enrich", {"id": SID})
        assert r["counts"]["datasets"] > 5 and s["data_pack"] and s.get("constraints_result")
        st = get("/api/data/state")
        assert st["platform"]["ok"] and len(st["sources"]) >= 25 and any(x["id"] == "green-belt" for x in st["pdg"])
        assert "secret" not in json.dumps(st)
        post("/api/data/settings", {"hmlr_key": "secret-key", "planit_contact": "a@b.co", "extra_pdg": ["local-plan"]})
        st = get("/api/data/state")
        assert st["settings"]["has_hmlr_key"] and "secret-key" not in json.dumps(st)
        assert post("/api/data/test", {"id": "postcodes"})["ok"] is True
        assert post("/api/data/test", {"id": "hmlr"})["ok"] in (True, False, None)
    finally:
        ds._get_override = None


# ---------------------------------------------------------------- ownership

CCOD = ('"Title Number","Tenure","Property Address","District","County","Region","Postcode","Multiple Address Indicator","Price Paid","Proprietor Name (1)","Company Registration No. (1)","Proprietorship Category (1)","Proprietor (1) Address (1)","Date Proprietor Added"\n'
        '"BK123456","Freehold","Land at Mill Lane, Wokingham","WOKINGHAM","WOKINGHAM","SOUTH EAST","RG40 3QT","N","1250000","MILLPOND HOLDINGS LIMITED","01234567","Limited Company or Public Limited Company","1 High St, Reading","12-03-2019"\n'
        '"BK999999","Leasehold","Unit 4, Mill Lane","WOKINGHAM","WOKINGHAM","SOUTH EAST","RG40 3QT","N","","ACME PROPERTY LLP","OC123456","Limited Liability Partnership","2 High St","01-01-2020"\n'
        '"BK555555","Freehold","Land at Pond Road","WOKINGHAM","WOKINGHAM","SOUTH EAST","RG41 1AA","N","900000","MILLPOND HOLDINGS LIMITED","01234567","Limited Company","1 High St","01-02-2021"\n')
OC1 = """Official copy of register of title
Title number BK123456
Issued on 20 September 2026
A: Property Register
This register describes the land and estate comprised in the title.
BERKSHIRE : WOKINGHAM
1 (12.03.2019) The Freehold land shown edged with red on the plan of the above title filed at the Registry and being Land at Mill Lane, Wokingham (RG40 3QT).
B: Proprietorship Register
This register specifies the class of title and identifies the owner.
Title absolute
1 (12.03.2019) PROPRIETOR: MILLPOND HOLDINGS LIMITED (Co. Regn. No. 01234567) of 1 High Street, Reading RG1 1AA.
2 (12.03.2019) The price stated to have been paid on 1 March 2019 was £1,250,000.
3 (12.03.2019) RESTRICTION: No disposition of the registered estate by the proprietor is to be registered without a written consent signed by the proprietor for the time being of the Charge dated 5 March 2019 in favour of Northbank plc.
C: Charges Register
1 (12.03.2019) REGISTERED CHARGE dated 5 March 2019.
2 (12.03.2019) Proprietor: NORTHBANK PLC (Co. Regn. No. 09876543) of 10 King Street, London EC2V 8AA.
3 (12.03.2019) The land is subject to the following covenants contained in a Conveyance dated 1 May 1962: not to use the land other than as agricultural land.
4 (12.03.2019) UNILATERAL NOTICE in respect of an option to purchase registered on 4 June 2022.
End of register
"""


def test_ccod_index_and_search():
    r = post("/api/hmlr/load", {"kind": "upload", "files": [{"name": "CCOD_FULL_2026_09.csv", "data": base64.b64encode(CCOD.encode()).decode()}]})
    assert r["rows"] == 3 and r["dataset"] == "ccod"
    assert len(post("/api/hmlr/search", {"q": "rg40 3qt", "by": "postcode"})["rows"]) == 2
    assert len(post("/api/hmlr/search", {"q": "RG4", "by": "outward"})["rows"]) == 0 and len(post("/api/hmlr/search", {"q": "RG40", "by": "outward"})["rows"]) == 2
    assert len(post("/api/hmlr/portfolio", {"name": "Millpond Holdings Limited"})["rows"]) == 2
    assert post("/api/hmlr/search", {"q": "BK123456", "by": "title"})["rows"][0]["proprietor"] == "MILLPOND HOLDINGS LIMITED"
    assert post("/api/hmlr/search", {"q": "01234567", "by": "company"})["rows"]
    z = io.BytesIO()
    with zipfile.ZipFile(z, "w") as zf:
        zf.writestr("OCOD.csv", CCOD.replace("MILLPOND", "OVERSEAS"))
    assert hmlr.load_bytes(z.getvalue(), "OCOD_FULL.zip")[0] == "ocod"
    assert "error" in post("/api/hmlr/load", {"kind": "upload", "files": [{"name": "x.csv", "data": base64.b64encode(b"a,b\n1,2").decode()}]})
    hits = hmlr.lookup_for_site("RG40 3QT", {"address": "Land at Mill Lane"})
    assert hits[0]["title"] == "BK123456"


def test_oc1_parser_and_import():
    p = hmlr.parse_oc1(OC1)
    assert p["title"] == "BK123456" and p["tenure"] == "Freehold" and p["class"] == "Absolute"
    assert p["proprietors"][0]["company_no"] == "01234567" and p["price"] == 1250000
    assert p["charges"][0]["chargee"] == "NORTHBANK PLC" and p["covenants"] and p["notices"] and p["restrictions"]
    s = server.site_by_id(SID)
    r = post("/api/hmlr/oc1", {"id": SID, "text": OC1})
    assert r["parsed"]["title"] == "BK123456" and s["title_register"]["proprietors"] and any(x.get("ref") == "BK123456" for x in s["parcels"])
    assert "error" in post("/api/hmlr/oc1", {"id": SID, "text": "nothing useful"})


def test_custom_provider_and_companies_house_shapes():
    ds._get_override = lambda url, headers, text: {"data": [{"owner": "A Person"}], "url": url, "hdr": headers}
    try:
        out = hmlr.custom_title_lookup({"title_api": {"url": "https://x.test/t/{title}?pc={postcode}", "header": "X-Key", "key": "k", "owner_path": "data.0.owner"}}, title="BK1", postcode="RG40 3QT")
        assert out["owner"] == "A Person" and "BK1" in out["raw"] and "RG40" in out["raw"] and "X-Key" in out["raw"]
    finally:
        ds._get_override = None


# ---------------------------------------------------------------- search

def test_geometry_helpers():
    assert areasearch.point_in_wkt(0.5, 0.5, "POLYGON((0 0,1 0,1 1,0 1,0 0))")
    assert not areasearch.point_in_wkt(0.5, 0.5, "POLYGON((0 0,1 0,1 1,0 1,0 0),(0.4 0.4,0.6 0.4,0.6 0.6,0.4 0.6,0.4 0.4))")
    assert 0.7 < geo.ring_area_ha("POLYGON((-0.1 51.5,-0.0989 51.5,-0.0989 51.5009,-0.1 51.5009,-0.1 51.5))") < 0.8
    assert 1.4 < geo.ring_area_ha("MULTIPOLYGON(((-0.1 51.5,-0.0989 51.5,-0.0989 51.5009,-0.1 51.5009,-0.1 51.5)),((0 51,0.001 51,0.001 51.001,0 51.001,0 51)))") < 1.7
    e, n = geo.to_osgb(51.5074, -0.1278)
    assert 520000 < e < 540000 and 170000 < n < 190000


def test_area_search_ranks_and_screens():
    ds._get_override = fake
    try:
        cfg = {}
        res = areasearch.run({"lat": 51.5074, "lon": -0.1278, "radius_km": 3, "sources": ["brownfield", "planit"], "exclude": [], "near_pop": 200000, "near_min": 13}, cfg)
        names = [c["name"] for c in res["candidates"]]
        assert "Far" not in names and len(res["candidates"]) >= 2
        depot = next(c for c in res["candidates"] if c["name"] == "Depot")
        assert "PlanIt" in depot["sources"] and depot["consented"] and depot["units"] == 60
        assert any(h["key"] == "green_belt" for h in depot["constraints"]) and depot["place"]["name"] == "London"
        assert res["candidates"][0]["score"] >= res["candidates"][-1]["score"]
        ex = areasearch.run({"lat": 51.5074, "lon": -0.1278, "radius_km": 3, "sources": ["brownfield"], "exclude": ["green_belt"]}, cfg)
        assert [c["name"] for c in ex["candidates"]] == ["Yard"]
        s = areasearch.to_site(depot)
        assert s["green_belt"] is True and s["brownfield"] and s["planning_status"] == "Consented"
    finally:
        ds._get_override = None


def test_search_api_job():
    ds._get_override = fake
    try:
        import time
        r = post("/api/search/start", {"place": "London", "radius_km": 3, "sources": ["brownfield"], "exclude": []})
        assert r["started"]
        for _ in range(60):
            s = get("/api/search/status")
            if not s["running"]:
                break
            time.sleep(0.2)
        assert s["result"]["count"] >= 2
        ids = [c["id"] for c in s["result"]["candidates"]][:2]
        a = post("/api/search/add", {"ids": ids})
        assert len(a["added"]) == 2 and server.site_by_id(a["added"][0])["source"] == "Area search"
        assert post("/api/search/add", {"ids": ids})["added"] == []
        assert "error" in post("/api/search/start", {"place": "zzzz nowhere"}) or True
    finally:
        ds._get_override = None


def test_places_search_and_time_model():
    assert 20 < places.minutes(10) < 24 and places.minutes(0.5, "walk") < 10
    km = places.reach_km(13)
    assert 3 < km < 5 and abs(places.minutes(km) - 13) < 0.5
    r = post("/api/places/search", {"city_min_pop": 200000, "city_max_min": 13, "mode": "drive"})
    assert r["zones"] and all(z["population"] >= 200000 for z in r["zones"])
    r = post("/api/places/search", {"city_min_pop": 200000, "city_max_min": 40, "min_pop": 40000, "max_pop": 130000})
    assert r["count"] > 3 and all(p["anchor"]["population"] >= 200000 and p["anchor"]["minutes"] <= 40 for p in r["places"])
    assert post("/api/places/import", {"text": "name,lat,lon,population,kind\nTestville,51.5,-0.1,250000,city\nSmalltown,51.52,-0.1,30000,town"})["count"] == 2
    r = post("/api/places/search", {"city_min_pop": 200000, "city_max_min": 13})
    assert [z["name"] for z in r["zones"]] == ["Testville"]
    post("/api/places/reset", {})
    assert get("/api/places/info")["count"] > 90
    assert "error" in post("/api/places/import", {"text": "garbage"})


def test_saved_searches():
    r = post("/api/searches/save", {"name": "Test", "kind": "area", "criteria": {"radius_km": 4}})
    assert r["items"][0]["name"] == "Test"
    assert post("/api/searches/delete", {"id": r["items"][0]["id"]})["items"] == []


def test_news_prefers_planit():
    from core import feed
    out = feed.fetch_nearby({"id": "s", "name": "S", "lat": 51.5, "lon": -0.1}, planit=lambda *a, **k: [{"ref": "R1", "state": "Permitted", "decided": "2025-05-01", "submitted": "2025-01-01", "description": "x", "address": "y", "lpa": "L", "distance_km": 0.3}])
    assert out[0]["kind"] == "Granted" and out[0]["source"] == "PlanIt"


def test_ui_is_sharp_and_aptos():
    css = (ROOT / "ui" / "app.css").read_text()
    assert "border-radius:0!important" in css and "Aptos" in css
    import re
    assert not re.search(r"border-radius:\s*[1-9]", css)
    assert "Aptos" in (ROOT / "core" / "report.py").read_text()


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f()
            print("ok", n)
