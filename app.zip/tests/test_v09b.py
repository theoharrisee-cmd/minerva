"""Overnight hardening tests for v0.9: connector fallbacks and real-shape fixtures."""
import csv
import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import comps, levies, net  # noqa: E402

BIND = lambda **k: {kk: {"value": vv} for kk, vv in k.items()}


def test_comps_falls_back_to_nearby_postcodes():
    calls = []
    real = net.api_get

    def fake(url, headers=None, timeout=30, cache_ttl=0):
        calls.append(url)
        if "postcodes.io" in url:
            return {"result": [{"postcode": "RG40 3QU"}, {"postcode": "RG40 3QW"}]}
        if "VALUES" in url or "VALUES" in __import__("urllib.parse", fromlist=["x"]).unquote_plus(url):
            return {"results": {"bindings": [BIND(paon="1", street="MILL LANE", town="WOKINGHAM", postcode="RG40 3QU", amount="450000", date="2026-03-01",
                                                  type="http://landregistry.data.gov.uk/def/common/terraced", newbuild="false", estate="http://landregistry.data.gov.uk/def/common/freehold")]}}
        raise RuntimeError("HTTP 504: timeout")
    net.api_get = fake
    try:
        r = comps.fetch({"postcode": "RG40 3QT"})
        assert "error" not in r and r["mode"] == "nearby postcodes" and r["sales"][0]["price"] == 450000.0
        assert any("postcodes.io" in c for c in calls)
    finally:
        net.api_get = real


def test_comps_reports_error_when_everything_fails():
    real = net.api_get
    net.api_get = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("cannot connect"))
    try:
        assert "error" in comps.fetch({"postcode": "RG40 3QT"})
    finally:
        net.api_get = real


def _csv(rows):
    out = io.StringIO()
    w = csv.DictWriter(out, fieldnames=["dataset", "end-date", "entity", "entry-date", "geojson", "geometry", "name", "organisation-entity", "point", "prefix", "quality", "reference", "start-date", "typology", "adopted-date", "description", "document-url", "documentation-url", "notes", "organisation"])
    w.writeheader()
    for r in rows:
        w.writerow({"dataset": "community-infrastructure-levy-schedule", **r})
    return out.getvalue().encode()


def test_levies_schedule_from_dataset_file():
    """Fixture in the real column layout of the dataset file, including a row with no name and an unrelated document."""
    orgs = "entity,name,official-name\n29,Ashfield District Council,\n33,Babergh District Council,\n35,Basildon Borough Council,\n"
    sched = _csv([
        {"entity": "900000", "name": "Arun CIL Charging Schedule January 2020", "organisation-entity": "29", "reference": "ARU/1", "adopted-date": "2020-01-15", "document-url": "https://www.arun.gov.uk/download.cfm?doc=x.pdf", "documentation-url": "https://www.arun.gov.uk/cil/"},
        {"entity": "900001", "name": "Community Infrastructure Levy Babergh Charging Schedule", "organisation-entity": "33", "reference": "BAB/1", "adopted-date": "2016-01-20", "document-url": "https://www.babergh.gov.uk/documents/BDC-Charging-Schedule.pdf"},
        {"entity": "900002", "name": "", "organisation-entity": "35", "reference": "BAI/1", "document-url": "https://www.basildon.gov.uk/media/1/Basildon-Council-Local-Development-Scheme-LDS-2024-2026.pdf"},
    ]).decode()
    def fetch(url):
        if url.endswith("organisation.csv"):
            return orgs.encode(), "text/csv"
        if url.endswith("community-infrastructure-levy-schedule.csv"):
            return sched.encode(), "text/csv"
        raise RuntimeError("HTTP 404")
    levies._fetch_override = fetch
    try:
        a = levies.find_schedule("Arun")
        assert a["ok"] and "arun.gov.uk" in a["items"][0]["document_url"]
        b = levies.find_schedule("Babergh District Council")
        assert b["ok"] and b["items"][0]["adopted"] == "2016-01-20"
        c = levies.find_schedule("Basildon")
        assert not c["ok"], "a Local Development Scheme is not a charging schedule"
    finally:
        levies._fetch_override = None


def test_osrm_walk_and_cycle_use_road_distance():
    from core import datasources as ds, places
    real = ds._http
    seen = []
    ds._http = lambda url, *a, **k: (seen.append(url), {"routes": [{"duration": 600.0, "distance": 4800.0}]})[1]
    try:
        assert round(places.osrm_minutes((51.4, -0.8), (51.5, -0.1), "drive")) == 10
        assert round(places.osrm_minutes((51.4, -0.8), (51.5, -0.1), "walk")) == 60
        assert 20 < places.osrm_minutes((51.4, -0.8), (51.5, -0.1), "cycle") < 22
        assert all("/driving/" in u for u in seen)
    finally:
        ds._http = real


def test_costplan_messy_workbook_reconciles_and_flags_credits():
    import openpyxl
    from core import costplan
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Project: Mill Pond Meadows - Cost Plan Rev C"])
    ws.append([])
    ws.append(["Ref", "Description", "Total"])
    for r in [("1.1", "Foundations", "£222,600"), ("2.1", "Frame", "4,018,000"), ("3", "Preliminaries @ 12%", "£515,000"), ("5", "Design contingency 5%", "£262,000"),
              ("6", "Professional fees", "£620,000"), ("7", "Value engineering saving", "(£150,000)"), ("", "TOTAL", "£5,487,600")]:
        ws.append(list(r))
    b = io.BytesIO()
    wb.save(b)
    s = costplan.summarise(costplan.parse(b.getvalue(), "plan.xlsx"))
    assert s["build"] == 4605600.0 and s["contingency"] == 262000.0 and s["fees"] == 620000.0
    assert s["reconciliation"] and s["reconciliation"]["diff"] == 0
    assert any("negative" in w for w in s["warnings"])
    # a total that does not agree is called out
    ws["C10"] = "£6,000,000"
    b = io.BytesIO()
    wb.save(b)
    s = costplan.summarise(costplan.parse(b.getvalue(), "plan.xlsx"))
    assert any("says 6,000,000" in w for w in s["warnings"])


def test_costplan_messy_csv_with_headings_credit_and_partial_exclusion():
    """Round 6 overnight: a QS cost plan as CSV with section headings that drive the construction grouping, a
    parenthesised credit line, a GIA given in m2, and a grand total that includes land and sales lines that the
    build cost correctly excludes (so the reconciliation should explain the gap, not just flag it as wrong)."""
    import csv
    from core import costplan
    rows = [
        ["Cost Plan - Riverside Scheme", "", ""], ["GIA (m2)", "8500", ""], ["", "", ""],
        ["Description", "Qty", "Total £"], ["SUBSTRUCTURE", "", ""], ["Piling and foundations", "", "£425,000.00"], ["", "", ""],
        ["SUPERSTRUCTURE", "", ""], ["Frame and upper floors", "", "£1,250,000.00"], ["Roof coverings", "", "£180,500"], ["", "", ""],
        ["EXTERNAL WORKS", "", ""], ["Landscaping and drainage", "", "£95,000"], ["Retention released by groundworker", "", "(15,000)"], ["", "", ""],
        ["Contingency at 5%", "", "£97,275"], ["Professional fees (architect, QS, M&E)", "", "£320,000"], ["Section 106 contribution", "", "£150,000"],
        ["VAT on fees", "", "£64,000"], ["Land purchase price", "", "£3,200,000"], ["Sales and marketing", "", "£45,000"], ["", "", ""],
        ["GRAND TOTAL", "", "£5,826,775"],
    ]
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    plan = costplan.parse(buf.getvalue().encode(), "riverside.csv")
    assert abs(plan["area_sqft"] - 8500 * costplan.SQM_TO_SQFT) < 1, "GIA given in m2 must be converted to sq ft"
    groups = {x["label"]: x["group"] for x in plan["items"] if x["kind"] == "construction"}
    assert groups["Piling and foundations"] == "Substructure" and groups["Frame and upper floors"] == "Superstructure" and groups["Landscaping and drainage"] == "External works"
    credit = next(x for x in plan["items"] if "Retention" in x["label"])
    assert credit["amount"] == -15000.0, "a parenthesised amount in a CSV cell is a credit"
    s = costplan.summarise(plan)
    assert s["build"] == 425_000 + 1_250_000 + 180_500 + 95_000 - 15_000
    assert s["contingency"] == 97_275 and s["fees"] == 320_000 + 64_000  # VAT on fees is folded into fees, not left out
    assert s["reconciliation"]["scope"] == "all lines" and s["reconciliation"]["plan"] == 5_826_775.0
    assert s["excluded"] == 150_000 + 3_200_000 + 45_000, "land, S106 and sales lines are correctly switched off the build cost"
    assert any("Check for lines that are missing, switched off or counted twice" in w for w in s["warnings"])
    assert any("negative" in w for w in s["warnings"])


def test_requirements_page_parses_the_real_markdown_file():
    """Round 7 overnight: the in-app Requirements page reads API_REQUIREMENTS.md directly, so it can never drift
    from that file. Parse the real file (not a fixture) and check the sections a developer actually wrote survive."""
    from core import requirements
    d = requirements.load()
    assert d["available"] and d["title"].startswith("Which functions need an API")
    headings = [s["heading"] for s in d["sections"]]
    assert "Needs a key or account you must obtain" in headings
    assert "No key, but needs internet access from the server" in headings
    assert "Cannot be done by API (and how it is handled)" in headings
    need = next(s for s in d["sections"] if s["heading"] == "Needs a key or account you must obtain")
    assert need["table"]["headers"][:2] == ["Function", "What it needs"]
    rows = {r[0]: r for r in need["table"]["rows"]}
    assert any("Anthropic API key" in v for v in rows["Ask, planning document analysis, reply drafting, intake from emails, portfolio interpretation"])
    # a small synthetic file exercises the parser's edge cases directly
    sample = "# Title here\n\nSome intro text.\n\n## Section one\n| A | B |\n|---|---|\n| x | y |\n| z | w |\n\n## Section two\nJust a paragraph, no table.\n"
    p = requirements.load(sample)
    assert p["title"] == "Title here"
    assert [s["heading"] for s in p["sections"]] == ["", "Section one", "Section two"], "text before the first ## heading is its own preamble section, same as the real file's intro line"
    assert p["sections"][0]["paragraphs"] == ["Some intro text."]
    assert p["sections"][1]["table"] == {"headers": ["A", "B"], "rows": [["x", "y"], ["z", "w"]]}
    assert p["sections"][2]["paragraphs"] == ["Just a paragraph, no table."]


def test_ppdfile_parses_the_official_column_layout_and_comps_prefers_it():
    """Round 8 overnight: live-tested the Land Registry SPARQL endpoint directly (not against a fixture) and found
    it answers vocabulary queries but returns HTTP 400 on every triple pattern tried against the real transaction
    data (pricePaid, postcode; open scan, FILTER, and a VALUES-pinned exact postcode all failed the same way), so
    the linked-data service cannot be relied on for comparables right now. HM Land Registry also publishes the same
    data as plain CSV (no header row, a stable column layout), so this loads a Price Paid Data yearly file, the same
    'load a bulk file in Settings' pattern already used for EPC certificates and HMLR ownership data, and comps.fetch
    is checked to prefer it over the network call when a file is loaded."""
    from core import comps, ppdfile
    ppdfile.clear()
    try:
        rows = [
            ["{A}", "425000", "2025-03-14 00:00", "RG1 4AA", "D", "N", "F", "12", "", "MILL LANE", "", "READING", "READING", "BERKSHIRE", "A", "A"],
            ["{B}", "610000", "2025-06-01 00:00", "RG1 4AB", "S", "Y", "L", "3", "FLAT 2", "MILL LANE", "", "READING", "READING", "BERKSHIRE", "A", "A"],
            ["{C}", "1250000", "2020-01-01 00:00", "RG1 4AA", "F", "N", "L", "1", "", "MILL LANE", "", "READING", "READING", "BERKSHIRE", "A", "A"],  # too old for a 24-month window
        ]
        buf = io.StringIO()
        csv.writer(buf, quoting=csv.QUOTE_ALL).writerows(rows)
        st = ppdfile.load_bytes(buf.getvalue().encode(), "pp-2025.csv")
        assert st["rows"] == 3 and st["sectors"] == 1
        sales = ppdfile.for_sector("RG1 4")
        by_price = {s["price"]: s for s in sales}
        assert by_price[425000.0]["type"] == "Detached" and by_price[425000.0]["tenure"] == "Freehold" and by_price[425000.0]["postcode"] == "RG1 4AA"
        assert by_price[610000.0]["type"] == "Semi-detached" and by_price[610000.0]["tenure"] == "Leasehold" and by_price[610000.0]["new_build"] is True
        r = comps.fetch({"postcode": "RG1 4AA"}, months=24)
        assert r["mode"] == "Price Paid Data file" and not r.get("error")
        assert len(r["sales"]) == 2, "the 2020 sale is outside a 24-month lookback and should be excluded"
    finally:
        ppdfile.clear()


def test_data_test_all_and_new_sources():
    from core import datasources as ds
    ids = {x["id"] for x in ds.SOURCES}
    assert {"levy-schedules", "osrm"} <= ids
    real = ds.test
    ds.test = lambda sid, cfg=None: {"ok": sid != "osrm", "ms": 1, "detail": "x"}
    try:
        r = ds.test_all({})
        assert r["osrm"]["ok"] is False and r["levies"]["ok"] is True and "ppd" in r and "planit" in r
    finally:
        ds.test = real
    levies._fetch_override = lambda url: (_csv([{"entity": "1", "name": "X CIL", "document-url": "https://x.gov.uk/a.pdf"}]), "text/csv")
    try:
        assert ds.test("levies")["ok"] is True
    finally:
        levies._fetch_override = None


def test_listing_alert_layouts():
    from core import listings
    html = """<table><tr><td><a href="https://www.rightmove.co.uk/properties/149876543#/?channel=RES_BUY&amp;utm_source=alert"><img src="https://media.rightmove.co.uk/dir/img.jpeg"></a></td>
<td><a href="https://www.rightmove.co.uk/properties/149876543#/?channel=RES_BUY&amp;utm_source=alert">Land off Church Lane, Bracknell</a><br>£1,250,000<br>Building plot with detailed planning for 6 houses. Bracknell RG12 9AB</td></tr></table>
<a href="https://click.email.rightmove.co.uk/?u=https%3A%2F%2Fwww.rightmove.co.uk%2Fproperties%2F150000111&amp;x=1">Former nursery, Ascot SL5 0AA</a> £2,000,000 Site of 0.8 acres, STPP for 12 flats"""
    a = listings.parse_alert(html)
    assert [c["id"] for c in a] == ["149876543", "150000111"]
    assert a[0]["address"] == "Land off Church Lane, Bracknell" and a[0]["price"] == 1250000.0 and a[0]["postcode"] == "RG12 9AB"
    assert a[1]["price"] == 2000000.0 and a[1]["address"].startswith("Former nursery") and a[1]["development_signal"]
    txt = "New properties for you\nLand off Church Lane, Bracknell\n£1,250,000\nBuilding plot with planning for 6 houses\nhttps://www.rightmove.co.uk/properties/149876543#/?channel=RES_BUY\n\nFormer nursery, Ascot SL5 0AA\n£2,000,000\nhttps://www.zoopla.co.uk/for-sale/details/61234567/?utm_source=x"
    assert [c["id"] for c in listings.parse_alert(txt)] == ["149876543", "61234567"], "a message returned as plain text in the html slot"
    t = listings.parse_alert("", txt)
    assert [(c["source"], c["id"]) for c in t] == [("rightmove", "149876543"), ("zoopla", "61234567")]
    assert t[0]["address"] == "Land off Church Lane, Bracknell" and t[1]["price"] == 2000000.0


def test_listing_alert_messier_real_world_layouts():
    """Round 6 overnight fixes: a price phrase with no currency symbol ('Offers over'), an em dash used as the
    separator instead of a hyphen, a price glued to the title on one line with no line break, a bed count that is
    only a badge ('3 bed house') versus one folded into the real address line, and a double-URL-encoded tracking
    link from a third-party alert forwarder."""
    from core import listings
    html = """<table><tr><td>
<a href="https://elink.clickdimensions.com/t/r?u=https%253A%252F%252Fwww.rightmove.co.uk%252Fproperties%252F123456789"><img src="https://media.rightmove.co.uk/1.jpg"></a>
<a href="https://elink.clickdimensions.com/t/r?u=https%253A%252F%252Fwww.rightmove.co.uk%252Fproperties%252F123456789">Land at Mill Lane, Reading, rg1 4aa &ndash; development opportunity</a>
<div>Offers over 250,000</div><div>3&#8211;4 bed potential, STPP</div></td></tr>
<tr><td><a href="https://www.zoopla.co.uk/for-sale/details/987654321/"><img src="https://lc.zoocdn.com/2.jpg"></a>
<a href="https://www.zoopla.co.uk/for-sale/details/987654321/">Guide price £850,000 &mdash; 2 bed flat, Manchester M1 2AB</a></td></tr>
<tr><td><a href="https://www.onthemarket.com/details/55512345/"><img src="https://on.tm/3.jpg"></a>
<a href="https://www.onthemarket.com/details/55512345/">3 bed house</a>
<div>OIRO £399,995</div><div>Plot with planning consent, Oak Farm, Leeds LS1 3AB</div></td></tr></table>"""
    a = listings.parse_alert(html)
    assert [c["id"] for c in a] == ["123456789", "987654321", "55512345"], "double-url-encoded tracking link (u=...%253A...) should still resolve to the real listing id"
    rm, zp, otm = a
    assert rm["price"] == 250000.0, "'Offers over 250,000' with no currency symbol should still be read as the price"
    assert rm["postcode"] == "RG1 4AA" and rm["beds"] == 4
    assert zp["price"] == 850000.0
    assert zp["address"] == "2 bed flat, Manchester M1 2AB", "an address line that starts with a bed count must not be dropped, and 'Guide price' must not be mistaken for the address"
    assert zp["beds"] == 2 and zp["postcode"] == "M1 2AB"
    assert otm["price"] == 399995.0
    assert otm["address"].startswith("Plot with planning consent"), "a standalone bed-count badge line ('3 bed house') must not swallow the real address that follows it"
    assert otm["beds"] == 3 and otm["postcode"] == "LS1 3AB"


def test_levies_extraction_messy_policy_text():
    t = """Table 1: CIL charging rates
Residential (Zone 1 - Central) | £325
Residential (Zone 2) | £150
Supermarkets (over 500 sq m) £175/sqm
Offices, industrial | £0
Planning obligations (Section 106): we will seek £2,415 per dwelling towards secondary education and £500 per home for SANG mitigation (Thames Basin Heaths SPA). A Habitats contribution of £1,200 per net additional dwelling.
Policy CP5: The Council will require 30% of homes on sites of 15 dwellings or more to be affordable, with a tenure split of 70% social rent and 30% intermediate. On brownfield sites the target is 20% affordable housing."""
    e = levies.extract(t)
    assert {c["rate_sqm"] for c in e["cil"]} == {325.0, 150.0, 175.0}
    assert {x["amount"] for x in e["tariffs"]} == {2415.0, 500.0, 1200.0}
    assert next(x for x in e["tariffs"] if x["amount"] == 2415.0)["label"] == "secondary education"
    assert next(x for x in e["tariffs"] if x["amount"] == 1200.0)["label"].startswith("A Habitats contribution")
    assert sorted(a["pct"] for a in e["affordable"]) == [20.0, 30.0], "tenure split percentages are not affordable housing targets"


def test_excel_model_carries_tax_and_cost_plan_sheets():
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import base64
    import openpyxl
    import test_v08 as t
    xl = io.BytesIO()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Description", "Total"])
    for r in [("Foundations", 500000), ("Frame", 3000000), ("Contingency 5%", 175000), ("Professional fees", 400000)]:
        ws.append(list(r))
    wb.save(xl)
    t.post("/api/costplan/read", {"id": t.SID, "name": "plan.xlsx", "data": base64.b64encode(xl.getvalue()).decode()})
    import urllib.request
    data = urllib.request.urlopen(t.B + f"/download/model/{t.SID}.xlsx").read()
    book = openpyxl.load_workbook(io.BytesIO(data))
    assert "Tax" in book.sheetnames and "Cost Plan" in book.sheetnames, book.sheetnames
    vals = [c.value for row in book["Cost Plan"].iter_rows() for c in row if c.value is not None]
    assert "Foundations" in vals and "Frame" in vals


def test_planning_data_slugs_and_watch_query_shape():
    from core import datasources as ds, watch
    ids = {x["id"] for x in ds.PDG_SETS}
    assert "transport-access-node" in ids and "public-transport-access-node" not in ids
    seen = []
    site = {"lat": 51.41, "lon": -0.83, "watch": {"snap": {}, "events": []}}
    try:
        watch.check_planning(site, get_json=lambda url, timeout=15: (seen.append(url), {"entities": []})[1])
    except Exception:
        pass
    assert seen and "geometry=POLYGON" in seen[0] and "longitude=" not in seen[0]


def test_epc_certificate_file_matches_sales():
    import tempfile
    from core import epcfile
    old = epcfile.PATH
    epcfile.PATH = Path(tempfile.mkdtemp()) / "epc.json.gz"
    epcfile._cache = None
    try:
        text = "LMK_KEY,ADDRESS1,ADDRESS2,POSTCODE,TOTAL_FLOOR_AREA,LODGEMENT_DATE\n1,1 Mill Lane,,RG40 3QU,80.0,2015-01-01\n2,1 Mill Lane,,RG40 3QU,82.0,2022-05-01\n3,\"Flat 2, Oak House\",Church Road,RG40 3QW,55,2020-01-01\n4,bad row,,RG40 3QW,,2020-01-01\n"
        st = epcfile.load_bytes(text.encode(), "certificates.csv")
        assert st["keys"] >= 2 and st["files"][0]["certificates"] == 3
        # the newest certificate for an address wins
        assert abs(epcfile.areas()["1milllanerg403qu"] - 82.0 * 10.7639) < 0.5
        sales = [{"saon": "", "paon": "1", "street": "Mill Lane", "postcode": "RG40 3QU", "price": 450000.0}, {"saon": "", "paon": "9", "street": "Nowhere Road", "postcode": "RG40 3QU", "price": 300000.0}]
        assert comps.attach_areas(sales, epcfile.areas()) == 1 and sales[0]["psf"] == round(450000 / (82.0 * 10.7639))
        # zip of csvs, and a file that is not a certificate file
        z = io.BytesIO()
        import zipfile
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("la/certificates.csv", "address_line_1,postcode,total_floor_area\n5 High St,RG12 1AA,90\n")
            zf.writestr("la/recommendations.csv", "x,y\n1,2\n")
        assert epcfile.load_bytes(z.getvalue(), "la.zip")["keys"] >= 3
        try:
            epcfile.load_bytes(b"a,b\n1,2\n", "x.csv")
            assert False
        except ValueError:
            pass
        epcfile.clear()
        assert epcfile.status()["keys"] == 0
    finally:
        epcfile.PATH = old
        epcfile._cache = None


def test_mayoral_cil_by_borough_and_apply():
    assert levies.mayoral("Westminster")["band"] == 1 and levies.mayoral("Hackney")["band"] == 2 and levies.mayoral("Bexley")["band"] == 3
    assert levies.mayoral("Kensington & Chelsea")["band"] == 1 and levies.mayoral("Wokingham") is None and levies.mayoral("") is None
    assert abs(levies.mayoral("Hackney")["rate_sqft"] - 72.73 / 10.7639) < 0.01
    import test_v08 as t
    s = t.post("/api/site", {"site": {"id": t.SID, "la": "Hackney"}})
    r = t.post("/api/levies/apply", {"id": t.SID, "key": "cil_psf", "value": 10, "mayoral": True, "source": "x"})
    assert r["mayoral"]["band"] == 2
    ov = [x for x in t.post("/api/levies/get", {"id": t.SID})["current"].items() if x[0] == "cil_psf"][0][1]["value"]
    assert abs(ov - (10 + 72.73 / 10.7639)) < 0.01
    t.post("/api/levies/clear", {"id": t.SID, "key": "cil_psf"})
    t.post("/api/site", {"site": {"id": t.SID, "la": "Wokingham"}})


def test_costplan_switch_sheet_without_reupload():
    import base64
    import openpyxl
    import test_v08 as t
    wb = openpyxl.Workbook()
    a = wb.active
    a.title = "Summary"
    a.append(["Description", "Total"])
    a.append(["Construction", 1000000])
    a.append(["Fees", 100000])
    b2 = wb.create_sheet("Detail")
    b2.append(["Description", "Total"])
    b2.append(["Foundations", 300000])
    b2.append(["Frame", 700000])
    buf = io.BytesIO()
    wb.save(buf)
    r = t.post("/api/costplan/read", {"id": t.SID, "name": "plan.xlsx", "data": base64.b64encode(buf.getvalue()).decode(), "sheet": "Summary"})
    assert r["sheet"] == "Summary" and {x["name"] for x in r["sheets"]} == {"Summary", "Detail"}
    r2 = t.post("/api/costplan/read", {"id": t.SID, "sheet": "Detail"})
    assert r2["sheet"] == "Detail" and [x["label"] for x in r2["items"]] == ["Foundations", "Frame"]
    t.post("/api/costplan/clear", {"id": t.SID})


def test_area_search_falls_back_when_planit_is_down():
    from core import areasearch, datasources as ds
    realp, realh = ds.planit, ds._http
    def boom(*a, **k):
        raise RuntimeError("HTTP 403")
    def http(url, headers=None, timeout=15, ttl=0, text=False):
        if "dataset=planning-application" in url:
            return {"entities": [{"entity": 77, "reference": "24/0001", "description": "Erection of 24 dwellings", "point": "POINT (-0.13 51.51)", "decision": "approved", "decision-date": "2025-01-10"}]}
        return {"entities": []}
    ds.planit, ds._http = boom, http
    try:
        res = areasearch.run({"lat": 51.5074, "lon": -0.1278, "radius_km": 3, "sources": ["planit"], "exclude": []}, {})
        assert any("PlanIt could not be reached" in n for n in res["notes"]), res["notes"]
        assert any(c["source"] == "planning.data.gov.uk" and c["units"] == 24 for c in res["candidates"] + []) or res["considered"] >= 1
    finally:
        ds.planit, ds._http = realp, realh


def test_bad_requests_are_client_errors_not_server_errors():
    import json
    import urllib.error
    import urllib.request
    import test_v08 as t
    def call(path, body):
        req = urllib.request.Request(t.B + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        try:
            return urllib.request.urlopen(req).status
        except urllib.error.HTTPError as e:
            return e.code
    assert call("/api/site", {}) == 400
    assert call("/api/dd/get", {"id": "no-such-site"}) == 404
    assert call("/api/typology/get", {"id": "no-such-site"}) == 404


def test_residential_sdlt_basis():
    from core import tax
    assert abs(tax.sdlt(500_000, "residential") - 40_000) < 1
    assert abs(tax.sdlt(500_000) - (100_000 * 0.02 + 250_000 * 0.05)) < 1  # non-res: 0-150k nil, 150-250k 2%, above 5%
    assert tax.clean({"sdlt_basis": "residential"})["sdlt_basis"] == "residential"
    assert "sdlt_basis" not in tax.clean({"sdlt_basis": "bogus"})


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("test_")]

if __name__ == "__main__":
    bad = 0
    for t in TESTS:
        try:
            t()
            print("ok  ", t.__name__)
        except Exception as e:
            bad += 1
            print("FAIL", t.__name__, repr(e))
    sys.exit(1 if bad else 0)
