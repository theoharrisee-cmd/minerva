"""v0.5: scenarios, break-even, replies, feed, report, deck, views and downloads through the HTTP API."""
import json, os, pathlib, sys, tempfile, threading, urllib.request, zipfile, io

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="ed-test5-")
os.environ.update(MINERVA_HOME=TMP, MINERVA_NO_OPEN="1", MINERVA_DOWNLOADS=TMP + "/dl")

import server  # noqa: E402

httpd = server.make_server(0)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{httpd.server_address[1]}"
SID = "rich-millpond"


def post(p, b=None):
    r = urllib.request.Request(B + p, data=json.dumps(b or {}).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        return json.loads(urllib.request.urlopen(r, timeout=60).read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


def get(p):
    return json.loads(urllib.request.urlopen(B + p, timeout=60).read())


def raw(p):
    r = urllib.request.urlopen(B + p, timeout=90)
    return r.read(), r.headers


def test_scenarios_and_breakeven():
    r = post("/api/scenarios", {"id": SID})
    assert len(r["rows"]) >= 3 and r["breakeven"]["land"]
    base = next(x for x in r["rows"] if x["id"] == "base")
    r2 = post("/api/scenarios", {"id": SID, "scenarios": [{"id": "base"}, {"id": "x", "name": "Mine", "sales": 3, "build": -2}], "save": True})
    assert len(r2["rows"]) == 2
    mine = next(x for x in r2["rows"] if x["id"] == "x")
    assert mine["profit"] > base["profit"]


def test_replies():
    d = post("/api/replies", {"id": SID, "kind": "officer", "text": "Dear Mr H,\nApp O/2026/1774. 1. Provide drainage strategy\n2. Confirm BNG"})
    assert d["mode"] in ("template", "claude") and d["topics"]
    assert d["placeholders"]
    post("/api/replies", {"id": SID, "op": "save", "reply": d})
    assert len(post("/api/replies", {"id": SID, "op": "list"})["items"]) == 1
    assert "error" in post("/api/replies", {"id": SID, "kind": "officer", "text": ""})


def test_feed_and_news():
    f = get("/api/feed")
    assert f["unseen"] > 0
    post("/api/feed/seen", {"all": True})
    assert get("/api/feed")["unseen"] == 0
    n = get("/api/news?nofetch=1")
    assert "items" in n and "live_sites" in n


def test_views():
    r = post("/api/views", {"view": {"name": "BTR North", "filters": {"strategy": "btr"}}})
    assert [v["name"] for v in r["views"]] == ["BTR North"]
    r = post("/api/views", {"op": "delete", "vid": r["views"][0]["id"]})
    assert r["views"] == []


def test_report_deck_committee():
    b, h = raw(f"/report/{SID}")
    assert b"easyDevelopment" in b and "text/html" in h["Content-Type"]
    b, _ = raw(f"/download/deck/{SID}.pptx")
    assert zipfile.is_zipfile(io.BytesIO(b))
    from pptx import Presentation
    assert len(Presentation(io.BytesIO(b)).slides) >= 8
    b, _ = raw(f"/download/committee/{SID}.docx")
    assert zipfile.is_zipfile(io.BytesIO(b))
    assert post("/api/deck/save", {"id": SID})


def test_every_demo_site_renders():
    for x in ("rich-kingsfield", "rich-harbour", "rich-infirmary"):
        assert len(raw(f"/report/{x}")[0]) > 2000
        assert len(raw(f"/download/deck/{x}.pptx")[0]) > 10000


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f()
            print("ok", n)
