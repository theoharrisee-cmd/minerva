"""v0.8: programme, funding, comparables, planning strategy, history and the deal room."""
import json, os, pathlib, sys, tempfile, threading, urllib.request
from datetime import date

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="ed-test8-")
os.environ.update(MINERVA_HOME=TMP, MINERVA_NO_OPEN="1", MINERVA_DOWNLOADS=TMP + "/dl")

import server  # noqa: E402
from core import appraisal, compset, funding, history, packs, programme, strategy  # noqa: E402
from core.config import DEFAULT_ASSUMPTIONS as A0  # noqa: E402

httpd = server.make_server(0)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{httpd.server_address[1]}"
SID = "rich-millpond"


def post(p, b=None):
    r = urllib.request.Request(B + p, data=json.dumps(b or {}).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        return json.loads(urllib.request.urlopen(r, timeout=90).read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


def raw(p):
    r = urllib.request.urlopen(B + p, timeout=90)
    return r.read(), r.headers


def site():
    return server.site_by_id(SID)


BASE = {"site_ha": 2, "asking_price": 3e6, "units": 40, "strategy": "develop_sell", "sales_psf": 520}


# ---------------------------------------------------------------- programme

def test_programme_off_matches_standard_timing():
    a = appraisal.appraise(BASE)
    b = appraisal.appraise({**BASE, "programme": {}})
    assert abs(a["profit"] - b["profit"]) < 1e-6 and a["cashflow"][0].keys() >= {"levered", "unlevered", "debt", "draw"}


def test_programme_moves_cash():
    base = appraisal.appraise(BASE)
    p = appraisal.appraise({**BASE, "programme": {"planning_months": 12, "precon_months": 6, "build_months": 20, "sales_months": 9}})
    tl = programme.timeline(p["programme"])
    assert tl["grant"] == 12 and tl["build_start"] == 19 and tl["pc"] == 38 and len(p["cashflow"]) == tl["n"]
    assert p["profit"] < base["profit"] and p["months_land"] > base["months_land"]
    assert abs(sum(r["unlevered"] for r in p["cashflow"]) - sum(sum(r[k] for k in ("land", "fees", "build", "statutory", "receipts")) for r in p["cashflow"])) < 1e-3
    # conditional land: deposit now, balance at grant, and the land is financed for less time
    c = appraisal.appraise({**BASE, "programme": {"planning_months": 12, "land_mode": "conditional", "land_deposit_pct": 10}})
    assert abs(c["cashflow"][0]["land"] + c["land_cost"] * 0.1) < 1 and abs(c["cashflow"][12]["land"] + c["land_cost"] * 0.9) < 1
    assert c["months_land"] < appraisal.appraise({**BASE, "programme": {"planning_months": 12}})["months_land"]
    # presales bring receipts to practical completion
    ps = appraisal.appraise({**BASE, "programme": {"presale_pct": 40}})
    pc = programme.timeline(ps["programme"])["pc"]
    assert abs(ps["cashflow"][pc]["receipts"] - 0.4 * ps["net_value"]) < 1


def test_delay_cost_and_clean():
    d = programme.delay_table(BASE, A0, "develop_sell", appraise=appraisal.appraise)
    assert [r["delay"] for r in d["rows"]] == [0, 3, 6, 12] and d["rows"][3]["cost"] > d["rows"][1]["cost"] > 0 and d["per_month"] > 0
    assert programme.clean({"planning_months": 999, "presale_pct": 30, "land_mode": "x", "start": "2027-13"}) == {"planning_months": 84, "presale_pct": 0.3}
    d2 = programme.delay_table({**BASE, "programme": {"planning_months": 6}}, A0, "develop_sell", appraise=appraisal.appraise)
    assert d2["rows"][1]["cost"] > 0


def test_programme_route():
    r = post("/api/programme/get", {"id": SID})
    assert r["timeline"]["n"] == len(r["rows"]) and r["delay"]["rows"] and not r["custom"]
    r = post("/api/programme/save", {"id": SID, "programme": {"planning_months": 10, "precon_months": 5, "start": "2027-01"}})
    assert r["custom"] and r["programme"]["source"]["planning_months"] == "set" and r["rows"][0]["label"] == "Jan 2027"
    assert site()["programme"]["planning_months"] == 10
    assert post("/api/programme/save", {"id": SID, "clear": True})["custom"] is False and "programme" not in site()
    assert "error" in post("/api/programme/get", {"id": "nope"})


# ---------------------------------------------------------------- funding

def test_equity_first_and_exit_fee():
    pr = appraisal.appraise({**BASE})
    ef = appraisal.appraise({**BASE}, {**A0, "draw_mode": "equity_first"})
    assert ef["peak_equity"] > pr["peak_equity"] * 0.9
    fl = [r["unlevered"] for r in ef["cashflow"]]
    first_draw = next(i for i, r in enumerate(ef["cashflow"]) if r["draw"] > 0)
    assert first_draw > 0 or ef["cashflow"][0]["draw"] == 0  # equity goes in before the loan
    xf = appraisal.appraise({**BASE}, {**A0, "exit_fee_pct": 0.02})
    assert xf["exit_fees"] > 0 and xf["equity_profit"] < pr["equity_profit"]
    # the loan is always repaid in full
    assert abs(ef["cashflow"][-1]["debt"]) < 1e3


def test_funding_route_and_termsheet():
    r = post("/api/funding/get", {"id": SID})
    assert r["compare"][0]["name"] == "No debt" and r["compare"][-1]["current"] and r["sources_uses"]["uses"] and r["request"]["senior"] > 0
    nodebt, senior = r["compare"][0], r["compare"][2]
    assert senior["peak_equity"] < nodebt["peak_equity"]
    r = post("/api/funding/save", {"id": SID, "terms": {"ltc": 55, "mezz_ltc": 10, "finance_rate": 9.25, "draw_mode": "equity_first", "exit_fee_pct": 1}})
    assert abs(r["terms"]["ltc"] - 0.55) < 1e-9 and r["terms"]["draw_mode"] == "equity_first" and abs(r["terms"]["finance_rate"] - 0.0925) < 1e-9
    assert site()["ovr"]["ltc"] == 0.55 and site()["funding"]["exit_fee_pct"] == 0.01
    assert "error" in post("/api/funding/save", {"id": SID, "terms": {"ltc": 80, "mezz_ltc": 20}})
    body, h = raw(f"/download/termsheet/{SID}.docx")
    assert body[:2] == b"PK" and "docx" in h["Content-Disposition"]
    import zipfile, io, re
    xml = zipfile.ZipFile(io.BytesIO(body)).read("word/document.xml").decode()
    txt = re.sub(r"<[^>]+>", " ", xml)
    assert "Senior facility" in txt and "[Special purpose vehicle" in txt and "Exit fee" in txt
    site()["ovr"].pop("ltc"); site()["ovr"].pop("mezz_ltc"); site()["ovr"].pop("finance_rate"); site().pop("funding")


def test_excel_ignores_programme():
    s = site()
    s["programme"] = {"planning_months": 20}
    try:
        assert server.model_bytes(s)[:2] == b"PK"
    finally:
        s.pop("programme")


# ---------------------------------------------------------------- comparables

def fake_sales():
    out = []
    for i in range(12):
        out.append({"paon": str(i + 1), "saon": "", "street": "Mill Lane", "town": "Wokingham", "postcode": f"RG40 3{chr(65 + i % 4)}{chr(65 + i % 3)}", "price": 300000 + i * 5000, "date": f"2026-0{1 + i % 8}-15",
                    "type": "Terraced", "new_build": i % 4 == 0, "tenure": "Freehold", **({"sqft": 900, "psf": round((300000 + i * 5000) / 900)} if i % 2 == 0 else {})})
    for i in range(6):
        out.append({"paon": str(i + 1), "saon": "Flat", "street": "High St", "town": "Wokingham", "postcode": "RG40 3AA", "price": 210000 + i * 4000, "date": "2026-03-01", "type": "Flat / maisonette", "new_build": False, "tenure": "Leasehold"})
    out.append({"paon": "9", "saon": "", "street": "Far Rd", "town": "x", "postcode": "RG40 3ZZ", "price": 999999, "date": "2019-03-01", "type": "Terraced", "new_build": False, "tenure": "Freehold"})
    return out


def fake_geocoder(pcs):
    return {pc: (51.41 + 0.002 * (i % 5), -0.83 + 0.002 * (i % 7)) for i, pc in enumerate(sorted(set(pcs)))}


def test_compset_adjustments():
    s = {"lat": 51.41, "lon": -0.83, "data_pack": {"hpi": {"annual": 3.0}}}
    cs = compset.ingest(s, {"sales": fake_sales(), "sector": "RG40 3", "months": 24}, fake_geocoder)
    assert len(cs["sales"]) == 19 and all(x["id"] for x in cs["sales"]) and cs["geocoded"] > 0 and any(x.get("dist_km") is not None for x in cs["sales"])
    f = compset.factors(s)
    assert abs(f["values"]["growth_pa"] - 0.03) < 1e-9 and f["source"]["growth_pa"] == "house price index"
    today = date(2026, 9, 21)
    r = compset.value_for(s, "Terraced", 950, today)
    assert r["n"] >= 8 and 280000 < r["value"] < 420000 and r["low"] <= r["value"] <= r["high"]
    statuses = {x["status"] for x in r["rows"]}
    assert "out of range" in statuses  # the 2019 sale is older than 36 months
    used = next(x for x in r["rows"] if x["status"] == "used" and not x["new_build"])
    assert any("New build premium" in st["label"] for st in used["steps"])
    # switching a sale off, and raising the premium, both move the answer
    before = r["value"]
    s["comp_set"]["adj"] = compset.clean_adj({"newbuild_premium": 20})
    assert compset.value_for(s, "Terraced", 950, today)["value"] > before
    s["comp_set"]["off"] = [x["id"] for x in s["comp_set"]["sales"] if x["type"] == "Terraced"][:9]
    assert compset.value_for(s, "Terraced", 950, today)["n"] < r["n"]
    assert "value" not in compset.value_for(s, "Detached", 1200, today)
    assert compset.clean_adj({"newbuild_premium": 500, "max_km": 0}) == {"newbuild_premium": 0.5, "max_km": 0.2}


def test_compset_routes_and_pricing():
    s = site()
    compset.ingest(s, {"sales": fake_sales(), "sector": "RG40 3", "months": 24, "fetched": "2026-09-21"}, fake_geocoder)
    s["lat"], s["lon"] = 51.41, -0.83
    for x in s["comp_set"]["sales"]:  # recent enough for the fixed test date
        x["date"] = "2026-06-15"
    try:
        r = post("/api/compset/get", {"id": SID})
        assert r["has"] and r["subjects"] and r["factors"]["values"]["max_months"] == 36
        assert any(sub["class"] == "Terraced" or sub["class"] == "Flat / maisonette" for sub in r["subjects"])
        r2 = post("/api/compset/save", {"id": SID, "adj": {"newbuild_premium": 15}})
        assert abs(r2["factors"]["values"]["newbuild_premium"] - 0.15) < 1e-9 and r2["factors"]["source"]["newbuild_premium"] == "set"
        sid0 = s["comp_set"]["sales"][1]["id"]
        r3 = post("/api/compset/save", {"id": SID, "toggle": sid0})
        assert sid0 in r3["off"] and sid0 not in post("/api/compset/save", {"id": SID, "toggle": sid0})["off"]
        m = post("/api/homes/market", {"id": SID})
        assert m["units"] and any("adjusted comparables" in (u.get("basis") or "") for u in m["units"] if u.get("sale_value"))
        assert post("/api/compset/save", {"id": SID, "reset": True})["factors"]["source"]["newbuild_premium"] == "default"
    finally:
        s.pop("comp_set", None)


# ---------------------------------------------------------------- planning strategy

def test_strategy_rules():
    a = dict(A0)
    site_ = {"units": 150, "site_ha": 4.8, "planning_status": "Allocated", "consultees": [{"body": "Highways", "stance": "Object", "summary": "junction at 96% capacity"},
             {"body": "Natural England", "stance": "Conditions", "summary": "SANG"}, {"body": "Lead local flood authority", "stance": "Support", "summary": "ok"}]}
    track_ = {"ok": True, "approval_rate": 0.75, "approved": 9, "refused": 3, "median_days": 190, "months_to_decide": 6.2, "radius_km": 8, "precedents": [{"ref": "P/1"}, {"ref": "P/2"}]}
    pol = {"checks": [{"id": "ndss_gia", "title": "Gross internal area", "status": "fail", "detail": "Short"}, {"id": "outdoor", "title": "Outdoor space", "status": "pass", "detail": ""}]}
    st = strategy.build(site_, {}, track_, pol, a)
    assert st["level"] in ("Medium", "High") and st["score"] >= 5 and any("Major" in f["label"] for f in st["factors"])
    assert "Pre-application" in st["route"]["title"] and any("P/1" in x["text"] for x in st["arguments"])
    assert any(c["topic"] == "Highways" and "Transport" in c["mitigation"] for c in st["concerns"]) and st["concerns"][0]["level"] == "High"
    assert st["timeline"]["total_months"] >= 10 and any("Determination" in x["stage"] for x in st["timeline"]["stages"])
    gb = strategy.build({"units": 30, "planning_status": "Unallocated"}, {"flags": {"green_belt": True}}, None, None, a)
    assert "Green Belt" in gb["route"]["title"] and any(f["label"] == "Green Belt" for f in gb["factors"])
    done = strategy.build({"units": 30, "planning_status": "Consented"}, {}, None, None, a)
    assert "Implement" in done["route"]["title"] and done["timeline"]["total_months"] == 0
    small = strategy.build({"units": 4, "planning_status": "Unallocated"}, {}, None, None, a)
    assert small["level"] == "Low" and small["route"]["title"].startswith("Submit")


def test_strategy_routes():
    r = post("/api/strategy/get", {"id": SID})
    assert r["route"]["title"] and r["factors"] and r["concerns"] and r["timeline"]["total_months"] > 0
    r = post("/api/strategy/apply", {"id": SID})
    assert r["applied"] and site()["programme"]["planning_months"] == r["timeline"]["total_months"]
    site().pop("programme")
    body, h = raw(f"/download/strategy/{SID}.docx")
    import zipfile, io, re
    txt = re.sub(r"<[^>]+>", " ", zipfile.ZipFile(io.BytesIO(body)).read("word/document.xml").decode())
    assert "Recommended route" in txt and "Likely concerns" in txt


# ---------------------------------------------------------------- history

def test_history_records_and_diffs():
    s = site()
    s.pop("history", None)
    r = post("/api/history/get", {"id": SID})
    assert r["versions"] == []
    post("/api/site", {"site": {"id": SID, "asking_price": (s.get("asking_price") or 5600000) + 250000}})
    post("/api/programme/save", {"id": SID, "programme": {"planning_months": 14}})
    post("/api/programme/save", {"id": SID, "programme": {"planning_months": 14}})  # no change, no new version
    v = post("/api/history/get", {"id": SID})["versions"]
    assert [x["label"] for x in v] == ["Before the first recorded change", "Site details edited", "Programme changed"]
    d = post("/api/history/diff", {"id": SID, "a": 0, "b": "now"})
    labels = {c["label"] for c in d["changes"]}
    assert "Asking price" in labels and "Programme: Planning to grant" in labels
    groups = {p["group"] for p in d["attribution"]}
    assert {"pricing", "programme"} <= groups
    tot = sum(p["profit_change"] for p in d["attribution"])
    prof = next(m for m in d["metrics"] if m["key"] == "profit")
    assert abs(tot - prof["delta"]) < 1.0
    assert all(p["profit_change"] < 0 for p in d["attribution"])  # a dearer site and a longer wait both cost profit
    tl = post("/api/history/get", {"id": SID})["timeline"]
    assert tl[0]["kind"] in ("version", "event") and any(t["kind"] == "version" for t in tl)
    assert "error" in post("/api/history/diff", {"id": SID, "a": 99})
    st = server.public_state()
    assert all("history" not in row for row in st["sites"]) if "sites" in st else True
    s["asking_price"] = s["asking_price"] - 250000
    s.pop("programme", None)
    s.pop("history", None)


def test_history_caps_and_labels():
    site_ = {"asking_price": 1, "units": 5}
    for i in range(80):
        site_["asking_price"] = 1000 + i
        history.record(site_, "x", lambda s: {"appraisal": {"profit": i}})
    assert len(site_["history"]) == history.KEEP and site_["history"][0]["headline"]["profit"] == 0
    assert history.label_for("/api/typology/unit") == "Homes schedule changed" and history.label_for("/api/zzz") == "Edited"


# ---------------------------------------------------------------- packs

def _text_docx(b):
    import zipfile, io, re
    return re.sub(r"<[^>]+>", " ", zipfile.ZipFile(io.BytesIO(b)).read("word/document.xml").decode())


def test_pack_report_sections_and_brand():
    s = site()
    s["programme"] = {"planning_months": 9, "precon_months": 3}
    try:
        r = post("/api/pack/get", {"id": SID, "kind": "report"})
        titles = [x["title"] for x in r["sections"]]
        assert "Programme and cash flow" in titles and "Planning strategy" in titles and "Funding package" in titles and "Appraisal" in titles
        assert "Programme and cash flow" in r["html"] and "Delay to consent" in r["html"]
        ids = [x["id"] for x in r["sections"]]
        order = list(reversed(ids))
        off = ["planning-strategy"]
        r2 = post("/api/pack/save", {"id": SID, "kind": "report", "opts": {"order": order, "off": off}})
        assert [x["id"] for x in r2["sections"]][0] == order[0] and next(x for x in r2["sections"] if x["id"] == "planning-strategy")["on"] is False
        assert "<h2>Planning strategy</h2>" not in r2["html"] and r2["html"].index(f"<h2>{r2['sections'][0]['title']}</h2>") < r2["html"].index(f"<h2>{r2['sections'][1]['title']}</h2>") if r2["sections"][0]["on"] and r2["sections"][1]["on"] else True
        body, _ = raw(f"/report/{SID}.html") if False else (None, None)
        post("/api/brand/save", {"name": "Derwent Land", "accent": "#0a6640"})
        html_ = post("/api/pack/get", {"id": SID, "kind": "report"})["html"]
        assert "Derwent Land" in html_ and "#0A6640" in html_ and "#FF6600" not in html_
        assert server.STATE["brand"]["accent"] == "#0A6640"
        assert packs.brand_of({"name": "<b>x</b>", "accent": "red"}) == {"name": "bx/b", "accent": "#FF6600"}
    finally:
        s.pop("programme", None)
        s.get("pack_opts", {}).pop("report", None)
        post("/api/brand/save", {"name": "", "accent": ""})


def test_deck_and_committee_carry_programme_funding_strategy():
    s = site()
    import io
    from pptx import Presentation
    post("/api/programme/save", {"id": SID, "programme": {"precon_months": 6, "build_months": 18}})
    post("/api/funding/save", {"id": SID, "ovr": {"ltc": 0.6}})
    try:
        prs = Presentation(io.BytesIO(server.deck_bytes(s, opts={})))
        titles = [sh.text_frame.text for sl in prs.slides for sh in sl.shapes if sh.has_text_frame]
        assert "Programme and funding" in titles and "Planning strategy" in titles
        t = _text_docx(server.committee_bytes(s, opts={}))
        assert "Funding package options" in t and "Programme" in t
    finally:
        s.pop("programme", None)
        s.pop("funding", None)


def test_pack_word_and_deck_arrangement():
    s = site()
    try:
        c = post("/api/pack/get", {"id": SID, "kind": "committee"})
        ids = [x["id"] for x in c["sections"]]
        assert "recommendation" in ids and "financial-appraisal" in ids and c["outline"]
        r = post("/api/pack/save", {"id": SID, "kind": "committee", "opts": {"order": ["financial-appraisal", "recommendation"], "off": ["due-diligence-status"]}})
        secs = [x["id"] for x in r["sections"]]
        assert secs[0] == "financial-appraisal" and secs[1] == "recommendation" and [x for x in r["sections"] if x["id"] == "due-diligence-status"][0]["on"] is False
        body = server.committee_bytes(s)
        t = _text_docx(body)
        assert "Due diligence status" not in t and t.index("Financial appraisal") < t.index("Recommendation")
        assert "1. Financial appraisal" in t.replace("  ", " ") or "1. Financial" in t
        d = post("/api/pack/get", {"id": SID, "kind": "deck"})
        assert d["sections"] and d["outline"][0]["title"] and any(o["title"] == "Recommendation" for o in d["outline"])
        first = d["sections"][0]["id"]
        post("/api/pack/save", {"id": SID, "kind": "deck", "opts": {"order": [], "off": [first]}})
        post("/api/brand/save", {"name": "Derwent Land", "accent": "#0a6640"})
        from pptx import Presentation
        import io
        prs = Presentation(io.BytesIO(server.deck_bytes(s)))
        n_all = len(Presentation(io.BytesIO(server.deck_bytes(s, opts={}))).slides)
        assert len(prs.slides) == n_all - 1
        txt = " ".join(sh.text_frame.text for sl in prs.slides for sh in sl.shapes if sh.has_text_frame)
        assert "Derwent Land" in txt and "easyDevelopment" not in txt
        nums = [sh.text_frame.text for sl in list(prs.slides)[1:] for sh in sl.shapes if sh.has_text_frame and sh.text_frame.text.isdigit()]
        assert nums[:3] == ["2", "3", "4"]
        b = post("/api/pack/get", {"id": SID, "kind": "brief"})
        assert b["sections"] and b["outline"]
        assert "error" in post("/api/pack/get", {"id": SID, "kind": "zzz"})
    finally:
        s.get("pack_opts", {}).clear()
        post("/api/brand/save", {"name": "", "accent": ""})


if __name__ == "__main__":
    fails = 0
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            try:
                f(); print("ok  ", n)
            except Exception as e:
                import traceback; traceback.print_exc(); fails += 1; print("FAIL", n, e)
    sys.exit(1 if fails else 0)
