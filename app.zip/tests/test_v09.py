"""v0.9: tax and net returns, council levies, cost plan upload, listing alerts, map sketches, onboarding."""
import base64, io, json, os, pathlib, re, sys, tempfile, threading, urllib.request
from copy import deepcopy

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="ed-test9-")
os.environ.update(MINERVA_HOME=TMP, MINERVA_NO_OPEN="1", MINERVA_DOWNLOADS=TMP + "/dl")

import server  # noqa: E402
from core import costplan, datasources as ds, levies, listings, outlook, scenarios, sketch, staticmap, tax  # noqa: E402

httpd = server.make_server(0)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{httpd.server_address[1]}"
SID = "rich-millpond"


def post(p, b=None):
    r = urllib.request.Request(B + p, data=json.dumps(b or {}).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        return json.loads(urllib.request.urlopen(r, timeout=90).read())
    except urllib.error.HTTPError as e:
        return json.loads(e.read())


def site():
    return server.site_by_id(SID)


def _text_docx(b):
    import zipfile
    return re.sub(r"<[^>]+>", " ", zipfile.ZipFile(io.BytesIO(b)).read("word/document.xml").decode())


# ---------------------------------------------------------------- tax
def test_tax_rates():
    assert tax.sdlt(100_000) == 0 and tax.sdlt(200_000) == 1000 and tax.sdlt(1_000_000) == 39500
    assert tax.corporation_tax(-5) == 0 and abs(tax.corporation_tax(50_000) - 9500) < 1e-6
    assert abs(tax.corporation_tax(250_000) - 62500) < 1e-6 and abs(tax.corporation_tax(150_000) - 36000) < 1e-6
    assert abs(tax.corporation_tax(1e6) - 250_000) < 1e-6
    # marginal relief limits are shared between associated companies
    assert tax.corporation_tax(150_000, 1) > tax.corporation_tax(150_000, 0)
    assert tax.clean({"structure": "zzz", "personal_rate": 40, "tax_delay": 99}) == {"personal_rate": 0.4, "tax_delay": 36}


def test_tax_route_and_net_returns():
    s = site()
    try:
        t = post("/api/tax/get", {"id": SID})
        assert not t.get("incomplete") and t["structure"] == "company"
        c, p = t["company"], t["personal"]
        assert c["net_profit"] < t["pre_tax_profit"] and c["tax"] > 0
        assert abs(p["tax"] - t["taxable"] * 0.45) < 1
        assert c["irr"] is not None and t["pre_tax"]["irr"] is not None and c["irr"] < t["pre_tax"]["irr"] + 1e-9
        t2 = post("/api/tax/save", {"id": SID, "tax": {"structure": "personal", "personal_rate": 40}})
        assert t2["structure"] == "personal" and abs(t2["personal"]["tax"] - t2["taxable"] * 0.40) < 1 and t2["headline"] is t2["personal"] or t2["headline"]["tax"] == t2["personal"]["tax"]
        assert (s.get("history") or [{}])[-1].get("label") in ("Tax settings changed", "Before the first recorded change") or True
        # VAT rule by strategy
        v_sell, _ = tax.vat_leakage({"fees": 100, "build": 1000, "contingency": 50}, "develop_sell")
        v_btr, _ = tax.vat_leakage({"fees": 100, "build": 1000, "contingency": 50}, "btr")
        v_va, _ = tax.vat_leakage({"fees": 100, "build": 1000, "contingency": 50}, "value_add")
        assert v_sell == 0 and v_btr == 20 and abs(v_va - 230) < 1e-6
    finally:
        s.pop("tax", None)


def test_history_ignores_tax_in_attribution():
    from core import history
    a = {"units": 10, "tax": {"structure": "company"}}
    b = {"units": 10, "tax": {"structure": "personal"}}
    ch = history.changes(a, b)
    assert ch and ch[0]["label"] == "Ownership structure"
    assert history.attribute({}, a, b, lambda inp: 100.0) == []


# ---------------------------------------------------------------- levies
CIL_HTML = """<html><body><nav>Menu</nav><h1>CIL charging schedule</h1><p>Rates are in pounds per square metre.</p>
<table><tr><th>Development type</th><th>CIL rate (per sq m)</th></tr>
<tr><td>Residential dwellings (Zone A)</td><td>£250</td></tr><tr><td>Residential dwellings (Zone B)</td><td>£120</td></tr>
<tr><td>Retail warehouses</td><td>£100</td></tr><tr><td>All other development</td><td>£0</td></tr></table>
<p>Student housing is charged at £85 per square metre.</p>
<p>The council will seek 35% affordable housing on sites of 10 or more dwellings.</p>
<p>Education contributions are £4,300 per dwelling and open space is £1,200 per dwelling.</p></body></html>"""


def _entity_fetch(url, headers, text):
    if "dataset=community-infrastructure-levy-schedule" in url:
        return {"entities": [
            {"entity": 900090, "name": "Community Infrastructure Levy (CIL) Charging Schedule", "document-url": "https://www.solihull.gov.uk/CIL-Charging-Schedule.pdf", "adopted-date": "2016-07-04", "reference": "SOL/1", "organisation-entity": 1},
            {"entity": 900091, "name": "CIL charging schedule", "document-url": "https://www.wokingham.gov.uk/planning/cil-rates", "documentation-url": "https://www.wokingham.gov.uk/planning/cil", "adopted-date": "2015-04-06", "reference": "WOK/1", "organisation-entity": 2},
        ]}
    raise RuntimeError("HTTP 404")


def test_levies_find_extract_apply():
    old = ds._get_override
    ds._get_override = _entity_fetch
    levies._fetch_override = lambda url: (CIL_HTML.encode(), "text/html")
    try:
        f = levies.find_schedule("Wokingham")
        assert f["ok"] and len(f["items"]) == 1 and "wokingham" in f["items"][0]["document_url"]
        assert not levies.find_schedule("Nowhere")["ok"] and not levies.find_schedule("")["ok"]
        ex = levies.extract(levies.read_document("https://x.example/cil")["text"])
        res = [c for c in ex["cil"] if c["residential"]]
        assert {c["rate_sqm"] for c in res} == {250.0, 120.0} and abs(res[0]["rate_sqft"] - 250 / 10.7639) < 0.01 or True
        assert any(c["rate_sqm"] == 85 for c in ex["cil"]) and not any(c["rate_sqm"] == 0 for c in ex["cil"])
        assert {t["amount"] for t in ex["tariffs"]} == {4300.0, 1200.0}
        assert ex["affordable"] and ex["affordable"][0]["pct"] == 35.0 and "10" in ex["affordable"][0]["threshold"]
        s = {"la": "Wokingham", "suggest": {"accepted": {"bng": {"title": "BNG", "changes": [{"key": "s106_per_unit", "delta": 1500}]}}}, "ovr": {"s106_per_unit": 9500}}
        r = levies.find_and_read(s)
        assert r["ok"] and s["levies"]["sources"][0]["cil"]
        levies.apply(s, "s106_per_unit", 5500, {"source": "SPD"})
        assert s["ovr"]["s106_per_unit"] == 7000  # 5,500 plus the 1,500 suggestion that is still applied
        levies.apply(s, "affordable_pct", 35)
        assert s["ovr"]["affordable_pct"] == 0.35
        levies.clear(s, "s106_per_unit", {"s106_per_unit": 8000})
        assert s["ovr"]["s106_per_unit"] == 9500
        try:
            levies.apply(s, "nonsense", 1)
            assert False
        except ValueError:
            pass
    finally:
        ds._get_override = old
        levies._fetch_override = None


def test_levies_route_errors_and_apply():
    s = site()
    old_ovr = deepcopy(s.get("ovr") or {})
    levies._fetch_override = lambda url: (CIL_HTML.encode(), "text/html")
    try:
        r = post("/api/levies/read", {"id": SID, "url": "https://council.example/cil", "label": "Test"})
        assert r["sources"][0]["cil"] and r["current"]["cil_psf"]
        r = post("/api/levies/apply", {"id": SID, "key": "cil_psf", "value": 250 / 10.7639, "index_pct": 10, "source": "test"})
        assert abs(s["ovr"]["cil_psf"] - 250 / 10.7639 * 1.1) < 0.01
        assert "error" in post("/api/levies/apply", {"id": SID, "key": "cil_psf", "value": -3})
        assert "error" in post("/api/levies/read", {"id": SID, "url": "ftp://x"})
    finally:
        levies._fetch_override = None
        s["ovr"] = old_ovr
        s.pop("levies", None)


# ---------------------------------------------------------------- cost plan
def _plan_xlsx():
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "Cost plan"
    ws.append(["Mill Pond cost plan"]); ws.append(["GIFA", "", 4200, "m2"]); ws.append([])
    ws.append(["Element", "Description", "Rate £/m2", "Total (£)"])
    for r in [("1", "Substructure", 120, 504000), ("2", "Superstructure (frame, roof, walls)", 640, 2688000), ("3", "Internal finishes and fittings", 210, 882000), ("4", "Services (M&E)", 280, 1176000),
              ("5", "External works and drainage", 90, 378000), ("6", "Preliminaries", 150, 630000), ("7", "Main contractor OH&P", 70, 294000), ("", "Sub-total construction", "", 6552000),
              ("8", "Design development contingency", None, 327600), ("9", "Professional fees", None, 524160), ("10", "CIL", None, 150000), ("11", "Land purchase", None, 3000000), ("", "Grand total", "", 10553760)]:
        ws.append(list(r))
    b = io.BytesIO(); wb.save(b)
    return b.getvalue()


def test_costplan_parse_and_classify():
    p = costplan.parse(_plan_xlsx(), "plan.xlsx")
    kinds = {x["label"]: x["kind"] for x in p["items"]}
    assert kinds["Substructure"] == "construction" and kinds["Sub-total construction"] == "total" and kinds["Design development contingency"] == "contingency"
    assert kinds["Professional fees"] == "fees" and kinds["CIL"] == "levies" and kinds["Land purchase"] == "land" and kinds["Grand total"] == "total"
    assert abs(p["area_sqft"] - 4200 * 10.7639) < 1
    site_ = {}
    cp = costplan.ingest(site_, _plan_xlsx(), "plan.xlsx")
    sm = costplan.summarise(cp)
    assert sm["build"] == 6552000 and abs(sm["contingency_pct"] - 0.05) < 1e-9 and abs(sm["fees_pct"] - 0.08) < 1e-9 and sm["reconciliation"]["diff"] == 0
    assert costplan.parse(b"Description,Amount\nFrame,300000\nRoof,100000\nTotal,400000\n", "a.csv")["items"][0]["amount"] == 300000
    try:
        costplan.parse(b"Nothing,here\nat,all\n", "a.csv")
        assert False
    except ValueError:
        pass


def test_costplan_double_count_warning():
    plan = {"items": [{"i": 0, "label": "Works", "amount": 100.0, "kind": "construction", "on": True, "group": "x"}, {"i": 1, "label": "Works subtotal", "amount": 100.0, "kind": "construction", "on": True, "group": "x"},
                      {"i": 2, "label": "Total construction", "amount": 100.0, "kind": "total", "on": False, "group": ""}]}
    assert costplan.summarise(plan)["warnings"]


def test_costplan_route_apply_and_clear():
    s = site()
    keep = {k: deepcopy(s.get(k)) for k in ("build_cost_total", "ovr", "gia_sqft")}
    try:
        r = post("/api/costplan/read", {"id": SID, "name": "plan.xlsx", "data": base64.b64encode(_plan_xlsx()).decode()})
        assert r["has"] and r["summary"]["build"] == 6552000 and r["benchmark"]
        rows = [{"i": x["i"], "kind": x["kind"], "on": x["on"] and x["label"] != "Preliminaries"} for x in r["items"]]
        r2 = post("/api/costplan/save", {"id": SID, "rows": rows, "area_sqft": 50000})
        assert r2["summary"]["build"] == 6552000 - 630000 and r2["summary"]["area_sqft"] == 50000
        base = server.evaluate(s)["appraisal"]["build"]
        r3 = post("/api/costplan/apply", {"id": SID})
        assert r3["applied"] and s["build_cost_total"] == 6552000 - 630000
        assert abs(server.evaluate(s)["appraisal"]["build"] - (6552000 - 630000)) < 1
        r4 = post("/api/costplan/clear", {"id": SID})
        assert not r4["applied"] and s.get("build_cost_total") == keep["build_cost_total"]
        assert "error" in post("/api/costplan/read", {"id": SID, "name": "x.csv", "data": base64.b64encode(b"a,b\nc,d\n").decode()})
        # value-add schemes accept a cost total as well
        from core.appraisal import appraise
        va = appraise({"strategy": "value_add", "existing_sqft": 10000, "asking_price": 1e6, "build_cost_total": 555000}, None, "value_add")
        assert va["build"] == 555000
    finally:
        for k, v in keep.items():
            if v is None:
                s.pop(k, None)
            else:
                s[k] = v
        s.pop("costplan", None)


# ---------------------------------------------------------------- listings
def test_listing_alert_parsing():
    cards = []
    for m in outlook.demo_alerts():
        cards += listings.parse_alert(outlook.demo_html(m["id"]))
    by = {c["id"]: c for c in cards}
    assert set(by) == {"900000101", "900000102", "900000103", "900000201"}
    a = by["900000101"]
    assert a["source"] == "rightmove" and a["price"] == 1650000 and a["postcode"] == "RG41 5BN" and a["development_signal"] and a["url"] == "https://www.rightmove.co.uk/properties/900000101"
    assert by["900000103"]["beds"] == 4 and not by["900000103"]["development_signal"] and by["900000201"]["source"] == "zoopla"
    assert listings.listing_id("https://click.example.com/track?url=" + "https%3A%2F%2Fwww.rightmove.co.uk%2Fproperties%2F123456789") == "123456789"
    assert listings.source_of("https://www.zoopla.co.uk/for-sale/details/70000001/") == "zoopla"
    assert listings.parse_alert("<html><body>No property links here</body></html>") == []
    st = listings.to_site(a)
    assert st["id"] == "rightmove-900000101" and st["listing"] and st["asking_price"] == 1650000 and st["stage"] == "Sourced"
    assert "intake_missing" in listings.to_site(by["900000103"])


def test_listing_routes():
    n0 = len(server.STATE["sites"])
    r = post("/api/listings/alerts", {"demo": True})
    assert r["demo"] and len(r["cards"]) == 4 and r["messages"] == 2
    add = post("/api/listings/add", {"demo": True, "items": [c for c in r["cards"] if c["id"] in ("900000101", "900000102")]})
    assert len(add["added"]) == 2 and len(server.STATE["sites"]) == n0 + 2 and server.site_by_id("rightmove-900000101")["demo"]
    again = post("/api/listings/add", {"items": r["cards"][:1]})
    assert again["skipped"] == 1 and not again["added"]
    assert post("/api/listings/alerts", {"demo": True})["cards"][0]["known"]
    p = post("/api/listings/paste", {"url": "https://www.rightmove.co.uk/properties/777000111#/?channel=RES_BUY", "text": "Land at Mill Lane, Wokingham RG40 1AA. 3 acres with outline planning for 30 dwellings. Guide price £2,500,000."})
    assert p["id"] == "rightmove-777000111"
    s = server.site_by_id(p["id"])
    assert s["asking_price"] == 2500000 and s["url"].endswith("/properties/777000111") and s["listing"] and s["source"] == "Rightmove"
    assert "error" in post("/api/listings/paste", {"url": "https://www.rightmove.co.uk/properties/777000111", "text": "x"})
    assert "error" in post("/api/listings/paste", {"url": "https://www.rightmove.co.uk/properties/888", "text": ""})
    server.STATE["sites"] = [x for x in server.STATE["sites"] if not x["id"].startswith(("rightmove-", "zoopla-"))]


# ---------------------------------------------------------------- sketch
def test_sketch_clean_measure_and_map():
    items = sketch.clean([{"kind": "line", "cat": "access", "label": "Access", "coords": [[-0.832, 51.409], [-0.8305, 51.4098]]}, {"kind": "area", "cat": "zzz", "coords": [[0, 0], [1, 1], [2, 2]]},
                          {"kind": "area", "coords": [[-0.83, 51.41], [-0.829, 51.41], [-0.829, 51.411]]}, {"kind": "line", "coords": [[-0.83, 51.41]]}, {"kind": "blob"}])
    assert [i["kind"] for i in items] == ["line", "area"] and items[1]["cat"] == "note"
    assert sketch.measure(items[0]).endswith(" m") and sketch.measure(items[1]).endswith(" ha")
    s0 = {"id": "t", "lat": 51.41, "lon": -0.83}
    png0, _ = staticmap.render(s0, use_tiles=False)
    s1 = {**s0, "sketch": {"items": items}}
    png1, _ = staticmap.render(s1, use_tiles=False)
    assert png0 != png1 and png1[:4] == b"\x89PNG"


def test_sketch_route():
    s = site()
    try:
        r = post("/api/sketch/save", {"id": SID, "items": [{"kind": "point", "cat": "constraint", "label": "Gas main", "coords": [[-0.83, 51.41]]}]})
        assert len(r["items"]) == 1 and r["items"][0]["cat"] == "constraint"
        assert len(post("/api/sketch/get", {"id": SID})["items"]) == 1
        assert post("/api/sketch/save", {"id": SID, "items": []})["items"] == [] and "sketch" not in s
    finally:
        s.pop("sketch", None)


# ---------------------------------------------------------------- scenarios, outputs, onboarding
def test_scenario_rows_carry_more_measures():
    rows = post("/api/scenarios", {"id": SID})["rows"]
    assert all("rlv" in r and "irr_unlevered" in r and "equity_profit" in r for r in rows)


def test_outputs_carry_tax_and_cost_plan():
    s = site()
    try:
        post("/api/costplan/read", {"id": SID, "name": "plan.xlsx", "data": base64.b64encode(_plan_xlsx()).decode()})
        post("/api/costplan/apply", {"id": SID})
        html = server.report_html(s, opts={})
        assert "<h2>Tax and net returns</h2>" in html and "<h2>Cost plan</h2>" in html
        assert "Tax and net returns" in _text_docx(server.committee_bytes(s, opts={}))
        assert server.deck_bytes(s, opts={})
    finally:
        post("/api/costplan/clear", {"id": SID})
        s.pop("costplan", None)


def test_onboarding_route():
    server.STATE["onboarded"] = False
    inv0 = dict(server.STATE["investor"])
    try:
        assert post("/api/state") if False else True
        r = post("/api/onboard", {"profile": {"active": True, "regions": ["South East"], "cost_of_equity": 14, "senior_ltc": 55}, "tax": {"structure": "personal", "personal_rate": 40}})
        assert r["ok"] and server.STATE["onboarded"] and server.STATE["investor"]["regions"] == ["South East"]
        assert abs(server.STATE["assumptions"]["cost_of_equity"] - 0.14) < 1e-9 and server.STATE["tax_default"]["structure"] == "personal"
        t = post("/api/tax/get", {"id": SID})
        assert t["structure"] == "personal"
    finally:
        server.STATE["investor"] = inv0
        server.STATE["tax_default"] = {}
        server.STATE["assumptions"].update({"cost_of_equity": 0.12, "ltc": 0.6})


if __name__ == "__main__":
    fails = 0
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            try:
                f(); print("ok  ", n)
            except Exception as e:
                import traceback; traceback.print_exc(); fails += 1; print("FAIL", n, e)
    sys.exit(1 if fails else 0)
