"""Shape a pack before exporting: choose sections, put them in order, and apply a house style.

The report, committee paper, brief and deck are each built in full, then arranged: sections can be switched off or moved,
and the colour and name can be changed. Sections are found by their headings (Heading 1 in Word, the h2 in the report,
the title on each slide), so the arrangement survives changes to what a section contains.
"""
from __future__ import annotations

import io
import re

DEFAULT_BRAND = {"name": "easyDevelopment", "accent": "#FF6600"}
KINDS = ("report", "committee", "brief", "deck")


def slug(t: str) -> str:
    t = re.sub(r"^\s*(\d+\.|Appendix:)\s*", "", t or "")
    return re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-") or "section"


def brand_of(b: dict | None) -> dict:
    b = b or {}
    accent = str(b.get("accent") or "")
    if not re.fullmatch(r"#?[0-9A-Fa-f]{6}", accent):
        accent = DEFAULT_BRAND["accent"]
    name = re.sub(r"[<>&]", "", str(b.get("name") or "")).strip()[:40] or DEFAULT_BRAND["name"]
    return {"name": name, "accent": "#" + accent.lstrip("#").upper()}


def clean_opts(o: dict | None) -> dict:
    o = o or {}
    ok = lambda xs: [str(x)[:80] for x in xs if isinstance(x, str)][:60] if isinstance(xs, list) else []
    return {"order": ok(o.get("order")), "off": ok(o.get("off"))}


def _arranged(ids: list[str], opts: dict) -> list[str]:
    """Ids in the requested order, with any section the request did not mention kept in its natural place at the end."""
    want = [i for i in opts.get("order", []) if i in ids]
    rest = [i for i in ids if i not in want]
    return [i for i in want + rest if i not in set(opts.get("off", []))]


def _unique(ids: list[str]) -> list[str]:
    seen, out = {}, []
    for i in ids:
        seen[i] = seen.get(i, 0) + 1
        out.append(i if seen[i] == 1 else f"{i}-{seen[i]}")
    return out


# ------------------------------------------------------------------ report (html)

def split_report(chunks: list[str]) -> tuple[list[str], list[tuple[str, str, list[str]]], str]:
    """Head, sections (id, title, chunks) and the footer chunk of the report."""
    foot, body = chunks[-1], chunks[:-1]
    head: list[str] = []
    secs: list[list] = []
    for ch in body:
        m = re.match(r"<h2>(.*?)</h2>", ch)
        if m:
            secs.append([m.group(1), [ch]])
        elif secs:
            secs[-1][1].append(ch)
        else:
            head.append(ch)
    ids = _unique([slug(t) for t, _ in secs])
    return head, [(i, t, c) for i, (t, c) in zip(ids, secs)], foot


def arrange_report(chunks: list[str], opts: dict | None) -> list[str]:
    head, secs, foot = split_report(chunks)
    by = {i: c for i, _, c in secs}
    order = _arranged([i for i, _, _ in secs], clean_opts(opts))
    out = list(head)
    for i in order:
        out += by[i]
    return out + [foot]


def report_sections(chunks: list[str], opts: dict | None) -> list[dict]:
    _, secs, _ = split_report(chunks)
    return _listing([(i, t) for i, t, _ in secs], opts)


def _listing(pairs: list[tuple[str, str]], opts: dict | None) -> list[dict]:
    o = clean_opts(opts)
    ids = [i for i, _ in pairs]
    title = dict(pairs)
    on = _arranged(ids, {"order": o["order"], "off": []})
    return [{"id": i, "title": title[i], "on": i not in set(o["off"])} for i in on]


# ------------------------------------------------------------------ word

def _h1s(doc):
    from docx.oxml.ns import qn
    body = doc.element.body
    kids = list(body.iterchildren())
    tail = kids[-1] if kids and kids[-1].tag == qn("w:sectPr") else None
    kids = kids[:-1] if tail is not None else kids
    groups: list[list] = [[None, []]]
    for el in kids:
        title = None
        if el.tag == qn("w:p"):
            st = el.find(qn("w:pPr") + "/" + qn("w:pStyle"))
            if st is not None and st.get(qn("w:val")) == "Heading1":
                title = "".join(t.text or "" for t in el.iter(qn("w:t")))
        if title is not None:
            groups.append([title, [el]])
        else:
            groups[-1][1].append(el)
    return body, tail, groups


def docx_sections(data: bytes, opts: dict | None) -> list[dict]:
    from docx import Document
    _, _, groups = _h1s(Document(io.BytesIO(data)))
    ids = _unique([slug(t) for t, _ in groups[1:]])
    return _listing([(i, re.sub(r"^\s*\d+\.\s*", "", t)) for i, (t, _) in zip(ids, groups[1:])], opts)


def arrange_docx(data: bytes, opts: dict | None, brand: dict | None = None) -> bytes:
    from docx import Document
    from docx.oxml.ns import qn
    doc = Document(io.BytesIO(data))
    o = clean_opts(opts)
    if o["order"] or o["off"]:
        body, tail, groups = _h1s(doc)
        ids = _unique([slug(t) for t, _ in groups[1:]])
        by = dict(zip(ids, groups[1:]))
        keep = _arranged(ids, o)
        for _, els in groups:
            for el in els:
                body.remove(el)
        for el in groups[0][1]:
            (tail.addprevious(el) if tail is not None else body.append(el))
        n = 0
        for i in keep:
            title, els = by[i]
            if re.match(r"^\s*\d+\.\s", title):
                n += 1
                for t in els[0].iter(qn("w:t")):
                    t.text = re.sub(r"^\s*\d+\.\s*", f"{n}. ", t.text or "", count=1)
                    break
            for el in els:
                (tail.addprevious(el) if tail is not None else body.append(el))
    buf = io.BytesIO()
    doc.save(buf)
    return _brand_zip(buf.getvalue(), brand)


def _brand_zip(data: bytes, brand: dict | None) -> bytes:
    """Swap the accent colour and the product name inside a docx or pptx package."""
    b = brand_of(brand)
    if b == DEFAULT_BRAND:
        return data
    import zipfile
    src = zipfile.ZipFile(io.BytesIO(data))
    out = io.BytesIO()
    hexs = b["accent"].lstrip("#")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for it in src.infolist():
            raw = src.read(it.filename)
            if it.filename.endswith(".xml") and (it.filename.startswith(("word/", "ppt/slides/", "ppt/charts/"))):
                t = raw.decode("utf8")
                t = re.sub(r'(?i)FF6600', hexs, t)
                t = t.replace("easyDevelopment", b["name"])
                raw = t.encode("utf8")
            z.writestr(it, raw)
    return out.getvalue()


def brand_html(html: str, brand: dict | None) -> str:
    b = brand_of(brand)
    return html.replace("#FF6600", b["accent"]).replace("easyDevelopment", b["name"])


# ------------------------------------------------------------------ slides

def _slide_title(sl):
    from pptx.util import Pt
    for sh in sl.shapes:
        if sh.has_text_frame and sh.text_frame.text.strip():
            for p in sh.text_frame.paragraphs:
                for r in p.runs:
                    if r.font.size == Pt(28):
                        return sh.text_frame.text.strip()
    return ""


def slide_ids(prs) -> list[tuple[str, str]]:
    raw = [(_slide_title(sl) or ("Cover" if i == 0 else f"Slide {i + 1}")) for i, sl in enumerate(prs.slides)]
    ids = _unique([slug(t) for t in raw])
    return list(zip(ids, raw))


def pptx_sections(data: bytes, opts: dict | None) -> list[dict]:
    from pptx import Presentation
    pairs = slide_ids(Presentation(io.BytesIO(data)))[1:]
    return _listing(pairs, opts)


def pptx_outline(data: bytes, limit: int = 7) -> list[dict]:
    from pptx import Presentation
    prs = Presentation(io.BytesIO(data))
    out = []
    for i, sl in enumerate(prs.slides):
        title, lines, extras = "", [], []
        for sh in sl.shapes:
            if sh.has_text_frame and sh.text_frame.text.strip():
                t = sh.text_frame.text.strip()
                if not title and any(r.font.size and r.font.size.pt >= 28 for p in sh.text_frame.paragraphs for r in p.runs):
                    title = t
                elif not t.startswith("easyDevelopment ·") and not t.isdigit():
                    lines.append(t.replace("\n", " ")[:160])
            elif sh.shape_type == 19 or getattr(sh, "has_table", False) and sh.has_table:
                extras.append("Table")
            elif getattr(sh, "has_chart", False) and sh.has_chart:
                extras.append("Chart")
            elif sh.shape_type == 13:
                extras.append("Image")
        out.append({"n": i + 1, "title": title or ("Cover" if i == 0 else f"Slide {i + 1}"), "lines": lines[:limit], "extras": sorted(set(extras))})
    return out


def arrange_pptx(data: bytes, opts: dict | None, brand: dict | None = None) -> bytes:
    from pptx import Presentation
    from pptx.util import Inches
    prs = Presentation(io.BytesIO(data))
    o = clean_opts(opts)
    if o["order"] or o["off"]:
        pairs = slide_ids(prs)
        lst = prs.slides._sldIdLst
        els = list(lst)
        by = {i: els[k] for k, (i, _) in enumerate(pairs)}
        ids = [i for i, _ in pairs[1:]]
        keep = _arranged(ids, o)
        for el in els[1:]:
            lst.remove(el)
        for i in keep:
            lst.append(by[i])
        for i in ids:
            if i not in keep:
                prs.part.drop_rel(by[i].rId)
        for n, sl in enumerate(prs.slides, 1):
            for sh in sl.shapes:
                if sh.has_text_frame and sh.text_frame.text.strip().isdigit() and abs(sh.left - Inches(11.7)) < 20000:
                    sh.text_frame.paragraphs[0].runs[0].text = str(n)
    buf = io.BytesIO()
    prs.save(buf)
    return _brand_zip(buf.getvalue(), brand)


# ------------------------------------------------------------------ word outline

def docx_outline(data: bytes) -> list[dict]:
    from docx import Document
    doc = Document(io.BytesIO(data))
    out, cur = [], None
    for p in doc.paragraphs:
        sty = p.style.name if p.style is not None else ""
        if sty == "Heading 1":
            cur = {"title": p.text.strip(), "lines": []}
            out.append(cur)
        elif cur is not None and p.text.strip() and len(cur["lines"]) < 5:
            cur["lines"].append(("• " if sty.startswith("Heading") else "") + p.text.strip()[:160])
    return out
