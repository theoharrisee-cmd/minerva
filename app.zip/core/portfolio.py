"""Existing schemes, organisation balance sheet and cash flow, plus reading the organisation's Excel files.

The importer has two engines. Without an API key it matches sheet and column names against common finance
terminology. With a Claude key it sends a compact text view of each sheet to the model and asks for structured
output, then falls back to the name matching if the reply cannot be parsed."""
from __future__ import annotations

import io
import json
import re
import uuid
from datetime import date, datetime

STATUSES = ["Pipeline", "Pre-construction", "On site", "Complete, selling", "Stabilised", "Sold"]
STRATS = {"develop_sell": "Ground-up development (sell)", "btr": "Build-to-rent / multifamily", "value_add": "Value-add acquisition"}

NUM_FIELDS = ["units", "gdv", "total_cost", "equity_invested", "equity_committed", "debt_facility", "debt_drawn", "debt_rate", "sales_to_date", "income_pa"]
TXT_FIELDS = ["name", "location", "region", "strategy", "status", "debt_maturity", "start_date", "pc_date", "notes", "source"]


def _num(v):
    if v in (None, ""):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def clean_scheme(d: dict) -> dict:
    o = {"id": d.get("id") or "sch-" + uuid.uuid4().hex[:6]}
    for k in TXT_FIELDS:
        o[k] = str(d.get(k) or "").strip()
    for k in NUM_FIELDS:
        o[k] = _num(d.get(k))
    for k in ("lat", "lon"):
        if _num(d.get(k)) is not None:
            o[k] = float(d[k])
    if d.get("demo"):
        o["demo"] = True
    if o["debt_rate"] is not None and o["debt_rate"] > 1:
        o["debt_rate"] = o["debt_rate"] / 100.0
    if o["strategy"] not in STRATS:
        low = o["strategy"].lower()
        o["strategy"] = "btr" if ("rent" in low or "btr" in low or "prs" in low) else "value_add" if ("value" in low or "refurb" in low or "invest" in low) else "develop_sell"
    if o["status"] not in STATUSES:
        low = o["status"].lower()
        o["status"] = ("Sold" if "sold" in low else "Stabilised" if "stabil" in low or "let" in low else "Complete, selling" if ("complete" in low or "sell" in low)
                       else "On site" if ("site" in low or "construct" in low or "build" in low or "progress" in low) else "Pre-construction" if ("pre" in low or "plan" in low)
                       else "Pipeline")
    return o


def summary(schemes: list[dict], investor: dict | None = None, pipeline: list[dict] | None = None, org: dict | None = None) -> dict:
    live = [s for s in schemes if s["status"] != "Sold"]
    tot = lambda k, xs=live: sum((s.get(k) or 0) for s in xs)
    invested, committed = tot("equity_invested"), tot("equity_committed")
    to_come = max(0.0, committed - invested)
    drawn, fac = tot("debt_drawn"), tot("debt_facility")
    cost = tot("total_cost")
    rate_w = (sum((s.get("debt_rate") or 0) * (s.get("debt_drawn") or 0) for s in live) / drawn) if drawn else None
    by_status, by_region, by_strategy, mats = {}, {}, {}, {}
    for s in live:
        v = s.get("gdv") or s.get("total_cost") or 0
        by_status[s["status"]] = by_status.get(s["status"], 0) + v
        by_region[s.get("region") or "Unassigned"] = by_region.get(s.get("region") or "Unassigned", 0) + v
        by_strategy[s["strategy"]] = by_strategy.get(s["strategy"], 0) + v
        m = (s.get("debt_maturity") or "")[:4]
        if m.isdigit() and s.get("debt_drawn"):
            mats[m] = mats.get(m, 0) + s["debt_drawn"]
    pipe_equity = sum(p.get("peak_equity") or 0 for p in (pipeline or []))
    fund = (investor or {}).get("fund_size", 0) * 1e6
    avail = (investor or {}).get("equity_available", 0) * 1e6
    cash = (org or {}).get("balance_sheet", {}).get("cash") if org else None
    largest = max(live, key=lambda s: s.get("equity_committed") or s.get("total_cost") or 0, default=None)
    return {
        "n": len(schemes), "n_live": len(live), "units": tot("units"), "gdv": tot("gdv"), "cost": cost, "equity_invested": invested, "equity_committed": committed,
        "equity_to_come": to_come, "debt_drawn": drawn, "debt_facility": fac, "debt_undrawn": max(0.0, fac - drawn), "debt_rate": rate_w,
        "ltc": (drawn / cost) if cost else None, "income_pa": tot("income_pa"),
        "by_status": by_status, "by_region": by_region, "by_strategy": by_strategy, "maturities": dict(sorted(mats.items())),
        "pipeline_equity": pipe_equity, "n_pipeline": len(pipeline or []),
        "fund_size": fund, "equity_available": avail, "cash": cash,
        "headroom": (avail - to_come - pipe_equity) if avail else None,
        "deployed_pct": (invested / fund) if fund else None,
        "largest": {"name": largest["name"], "share": ((largest.get("equity_committed") or 0) / fund) if fund else None} if largest else None,
    }


# --------------------------------------------------------------------------- Excel reading

ALIASES = {
    "name": ["scheme", "scheme name", "project", "project name", "development", "site", "asset", "name", "property"],
    "location": ["location", "address", "town", "city", "postcode", "area"],
    "strategy": ["strategy", "type", "tenure", "use", "product", "business plan"],
    "status": ["status", "stage", "phase", "progress"],
    "units": ["units", "no of units", "number of units", "homes", "dwellings", "apartments", "no. units"],
    "gdv": ["gdv", "gross development value", "end value", "exit value", "market value", "completed value", "value"],
    "total_cost": ["total cost", "development cost", "total development cost", "budget", "total budget", "cost", "tdc", "cost to complete total"],
    "equity_invested": ["equity invested", "equity in", "equity drawn", "equity to date", "invested", "equity injected"],
    "equity_committed": ["equity committed", "equity commitment", "total equity", "equity required", "equity"],
    "debt_facility": ["facility", "loan facility", "debt facility", "facility size", "loan commitment", "commitment", "total facility"],
    "debt_drawn": ["drawn", "debt drawn", "loan drawn", "outstanding", "loan balance", "debt outstanding", "borrowings drawn"],
    "debt_rate": ["interest rate", "rate", "all-in rate", "margin", "coupon"],
    "debt_maturity": ["maturity", "loan maturity", "expiry", "repayment date", "facility expiry", "term end"],
    "start_date": ["start on site", "sos", "start", "start date", "construction start"],
    "pc_date": ["practical completion", "pc", "pc date", "completion", "completion date", "handover"],
    "sales_to_date": ["sold", "sales to date", "exchanged", "reserved", "sales achieved"],
    "income_pa": ["rent", "income", "annual rent", "noi", "rent pa", "passing rent", "net operating income"],
}

BS_ROWS = {
    "cash": ["cash", "cash at bank", "cash and cash equivalents", "cash and bank", "bank balance"],
    "stock_wip": ["stock", "work in progress", "wip", "inventory", "development stock", "properties under development", "investment property"],
    "debtors": ["debtors", "trade debtors", "receivables", "trade and other receivables"],
    "total_assets": ["total assets"],
    "creditors": ["creditors", "trade creditors", "payables", "trade and other payables"],
    "borrowings": ["borrowings", "bank loans", "loans", "debt", "total debt", "development loans", "bank borrowings"],
    "total_liabilities": ["total liabilities"],
    "net_assets": ["net assets", "net worth", "total equity", "shareholders funds", "shareholders' funds", "equity"],
}

CF_ROWS = {
    "inflow": ["receipts", "inflows", "cash in", "income", "sales receipts", "total receipts", "total inflows", "sales proceeds"],
    "outflow": ["payments", "outflows", "cash out", "costs", "total payments", "total outflows", "construction costs", "total costs"],
    "net": ["net cash flow", "net cash", "net movement", "net flow", "net"],
    "closing": ["closing cash", "closing balance", "cash carried forward", "closing bank", "cash balance"],
}


def _norm(x) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9£% ]+", " ", str(x or "").lower())).strip()


def _scale_of(header: str) -> float:
    h = str(header or "").lower()
    if re.search(r"£\s*m\b|\(m\)|\bmn\b|£m|millions|\bm\)", h):
        return 1e6
    if re.search(r"£\s*000|£k\b|\(k\)|000s|thousand|£'000|\(000", h):
        return 1e3
    return 1.0


def _to_number(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    if v is None:
        return None
    s = str(v).strip()
    if not s or s in ("-", "n/a", "N/A", "TBC", "tbc"):
        return None
    neg = s.startswith("(") and s.endswith(")")
    s2 = re.sub(r"[£$,\s()]", "", s)
    mult = 1.0
    if re.search(r"[mM]$", s2):
        mult, s2 = 1e6, s2[:-1]
    elif re.search(r"[kK]$", s2):
        mult, s2 = 1e3, s2[:-1]
    pct = s2.endswith("%")
    s2 = s2.rstrip("%")
    try:
        n = float(s2) * mult
    except ValueError:
        return None
    n = n / 100.0 if pct else n
    return -n if neg else n


def _iso(v):
    if isinstance(v, (datetime, date)):
        return v.date().isoformat() if isinstance(v, datetime) else v.isoformat()
    return str(v).strip() if v not in (None, "") else ""


def read_grids(data: bytes, max_rows: int = 200, max_cols: int = 40) -> list[dict]:
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(data), data_only=True, read_only=True)
    out = []
    for ws in wb.worksheets:
        rows = []
        for r in ws.iter_rows(min_row=1, max_row=max_rows, max_col=max_cols, values_only=True):
            rows.append(list(r))
        while rows and all(c in (None, "") for c in rows[-1]):
            rows.pop()
        if rows:
            out.append({"name": ws.title, "rows": rows})
    return out


def _alias_field(cell: str, taken: set) -> str | None:
    n = _norm(re.sub(r"\(.*?\)", "", str(cell)))
    if not n:
        return None
    best, score = None, 0
    for f, al in ALIASES.items():
        if f in taken:
            continue
        for a in al:
            if n == a:
                sc = 100 + len(a)
            elif re.search(rf"\b{re.escape(a)}\b", n):
                sc = 10 + len(a)
            else:
                continue
            if sc > score:
                best, score = f, sc
    return best


def _find_scheme_table(rows):
    for i, r in enumerate(rows[:25]):
        taken: set = set()
        cols = {}
        for j, c in enumerate(r):
            if isinstance(c, str):
                f = _alias_field(c, taken)
                if f:
                    cols[f] = (j, c)
                    taken.add(f)
        if "name" in cols and len(cols) >= 3:
            return i, cols
    return None


def _scheme_rows(rows, header_i, cols):
    out = []
    for r in rows[header_i + 1:]:
        if not r or all(c in (None, "") for c in r):
            if out:
                break
            continue
        nm = r[cols["name"][0]] if cols["name"][0] < len(r) else None
        if not isinstance(nm, str) or not nm.strip() or re.match(r"(?i)^\s*(total|sub-?total|grand total)", nm):
            continue
        d = {}
        for f, (j, head) in cols.items():
            v = r[j] if j < len(r) else None
            if f in NUM_FIELDS:
                n = _to_number(v)
                if n is not None and f not in ("units", "debt_rate"):
                    n *= _scale_of(head)
                d[f] = n
            elif f in ("debt_maturity", "start_date", "pc_date"):
                d[f] = _iso(v)
            else:
                d[f] = str(v).strip() if v not in (None, "") else ""
        out.append(d)
    return out


def _label_match(label, table):
    n = _norm(label)
    for f, al in table.items():
        if n in al:
            return f
    for f, al in table.items():
        if any(n.startswith(a + " ") or n.endswith(" " + a) for a in al if len(a) > 3):
            return f
    return None


def _period_header(rows):
    """Row index with the most date-like or period-like cells."""
    best, bi = 0, None
    for i, r in enumerate(rows[:15]):
        n = sum(1 for c in r[1:] if isinstance(c, (datetime, date)) or (isinstance(c, str) and re.match(r"(?i)^(q[1-4]|fy|h[12]|(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)|\d{4}|month|m\d+)", c.strip())))
        if n > best:
            best, bi = n, i
    return bi if best >= 3 else None


def _sheet_scale(rows) -> float:
    for r in rows[:6]:
        for c in r:
            if isinstance(c, str):
                k = _scale_of(c)
                if k != 1.0:
                    return k
    return 1.0


def _last_num(row):
    for c in reversed(row[1:]):
        n = _to_number(c)
        if n is not None:
            return n
    return None


def heuristic(grids: list[dict]) -> dict:
    res = {"schemes": [], "balance_sheet": {}, "cashflow": [], "notes": [], "sheets": [], "engine": "name matching"}
    for g in grids:
        rows, kind = g["rows"], None
        t = _find_scheme_table(rows)
        bs, cf = {}, {}
        for r in rows:
            if not r or r[0] in (None, ""):
                continue
            f = _label_match(r[0], BS_ROWS)
            if f and f not in bs and _last_num(r) is not None:
                bs[f] = _last_num(r)
            f2 = _label_match(r[0], CF_ROWS)
            if f2 and f2 not in cf:
                cf[f2] = r
        ph = _period_header(rows)
        sc_k = _sheet_scale(rows)
        if t:
            kind = "portfolio"
            sc = _scheme_rows(rows, *t)
            res["schemes"].extend(sc)
            res["notes"].append(f"Sheet '{g['name']}': read {len(sc)} schemes, matched {len(t[1])} columns ({', '.join(sorted(t[1]))}).")
        elif ph is not None and len(cf) >= 2:
            kind = "cashflow"
            head = rows[ph]
            series = []
            for j in range(1, len(head)):
                lab = _iso(head[j])
                if not lab:
                    continue
                pick = lambda key: (_to_number(cf[key][j]) * sc_k) if key in cf and j < len(cf[key]) and _to_number(cf[key][j]) is not None else None
                item = {"period": lab, "inflow": pick("inflow"), "outflow": pick("outflow"), "net": pick("net"), "closing": pick("closing")}
                if item["net"] is None and item["inflow"] is not None and item["outflow"] is not None:
                    item["net"] = item["inflow"] + (item["outflow"] if item["outflow"] < 0 else -item["outflow"])
                if any(item[k] is not None for k in ("inflow", "outflow", "net", "closing")):
                    series.append(item)
            res["cashflow"] = series
            res["notes"].append(f"Sheet '{g['name']}': read {len(series)} periods of cash flow.")
        elif len(bs) >= 3:
            kind = "balance_sheet"
            res["balance_sheet"] = {k: v * sc_k for k, v in bs.items()}
            res["notes"].append(f"Sheet '{g['name']}': matched {len(bs)} balance sheet lines ({', '.join(sorted(bs))}).")
        else:
            res["notes"].append(f"Sheet '{g['name']}': nothing recognised, skipped.")
        res["sheets"].append({"name": g["name"], "kind": kind or "unrecognised", "rows": len(rows)})
    return res


CLAUDE_SYSTEM = ("You read spreadsheets from a UK property developer or investor and return structured data as JSON only. "
                 "Values in the sheets may be in pounds, thousands or millions: convert everything to whole pounds. Rates are decimals (0.075 for 7.5%). "
                 "Never invent numbers. Omit a field if the sheet does not give it.")
CLAUDE_SCHEMA = """Return one JSON object:
{"schemes":[{"name":"","location":"","strategy":"develop_sell|btr|value_add","status":"Pipeline|Pre-construction|On site|Complete, selling|Stabilised|Sold","units":0,"gdv":0,"total_cost":0,"equity_invested":0,"equity_committed":0,"debt_facility":0,"debt_drawn":0,"debt_rate":0.0,"debt_maturity":"YYYY-MM-DD","start_date":"","pc_date":"","sales_to_date":0,"income_pa":0,"notes":""}],
"balance_sheet":{"as_at":"","cash":0,"stock_wip":0,"debtors":0,"total_assets":0,"creditors":0,"borrowings":0,"total_liabilities":0,"net_assets":0},
"cashflow":[{"period":"","inflow":0,"outflow":0,"net":0,"closing":0}],
"notes":["one line per sheet saying what you found and any assumption you made"]}"""


def _dump(grids, max_chars=60000):
    parts = []
    for g in grids:
        lines = []
        for r in g["rows"][:80]:
            cells = [_iso(c) if isinstance(c, (datetime, date)) else ("" if c is None else str(c)) for c in r[:25]]
            lines.append(" | ".join(cells).rstrip(" |"))
        parts.append(f"### SHEET {g['name']}\n" + "\n".join(lines))
    return "\n\n".join(parts)[:max_chars]


def interpret(data: bytes, api_key: str | None = None, model: str = "") -> dict:
    grids = read_grids(data)
    if not grids:
        raise ValueError("The workbook has no readable cells")
    base = heuristic(grids)
    engine = base["engine"]
    result = base
    if api_key:
        try:
            from . import planning
            raw = planning._claude(api_key, model, CLAUDE_SYSTEM, [{"role": "user", "content": f"{CLAUDE_SCHEMA}\n\nWORKBOOK:\n{_dump(grids)}"}], 6000)
            js = planning._parse_json(raw)
            result = {"schemes": js.get("schemes") or [], "balance_sheet": js.get("balance_sheet") or {}, "cashflow": js.get("cashflow") or [],
                      "notes": js.get("notes") or [], "sheets": base["sheets"], "engine": f"claude:{model}"}
            engine = result["engine"]
        except Exception as e:  # keep the name matching result and say why
            base["notes"].append(f"Claude reading failed ({str(e)[:120]}). Showing the name matching result.")
    result["engine"] = engine
    result["schemes"] = [clean_scheme({**s, "source": "Excel import"}) for s in result["schemes"]]
    for s in result["schemes"]:
        miss = [k for k in ("gdv", "total_cost", "equity_committed", "debt_drawn") if not s.get(k)]
        s["_review"] = miss
    return result


DEMO_SCHEMES = [
    dict(id="demo-riverside", name="Riverside Quarter, Leeds (fictional)", location="Leeds LS1", region="Yorkshire and the Humber", strategy="btr", status="On site", units=180, gdv=52_000_000, total_cost=41_000_000, equity_committed=12_500_000, equity_invested=9_100_000,
         debt_facility=26_000_000, debt_drawn=19_000_000, debt_rate=0.079, debt_maturity="2028-03-31", start_date="2025-09-01", pc_date="2027-06-30", lat=53.7940, lon=-1.5400, demo=True),
    dict(id="demo-orchard", name="Orchard Gate, Reading (fictional)", location="Reading RG2", region="South East", strategy="develop_sell", status="Complete, selling", units=96, gdv=38_000_000, total_cost=29_000_000, equity_committed=8_000_000, equity_invested=8_000_000,
         debt_facility=20_000_000, debt_drawn=11_000_000, debt_rate=0.086, debt_maturity="2027-06-30", sales_to_date=21_000_000, lat=51.4290, lon=-0.9660, demo=True),
    dict(id="demo-foundry", name="Foundry Lofts, Manchester (fictional)", location="Manchester M4", region="North West", strategy="value_add", status="Stabilised", units=64, gdv=22_000_000, total_cost=15_000_000, equity_committed=6_000_000, equity_invested=6_000_000,
         debt_facility=9_000_000, debt_drawn=9_000_000, debt_rate=0.064, debt_maturity="2029-09-30", income_pa=1_300_000, lat=53.4850, lon=-2.2300, demo=True),
    dict(id="demo-basin", name="Canal Basin, Birmingham (fictional)", location="Birmingham B1", region="West Midlands", strategy="develop_sell", status="Pre-construction", units=120, gdv=34_000_000, total_cost=27_000_000, equity_committed=9_000_000, equity_invested=2_200_000,
         debt_facility=17_000_000, debt_drawn=0, debt_rate=0.09, debt_maturity="2028-12-31", lat=52.4790, lon=-1.9010, demo=True),
]
DEMO_ORG = {"balance_sheet": {"as_at": "30 June 2026", "cash": 4_800_000, "stock_wip": 61_000_000, "debtors": 2_100_000, "total_assets": 68_000_000, "creditors": 5_000_000, "borrowings": 39_000_000, "total_liabilities": 44_000_000, "net_assets": 24_000_000},
            "cashflow": [{"period": p, "inflow": i, "outflow": o, "net": i - o, "closing": c} for p, i, o, c in [
                ("Q3 2026", 6_500_000, 5_200_000, 6_100_000), ("Q4 2026", 8_800_000, 7_900_000, 7_000_000), ("Q1 2027", 5_100_000, 6_400_000, 5_700_000), ("Q2 2027", 9_400_000, 7_600_000, 7_500_000),
                ("Q3 2027", 7_200_000, 6_800_000, 7_900_000), ("Q4 2027", 6_000_000, 8_300_000, 5_600_000)]],
            "file": "Illustrative accounts", "imported": "2026-09-01T09:00+00:00", "demo": True}
