"""Small geodesy helpers (standard library only)."""
from __future__ import annotations

import math
import re


def km(lat1, lon1, lat2, lon2) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2
    return 6371.0088 * 2 * math.asin(math.sqrt(a))


def bbox(lat: float, lon: float, radius_km: float) -> tuple[float, float, float, float]:
    """(min_lon, min_lat, max_lon, max_lat) around a point."""
    dlat = radius_km / 111.32
    dlon = radius_km / (111.32 * max(0.2, math.cos(math.radians(lat))))
    return lon - dlon, lat - dlat, lon + dlon, lat + dlat


def bbox_wkt(b) -> str:
    x0, y0, x1, y1 = b
    return f"POLYGON(({x0:.6f} {y0:.6f},{x1:.6f} {y0:.6f},{x1:.6f} {y1:.6f},{x0:.6f} {y1:.6f},{x0:.6f} {y0:.6f}))"


def point_of(wkt: str | None):
    """(lon, lat) from POINT, or the centroid of the first ring of a POLYGON or MULTIPOLYGON."""
    if not wkt:
        return None
    nums = wkt.replace("(", " ").replace(")", " ").replace(",", " ").split()
    vals = []
    for n in nums:
        try:
            vals.append(float(n))
        except ValueError:
            pass
    if len(vals) < 2:
        return None
    xs, ys = vals[0::2], vals[1::2]
    if wkt.strip().upper().startswith("POINT"):
        return xs[0], ys[0]
    return sum(xs) / len(xs), sum(ys) / len(ys)


def _ring_area(pts) -> float:
    lat0 = sum(y for _, y in pts) / len(pts)
    kx, ky = 111320 * math.cos(math.radians(lat0)), 110574
    a = 0.0
    for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
        a += (x1 * kx) * (y2 * ky) - (x2 * kx) * (y1 * ky)
    return abs(a) / 2


def _polygons(wkt: str) -> list[list[list[tuple[float, float]]]]:
    """Polygons as lists of rings (first ring outer, the rest holes) from POLYGON or MULTIPOLYGON text."""
    polys, cur = [], []
    for m in re.finditer(r"\(([^()]+)\)(\)*)", wkt):
        pts = []
        for pair in m.group(1).split(","):
            p = pair.split()
            if len(p) >= 2:
                try:
                    pts.append((float(p[0]), float(p[1])))
                except ValueError:
                    pass
        if len(pts) >= 4:
            cur.append(pts)
        if m.group(2):
            if cur:
                polys.append(cur)
            cur = []
    if cur:
        polys.append(cur)
    return polys


def ring_area_ha(wkt: str | None) -> float | None:
    """Approximate area of a WKT POLYGON or MULTIPOLYGON in hectares (equirectangular; good to a few percent at plot scale). Inner rings are holes."""
    if not wkt or "POLYGON" not in wkt.upper():
        return None
    total = 0.0
    for rings in _polygons(wkt[wkt.index("("):]):
        for i, r in enumerate(rings):
            total += _ring_area(r) if i == 0 else -_ring_area(r)
    return round(total / 10000, 3) if total > 0 else None


# ---- WGS84 to British National Grid (Helmert, good to tens of metres), used for map deep links only
def to_osgb(lat: float, lon: float) -> tuple[int, int]:
    a, b = 6378137.0, 6356752.3141
    f0, phi0, lam0, e0, n0 = 0.9996012717, math.radians(49), math.radians(-2), 400000, -100000
    la, lo = math.radians(lat), math.radians(lon)

    def cart(phi, lam, a_, b_, h=0):
        e2 = 1 - (b_ * b_) / (a_ * a_)
        nu = a_ / math.sqrt(1 - e2 * math.sin(phi) ** 2)
        return ((nu + h) * math.cos(phi) * math.cos(lam), (nu + h) * math.cos(phi) * math.sin(lam), ((1 - e2) * nu + h) * math.sin(phi))

    x, y, z = cart(la, lo, a, b)
    tx, ty, tz, s, rx, ry, rz = -446.448, 125.157, -542.060, 20.4894e-6, math.radians(-0.1502 / 3600), math.radians(-0.2470 / 3600), math.radians(-0.8421 / 3600)
    x2 = tx + (1 + s) * x - rz * y + ry * z
    y2 = ty + rz * x + (1 + s) * y - rx * z
    z2 = tz - ry * x + rx * y + (1 + s) * z
    a2, b2 = 6377563.396, 6356256.909
    e2 = 1 - (b2 * b2) / (a2 * a2)
    p = math.hypot(x2, y2)
    phi = math.atan2(z2, p * (1 - e2))
    for _ in range(10):
        nu = a2 / math.sqrt(1 - e2 * math.sin(phi) ** 2)
        phi = math.atan2(z2 + e2 * nu * math.sin(phi), p)
    lam = math.atan2(y2, x2)
    n = (a2 - b2) / (a2 + b2)
    nu = a2 * f0 / math.sqrt(1 - e2 * math.sin(phi) ** 2)
    rho = a2 * f0 * (1 - e2) / (1 - e2 * math.sin(phi) ** 2) ** 1.5
    eta2 = nu / rho - 1
    ma = (1 + n + 1.25 * n ** 2 + 1.25 * n ** 3) * (phi - phi0) - (3 * n + 3 * n ** 2 + 2.625 * n ** 3) * math.sin(phi - phi0) * math.cos(phi + phi0) \
        + (1.875 * n ** 2 + 1.875 * n ** 3) * math.sin(2 * (phi - phi0)) * math.cos(2 * (phi + phi0)) - (35 / 24) * n ** 3 * math.sin(3 * (phi - phi0)) * math.cos(3 * (phi + phi0))
    mm = b2 * f0 * ma
    c, s_ = math.cos(phi), math.sin(phi)
    t = math.tan(phi)
    i, ii = mm + n0, nu / 2 * s_ * c
    iii = nu / 24 * s_ * c ** 3 * (5 - t ** 2 + 9 * eta2)
    iiia = nu / 720 * s_ * c ** 5 * (61 - 58 * t ** 2 + t ** 4)
    iv, v = nu * c, nu / 6 * c ** 3 * (nu / rho - t ** 2)
    vi = nu / 120 * c ** 5 * (5 - 18 * t ** 2 + t ** 4 + 14 * eta2 - 58 * t ** 2 * eta2)
    d = lam - lam0
    north = i + ii * d ** 2 + iii * d ** 4 + iiia * d ** 6
    east = e0 + iv * d + v * d ** 3 + vi * d ** 5
    return int(round(east)), int(round(north))


# ---------------------------------------------------------------- local metric geometry (for boundaries, parcels and layouts)

def to_xy(lat0: float, lon0: float, lat: float, lon: float) -> tuple[float, float]:
    """Metres east and north of a reference point (flat-earth approximation, fine over a few kilometres)."""
    return ((lon - lon0) * 111320.0 * math.cos(math.radians(lat0)), (lat - lat0) * 110574.0)


def from_xy(lat0: float, lon0: float, x: float, y: float) -> tuple[float, float]:
    """Inverse of to_xy: returns (lat, lon)."""
    return (lat0 + y / 110574.0, lon0 + x / (111320.0 * math.cos(math.radians(lat0))))


def ring_to_xy(ring, lat0: float, lon0: float) -> list[tuple[float, float]]:
    """Ring of (lon, lat) points to metres."""
    return [to_xy(lat0, lon0, y, x) for x, y in ring]


def area_m2(xy) -> float:
    s = 0.0
    for i in range(len(xy)):
        x1, y1 = xy[i]
        x2, y2 = xy[(i + 1) % len(xy)]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2


def centroid_xy(xy) -> tuple[float, float]:
    a = cx = cy = 0.0
    for i in range(len(xy)):
        x1, y1 = xy[i]
        x2, y2 = xy[(i + 1) % len(xy)]
        f = x1 * y2 - x2 * y1
        a += f
        cx += (x1 + x2) * f
        cy += (y1 + y2) * f
    if abs(a) < 1e-9:
        return (sum(p[0] for p in xy) / len(xy), sum(p[1] for p in xy) / len(xy))
    return (cx / (3 * a), cy / (3 * a))


def seg_dist(px, py, ax, ay, bx, by) -> float:
    dx, dy = bx - ax, by - ay
    L = dx * dx + dy * dy
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def dist_to_ring_m(lat: float, lon: float, ring) -> float:
    """Distance in metres from a point to the edge of a ring of (lon, lat) points, or 0 if the point is inside."""
    xy = ring_to_xy(ring, lat, lon)
    inside = False
    j = len(xy) - 1
    for i in range(len(xy)):
        xi, yi = xy[i]
        xj, yj = xy[j]
        if (yi > 0) != (yj > 0) and 0 < (xj - xi) * (0 - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    if inside:
        return 0.0
    return min(seg_dist(0, 0, *xy[i], *xy[(i + 1) % len(xy)]) for i in range(len(xy)))


def polygon_of(wkt: str | None):
    """First outer ring of a POLYGON or MULTIPOLYGON as a list of (lon, lat), or None."""
    if not wkt or "(" not in wkt:
        return None
    ps = _polygons(wkt[wkt.index("("):])
    return ps[0][0] if ps and ps[0] else None


def ring_wkt(ring) -> str:
    pts = list(ring)
    if pts[0] != pts[-1]:
        pts.append(pts[0])
    return "POLYGON((" + ",".join(f"{x:.7f} {y:.7f}" for x, y in pts) + "))"
