"""Ask this deal: questions answered from what the app holds about one site.

The file is split into labelled passages: the site record, appraisal, data checks, homes schedule, layout test,
planning record, ownership, and every document in the vault. With a Claude key the best passages go to the model,
which answers only from them and cites them. Without a key the best passages are returned as the answer, so the
box still works offline.
"""
from __future__ import annotations

import json
import re

from . import docs as docs_mod

STOP = set("a an and are as at be by can do does for from has have how i in is it its of on or our that the their there this to was we what when where which who why will with would you your about any much many".split())


def _tok(s: str) -> list[str]:
    ws = [w for w in re.findall(r"[a-z0-9£%]+", (s or "").lower()) if w not in STOP and len(w) > 1]
    return [re.sub(r"(ings|ing|als|al|ed|es|s)$", "", w) if len(w) > 5 else w for w in ws]


def _chunk(text: str, size: int = 900) -> list[str]:
    parts, cur = [], ""
    for para in re.split(r"\n\s*\n|(?<=[.!?])\s{2,}", text):
        para = re.sub(r"\s+", " ", para).strip()
        if not para:
            continue
        if len(cur) + len(para) > size and cur:
            parts.append(cur)
            cur = ""
        cur = (cur + " " + para).strip()
        while len(cur) > size * 1.6:
            parts.append(cur[:size])
            cur = cur[size:]
    if cur:
        parts.append(cur)
    return parts


def passages(site: dict, ev: dict | None = None, homes: dict | None = None, doc_text=None) -> list[dict]:
    out: list[dict] = []

    def add(label, text, ref=""):
        if text and str(text).strip():
            out.append({"id": f"P{len(out) + 1}", "label": label, "text": str(text).strip(), "ref": ref})
    f = [f"{k}: {site[k]}" for k in ("name", "address", "postcode", "stage", "strategy", "planning_status", "site_ha", "units", "asking_price", "vendor", "description") if site.get(k) not in (None, "")]
    add("Site record", "; ".join(f))
    a = (ev or {}).get("appraisal") or {}
    if a and not a.get("incomplete"):
        add("Appraisal", f"Gross development value £{a['gdv']:,.0f}; total cost £{a['total_cost']:,.0f}; profit £{a['profit']:,.0f} ({a['profit_on_gdv']:.1%} of GDV); residual land value £{a['rlv']:,.0f}; asking price £{a.get('asking') or 0:,.0f}; "
                          f"levered IRR {a['irr_levered']:.1%}; equity multiple {a['equity_multiple']:.2f}x; viable at asking price: {'yes' if a['viable'] else 'no'}." if a.get("irr_levered") is not None else
            f"Gross development value £{a['gdv']:,.0f}; total cost £{a['total_cost']:,.0f}; profit £{a['profit']:,.0f}; residual land value £{a['rlv']:,.0f}.")
    for fl in (ev or {}).get("flags", [])[:8]:
        add("Risk", f"{fl['severity']}: {fl['flag']}. {fl['why']} Mitigation: {fl.get('mitigation', '')}")
    for it in (site.get("data_pack") or {}).get("items", []):
        if it.get("status") in ("hit", "clear", "info"):
            add(f"Data check, {it['source']}", f"{it['label']}: {it.get('value', '')}. {it.get('detail', '')}", it.get("url", ""))
    if homes:
        from . import homes_out
        rows, tot = homes_out.schedule(homes)
        add("Homes schedule", "; ".join(" | ".join(r) for r in rows[1:]) + ". Totals: " + ", ".join(tot))
        for c in homes.get("policy", {}).get("checks", []):
            add("Policy check", f"{c['title']} ({c['status']}): {c['detail']}")
    lay = site.get("layout")
    if lay and lay.get("ok"):
        add("Layout test", f"{lay['homes']} houses fit at {lay['density_dph']} dph on {lay['site_ha']} ha; shortest garden {lay['min_garden_m']} m; back to back {lay['min_back_to_back_m']} m; {lay['parking_plot']} spaces on plot and {lay['parking_street']} on street.")
        for c in lay["checks"]:
            add("Layout check", f"{c['title']} ({c['status']}): {c['detail']}")
    tr = site.get("track")
    if tr and tr.get("ok"):
        add("Planning record, last five years", f"{tr['approved']} approved and {tr['refused']} refused among decided major residential applications within {tr['radius_km']:g} km; median {tr.get('median_days') or 0:.0f} days to decide. " + tr.get("note", ""))
        for p in tr.get("precedents", [])[:6]:
            add("Comparable approval", f"{p['ref']}, {p['address']}: {p['description'][:160]} (decided {p['decided']}, {p['distance_km']} km)", p.get("url", ""))
        for p in tr.get("refused_nearby", [])[:4]:
            add("Refusal nearby", f"{p['ref']}, {p['address']}: {p['description'][:160]} (decided {p['decided']})", p.get("url", ""))
    r = site.get("title_register")
    if r:
        add("Title register", f"Title {r['title']}, {r.get('tenure', '')}. Proprietors: {'; '.join(p['name'] for p in r['proprietors'])}. Charges: {'; '.join((c.get('chargee') or '') for c in r['charges']) or 'none read'}. Covenants: {'; '.join(r.get('covenants', []))[:400]}")
    asm = site.get("assembly")
    if asm:
        for g in (asm.get("owners") or {}).get("groups", [])[:8]:
            add("Nearby owner", f"{g['proprietor']} holds {g['nearby']} titles near the site. " + "; ".join(x["text"] for x in g.get("distress", [])))
    for h in site.get("planning_history", [])[:6]:
        add("Application on file", f"{h.get('ref', '')} {h.get('status', '')}: {h.get('description', '')}. " + "; ".join(h.get("key_points", []))[:300])
    for c in site.get("consultees", [])[:10]:
        add("Consultee", f"{c.get('body', '')} ({c.get('stance', '')}): {c.get('summary', '')}")
    an = site.get("planning_analysis")
    if an:
        add("Document analysis", an.get("summary", ""))
        for k in an.get("constraints", [])[:8]:
            add("Document analysis, constraint", f"{k['item']} ({k['severity']}): {k.get('note', '')}", k.get("source_doc", ""))
    if doc_text:
        for d in site.get("docs", []):
            t = doc_text(d)
            for i, ch in enumerate(_chunk(t)[:60]):
                add(f"Document: {d.get('name', '')}", ch, d.get("id", ""))
    return out


def retrieve(ps: list[dict], question: str, k: int = 10) -> list[dict]:
    q = _tok(question)
    if not q:
        return ps[:k]
    df: dict[str, int] = {}
    toks = [_tok(p["label"] + " " + p["text"]) for p in ps]
    for t in toks:
        for w in set(t):
            df[w] = df.get(w, 0) + 1
    n = len(ps)
    scored = []
    for p, t in zip(ps, toks):
        tf: dict[str, int] = {}
        for w in t:
            tf[w] = tf.get(w, 0) + 1
        s = sum((1 + tf[w] ** 0.5) * (1 + (n / (1 + df.get(w, 0))) ** 0.5) for w in set(q) if w in tf)
        if s:
            scored.append((s, p))
    scored.sort(key=lambda x: -x[0])
    return [p for _, p in scored[:k]]


SYSTEM = """You answer questions about one property site for a UK developer or investor. Use only the numbered passages you are given. Cite each fact with the passage id in square brackets, for example [P3].
If the passages do not answer the question, say what is missing and where the user could add it (a document, a data check, the appraisal). Do not invent figures, policies or dates. British English, plain prose, no em dashes, no bullet lists unless the question asks for a list. Keep it short."""


def answer(site: dict, question: str, ev=None, homes=None, doc_text=None, api_key=None, model=None, history=None, claude=None) -> dict:
    ps = passages(site, ev, homes, doc_text)
    top = retrieve(ps, question, 10)
    if not top:
        return {"answer": "Nothing on file for this site touches that question yet. Add documents, run the data checks or complete the appraisal, then ask again.", "sources": [], "mode": "none", "n": len(ps)}
    if api_key:
        try:
            from . import planning
            call = claude or planning._claude
            ctx = "\n\n".join(f"[{p['id']}] ({p['label']}) {p['text'][:1400]}" for p in top)
            msgs = [{"role": "user", "content": f"Passages:\n{ctx}\n\nQuestion: {question}"}]
            for h in (history or [])[-6:]:
                msgs.insert(-1, {"role": h["role"], "content": h["content"]})
            txt = call(api_key, model or "claude-sonnet-4-5", SYSTEM, msgs, 900).replace(chr(0x2014), ", ")
            cited = [p for p in top if f"[{p['id']}]" in txt]
            return {"answer": txt, "sources": [{k: p[k] for k in ("id", "label", "text", "ref")} for p in (cited or top[:4])], "mode": "claude", "n": len(ps)}
        except Exception as e:
            note = f" The Claude answer failed ({str(e)[:80]}), so the closest passages are shown."
    else:
        note = " Add a Claude API key in Settings for a written answer."
    lines = [f"{p['label']}: {p['text'][:260]}{'...' if len(p['text']) > 260 else ''}" for p in top[:4]]
    return {"answer": "Closest matches on file:\n\n" + "\n\n".join(lines) + "\n\n" + note.strip(), "sources": [{k: p[k] for k in ("id", "label", "text", "ref")} for p in top[:4]], "mode": "search", "n": len(ps)}
