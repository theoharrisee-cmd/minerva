"""A location map as a PNG for reports, the committee paper, the deck and the site brief.

Draws Carto basemap tiles when they can be fetched quickly, and a plain grid when they cannot, with the site marker,
boundary, title polygons and search radius on top. Needs Pillow. Tiles are only used for the picture and carry the
provider's attribution on it.
"""
from __future__ import annotations

import io
import math
import os
import urllib.request

from . import geo
from . import sketch as sketch_mod

TILE = 256
UA = "easyDevelopment/0.7 (site brief maps)"


def _px(lat, lon, z):
    s = TILE * 2 ** z
    r = math.radians(lat)
    return ((lon + 180) / 360 * s, (1 - math.log(math.tan(r) + 1 / math.cos(r)) / math.pi) / 2 * s)


def _zoom_for(lat, radius_m, w):
    m_per_px_needed = (2 * radius_m) / w
    for z in range(18, 4, -1):
        if 156543.03 * math.cos(math.radians(lat)) / 2 ** z >= m_per_px_needed:
            return z
    return 5


def _tile(z, x, y, fetch):
    n = 2 ** z
    if y < 0 or y >= n:
        return None
    url = f"https://a.basemaps.cartocdn.com/light_all/{z}/{x % n}/{y}.png"
    return fetch(url)


def _http_tile(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=3) as r:
        return r.read()


def render(site: dict, polygons=None, radius_m: int = 600, size=(1200, 700), fetch=None, use_tiles: bool = True) -> tuple[bytes, bool]:
    """PNG bytes and whether real map tiles were used. polygons: rings of (lon, lat) to shade, for example title polygons."""
    from PIL import Image, ImageDraw, ImageFont
    lat, lon = site["lat"], site["lon"]
    w, h = size
    b = site.get("boundary")
    if b and b.get("ring"):
        xy = geo.ring_to_xy([tuple(p) for p in b["ring"]], lat, lon)
        ext = max(max(abs(p[0]) for p in xy), max(abs(p[1]) for p in xy)) * 2.6
        radius_m = max(120, min(radius_m, ext))
    z = _zoom_for(lat, radius_m, min(w, h * 1.4))
    cx, cy = _px(lat, lon, z)
    img = Image.new("RGB", (w, h), "#F1F1EE")
    tiles_used = False
    if use_tiles:
        fetch = fetch or _http_tile
        failed = 0
        for tx in range(int((cx - w / 2) // TILE), int((cx + w / 2) // TILE) + 1):
            for ty in range(int((cy - h / 2) // TILE), int((cy + h / 2) // TILE) + 1):
                if failed >= 2:
                    break
                try:
                    data = _tile(z, tx, ty, fetch)
                    if data:
                        t = Image.open(io.BytesIO(data)).convert("RGB")
                        img.paste(t, (int(tx * TILE - cx + w / 2), int(ty * TILE - cy + h / 2)))
                        tiles_used = True
                except Exception:
                    failed += 1
    d = ImageDraw.Draw(img, "RGBA")
    if not tiles_used:
        step = 100
        m_per_px = 156543.03 * math.cos(math.radians(lat)) / 2 ** z
        gap = step / m_per_px
        k = 0.0
        while k < max(w, h):
            for off in (w / 2 + k, w / 2 - k):
                d.line([(off, 0), (off, h)], fill=(0, 0, 0, 22), width=1)
            for off in (h / 2 + k, h / 2 - k):
                d.line([(0, off), (w, off)], fill=(0, 0, 0, 22), width=1)
            k += gap
    P = lambda lo, la: (_px(la, lo, z)[0] - cx + w / 2, _px(la, lo, z)[1] - cy + h / 2)  # noqa: E731
    for ring in polygons or []:
        pts = [P(x, y) for x, y in ring]
        if len(pts) > 2:
            d.polygon(pts, fill=(120, 120, 120, 40), outline=(90, 90, 90, 200))
    if b and b.get("ring"):
        pts = [P(x, y) for x, y in b["ring"]]
        d.polygon(pts, fill=(255, 102, 0, 70))
        d.line(pts + [pts[0]], fill=(0, 0, 0, 255), width=3)
    sk = (site.get("sketch") or {}).get("items")
    if sk:
        try:
            f0 = ImageFont.truetype("/usr/share/fonts/truetype/crosextra/Carlito-Regular.ttf", 15)
        except Exception:
            f0 = ImageFont.load_default()
        sketch_mod.draw(d, P, sk, f0, w, h)
    x, y = P(lon, lat)
    d.ellipse([x - 9, y - 9, x + 9, y + 9], fill=(255, 102, 0, 255), outline=(255, 255, 255, 255), width=3)
    # scale bar
    m_per_px = 156543.03 * math.cos(math.radians(lat)) / 2 ** z
    bar_m = next(v for v in (20, 50, 100, 200, 500, 1000, 2000) if v / m_per_px > 90 or v == 2000)
    bx = 24
    d.rectangle([bx - 6, h - 46, bx + bar_m / m_per_px + 70, h - 12], fill=(255, 255, 255, 220))
    d.line([(bx, h - 24), (bx + bar_m / m_per_px, h - 24)], fill=(0, 0, 0, 255), width=3)
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/crosextra/Carlito-Regular.ttf", 15)
    except Exception:
        f = ImageFont.load_default()
    d.text((bx + bar_m / m_per_px + 8, h - 33), f"{bar_m} m" if bar_m < 1000 else f"{bar_m // 1000} km", fill=(0, 0, 0, 255), font=f)
    if tiles_used:
        t = "© OpenStreetMap contributors © CARTO"
        d.rectangle([w - 300, h - 26, w, h], fill=(255, 255, 255, 200))
        d.text((w - 294, h - 22), t, fill=(60, 60, 60, 255), font=f)
    out = io.BytesIO()
    img.save(out, "PNG", optimize=True)
    return out.getvalue(), tiles_used


def for_site(site: dict, cache_dir=None, fetch=None, use_tiles: bool = True) -> bytes | None:
    """Cached map for a site: reused while the location, boundary and polygons are unchanged."""
    if site.get("lat") is None:
        return None
    import hashlib
    polys = [geo.polygon_of(p["wkt"]) for p in ((site.get("assembly") or {}).get("polygons") or [])[:40] if p.get("wkt")]
    polys = [p for p in polys if p]
    key = hashlib.md5(repr((site["lat"], site["lon"], (site.get("boundary") or {}).get("ring"), len(polys), use_tiles, (site.get("sketch") or {}).get("items"))).encode()).hexdigest()[:10]
    path = None
    if cache_dir:
        os.makedirs(cache_dir, exist_ok=True)
        path = os.path.join(cache_dir, f"{site['id']}-{key}.png")
        if os.path.exists(path):
            return open(path, "rb").read()
    try:
        png, used = render(site, polys, fetch=fetch, use_tiles=use_tiles)
    except ImportError:
        return None
    if path and (used or not use_tiles):
        open(path, "wb").write(png)
    return png
