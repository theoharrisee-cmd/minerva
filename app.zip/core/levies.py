"""Section 106 and CIL by council.

Finds the council's Community Infrastructure Levy charging schedule through the planning.data.gov.uk dataset of schedules
(which lists a document link for each charging authority), reads that document, and pulls out the rates and policy figures it
states: CIL in pounds per square metre, planning obligation tariffs per home, and affordable housing percentages. A link to any
other public page or PDF (a planning obligations SPD, a local plan policy) can be read the same way.

Nothing is written into the appraisal until you choose a figure. Each figure carries the sentence it was taken from and the
document it came from, so it can be checked. Reading is by pattern, so odd layouts can be missed or misread. CIL rates are
indexed every year from the date of adoption, so an adopted rate is usually below the current one; the index box lets you allow for it.
"""
from __future__ import annotations

import io
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser

from . import datasources as ds
from . import net

DATASET = "community-infrastructure-levy-schedule"
SQM_TO_SQFT = 10.7639
_fetch_override = None  # tests replace this: (url) -> (bytes, content_type)
MAX_BYTES = 12_000_000
RESIDENTIAL = re.compile(r"resid|dwelling|housing|house|apartment|flat|\bC3\b|homes?\b", re.I)
STOP = {"council", "borough", "city", "district", "county", "metropolitan", "royal", "london", "of", "the", "and", "unitary", "authority", "town", "&"}


# ------------------------------------------------------------------ fetching

def _get(url: str) -> tuple[bytes, str]:
    if not url.lower().startswith(("http://", "https://")):
        raise ValueError("Give a web address that starts with http or https")
    if _fetch_override:
        return _fetch_override(url)
    if not net.robots_allowed(url):
        raise RuntimeError("the site's robots.txt does not allow automated reading of that page")
    req = urllib.request.Request(url, headers={"User-Agent": net.DEFAULT_UA, "Accept": "text/html,application/pdf,*/*", "Accept-Language": "en-GB,en;q=0.9"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = r.read(MAX_BYTES + 1)
            ctype = r.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"the council site returned HTTP {e.code}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"cannot connect ({e.reason})")
    if len(data) > MAX_BYTES:
        raise RuntimeError("the document is larger than 12 MB")
    return data, ctype


class _Text(HTMLParser):
    BLOCK = {"p", "div", "li", "br", "h1", "h2", "h3", "h4", "h5", "tr", "table", "section", "article", "ul", "ol"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript", "nav", "footer", "header"):
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append("\n")
        elif tag in ("td", "th"):
            self.out.append(" | ")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "nav", "footer", "header"):
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.out.append("\n")

    def handle_data(self, d):
        if not self.skip:
            self.out.append(d)


def html_to_text(html: str) -> str:
    p = _Text()
    p.feed(html)
    t = "".join(p.out).replace("\xa0", " ")
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"(\s*\|\s*)+", lambda m: " | ", t)
    return re.sub(r"\n\s*\n+", "\n", t).strip()


def read_document(url: str) -> dict:
    """Fetch a page or PDF and return its text."""
    data, ctype = _get(url)
    if "pdf" in ctype.lower() or url.lower().split("?")[0].endswith(".pdf") or data[:5] == b"%PDF-":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise RuntimeError("Reading PDFs needs the pypdf package")
        rd = PdfReader(io.BytesIO(data))
        text = "\n".join((p.extract_text() or "") for p in rd.pages[:80])
        kind = "pdf"
    else:
        text = html_to_text(data.decode("utf-8", "ignore"))
        kind = "page"
    return {"url": url, "kind": kind, "text": text, "chars": len(text)}


# ------------------------------------------------------------------ finding the council's schedule

def _norm(name: str) -> set[str]:
    return {w for w in re.findall(r"[a-z]+", (name or "").lower()) if w not in STOP and len(w) > 2}


FILES = "https://files.planning.data.gov.uk"


def _csv_rows(url: str) -> list[dict]:
    """A dataset file from the planning data platform. The published files are far lighter than the entity API, which can time out."""
    import csv
    data, _ = _get(url)
    rd = csv.DictReader(io.StringIO(data.decode("utf-8-sig", "ignore")))
    if not rd.fieldnames or "entity" not in rd.fieldnames:
        raise RuntimeError("not a dataset file")
    return [r for r in rd]


def _org_names() -> dict:
    try:
        rows = _csv_rows(f"{FILES}/organisation-collection/dataset/organisation.csv")
        names = {str(r.get("entity")): r.get("name") or r.get("official-name") or "" for r in rows}
        if names:
            return names
    except Exception:
        pass
    try:
        js = ds._http(f"{ds.PDG}/organisation.json", ttl=7 * 86400)
        rows = js.get("organisations") if isinstance(js, dict) else js
        return {str(r.get("entity")): r.get("name") or r.get("official-name") or "" for r in rows or [] if isinstance(r, dict)}
    except Exception:
        return {}


def find_schedule(la: str) -> dict:
    """The charging schedule recorded for a council. Returns {ok, items, error}. Several items can come back when names are close."""
    if not la:
        return {"ok": False, "items": [], "error": "The site has no local authority yet. Add a postcode first."}
    rows, err = None, ""
    try:
        rows = _csv_rows(f"{FILES}/dataset/{DATASET}.csv")
    except Exception as e:
        err = str(e)
    if not rows:
        try:
            js = ds._http(f"{ds.PDG}/entity.json?dataset={DATASET}&limit=500", ttl=86400)
            rows = js.get("entities") if isinstance(js, dict) else js
        except Exception as e:
            return {"ok": False, "items": [], "error": f"planning.data.gov.uk could not be reached ({err or e}). Paste a link to the schedule instead."}
    if not rows:
        return {"ok": False, "items": [], "error": "The schedule dataset returned no entries"}
    want = _norm(la)
    orgs = _org_names()
    items = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        org = orgs.get(str(r.get("organisation-entity") or ""), "") or r.get("organisation") or ""
        hay = _norm(" ".join(str(r.get(k) or "") for k in ("name", "reference")) + " " + org) | set(re.findall(r"[a-z]+", str(r.get("document-url") or r.get("documentation-url") or "").lower()))
        title = f"{r.get('name') or ''} {r.get('document-url') or ''}".lower()
        if re.search(r"development[-_ ]scheme|\blds\b|local[-_ ]plan[-_ ]timetable", title) and not re.search(r"\bcil\b|levy|charging", title):
            continue
        if want and want <= hay:
            items.append({"name": r.get("name") or "", "organisation": org, "document_url": r.get("document-url") or "", "page_url": r.get("documentation-url") or "",
                          "adopted": r.get("adopted-date") or r.get("start-date") or "", "reference": r.get("reference") or "", "entity": r.get("entity")})
    items.sort(key=lambda x: x["adopted"] or "", reverse=True)
    return {"ok": bool(items), "items": items, "error": "" if items else f"No charging schedule is recorded for {la}. Some councils do not charge CIL. Paste a link to the schedule or policy instead."}


# ------------------------------------------------------------------ reading figures out of text

def _num(s: str) -> float:
    return float(s.replace(",", ""))


def _clean(s: str, n: int = 110) -> str:
    return re.sub(r"\s+", " ", s).strip(" |:-*.,;\u2013\u2014\u2022")[-n:]


def _snip(text: str, a: int, b: int, pad: int = 90) -> str:
    return re.sub(r"\s+", " ", text[max(0, a - pad):min(len(text), b + pad)]).strip()


def extract(text: str) -> dict:
    """CIL rates, per home tariffs and affordable housing percentages found in the text."""
    text = text or ""
    cil, tariffs, aff, seen = [], [], [], set()
    sqm = r"(?:per\s+)?(?:sq(?:uare)?\.?\s*m(?:etres?|eters?)?|sqm|m2|m²)"
    for m in re.finditer(r"£\s*([\d,]+(?:\.\d{1,2})?)\s*(?:/|per\s+)?\s*" + sqm, text, re.I):
        v = _num(m.group(1))
        if v < 5 or v > 3000:
            continue
        line_start = text.rfind("\n", 0, m.start()) + 1
        label = _clean(text[max(line_start, m.start() - 120):m.start()])
        if not label:
            prev = text.rfind("\n", 0, max(0, line_start - 1)) + 1
            label = _clean(text[prev:line_start])
        key = (label[-40:].lower(), v)
        if key in seen:
            continue
        seen.add(key)
        cil.append({"label": label or "Rate", "rate_sqm": v, "rate_sqft": round(v / SQM_TO_SQFT, 2), "residential": bool(RESIDENTIAL.search(label)), "snippet": _snip(text, m.start(), m.end())})
    # table rows: "Residential | £150" when the document states rates per square metre
    if re.search(r"per\s+square\s+met|£\s*/\s*(?:sq\s*)?m|£\s*per\s*sq", text, re.I) or cil:
        for m in re.finditer(r"^(?P<label>[^\n|£]{3,90}?)\s*\|\s*£\s*(?P<v>[\d,]+(?:\.\d{1,2})?)\s*(?:\||$)", text, re.M):
            v = _num(m.group("v"))
            label = _clean(m.group("label"))
            if 5 <= v <= 3000 and (label[-40:].lower(), v) not in seen:
                seen.add((label[-40:].lower(), v))
                cil.append({"label": label, "rate_sqm": v, "rate_sqft": round(v / SQM_TO_SQFT, 2), "residential": bool(RESIDENTIAL.search(label)), "snippet": _snip(text, m.start(), m.end())})
    for m in re.finditer(r"£\s*([\d,]+(?:\.\d{1,2})?)\s*(?:/|per\s+|for\s+each\s+|each\s+)\s*(?:net\s+)?(?:additional\s+)?(?:new\s+)?(dwelling|home|unit|house|flat|apartment|bedroom)s?\b", text, re.I):
        v = _num(m.group(1))
        if v < 50 or v > 100000:
            continue
        after = re.match(r"\s*(?:towards?|for|to\s+fund|to\s+provide|to\s+mitigate)\s+([^.;\n]{3,70}?)(?=\s+and\s+£|[.;,\n]|$)", text[m.end():m.end() + 120], re.I)
        label = _clean(after.group(1)) if after else _clean(re.split(r"[.;]\s+", text[max(text.rfind("\n", 0, m.start()) + 1, m.start() - 70):m.start()])[-1])
        key = (label[-40:].lower(), v, m.group(2).lower())
        if key in seen:
            continue
        seen.add(key)
        tariffs.append({"label": label or "Contribution", "per": m.group(2).lower(), "amount": v, "snippet": _snip(text, m.start(), m.end())})
    seen2 = set()
    for m in re.finditer(r"(\d{1,3}(?:\.\d)?)\s?(?:%|per\s?cent)", text):
        p = float(m.group(1))
        a0 = max(text.rfind(". ", 0, m.start()), text.rfind("\n", 0, m.start()), 0)
        a1 = min([i for i in (text.find(". ", m.end()), text.find("\n", m.end())) if i >= 0] or [len(text)])
        ctx = text[a0:a1]
        near = text[max(0, m.start() - 70):m.end() + 60]
        if not (5 <= p <= 100) or not re.search(r"affordable", near, re.I):
            continue
        if re.search(r"^\s*(?:%|per\s?cent)?\s*(?:as\s+)?(?:social|affordable\s+rent|intermediate|shared|first\s+homes|rented|tenure)", text[m.end():m.end() + 40], re.I) or re.search(r"(?:split|tenure)[^.]{0,40}$", text[max(0, m.start() - 60):m.start()], re.I):
            continue
        th = re.search(r"(\d+)\s*(?:or\s+more\s+)?(?:dwellings|homes|units|residential\s+units)|(?:major|10\s+or\s+more)", ctx, re.I)
        key = (p, _clean(ctx, 60))
        if key in seen2:
            continue
        seen2.add(key)
        aff.append({"pct": p, "threshold": _clean(th.group(0), 40) if th else "", "snippet": _snip(text, m.start(), m.end(), 120)})
    cil.sort(key=lambda x: (not x["residential"], x["rate_sqm"]))
    return {"cil": cil[:25], "tariffs": tariffs[:25], "affordable": aff[:12]}


# ------------------------------------------------------------------ state and applying

def read_source(site: dict, url: str, label: str = "") -> dict:
    doc = read_document(url)
    ex = extract(doc["text"])
    src = {"url": url, "kind": doc["kind"], "label": label or url, "chars": doc["chars"], "read": datetime.now(timezone.utc).isoformat(timespec="minutes"), **ex}
    lv = site.setdefault("levies", {})
    srcs = [s for s in lv.get("sources", []) if s["url"] != url]
    srcs.insert(0, src)
    lv["sources"] = srcs[:6]
    return src


def find_and_read(site: dict) -> dict:
    """Look the council's schedule up and read the newest one. Returns a message for the user when it cannot."""
    la = site.get("la") or ""
    found = find_schedule(la)
    lv = site.setdefault("levies", {})
    lv["found"] = {"la": la, "ok": found["ok"], "items": found["items"][:5], "error": found["error"], "when": datetime.now(timezone.utc).isoformat(timespec="minutes")}
    if not found["ok"]:
        return lv["found"]
    top = found["items"][0]
    url = top["document_url"] or top["page_url"]
    if not url:
        lv["found"]["error"] = "The schedule is recorded without a document link"
        return lv["found"]
    try:
        read_source(site, url, f"{top['organisation'] or la} charging schedule" + (f", adopted {top['adopted']}" if top["adopted"] else ""))
        lv["found"]["read"] = url
    except Exception as e:
        lv["found"]["error"] = f"Found the schedule but could not read it ({e}). Open the link and paste the page address of the rates instead."
    return lv["found"]


def _suggested(site: dict, a: dict) -> dict:
    """The current values for the three appraisal inputs and where each came from."""
    ap = (site.get("levies") or {}).get("applied") or {}
    out = {}
    for k, lbl in (("cil_psf", "CIL (£ per sq ft of floor area)"), ("s106_per_unit", "Planning obligations (£ per home)"), ("affordable_pct", "Affordable housing share")):
        out[k] = {"label": lbl, "value": (site.get("ovr") or {}).get(k, a.get(k)), "applied": ap.get(k)}
    return out


# Mayor of London CIL2. Source: Mayoral Community Infrastructure Levy annual rate summary 2026 (london.gov.uk/media/111917/download).
# It is charged on top of the borough's own CIL in every London borough, on permissions granted in the calendar year, and indexed each 1 January.
MCIL_YEAR = 2026
MCIL_SOURCE = "https://www.london.gov.uk/media/111917/download"
MCIL_RATES = {1: 96.97, 2: 72.73, 3: 30.30}
MCIL_BANDS = {
    1: ["camden", "city of london", "westminster", "hammersmith and fulham", "islington", "kensington and chelsea", "richmond upon thames", "wandsworth"],
    2: ["barnet", "brent", "bromley", "ealing", "enfield", "hackney", "haringey", "harrow", "hillingdon", "hounslow", "kingston upon thames", "lambeth", "lewisham", "merton",
        "redbridge", "southwark", "tower hamlets", "waltham forest"],
    3: ["barking and dagenham", "bexley", "croydon", "greenwich", "havering", "newham", "sutton"],
}


def mayoral(la: str) -> dict | None:
    """The Mayor of London's CIL band and rate for a borough, or None outside London. Residential rate; special central London rates for offices, retail and hotels are not included."""
    n = re.sub(r"\b(london borough of|royal borough of|city of|borough|council|the)\b", " ", (la or "").lower().replace("&", " and "))
    n = re.sub(r"[^a-z ]", " ", n)
    n = re.sub(r"\s+", " ", n).strip()
    for band, names in MCIL_BANDS.items():
        for nm in names:
            k = re.sub(r"\b(city of)\b", "", nm).strip()
            if n == k or n == nm or (n and n in (k, nm)):
                return {"band": band, "rate_sqm": MCIL_RATES[band], "rate_sqft": round(MCIL_RATES[band] / SQM_TO_SQFT, 2), "year": MCIL_YEAR, "source": MCIL_SOURCE,
                        "note": f"Mayor of London CIL2, Band {band}, {MCIL_YEAR} rate. It is charged on top of the borough's CIL, and the rate is re-indexed every January."}
    return None


def links(la: str) -> list[dict]:
    q = urllib.parse.quote
    return [{"label": f"Search: {la} CIL charging schedule", "url": f"https://www.google.com/search?q={q(la + ' community infrastructure levy charging schedule')}"},
            {"label": f"Search: {la} planning obligations SPD", "url": f"https://www.google.com/search?q={q(la + ' planning obligations supplementary planning document')}"},
            {"label": f"Search: {la} affordable housing policy local plan", "url": f"https://www.google.com/search?q={q(la + ' local plan affordable housing policy percentage')}"},
            {"label": "planning.data.gov.uk: CIL schedules", "url": f"{ds.PDG}/dataset/{DATASET}"}] if la else []


def state(site: dict, a: dict) -> dict:
    lv = site.get("levies") or {}
    return {"la": site.get("la") or "", "found": lv.get("found"), "sources": lv.get("sources", []), "current": _suggested(site, a), "links": links(site.get("la") or ""), "mayoral": mayoral(site.get("la") or ""),
            "note": "Figures come from published documents read by pattern. Check each against the source before relying on it. CIL rates are indexed each year from adoption."}


def apply(site: dict, key: str, value: float, meta: dict | None = None, base: dict | None = None) -> dict:
    """Write a chosen figure into the site's assumptions and record where it came from. Suggestions already applied keep their effect."""
    if key not in ("cil_psf", "s106_per_unit", "affordable_pct"):
        raise ValueError("Unknown input")
    value = float(value)
    if key == "affordable_pct":
        value = value / 100 if value > 1 else value
        if not 0 <= value <= 1:
            raise ValueError("The affordable share must be between 0 and 100%")
    if value < 0:
        raise ValueError("A rate cannot be negative")
    lv = site.setdefault("levies", {})
    prior = (lv.get("applied") or {}).get(key)
    deltas = 0.0
    for it in (site.get("suggest") or {}).get("accepted", {}).values():
        deltas += sum(c["delta"] for c in it.get("changes", []) if c["key"] == key)
    site.setdefault("ovr", {})[key] = round(value + deltas, 6)
    lv.setdefault("applied", {})[key] = {"value": value, "when": datetime.now(timezone.utc).isoformat(timespec="minutes"), "previous": prior, **(meta or {})}
    return lv["applied"][key]


def clear(site: dict, key: str, base: dict) -> None:
    lv = site.get("levies") or {}
    if key not in (lv.get("applied") or {}):
        return
    del lv["applied"][key]
    deltas = 0.0
    for it in (site.get("suggest") or {}).get("accepted", {}).values():
        deltas += sum(c["delta"] for c in it.get("changes", []) if c["key"] == key)
    ovr = site.setdefault("ovr", {})
    if abs(deltas) < 1e-9:
        ovr.pop(key, None)
    else:
        ovr[key] = round(base.get(key, 0) + deltas, 6)
