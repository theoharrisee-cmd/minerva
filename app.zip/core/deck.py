"""Investor deck for a site (python-pptx): a short, plain set of slides built from the same data as the committee paper."""
from __future__ import annotations

import io
from datetime import date

from .committee import fdate, money, pct, verdict

ORANGE = (0xFF, 0x66, 0x00)
INK = (0x14, 0x14, 0x14)
MUTED = (0x66, 0x66, 0x66)
SOFT = (0xF3, 0xF3, 0xF3)
WHITE = (255, 255, 255)
RED = (0xB3, 0x26, 0x1E)
GREEN = (0x1D, 0x7A, 0x3A)


def build(pack: dict) -> bytes:
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.dml.color import RGBColor
    from pptx.enum.chart import XL_CHART_TYPE
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.util import Emu, Inches, Pt

    s, ev, pl, dd, inv = pack["site"], pack["ev"], pack["planning"], pack.get("dd") or {}, pack.get("investor") or {}
    st, sc = pack.get("structure") or {}, pack.get("scenarios") or {}
    a = ev.get("appraisal") or {}
    ok = a and not a.get("incomplete")
    flags = ev.get("flags") or []
    vd, why = verdict(a, flags)
    strat = pack["strategies"].get(ev["strategy"], ev["strategy"])
    rgb = lambda c: RGBColor(*c)

    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    blank = prs.slide_layouts[6]
    total = [0]

    def rect(sl, x, y, w, h, fill, line=None):
        sh = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
        sh.fill.solid()
        sh.fill.fore_color.rgb = rgb(fill)
        if line:
            sh.line.color.rgb = rgb(line)
        else:
            sh.line.fill.background()
        sh.shadow.inherit = False
        return sh

    def text(sl, x, y, w, h, t, size=14, bold=False, color=INK, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP):
        tb = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = anchor
        tf.margin_left = tf.margin_right = Inches(0.05)
        lines = t if isinstance(t, list) else [t]
        for i, ln in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align
            r = p.add_run()
            r.text = str(ln)
            r.font.size, r.font.bold, r.font.name = Pt(size), bold, "Aptos"
            r.font.color.rgb = rgb(color)
            p.space_after = Pt(4)
        return tb

    def slide(title, sub=""):
        sl = prs.slides.add_slide(blank)
        total[0] += 1
        rect(sl, 0, 0, 13.333, 0.12, ORANGE)
        text(sl, 0.6, 0.35, 12, 0.7, title, 28, True)
        if sub:
            text(sl, 0.6, 1.0, 12, 0.4, sub, 14, False, MUTED)
        text(sl, 0.6, 7.0, 9, 0.3, f"easyDevelopment · {s.get('name', '')}", 10, False, MUTED)
        text(sl, 11.7, 7.0, 1.1, 0.3, str(total[0]), 10, False, MUTED, PP_ALIGN.RIGHT)
        return sl

    def table(sl, x, y, w, rows, widths, size=12, num=(), row_h=0.34):
        shp = sl.shapes.add_table(len(rows), len(rows[0]), Inches(x), Inches(y), Inches(w), Inches(row_h * len(rows)))
        tb = shp.table
        tbl = shp._element.graphic.graphicData.tbl
        tbl.tblPr.set("firstRow", "0")
        tbl.tblPr.set("bandRow", "0")
        for j, wd in enumerate(widths):
            tb.columns[j].width = Inches(wd)
        for i, row in enumerate(rows):
            tb.rows[i].height = Inches(row_h)
            for j, v in enumerate(row):
                c = tb.cell(i, j)
                c.fill.solid()
                c.fill.fore_color.rgb = rgb(SOFT if i == 0 else WHITE)
                c.margin_left = c.margin_right = Inches(0.08)
                c.margin_top = c.margin_bottom = Inches(0.03)
                c.vertical_anchor = MSO_ANCHOR.MIDDLE
                tf = c.text_frame
                tf.word_wrap = True
                p = tf.paragraphs[0]
                p.alignment = PP_ALIGN.RIGHT if j in num else PP_ALIGN.LEFT
                r = p.add_run()
                r.text = str(v)
                r.font.size, r.font.name, r.font.bold = Pt(size), "Aptos", i == 0
                r.font.color.rgb = rgb(INK)
        return shp

    def tile(sl, x, y, w, h, label, val, sub=""):
        rect(sl, x, y, w, h, WHITE, (0xDD, 0xDD, 0xDD))
        text(sl, x + 0.1, y + 0.08, w - 0.2, 0.3, label.upper(), 10, True, MUTED)
        text(sl, x + 0.1, y + 0.38, w - 0.2, 0.6, val, 24, True)
        if sub:
            text(sl, x + 0.1, y + 1.0, w - 0.2, 0.4, sub, 11, False, MUTED)

    # 1 title
    sl = prs.slides.add_slide(blank)
    total[0] += 1
    rect(sl, 0, 0, 13.333, 7.5, ORANGE)
    text(sl, 0.8, 0.7, 6, 0.5, "easyDevelopment", 20, True, WHITE)
    text(sl, 0.8, 2.3, 11.5, 1.5, s.get("name", "Site"), 44, True, WHITE)
    text(sl, 0.8, 3.7, 11.5, 0.5, s.get("address", ""), 20, False, WHITE)
    text(sl, 0.8, 4.4, 11.5, 0.5, f"{strat}  ·  {vd}", 18, True, WHITE)
    who = " · ".join(x for x in [inv.get("name"), inv.get("firm")] if x)
    text(sl, 0.8, 6.5, 11.5, 0.4, f"{who + '  ·  ' if who else ''}{date.today().day} {date.today():%B %Y}" + ("  ·  Illustrative site with fictional details" if s.get("demo") else ""), 12, False, WHITE)

    # 2 recommendation
    sl = slide("Recommendation", why)
    if ok:
        basis = "on GDV" if a["profit_basis"] == "gdv" else "on cost"
        m = a["profit_on_gdv"] if a["profit_basis"] == "gdv" else a["profit_on_cost"]
        cells = [("Gross development value", money(a["gdv"]), f"{a['units']} units"), ("Total cost", money(a["total_cost"]), "including land and finance"), ("Profit at asking", money(a["profit"]), f"{pct(m)} {basis}, target {pct(a['target_profit'], 0)}"),
                 ("Levered IRR", pct(a.get("irr_levered")), f"{a['equity_multiple']:.2f}x equity multiple"), ("Asking price", money(a["asking"]) if a["asking"] else "n/a", ""), ("Maximum bid", money(a["max_bid"]), f"opening offer {money(a['opening_offer'])}"),
                 ("Headroom to asking", pct(a["headroom_vs_asking"], 0) if a.get("headroom_vs_asking") is not None else "n/a", ""), ("Peak equity", money(a["peak_equity"]), f"hold {a['months_land']:.0f} months")]
        for i, (l, v, sub) in enumerate(cells):
            tile(sl, 0.6 + (i % 4) * 3.1, 1.7 + (i // 4) * 1.7, 2.9, 1.5, l, v, sub)
        hi = [f["flag"] for f in flags if f["severity"] == "High"]
        text(sl, 0.6, 5.2, 12, 1.2, (["High severity risks to resolve: " + "; ".join(hi) + "."] if hi else ["No high severity risks are recorded on the file."]) + [f"Score {ev['score']['score']} ({ev['score']['grade']}). Stage: {s.get('stage', '')}. Planning: {s.get('planning_status', 'Unknown')}."], 14)

    # 3 proposal
    if ok:
        sl = slide("The proposal and appraisal", f"{a['units']} units, {strat.lower()}")
        rows = [["Cost line", "Amount", "Share of GDV"]] + [[n, money(v), pct(v / a["gdv"]) if a["gdv"] else ""] for n, v in [
            ("Land and acquisition costs", a["land_cost"]), ("Land finance", a["land_finance"]), ("Build or refurbishment", a["build"]), ("Contingency and fees", a["contingency"] + a["fees"]),
            ("S106 and CIL", a["s106"] + a["cil"]), ("Build finance", a["build_finance"]), ("Sales costs", a["sales_costs"]), ("Total cost", a["total_cost"])]]
        table(sl, 0.6, 1.7, 7.2, rows, [3.9, 1.8, 1.5], 13, (1, 2), 0.42)
        A = pack["assumptions"]
        text(sl, 8.3, 1.7, 4.5, 4.5, ["Key assumptions", f"Sales £{(s.get('sales_psf') or A['sales_psf']):.0f} per sq ft", f"Build £{A['build_psf']:.0f} per sq ft GIA plus {pct(A['external_pct'], 0)} externals",
                                      f"Affordable housing {pct(A['affordable_pct'], 0)}", f"S106 {money(A['s106_per_unit'])} per unit", f"Build {A['build_months']:.0f} months, planning {A['planning_months']:.0f} months", f"Finance {pct(A['finance_rate'])} at {pct(A['ltc'], 0)} of cost"], 14)

    # 4 scenarios
    if sc.get("rows"):
        sl = slide("Scenarios and break-even", "Profit under each case, and how far one assumption can move before the scheme stops working")
        rows = [["Scenario", "Profit", "Margin", "IRR"]] + [[r["name"], money(r["profit"]), f"{pct(r['margin'])} {r['basis']}", pct(r["irr"])] for r in sc["rows"]]
        table(sl, 0.6, 1.7, 6.0, rows, [1.9, 1.4, 1.7, 1.0], 12, (1, 2, 3), 0.4)
        cd = CategoryChartData()
        cd.categories = [r["name"] for r in sc["rows"]]
        cd.add_series("Profit (£m)", [round(r["profit"] / 1e6, 2) for r in sc["rows"]])
        gf = sl.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(6.9), Inches(1.6), Inches(5.9), Inches(2.9), cd)
        ch = gf.chart
        ch.has_legend = False
        ch.has_title = False
        ch.plots[0].series[0].format.fill.solid()
        ch.plots[0].series[0].format.fill.fore_color.rgb = rgb(ORANGE)
        ch.plots[0].has_data_labels = True
        ch.plots[0].data_labels.font.size = Pt(11)
        ch.plots[0].data_labels.number_format = '0.0'
        ch.plots[0].data_labels.number_format_is_linked = False
        ch.category_axis.tick_labels.font.size = Pt(11)
        ch.value_axis.tick_labels.font.size = Pt(10)
        ch.value_axis.has_major_gridlines = False
        be = sc.get("breakeven") or {}
        if be.get("rows"):
            def f(x, u):
                return "not reached" if x is None else f"{x:+.1f}{'%' if u == '%' else (' bps' if u == 'bps' else ' months')}"
            rows = [["Single change", "Zero profit", "Meets target"]] + [[r["phrase"], f(r["zero"], r["unit"]), f(r["target"], r["unit"])] for r in be["rows"]]
            rows.append(["Land price", money(be["land"]["zero"]) if be["land"].get("zero") else "not reached", money(be["land"]["target"]) if be["land"].get("target") else "not reached"])
            table(sl, 0.6, 4.3 if len(sc["rows"]) < 5 else 4.6, 12.2, rows, [5.2, 3.5, 3.5], 12, (1, 2), 0.36)

    # homes and plans
    hm = pack.get("homes")
    if hm:
        from . import homes_out, floorplan
        rows, tot = homes_out.schedule(hm)
        sl = slide("Homes and layouts", ", ".join(tot[:3]))
        table(sl, 0.6, 1.6, 12.2, rows[:9], [5.2, 1.4, 1.2, 1.4, 1.5, 1.5], 12, (1, 2, 3, 4, 5), 0.38)
        text(sl, 0.6, 5.6, 12.2, 0.8, homes_out.counts_line(hm), 12, False, MUTED)
        sh = homes_out.sheets(hm, 6)
        for i in range(0, len(sh), 2):
            sl = slide("Typical home plans")
            for j, (title, prims, box) in enumerate(sh[i:i + 2]):
                floorplan.to_pptx(sl, prims, box, Inches(0.6 + j * 6.3), Inches(1.6), Inches(6.0), Inches(5.2))
        bl = homes_out.block(hm)
        if bl:
            sl = slide("Typical floor of the block")
            floorplan.to_pptx(sl, bl[0], bl[1], Inches(0.6), Inches(1.5), Inches(12.2), Inches(5.3))

    # site data
    dt = pack.get("data")
    if dt:
        sl = slide("Site and constraints", f"Data checked {dt.get('checked') or 'earlier'}")
        if dt.get("map"):
            sl.shapes.add_picture(io.BytesIO(dt["map"]), Inches(0.6), Inches(1.6), width=Inches(6.6))
        rows = dt["constraints"][:9] if dt.get("constraints") else [["Constraint", "Finding", "Source"], ["None found", dt.get("constraints_line", "")[:120] or "No constraints found in the sources checked", ""]]
        table(sl, 7.4, 1.6, 5.4, [[r[0], (r[1] or "")[:70]] for r in rows], [1.9, 3.5], 11, (), 0.5)
        if dt.get("constraints_line"):
            text(sl, 0.6, 6.5, 12.2, 0.6, dt["constraints_line"][:230], 11, False, MUTED)
        sl = slide("Ownership and surroundings")
        table(sl, 0.6, 1.6, 6.3, [["Item", "Detail"]] + [[r[0], r[1][:130]] for r in dt["ownership"][:6]], [1.9, 4.4], 11, (), 0.55)
        y = 1.6
        if dt.get("record_lines"):
            text(sl, 7.2, y, 5.6, 2.2, dt["record_lines"][:2], 12)
            y = 3.9
        if dt.get("applications"):
            table(sl, 7.2, y, 5.6, [["Reference", "Proposal", "Status"]] + [[r[0], r[1][:60], r[2]] for r in dt["applications"][1:5]], [1.3, 3.2, 1.1], 10, (), 0.5)
    lay = pack.get("layout")
    if lay:
        from . import layout as _lay
        sl = slide("Layout test", f"{lay['homes']} houses fit at {lay['density_dph']} homes per hectare")
        sl.shapes.add_picture(io.BytesIO(_lay.to_png(lay)), Inches(0.6), Inches(1.5), height=Inches(5.3))
        table(sl, 7.9, 1.6, 4.9, [["Check", "Result"]] + [[c["title"], c["status"].title()] for c in lay["checks"]], [3.6, 1.3], 11, (), 0.5)

    # 5 planning
    sl = slide("Planning", f"{s.get('planning_status') or 'Unknown'}" + (f" · {pl.get('la')}" if pl.get("la") else ""))
    ro = pl.get("read_out") or {}
    lines = [f"Planning risk: {ro.get('risk') or 'not assessed'}." + (f" Permission expires {fdate(ro['permission_expiry'])}." if ro.get("permission_expiry") else "")] + [f"{x['level']}: {x['text']}" for x in ro.get("points", [])[:5]]
    text(sl, 0.6, 1.6, 6.0, 5, lines, 13)
    cons = pl.get("consultees") or []
    if cons:
        table(sl, 6.9, 1.7, 5.9, [["Consultee", "Stance", "Summary"]] + [[c.get("body", ""), c.get("stance", ""), (c.get("summary", "") or "")[:90]] for c in cons[:7]], [1.5, 1.1, 3.3], 11, (), 0.5)

    ps = pack.get("strategy")
    if ps:
        sl = slide("Planning strategy", f"{ps['route']['title']} · complexity {ps['level'].lower()}")
        lines = [ps["route"]["summary"]] + (["About %d months to consent." % ps["timeline"]["total_months"]] if ps["timeline"].get("total_months") else []) + [x["text"] for x in ps["arguments"][:4]]
        text(sl, 0.6, 1.6, 6.0, 5, lines, 13)
        if ps["concerns"]:
            table(sl, 6.9, 1.7, 5.9, [["Likely concern", "Response"]] + [[x["topic"], (x["mitigation"] or "")[:110]] for x in ps["concerns"][:6]], [2.0, 3.9], 11, (), 0.55)

    # 6 risks
    sl = slide("Risks and mitigation")
    if flags:
        table(sl, 0.6, 1.5, 12.2, [["Risk", "Severity", "Mitigation"]] + [[f["flag"], f["severity"], f.get("mitigation", "")] for f in flags[:9]], [3.2, 1.2, 7.8], 12, (), 0.52)
    else:
        text(sl, 0.6, 1.6, 12, 1, "No risks are recorded on the file. That reflects the data held.", 14)
    ds = dd.get("summary")
    if ds:
        text(sl, 0.6, 6.4, 12, 0.5, f"Due diligence: {ds['done']} of {ds['total']} items complete, {ds['issues']} issues, {ds['overdue']} overdue.", 13, True)

    # 7 funding
    if ok:
        sl = slide("Funding and returns")
        A = pack["assumptions"]
        full = pack.get("full") or {}
        text(sl, 0.6, 1.5, 5.4, 3.5, ["Capital stack", f"Peak equity {money(a['peak_equity'])}", f"Senior debt at peak {money(full.get('senior_peak'))} at {pct(A['finance_rate'])}", *( [f"Mezzanine at peak {money(full.get('mezz_peak'))} at {pct(A['mezz_rate'])}"] if A.get("mezz_ltc") else []),
                                     f"Cost of equity {pct(A['cost_of_equity'])}, NPV of equity {money(a.get('npv_equity'))}"], 14)
        wf = st.get("waterfall")
        if wf:
            table(sl, 6.3, 1.6, 6.5, [["", "Invested", "Profit", "IRR", "Multiple"]] + [[n, money(w["invested"]), money(w["profit"]), pct(w["irr"]), f"{w['multiple']:.2f}x" if w["multiple"] else "n/a"] for n, w in (("All equity", wf["total"]), ("Investor", wf["investor"]), ("Sponsor", wf["sponsor"]))],
                  [1.5, 1.4, 1.4, 1.1, 1.1], 12, (1, 2, 3, 4), 0.42)
        ld = st.get("lender")
        if ld:
            table(sl, 0.6, 4.6, 12.2, [["Lender test", "Position", "Limit", "Result"]] + [[t["name"], f"{t['value']:.1f}{t['unit']}", f"{'max' if t['kind'] == 'max' else 'min'} {t['limit']:.1f}{t['unit']}", "Pass" if t["ok"] else "Breach"] for t in ld["tests"]], [5.2, 2.4, 2.6, 2.0], 12, (1, 2), 0.36)

    pg, fp = pack.get("programme"), pack.get("funding")
    if ok and (pg or fp):
        sl = slide("Programme and funding")
        if pg:
            table(sl, 0.6, 1.6, 6.0, [["Stage", "Months"]] + [[g["label"], g["end"] - g["start"] + 1] for g in pg["gantt"][:8]], [4.4, 1.6], 12, (1,), 0.42)
            if pg.get("delay") and pg["delay"].get("per_month"):
                text(sl, 0.6, 5.6, 6.0, 1, f"Each month of delay costs about {money(pg['delay']['per_month'])} of profit.", 13, True)
        if fp:
            table(sl, 6.9 if pg else 0.6, 1.6, 5.9 if pg else 8.0, [["Package", "Levered IRR", "Peak equity"]] + [[r["name"], pct(r["irr_levered"]), money(r["peak_equity"])] for r in fp["compare"][:6]], [2.6, 1.6, 1.7] if pg else [4.0, 2.0, 2.0], 12, (1, 2), 0.42)

    # 8 market
    comps = s.get("comps") or []
    near = ((pack.get("scheme_comps") or {}).get("items") or [])[:6]
    if comps or near:
        sl = slide("Market evidence")
        if comps:
            table(sl, 0.6, 1.5, 12.2, [["Type", "Evidence", "Detail", "Metric", "Date"]] + [[c["kind"], c["address"], c["detail"], c["metric"], c["date"]] for c in comps[:6]], [1.4, 3.6, 3.8, 2.3, 1.1], 12, (), 0.4)
        if near:
            table(sl, 0.6, 4.4, 12.2, [["Nearby scheme", "Status", "Units", "Distance", "Source"]] + [[x["name"], x["kind"], x.get("units") or "", f"{x['distance_km']:.1f} km", x["source"]] for x in near], [5.0, 2.0, 1.2, 1.6, 2.4], 11, (2, 3), 0.34)

    # 9 next steps
    sl = slide("Next steps")
    steps = list(((pl.get("analysis") or {}).get("next_steps")) or [])
    if ok and vd in ("Pursue", "Pursue with conditions"):
        steps.insert(0, f"Submit an offer at {money(a['opening_offer'])}, with authority to go to {money(a['walk_away'])}.")
    if ok and vd == "Renegotiate":
        steps.insert(0, f"Go back to the agent with an offer no higher than {money(a['max_bid'])}, or find cost or value evidence that closes the gap.")
    if any(f["severity"] == "High" for f in flags):
        steps.append("Close out the high severity risks before exchange.")
    steps.append("Commission a quantity surveyor's cost plan and an independent valuation.")
    text(sl, 0.6, 1.6, 12, 4.8, [f"{i}. {x}" for i, x in enumerate(steps[:8], 1)], 16)
    text(sl, 0.6, 6.5, 12, 0.4, "Figures marked * are indicative. Outputs depend on the assumptions shown and the data held at the date above.", 10, False, MUTED)

    bio = io.BytesIO()
    prs.save(bio)
    return bio.getvalue()
