"""One printable page per site: everything the file holds, laid out for reading and for printing to PDF."""
from __future__ import annotations

import html
from datetime import date

from . import costs
from .committee import fdate, money, pct, verdict

E = html.escape

CSS = """
:root{--o:#FF6600;--ink:#141414;--mut:#666;--line:#e4e4e4;--bg:#fff;--soft:#f6f6f6}
*{box-sizing:border-box}body{margin:0;background:#efefef;color:var(--ink);font:13px/1.5 Helvetica,Arial,sans-serif}
.page{max-width:900px;margin:24px auto;background:var(--bg);padding:0 0 28px;box-shadow:0 2px 24px rgba(0,0,0,.08)}
.mast{background:var(--o);color:#fff;padding:14px 32px;display:flex;justify-content:space-between;align-items:center;font-weight:800;font-size:17px;letter-spacing:-.02em}
.mast span{font-weight:500;font-size:12px;opacity:.95}
.in{padding:0 32px}h1{font-size:26px;margin:26px 0 2px;letter-spacing:-.02em}.addr{color:var(--mut);margin:0 0 14px}
h2{font-size:15px;margin:28px 0 8px;padding-bottom:5px;border-bottom:2px solid var(--o);letter-spacing:-.01em}h3{font-size:13px;margin:16px 0 6px}
.verdict{display:flex;gap:16px;align-items:center;background:var(--soft);border-left:5px solid var(--o);padding:12px 16px;margin:10px 0 6px}
.verdict b{font-size:16px}.verdict p{margin:2px 0 0;color:#333}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0}.k{border:1px solid var(--line);padding:9px 11px}
.k .l{font-size:10.5px;text-transform:uppercase;letter-spacing:.06em;color:var(--mut)}.k .v{font-size:19px;font-weight:700;margin-top:2px}.k .s{font-size:11px;color:var(--mut)}
table{border-collapse:collapse;width:100%;margin:6px 0 4px;font-size:12px}th{background:#f0f0f0;text-align:left;font-weight:700}th,td{border:1px solid var(--line);padding:5px 8px;vertical-align:top}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}tr.tot td{font-weight:700;background:var(--soft)}
.pill{display:inline-block;padding:1px 8px;border:1px solid var(--line);font-size:11px;font-weight:600}.pill.hi{border-color:#b3261e;color:#b3261e}.pill.ok{border-color:#1d7a3a;color:#1d7a3a}.pill.md{border-color:#a86a00;color:#a86a00}
.note{color:var(--mut);font-size:11px}.two{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.hm td{text-align:center;padding:4px 2px;font-size:11px}.bar{height:9px;background:var(--o);display:inline-block;vertical-align:middle}
.foot{margin:26px 32px 0;padding-top:10px;border-top:1px solid var(--line);color:var(--mut);font-size:11px}
.bar-row{display:flex;align-items:center;gap:8px;margin:3px 0;font-size:12px}.bar-row .t{width:150px}.bar-row .b{flex:1;background:var(--soft);height:11px}.bar-row .b i{display:block;height:11px;background:var(--o)}.bar-row .v{width:90px;text-align:right}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:none}h2{break-after:avoid}table,.verdict,.k{break-inside:avoid}.noprint{display:none}}
@page{size:A4;margin:12mm}
"""


def _t(head, rows, num=(), cls=""):
    th = "".join(f'<th class="{"n" if i in num else ""}">{E(str(h))}</th>' for i, h in enumerate(head))
    body = "".join("<tr>" + "".join(f'<td class="{"n" if i in num else ""}">{c if isinstance(c, _Raw) else E(str(c))}</td>' for i, c in enumerate(r)) + "</tr>" for r in rows)
    return f'<table class="{cls}"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table>'


class _Raw(str):
    pass


def _pill(t, kind=""):
    return _Raw(f'<span class="pill {kind}">{E(str(t))}</span>')


def _k(label, val, sub=""):
    return f'<div class="k"><div class="l">{E(label)}</div><div class="v">{E(str(val))}</div><div class="s">{E(str(sub))}</div></div>'


def render(pack: dict) -> str:
    s, ev, pl, dd, inv = pack["site"], pack["ev"], pack["planning"], pack.get("dd") or {}, pack.get("investor") or {}
    st, sc, cons = pack.get("structure") or {}, pack.get("scenarios") or {}, pack.get("constraints") or {}
    a = ev.get("appraisal") or {}
    ok = a and not a.get("incomplete")
    flags = ev.get("flags") or []
    vd, why = verdict(a, flags)
    A = pack["assumptions"]
    strat = pack["strategies"].get(ev["strategy"], ev["strategy"])
    o = []
    o.append(f'<div class="page"><div class="mast">easyDevelopment<span>Site report · {date.today().day} {date.today():%B %Y}</span></div><div class="in">')
    o.append(f'<h1>{E(s.get("name", "Site"))}</h1><p class="addr">{E(s.get("address", ""))} · {E(strat)} · Stage: {E(s.get("stage", ""))} · Score {ev["score"]["score"]} ({ev["score"]["grade"]})</p>')
    o.append(f'<div class="verdict"><div><b>{E(vd)}</b><p>{E(why)}</p></div></div>')
    if s.get("demo"):
        o.append('<p class="note">Illustrative site with fictional details.</p>')

    if ok:
        basis = "on GDV" if a["profit_basis"] == "gdv" else "on cost"
        m = a["profit_on_gdv"] if a["profit_basis"] == "gdv" else a["profit_on_cost"]
        o.append('<div class="grid">' + "".join([
            _k("Gross development value", money(a["gdv"]), f"{a['units']} units"), _k("Total cost", money(a["total_cost"]), "including land and finance"),
            _k("Profit at asking", money(a["profit"]), f"{pct(m)} {basis}, target {pct(a['target_profit'], 0)}"), _k("Levered IRR", pct(a.get("irr_levered")), f"{a['equity_multiple']:.2f}x equity multiple"),
            _k("Asking price", money(a["asking"]) if a["asking"] else "n/a"), _k("Maximum bid", money(a["max_bid"]), f"opening offer {money(a['opening_offer'])}"),
            _k("Headroom to asking", pct(a["headroom_vs_asking"], 0) if a.get("headroom_vs_asking") is not None else "n/a"), _k("Peak equity", money(a["peak_equity"]), f"hold {a['months_land']:.0f} months")]) + "</div>")
    else:
        o.append(f'<p>{E(why)}</p>')
    if s.get("description"):
        o.append(f'<p>{E(s["description"])}</p>')

    # appraisal
    if ok:
        o.append("<h2>Appraisal</h2>")
        rows = [[n, money(v), pct(v / a["gdv"]) if a["gdv"] else ""] for n, v in [
            ("Land and acquisition costs", a["land_cost"]), ("Land finance", a["land_finance"]), ("Build or refurbishment", a["build"]), ("Contingency", a["contingency"]), ("Professional fees", a["fees"]),
            ("S106 and CIL", a["s106"] + a["cil"]), ("Build finance", a["build_finance"]), ("Sales costs", a["sales_costs"])]]
        rows.append(["Total cost", money(a["total_cost"]), pct(a["total_cost"] / a["gdv"]) if a["gdv"] else ""])
        o.append(_t(["Cost line", "Amount", "Share of GDV"], rows, num=(1, 2)))
        o.append(f'<p class="note">Sales £{A["sales_psf"] if not s.get("sales_psf") else s["sales_psf"]:.0f} per sq ft. Build £{A["build_psf"]:.0f} per sq ft GIA plus {pct(A["external_pct"], 0)} externals. Affordable {pct(A["affordable_pct"], 0)}. Finance {pct(A["finance_rate"])} at {pct(A["ltc"], 0)} of cost.</p>')
        bc = pack.get("cost_benchmark")
        if bc:
            o.append(f'<p class="note">Build cost benchmark for {E(bc["label"].lower())} in {E(bc["region"])}: £{bc["low"]}* to £{bc["high"]}* per sq ft. {E(costs.FOOTNOTE)}</p>')

    # scenarios
    if sc.get("rows"):
        o.append("<h2>Scenarios and break-even</h2>")
        o.append(_t(["Scenario", "Sales", "Build", "Delay", "Profit", "Margin", "Levered IRR", "Result"],
                    [[r["name"], f"{r['changes']['sales']:+.1f}%", f"{r['changes']['build']:+.1f}%", f"{r['changes']['delay']:+.0f}m", money(r["profit"]), f"{pct(r['margin'])} {r['basis']}", pct(r["irr"]),
                      _pill("Meets target", "ok") if r["viable"] else _pill("Below target", "hi" if r["profit"] < 0 else "md")] for r in sc["rows"]], num=(1, 2, 3, 4, 5, 6)))
        be = sc.get("breakeven") or {}
        if be.get("rows"):
            def fmt(x, unit):
                return "not reached" if x is None else f"{x:+.1f}{'%' if unit == '%' else (' bps' if unit == 'bps' else ' months')}"
            o.append(_t(["Single change", "Profit reaches zero", "Meets target margin"], [[r["phrase"], fmt(r["zero"], r["unit"]), fmt(r["target"], r["unit"])] for r in be["rows"]]
                        + [["Land price", money(be["land"]["zero"]) if be["land"].get("zero") else "not reached", money(be["land"]["target"]) if be["land"].get("target") else "not reached"]], ))

    # sensitivity
    sens = pack.get("sens")
    if sens and ok:
        o.append("<h2>Sensitivity</h2>")
        o.append(f'<p class="note">Profit {E("on GDV" if a["profit_basis"] == "gdv" else "on cost")}. Rows: {E(sens["ylabel"])}. Columns: {E(sens["xlabel"])}. Target {pct(a["target_profit"], 0)}.</p>')
        tg = a["target_profit"]
        head = "<tr><th></th>" + "".join(f'<th class="n">{x * 100:+.0f}%</th>' for x in sens["x"]) + "</tr>"
        rows = ""
        for y, row in zip(sens["y"], sens["z"]):
            rows += f'<tr><th>{y * 100:+.0f}%</th>' + "".join(f'<td style="background:{"#e9f5ec" if v >= tg else "#fdecea" if v < 0 else "#fff4e0"}">{v * 100:.1f}%</td>' for v in row) + "</tr>"
        o.append(f'<table class="hm"><thead>{head}</thead><tbody>{rows}</tbody></table>')

    # planning
    o.append("<h2>Planning</h2>")
    ro = pl.get("read_out") or {}
    o.append(f'<p>Status: <b>{E(ro.get("status") or s.get("planning_status") or "Unknown")}</b>. Planning risk: {E(str(ro.get("risk") or "not assessed"))}.' + (f' Permission expires {E(fdate(ro["permission_expiry"]))}.' if ro.get("permission_expiry") else "") + "</p>")
    for x in ro.get("points", [])[:8]:
        o.append(f'<p style="margin:2px 0">{_pill(x["level"], "hi" if x["level"] == "High" else "md" if x["level"] == "Medium" else "")} {E(x["text"])}</p>')
    an = pl.get("analysis")
    if an:
        o.append(f'<p>{E(an.get("summary", ""))}</p>')
    if pl.get("apps"):
        o.append(_t(["Reference", "Status", "Submitted", "Decided", "Description"], [[h.get("ref", ""), h.get("status", ""), fdate(h.get("submitted")), fdate(h.get("decided")), h.get("description", "")] for h in pl["apps"]]))
    if pl.get("consultees"):
        o.append(_t(["Consultee", "Stance", "Summary", "Date"], [[c.get("body", ""), c.get("stance", ""), c.get("summary", ""), fdate(c.get("date"))] for c in pl["consultees"]]))

    # constraints and risks
    o.append("<h2>Constraints and risks</h2>")
    if cons.get("hits"):
        o.append(f'<p class="note">Open data check on {E(fdate(cons.get("checked", "")))}: ' + ", ".join(E(v["label"]) for v in cons["hits"].values()) + ".</p>")
    elif cons.get("checked"):
        o.append(f'<p class="note">Open data check on {E(fdate(cons["checked"]))} found none of the checked designations at this point.</p>')
    if flags:
        o.append(_t(["Risk", "Severity", "Mitigation"], [[f"{f['flag']}. {f.get('why', '')}", _pill(f["severity"], "hi" if f["severity"] == "High" else "md" if f["severity"] == "Medium" else ""), f.get("mitigation", "")] for f in flags]))
    else:
        o.append('<p class="note">No risks are recorded on the file. That reflects the data held.</p>')

    # market
    o.append("<h2>Market evidence</h2>")
    lr = s.get("land_registry")
    if lr:
        sm = lr["summary"]
        o.append(f'<p>HM Land Registry sales in {E(lr["sector"])}: {sm["n"]} sales, {sm["new_build_n"]} new build.' + (f' Median £{sm["median_psf"]:.0f} per sq ft.' if sm.get("median_psf") else "") + "</p>")
    if s.get("comps"):
        o.append(_t(["Type", "Evidence", "Detail", "Metric", "Date"], [[c["kind"], c["address"], c["detail"], c["metric"], c["date"]] for c in s["comps"]]))
    sm = (pack.get("scheme_comps") or {}).get("summary") or {}
    if sm.get("n"):
        o.append(f'<p>Nearby schemes within {sm["radius_km"]:g} km: {sm["n"]}' + (f', median density {sm["median_density"]:.0f} per ha' if sm.get("median_density") else "") + ".</p>")
        o.append(_t(["Scheme", "Status", "Units", "Distance", "Source"], [[x["name"], x["kind"], x.get("units") or "", f"{x['distance_km']:.1f} km", x["source"]] for x in pack["scheme_comps"]["items"][:10]], num=(2, 3)))
    if not (lr or s.get("comps") or sm.get("n")):
        o.append('<p class="note">No sold price or scheme evidence is on file yet.</p>')

    # structure
    if st.get("lender") or st.get("waterfall"):
        o.append("<h2>Funding structure</h2>")
        if st.get("lender"):
            o.append(_t(["Covenant", "Position", "Limit", "Result"], [[t["name"], f"{t['value']:.1f}{t['unit']}", f"{'max' if t['kind'] == 'max' else 'min'} {t['limit']:.1f}{t['unit']}", _pill("Pass", "ok") if t["ok"] else _pill("Breach", "hi")] for t in st["lender"]["tests"]]))
        wf = st.get("waterfall")
        if wf:
            o.append(_t(["", "Invested", "Returned", "Profit", "IRR", "Multiple"], [[n, money(w["invested"]), money(w["returned"]), money(w["profit"]), pct(w["irr"]), f"{w['multiple']:.2f}x" if w["multiple"] else "n/a"]
                                                                                    for n, w in (("All equity", wf["total"]), ("Investor", wf["investor"]), ("Sponsor", wf["sponsor"]))], num=(1, 2, 3, 4, 5)))

    # diligence
    o.append("<h2>Due diligence</h2>")
    if dd.get("summary"):
        d = dd["summary"]
        o.append(f'<p>{d["done"]} of {d["total"]} items complete ({d["pct"]}%). {d["issues"]} flagged as issues, {d["overdue"]} overdue.</p>')
        op = [i for i in dd["items"] if i["status"] not in ("Done", "Not applicable")]
        if op:
            o.append(_t(["Category", "Item", "Status", "Owner", "Due"], [[i["category"], i["item"], i["status"], i.get("owner", ""), fdate(i.get("due"))] for i in op[:20]]))
    else:
        o.append('<p class="note">The diligence tracker has not been opened for this site.</p>')

    # land
    ps = s.get("parcels") or []
    if ps:
        from . import land
        ls = land.summary(s)
        o.append("<h2>Land assembly</h2>")
        o.append(f'<p>{ls["n"]} parcels, {ls["area"]:.2f} ha. Secured {ls["secured_pct"]:.0f}% of the target area, with a further {ls["agreed_ha"]:.2f} ha on agreed terms.' + (f' Blended price £{ls["blended_per_ha"] / 1e6:.2f}m per ha.' if ls.get("blended_per_ha") else "") + "</p>")
        o.append(_t(["Parcel", "Owner", "Area (ha)", "Status", "Ask", "Offer"], [[p.get("ref") or p.get("address", ""), p.get("owner", ""), f"{p['area_ha']:.2f}" if p.get("area_ha") else "", p["status"], money(p["ask"]) if p.get("ask") else "", money(p["offer"]) if p.get("offer") else ""] for p in ps], num=(2, 4, 5)))

    # contact
    c = pack.get("contact") or {}
    if c:
        o.append("<h2>Agent and vendor</h2>")
        o.append("<p>" + E(" · ".join(x for x in [c.get("name"), c.get("firm"), c.get("best_phone"), c.get("best_email")] if x)) + (f"<br>Vendor: {E(s['vendor'])}" if s.get("vendor") else "") + "</p>")
    o.append(f'</div><div class="foot">Prepared with easyDevelopment{" for " + E(inv["firm"]) if inv.get("firm") else ""}. Figures marked * are indicative. Appraisal outputs depend on the assumptions shown and on the data held on the date above. This page is a working document and not advice.</div></div>')
    return f'<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(s.get("name", "Site"))} report</title><style>{CSS}</style></head><body>{"".join(o)}</body></html>'
