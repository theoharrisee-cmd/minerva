"""One printable page per site: everything the file holds, laid out for reading and for printing to PDF."""
from __future__ import annotations

import html
from datetime import date

from . import costs, homes_out, floorplan
from .committee import fdate, money, pct, verdict

E = html.escape

CSS = """
:root{--o:#FF6600;--ink:#141414;--mut:#666;--line:#e4e4e4;--bg:#fff;--soft:#f6f6f6}
*{box-sizing:border-box}body{margin:0;background:#efefef;color:var(--ink);font:13px/1.5 Aptos,"Segoe UI",Calibri,Arial,sans-serif}
.page{max-width:900px;margin:24px auto;background:var(--bg);padding:0 0 28px;box-shadow:0 2px 24px rgba(0,0,0,.08)}
.mast{background:var(--o);color:#fff;padding:14px 32px;display:flex;justify-content:space-between;align-items:center;font-weight:800;font-size:17px;letter-spacing:-.02em}
.mast span{font-weight:500;font-size:12px;opacity:.95}
.in{padding:0 32px}h1{font-size:26px;margin:26px 0 2px;letter-spacing:-.02em}.addr{color:var(--mut);margin:0 0 14px}
h2{font-size:15px;margin:28px 0 8px;padding-bottom:5px;border-bottom:2px solid var(--o);letter-spacing:-.01em}h3{font-size:13px;margin:16px 0 6px}
.verdict{display:flex;gap:16px;align-items:center;background:var(--soft);border-left:5px solid var(--o);padding:12px 16px;margin:10px 0 6px}
.verdict b{font-size:16px}.verdict p{margin:2px 0 0;color:#333}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:14px 0}.k{border:1px solid var(--line);padding:9px 11px}
.k .l{font-size:10.5px;text-transform:uppercase;letter-spacing:.06em;color:var(--mut)}.k .v{font-size:19px;font-weight:700;margin-top:2px}.k .s{font-size:11px;color:var(--mut)}
table{border-collapse:collapse;width:100%;margin:6px 0 4px;font-size:12px}th{background:#f0f0f0;text-align:left;font-weight:700}th,td{border:1px solid var(--line);padding:5px 8px;vertical-align:top}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}tr.tot td{font-weight:700;background:var(--soft)}
.pill{display:inline-block;padding:1px 8px;border:1px solid var(--line);font-size:11px;font-weight:600}.pill.hi{border-color:#b3261e;color:#b3261e}.pill.ok{border-color:#1d7a3a;color:#1d7a3a}.pill.md{border-color:#a86a00;color:#a86a00}
.plan{border:1px solid var(--line);margin:10px 0;padding:4px;line-height:0;break-inside:avoid}.plan svg{width:100%;height:auto;display:block}.note{color:var(--mut);font-size:11px}.two{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.hm td{text-align:center;padding:4px 2px;font-size:11px}.bar{height:9px;background:var(--o);display:inline-block;vertical-align:middle}
.foot{margin:26px 32px 0;padding-top:10px;border-top:1px solid var(--line);color:var(--mut);font-size:11px}
.bar-row{display:flex;align-items:center;gap:8px;margin:3px 0;font-size:12px}.bar-row .t{width:150px}.bar-row .b{flex:1;background:var(--soft);height:11px}.bar-row .b i{display:block;height:11px;background:var(--o)}.bar-row .v{width:90px;text-align:right}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:none}h2{break-after:avoid}table,.verdict,.k{break-inside:avoid}.noprint{display:none}}
@page{size:A4;margin:12mm}
"""


def _t(head, rows, num=(), cls=""):
    th = "".join(f'<th class="{"n" if i in num else ""}">{E(str(h))}</th>' for i, h in enumerate(head))
    body = "".join("<tr>" + "".join(f'<td class="{"n" if i in num else ""}">{c if isinstance(c, _Raw) else E(str(c))}</td>' for i, c in enumerate(r)) + "</tr>" for r in rows)
    return f'<table class="{cls}"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table>'


class _Raw(str):
    pass


def _pm(start, i):
    from .programme import month_label
    return month_label(start, i)


def _pill(t, kind=""):
    return _Raw(f'<span class="pill {kind}">{E(str(t))}</span>')


def _k(label, val, sub=""):
    return f'<div class="k"><div class="l">{E(label)}</div><div class="v">{E(str(val))}</div><div class="s">{E(str(sub))}</div></div>'


def render(pack: dict, opts: dict | None = None, brand: dict | None = None, list_only: bool = False):
    s, ev, pl, dd, inv = pack["site"], pack["ev"], pack["planning"], pack.get("dd") or {}, pack.get("investor") or {}
    st, sc, cons = pack.get("structure") or {}, pack.get("scenarios") or {}, pack.get("constraints") or {}
    a = ev.get("appraisal") or {}
    ok = a and not a.get("incomplete")
    flags = ev.get("flags") or []
    vd, why = verdict(a, flags)
    A = pack["assumptions"]
    strat = pack["strategies"].get(ev["strategy"], ev["strategy"])
    o = []
    o.append(f'<div class="page"><div class="mast">easyDevelopment<span>Site report · {date.today().day} {date.today():%B %Y}</span></div><div class="in">')
    o.append(f'<h1>{E(s.get("name", "Site"))}</h1><p class="addr">{E(s.get("address", ""))} · {E(strat)} · Stage: {E(s.get("stage", ""))} · Score {ev["score"]["score"]} ({ev["score"]["grade"]})</p>')
    o.append(f'<div class="verdict"><div><b>{E(vd)}</b><p>{E(why)}</p></div></div>')
    if s.get("demo"):
        o.append('<p class="note">Illustrative site with fictional details.</p>')

    if ok:
        basis = "on GDV" if a["profit_basis"] == "gdv" else "on cost"
        m = a["profit_on_gdv"] if a["profit_basis"] == "gdv" else a["profit_on_cost"]
        o.append('<div class="grid">' + "".join([
            _k("Gross development value", money(a["gdv"]), f"{a['units']} units"), _k("Total cost", money(a["total_cost"]), "including land and finance"),
            _k("Profit at asking", money(a["profit"]), f"{pct(m)} {basis}, target {pct(a['target_profit'], 0)}"), _k("Levered IRR", pct(a.get("irr_levered")), f"{a['equity_multiple']:.2f}x equity multiple"),
            _k("Asking price", money(a["asking"]) if a["asking"] else "n/a"), _k("Maximum bid", money(a["max_bid"]), f"opening offer {money(a['opening_offer'])}"),
            _k("Headroom to asking", pct(a["headroom_vs_asking"], 0) if a.get("headroom_vs_asking") is not None else "n/a"), _k("Peak equity", money(a["peak_equity"]), f"hold {a['months_land']:.0f} months")]) + "</div>")
    else:
        o.append(f'<p>{E(why)}</p>')
    if s.get("description"):
        o.append(f'<p>{E(s["description"])}</p>')

    # appraisal
    if ok:
        o.append("<h2>Appraisal</h2>")
        rows = [[n, money(v), pct(v / a["gdv"]) if a["gdv"] else ""] for n, v in [
            ("Land and acquisition costs", a["land_cost"]), ("Land finance", a["land_finance"]), ("Build or refurbishment", a["build"]), ("Contingency", a["contingency"]), ("Professional fees", a["fees"]),
            ("S106 and CIL", a["s106"] + a["cil"]), ("Build finance", a["build_finance"]), ("Sales costs", a["sales_costs"])]]
        rows.append(["Total cost", money(a["total_cost"]), pct(a["total_cost"] / a["gdv"]) if a["gdv"] else ""])
        o.append(_t(["Cost line", "Amount", "Share of GDV"], rows, num=(1, 2)))
        o.append(f'<p class="note">Sales £{A["sales_psf"] if not s.get("sales_psf") else s["sales_psf"]:.0f} per sq ft. Build £{A["build_psf"]:.0f} per sq ft GIA plus {pct(A["external_pct"], 0)} externals. Affordable {pct(A["affordable_pct"], 0)}. Finance {pct(A["finance_rate"])} at {pct(A["ltc"], 0)} of cost.</p>')
        bc = pack.get("cost_benchmark")
        if bc:
            o.append(f'<p class="note">Build cost benchmark for {E(bc["label"].lower())} in {E(bc["region"])}: £{bc["low"]}* to £{bc["high"]}* per sq ft. {E(costs.FOOTNOTE)}</p>')

    # homes
    hm = pack.get("homes")
    if hm:
        rows, tot = homes_out.schedule(hm)
        o.append("<h2>Homes and layouts</h2>")
        o.append(f'<p>{E(", ".join(tot))}.</p>')
        o.append(_t(rows[0], rows[1:], num=(1, 2, 3, 4, 5)))
        for title, prims, box in homes_out.sheets(hm, 4):
            o.append(f'<div class="plan">{floorplan.to_svg(prims, box, 40, 900)}</div>')
        bl = homes_out.block(hm)
        if bl:
            o.append(f'<div class="plan">{floorplan.to_svg(bl[0], bl[1], 30, 900)}</div>')
        o.append(f'<p class="note">{E(homes_out.counts_line(hm))}</p>')
        fs = homes_out.findings(hm)
        if fs:
            o.append(_t(["Check", "Result", "Detail"], [[c["title"], _pill("Not met", "hi") if c["status"] == "fail" else _pill("To confirm", "md"), c["detail"]] for c in fs]))

    # site data
    dt = pack.get("data")
    if dt:
        import base64
        o.append("<h2>Site data</h2>")
        if dt.get("map"):
            o.append(f'<div class="plan"><img alt="Site location" style="max-width:100%" src="data:image/png;base64,{base64.b64encode(dt["map"]).decode()}"></div>')
        if dt.get("constraints"):
            o.append("<h3>Constraints</h3>")
            o.append(_t(dt["constraints"][0], dt["constraints"][1:]))
            if dt.get("constraints_line"):
                o.append(f'<p class="note">{E(dt["constraints_line"])}</p>')
        o.append("<h3>Ownership and title</h3>")
        o.append(_t(["Item", "Detail"], dt["ownership"]))
        if dt.get("applications") or dt.get("record_lines"):
            o.append("<h3>Planning activity nearby</h3>")
            for ln in dt.get("record_lines", []):
                o.append(f"<p>{E(ln)}</p>")
            if dt.get("applications"):
                o.append(_t(dt["applications"][0], dt["applications"][1:], num=(4,)))
        if dt.get("access"):
            o.append("<h3>Access and amenities</h3>")
            o.append(_t(dt["access"][0], dt["access"][1:]))
        o.append(f'<p class="note">Data checked {E(dt.get("checked") or "on an earlier date")}. Sources are named against each finding on the Data tab.</p>')
    lay = pack.get("layout")
    if lay:
        from . import layout as _lay
        o.append("<h2>Layout test</h2>")
        o.append(f'<p>{lay["homes"]} houses fit at {lay["density_dph"]} homes per hectare on {lay["site_ha"]} ha ({E(lay["note"])}).</p>')
        o.append(f'<div class="plan">{_lay.to_svg(lay, _lay.colours_for(lay))}</div>')
        o.append(_t(["Check", "Result", "Detail"], [[c["title"], c["status"].title(), c["detail"]] for c in lay["checks"]]))

    # scenarios
    if sc.get("rows"):
        o.append("<h2>Scenarios and break-even</h2>")
        o.append(_t(["Scenario", "Sales", "Build", "Delay", "Profit", "Margin", "Levered IRR", "Result"],
                    [[r["name"], f"{r['changes']['sales']:+.1f}%", f"{r['changes']['build']:+.1f}%", f"{r['changes']['delay']:+.0f}m", money(r["profit"]), f"{pct(r['margin'])} {r['basis']}", pct(r["irr"]),
                      _pill("Meets target", "ok") if r["viable"] else _pill("Below target", "hi" if r["profit"] < 0 else "md")] for r in sc["rows"]], num=(1, 2, 3, 4, 5, 6)))
        be = sc.get("breakeven") or {}
        if be.get("rows"):
            def fmt(x, unit):
                return "not reached" if x is None else f"{x:+.1f}{'%' if unit == '%' else (' bps' if unit == 'bps' else ' months')}"
            o.append(_t(["Single change", "Profit reaches zero", "Meets target margin"], [[r["phrase"], fmt(r["zero"], r["unit"]), fmt(r["target"], r["unit"])] for r in be["rows"]]
                        + [["Land price", money(be["land"]["zero"]) if be["land"].get("zero") else "not reached", money(be["land"]["target"]) if be["land"].get("target") else "not reached"]], ))

    # programme
    pg = pack.get("programme")
    if pg:
        e = pg["programme"]
        o.append("<h2>Programme and cash flow</h2>")
        lab = lambda i: _pm(pg["start"], i)
        o.append(_t(["Stage", "From", "To", "Months"], [[g["label"], lab(g["start"]), lab(g["end"]), g["end"] - g["start"] + 1] for g in pg["gantt"]]))
        o.append(f'<p class="note">Peak equity falls in {lab(pg["peak_month"])}. Land: {E(pg["land_modes"][e["land_mode"]])}. Statutory payments {E(pg["statutory"][e["statutory_at"]].lower())}.</p>')
        if pg.get("delay") and pg["delay"]["rows"]:
            o.append(_t(["Delay to consent", "Profit", "Levered IRR", "Cost of delay"], [[f"+{r['delay']} months" if r["delay"] else "Base case", money(r["profit"]), pct(r["irr_levered"]), money(r["cost"]) if r["delay"] else ""] for r in pg["delay"]["rows"]], num=(1, 2, 3)))
            o.append(f'<p class="note">Each month of delay costs about {money(pg["delay"]["per_month"])} of profit at the price tested.</p>')

    # sensitivity
    sens = pack.get("sens")
    if sens and ok:
        o.append("<h2>Sensitivity</h2>")
        o.append(f'<p class="note">Profit {E("on GDV" if a["profit_basis"] == "gdv" else "on cost")}. Rows: {E(sens["ylabel"])}. Columns: {E(sens["xlabel"])}. Target {pct(a["target_profit"], 0)}.</p>')
        tg = a["target_profit"]
        head = "<tr><th></th>" + "".join(f'<th class="n">{x * 100:+.0f}%</th>' for x in sens["x"]) + "</tr>"
        rows = ""
        for y, row in zip(sens["y"], sens["z"]):
            rows += f'<tr><th>{y * 100:+.0f}%</th>' + "".join(f'<td style="background:{"#e9f5ec" if v >= tg else "#fdecea" if v < 0 else "#fff4e0"}">{v * 100:.1f}%</td>' for v in row) + "</tr>"
        o.append(f'<table class="hm"><thead>{head}</thead><tbody>{rows}</tbody></table>')

    # planning
    o.append("<h2>Planning</h2>")
    ro = pl.get("read_out") or {}
    o.append(f'<p>Status: <b>{E(ro.get("status") or s.get("planning_status") or "Unknown")}</b>. Planning risk: {E(str(ro.get("risk") or "not assessed"))}.' + (f' Permission expires {E(fdate(ro["permission_expiry"]))}.' if ro.get("permission_expiry") else "") + "</p>")
    for x in ro.get("points", [])[:8]:
        o.append(f'<p style="margin:2px 0">{_pill(x["level"], "hi" if x["level"] == "High" else "md" if x["level"] == "Medium" else "")} {E(x["text"])}</p>')
    an = pl.get("analysis")
    if an:
        o.append(f'<p>{E(an.get("summary", ""))}</p>')
    if pl.get("apps"):
        o.append(_t(["Reference", "Status", "Submitted", "Decided", "Description"], [[h.get("ref", ""), h.get("status", ""), fdate(h.get("submitted")), fdate(h.get("decided")), h.get("description", "")] for h in pl["apps"]]))
    if pl.get("consultees"):
        o.append(_t(["Consultee", "Stance", "Summary", "Date"], [[c.get("body", ""), c.get("stance", ""), c.get("summary", ""), fdate(c.get("date"))] for c in pl["consultees"]]))

    # planning strategy
    ps = pack.get("strategy")
    if ps:
        o.append("<h2>Planning strategy</h2>")
        o.append(f'<p><b>{E(ps["route"]["title"])}.</b> {E(ps["route"]["summary"])}</p>')
        o.append(f'<p>Complexity {E(ps["level"].lower())} ({ps["score"]} points).' + (f' About {ps["timeline"]["total_months"]} months to consent.' if ps["timeline"]["total_months"] else "") + "</p>")
        if ps["arguments"]:
            o.append(_t(["The case to make", "Source"], [[x["text"], x["source"]] for x in ps["arguments"]]))
        if ps["concerns"]:
            o.append(_t(["Likely concern", "Detail", "Response"], [[x["topic"], x["detail"], x["mitigation"]] for x in ps["concerns"][:8]]))
        o.append(f'<p class="note">{E(ps["caveat"])}</p>')

    # constraints and risks
    o.append("<h2>Constraints and risks</h2>")
    if cons.get("hits"):
        o.append(f'<p class="note">Open data check on {E(fdate(cons.get("checked", "")))}: ' + ", ".join(E(v["label"]) for v in cons["hits"].values()) + ".</p>")
    elif cons.get("checked"):
        o.append(f'<p class="note">Open data check on {E(fdate(cons["checked"]))} found none of the checked designations at this point.</p>')
    if flags:
        o.append(_t(["Risk", "Severity", "Mitigation"], [[f"{f['flag']}. {f.get('why', '')}", _pill(f["severity"], "hi" if f["severity"] == "High" else "md" if f["severity"] == "Medium" else ""), f.get("mitigation", "")] for f in flags]))
    else:
        o.append('<p class="note">No risks are recorded on the file. That reflects the data held.</p>')

    # market
    o.append("<h2>Market evidence</h2>")
    lr = s.get("land_registry")
    if lr:
        sm = lr["summary"]
        o.append(f'<p>HM Land Registry sales in {E(lr["sector"])}: {sm["n"]} sales, {sm["new_build_n"]} new build.' + (f' Median £{sm["median_psf"]:.0f} per sq ft.' if sm.get("median_psf") else "") + "</p>")
    if s.get("comps"):
        o.append(_t(["Type", "Evidence", "Detail", "Metric", "Date"], [[c["kind"], c["address"], c["detail"], c["metric"], c["date"]] for c in s["comps"]]))
    sm = (pack.get("scheme_comps") or {}).get("summary") or {}
    if sm.get("n"):
        o.append(f'<p>Nearby schemes within {sm["radius_km"]:g} km: {sm["n"]}' + (f', median density {sm["median_density"]:.0f} per ha' if sm.get("median_density") else "") + ".</p>")
        o.append(_t(["Scheme", "Status", "Units", "Distance", "Source"], [[x["name"], x["kind"], x.get("units") or "", f"{x['distance_km']:.1f} km", x["source"]] for x in pack["scheme_comps"]["items"][:10]], num=(2, 3)))
    if not (lr or s.get("comps") or sm.get("n")):
        o.append('<p class="note">No sold price or scheme evidence is on file yet.</p>')

    # comparable evidence
    cp = pack.get("compset")
    if cp and cp.get("has") and cp.get("subjects"):
        o.append("<h2>Comparable evidence</h2>")
        rows = [[x["class"], ", ".join(x["units"]) or "", x["n"], money(x["value"]) if x.get("value") else "too few sales", f'{money(x["low"])} to {money(x["high"])}' if x.get("value") else "", x.get("confidence", "")] for x in cp["subjects"]]
        o.append(_t(["Property type", "Homes in the schedule", "Sales used", "Adjusted value", "Range", "Confidence"], rows, num=(2, 3)))
        fv = cp["factors"]["values"]
        o.append(f'<p class="note">Sales from {E(str(cp.get("sector") or ""))}, adjusted for time ({fv["growth_pa"] * 100:.1f}% a year), a new build premium of {fv["newbuild_premium"] * 100:.0f}% on second-hand sales and, where floor areas are known, size. Adjustments are desk assumptions.</p>')
        best = max(cp["subjects"], key=lambda x: x["n"])
        used = [r for r in best["rows"] if r.get("included")][:10]
        if used:
            o.append(_t(["Address", "Sold", "Price", "Adjusted to subject", "Distance"], [[", ".join(x for x in (r.get("saon"), r.get("paon"), r.get("street")) if x) + " " + (r.get("postcode") or ""), fdate(r.get("date")), money(r["price"]), money(r["adjusted"]), f'{r["dist_km"]:.1f} km' if r.get("dist_km") is not None else ""] for r in used], num=(2, 3, 4)))

    # funding package
    fp = pack.get("funding")
    if fp:
        t = fp["terms"]
        o.append("<h2>Funding package</h2>")
        o.append(_t(["Term", "Position"], [["Senior debt", f'{t["ltc"] * 100:.0f}% of cost at {t["finance_rate"] * 100:.2f}%, {money(fp["request"]["senior"])} committed'], ["Mezzanine", f'{t["mezz_ltc"] * 100:.0f}% of cost at {t["mezz_rate"] * 100:.2f}%' if t["mezz_ltc"] else "None"], ["Fees", f'Arrangement {t["debt_fee_pct"] * 100:.2f}%, exit {t["exit_fee_pct"] * 100:.2f}%'], ["Drawdown", fp["draw_modes"].get(t["draw_mode"], "")], ["Term", f'{fp["request"]["tenor_months"]} months']]))
        o.append(_t(["Package", "Levered IRR", "Equity multiple", "Peak equity", "Profit to equity"], [[r["name"] + (" (current)" if r["current"] and r["name"] != "Current package" else ""), pct(r["irr_levered"]), f'{r["equity_multiple"]:.2f}x' if r.get("equity_multiple") else "", money(r["peak_equity"]), money(r["equity_profit"])] for r in fp["compare"] if r["name"] != "Current package" or True], num=(1, 2, 3, 4)))

    # tax and net returns
    tx = pack.get("tax")
    if tx and not tx.get("incomplete"):
        o.append("<h2>Tax and net returns</h2>")
        c, pr = tx["company"], tx["personal"]
        gdv_lbl = "Net margin on GDV" if a and a.get("strategy") == "develop_sell" else "Net margin on value"
        o.append(_t(["", "Company", "Personal"], [["Profit before tax", money(tx["pre_tax_profit"]), money(tx["pre_tax_profit"])], ["VAT not recovered", money(tx["vat"]["amount"]), money(tx["vat"]["amount"])],
                                                    ["Tax on profit", money(c["tax"]), money(pr["tax"])], ["Profit after tax", money(c["net_profit"]), money(pr["net_profit"])],
                                                    [gdv_lbl, pct(c["net_margin"]), pct(pr["net_margin"])], ["Levered IRR after tax", pct(c["irr"]), pct(pr["irr"])],
                                                    ["Equity multiple after tax", f'{c["multiple"]:.2f}x' if c.get("multiple") else "", f'{pr["multiple"]:.2f}x' if pr.get("multiple") else ""]], num=(1, 2)))
        sd = tx["sdlt"]
        o.append(f'<p class="note">Levered IRR before tax {pct(tx["pre_tax"]["irr"])}. Stamp duty on the land price tested is about {money(sd["calculated"])} against an acquisition allowance of {money(sd["allowance"])}. {E(tx["vat"]["note"])} {E(tx["rates_note"])} {E(tx["caveat"])}</p>')

    # cost plan
    cp = pack.get("costplan")
    if cp and cp.get("has") and cp.get("applied"):
        sm = cp["summary"]
        o.append("<h2>Cost plan</h2>")
        o.append(f'<p>Build cost of {money(sm["build"])} taken from the quantity surveyor\'s plan ({E(cp["file"])})' + (f', which is £{sm["psf"]:.0f} per sq ft of gross internal area' if sm.get("psf") else "") + ".</p>")
        o.append(_t(["Element", "Amount"], [[g["group"], money(g["amount"])] for g in sm["groups"]] + ([["Contingency", f'{money(sm["contingency"])} ({pct(sm["contingency_pct"])} of build)']] if sm.get("contingency") else []) + ([["Professional fees", f'{money(sm["fees"])} ({pct(sm["fees_pct"])} of build)']] if sm.get("fees") else []), num=(1,)))
        if cp.get("benchmark"):
            bm = cp["benchmark"]
            o.append(f'<p class="note">The plan is {E(bm["verdict"])} for {E(bm["label"].lower())} (£{bm["low"]} to £{bm["high"]} per sq ft, indicative).</p>')

    # structure
    if st.get("lender") or st.get("waterfall"):
        o.append("<h2>Funding structure</h2>")
        if st.get("lender"):
            o.append(_t(["Covenant", "Position", "Limit", "Result"], [[t["name"], f"{t['value']:.1f}{t['unit']}", f"{'max' if t['kind'] == 'max' else 'min'} {t['limit']:.1f}{t['unit']}", _pill("Pass", "ok") if t["ok"] else _pill("Breach", "hi")] for t in st["lender"]["tests"]]))
        wf = st.get("waterfall")
        if wf:
            o.append(_t(["", "Invested", "Returned", "Profit", "IRR", "Multiple"], [[n, money(w["invested"]), money(w["returned"]), money(w["profit"]), pct(w["irr"]), f"{w['multiple']:.2f}x" if w["multiple"] else "n/a"]
                                                                                    for n, w in (("All equity", wf["total"]), ("Investor", wf["investor"]), ("Sponsor", wf["sponsor"]))], num=(1, 2, 3, 4, 5)))

    # diligence
    o.append("<h2>Due diligence</h2>")
    if dd.get("summary"):
        d = dd["summary"]
        o.append(f'<p>{d["done"]} of {d["total"]} items complete ({d["pct"]}%). {d["issues"]} flagged as issues, {d["overdue"]} overdue.</p>')
        op = [i for i in dd["items"] if i["status"] not in ("Done", "Not applicable")]
        if op:
            o.append(_t(["Category", "Item", "Status", "Owner", "Due"], [[i["category"], i["item"], i["status"], i.get("owner", ""), fdate(i.get("due"))] for i in op[:20]]))
    else:
        o.append('<p class="note">The diligence tracker has not been opened for this site.</p>')

    # land
    ps = s.get("parcels") or []
    if ps:
        from . import land
        ls = land.summary(s)
        o.append("<h2>Land assembly</h2>")
        o.append(f'<p>{ls["n"]} parcels, {ls["area"]:.2f} ha. Secured {ls["secured_pct"]:.0f}% of the target area, with a further {ls["agreed_ha"]:.2f} ha on agreed terms.' + (f' Blended price £{ls["blended_per_ha"] / 1e6:.2f}m per ha.' if ls.get("blended_per_ha") else "") + "</p>")
        o.append(_t(["Parcel", "Owner", "Area (ha)", "Status", "Ask", "Offer"], [[p.get("ref") or p.get("address", ""), p.get("owner", ""), f"{p['area_ha']:.2f}" if p.get("area_ha") else "", p["status"], money(p["ask"]) if p.get("ask") else "", money(p["offer"]) if p.get("offer") else ""] for p in ps], num=(2, 4, 5)))

    # change history
    hs = pack.get("history")
    if hs:
        o.append("<h2>Change history</h2>")
        o.append(_t(["Date", "Change", "Profit", "Movement"], [[fdate(h["t"][:10]), h["title"], money(h["profit"]) if h.get("profit") is not None else "n/a", (("+" if h["delta"] >= 0 else "") + money(h["delta"])) if h.get("delta") is not None else ""] for h in hs], num=(2, 3)))

    # contact
    c = pack.get("contact") or {}
    if c:
        o.append("<h2>Agent and vendor</h2>")
        o.append("<p>" + E(" · ".join(x for x in [c.get("name"), c.get("firm"), c.get("best_phone"), c.get("best_email")] if x)) + (f"<br>Vendor: {E(s['vendor'])}" if s.get("vendor") else "") + "</p>")
    o.append(f'</div><div class="foot">Prepared with easyDevelopment{" for " + E(inv["firm"]) if inv.get("firm") else ""}. Figures marked * are indicative. Appraisal outputs depend on the assumptions shown and on the data held on the date above. This page is a working document and not advice.</div></div>')
    if list_only:
        from . import packs
        return packs.report_sections(o, opts)
    if opts:
        from . import packs
        o = packs.arrange_report(o, opts)
    return f'<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(s.get("name", "Site"))} report</title><style>{CSS}</style></head><body>{"".join(o)}</body></html>'
