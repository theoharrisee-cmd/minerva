"""Map layers for the map workspace: planning.data.gov.uk features in a view, simplified for drawing."""
from __future__ import annotations

from . import areasearch, datasources as ds, geo

LAYERS = {
    "title-boundary": {"label": "Title polygons", "colour": "#555555", "max_span_km": 1.2},
    "brownfield-land": {"label": "Brownfield land", "colour": "#7A4FD6", "max_span_km": 25},
    "tree-preservation-zone": {"label": "Tree preservation zones", "colour": "#2E8B57", "max_span_km": 6},
    **{k: {"label": v[0], "colour": c, "max_span_km": 25} for (k, v), c in zip(areasearch.SCREEN.items(), ["#2E8B57", "#1E6FD9", "#C0392B", "#1B7F5C", "#8E44AD", "#D35400", "#B7950B", "#C0392B", "#C0392B", "#7F8C8D", "#D68910"])},
}


def simplify(ring, max_pts: int = 120):
    if len(ring) <= max_pts:
        return ring
    step = len(ring) / max_pts
    out = [ring[int(i * step)] for i in range(max_pts)]
    return out + [out[0]] if out[0] != out[-1] else out


def features(dataset: str, bbox, fetch=None, limit: int = 200) -> dict:
    if dataset not in LAYERS:
        raise ValueError("Unknown layer")
    x0, y0, x1, y1 = bbox
    span = max(abs(x1 - x0) * 111.32 * 0.62, abs(y1 - y0) * 111.32)
    cap = LAYERS[dataset]["max_span_km"]
    if span > cap:
        return {"dataset": dataset, "too_wide": True, "max_km": cap, "features": []}
    ents = (fetch or ds.pdg_area)(dataset, (x0, y0, x1, y1), limit)
    out = []
    for e in ents:
        wkt = e.get("geometry") or ""
        name = e.get("name") or e.get("reference") or ""
        polys = geo._polygons(wkt[wkt.index("("):]) if "POLYGON" in wkt.upper() and "(" in wkt else []
        if polys:
            for rings in polys[:3]:
                out.append({"t": "poly", "ring": [[round(x, 6), round(y, 6)] for x, y in simplify(rings[0])], "name": name})
            continue
        p = geo.point_of(e.get("point") or wkt)
        if p:
            out.append({"t": "pt", "lon": round(p[0], 6), "lat": round(p[1], 6), "name": name})
    return {"dataset": dataset, "features": out[:limit], "label": LAYERS[dataset]["label"], "colour": LAYERS[dataset]["colour"]}
