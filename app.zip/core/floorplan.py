"""Schematic floorplans.

A unit is a list of rooms with a width and depth in metres. `fit_unit` lays the rooms out in two strips
(habitable rooms on the front, service rooms behind), keeping every room's area and letting its
proportions adjust so the strips close into a rectangle. `draw_*` functions turn the geometry into
drawing primitives in metres, and `to_svg`, `to_png` and `to_pptx` render those primitives.
"""
from __future__ import annotations

import math
from html import escape

FRONT, REAR, EXT = "front", "rear", "ext"
BAND = {"living": FRONT, "kdl": FRONT, "kitchen": FRONT, "dining": FRONT, "bedroom": FRONT, "study": FRONT, "communal": FRONT,
        "hall": REAR, "landing": REAR, "stair": REAR, "bathroom": REAR, "ensuite": REAR, "wc": REAR, "store": REAR, "utility": REAR, "lift": REAR,
        "balcony": EXT, "garden": EXT}
KIND_LABEL = {"living": "Living room", "kdl": "Living, kitchen, dining", "kitchen": "Kitchen", "dining": "Dining", "bedroom": "Bedroom", "study": "Study", "communal": "Shared space",
              "hall": "Hall", "landing": "Landing", "stair": "Stair", "bathroom": "Bathroom", "ensuite": "En-suite", "wc": "WC", "store": "Storage", "utility": "Utility",
              "lift": "Lift", "balcony": "Balcony", "garden": "Garden"}
SHORT = {"bathroom": "Bath", "ensuite": "En-suite", "wc": "WC", "store": "Store", "hall": "Hall", "landing": "Landing", "stair": "Stair", "utility": "Utility"}
FILL = {"living": "#f6efe4", "kdl": "#f6efe4", "kitchen": "#f3ece0", "dining": "#f6efe4", "bedroom": "#edf1f6", "study": "#edf1f6", "communal": "#f6efe4",
        "hall": "#f3f3f1", "landing": "#f3f3f1", "stair": "#ecece9", "bathroom": "#e3eff2", "ensuite": "#e3eff2", "wc": "#e3eff2", "store": "#efeeea", "utility": "#e9eef0",
        "lift": "#ecece9", "balcony": "#eaf1e3", "garden": "#e1efd8"}
INK, WALL, GLASS, DIM = "#23272d", "#4a4f57", "#4f86b3", "#8a8f97"
WF = 1.06
FLOOR_NAMES = ["Ground floor", "First floor", "Second floor", "Third floor", "Fourth floor"]
TYPE_COLOURS = ["#f4c9a3", "#a9c9e0", "#b7d9b0", "#e2c2e0", "#f0e0a0", "#c7c9e8", "#e8b6b6", "#b9dcd8"]


def band_of(r: dict) -> str:
    return r.get("band") or BAND.get(r.get("kind"), FRONT)


def room_area(r: dict) -> float:
    return max(0.5, float(r.get("w") or 1) * float(r.get("d") or 1))


def _r2(x):
    return round(x, 2)


def is_external(r: dict) -> bool:
    return bool(r.get("external")) or band_of(r) == EXT or r.get("kind") in ("balcony", "garden")


# ------------------------------------------------------------------ layout

def _order_rear(rooms: list[dict], mode: str) -> list[dict]:
    rank = {"hall": 0, "landing": 0, "stair": 1, "wc": 2, "bathroom": 3, "ensuite": 4, "utility": 5, "store": 6, "lift": 7}
    if mode == "deep":
        return sorted(rooms, key=lambda r: rank.get(r["kind"], 8))
    halls = [r for r in rooms if r["kind"] in ("hall", "landing")]
    rest = sorted([r for r in rooms if r["kind"] not in ("hall", "landing")], key=lambda r: rank.get(r["kind"], 8))
    half = len(rest) // 2 + len(rest) % 2
    return rest[:half] + halls + rest[half:]


def _order_front(rooms: list[dict], mode: str) -> list[dict]:
    if mode == "deep":
        return rooms
    lead = [r for r in rooms if r["kind"] in ("living", "kdl", "communal")]
    return lead + [r for r in rooms if r not in lead]


def fit_unit(unit: dict) -> dict:
    """Lay out every floor of a unit. Returns geometry in metres; y runs down the page, the façade is at y = 0."""
    mode = "deep" if unit.get("family") == "house" else "wide"
    rooms = [dict(r) for r in unit.get("rooms") or []]
    inside = [r for r in rooms if not is_external(r)]
    outside = [r for r in rooms if is_external(r)]
    floors = sorted({int(r.get("floor") or 0) for r in inside}) or [0]
    tot = {f: sum(room_area(r) for r in inside if int(r.get("floor") or 0) == f) for f in floors}
    prim = max(floors, key=lambda f: tot[f])
    fr = [r for r in inside if int(r.get("floor") or 0) == prim and band_of(r) == FRONT]
    rr = [r for r in inside if int(r.get("floor") or 0) == prim and band_of(r) != FRONT]
    A = sum(room_area(r) for r in fr)
    B = sum(room_area(r) for r in rr)
    across = lambda r: float(r.get("d") if mode == "wide" else r.get("w") or 1)
    s1 = min(7.5, max(2.4, max((across(r) for r in fr), default=3.0)))
    if not fr:
        s1 = 0
    U = (A / s1) if fr else (B / 2.0)
    s2 = B / U if rr and U else 0
    if not fr and rr:
        s2 = 2.0
    S = s1 + s2
    out_floors, stretch = [], 0.0
    for f in floors:
        rs = [r for r in inside if int(r.get("floor") or 0) == f]
        a = sum(room_area(r) for r in rs if band_of(r) == FRONT)
        b = sum(room_area(r) for r in rs if band_of(r) != FRONT)
        k = (U * S) / max(0.1, a + b)
        stretch = max(stretch, abs(k - 1))
        a2, b2 = a * k, b * k
        s1f = a2 / U if a else 0
        s2f = b2 / U if b else 0
        if a and b:
            sc = S / (s1f + s2f)
            s1f, s2f = s1f * sc, s2f * sc
        elif a:
            s1f = S
        else:
            s2f = S
        placed = []
        for band, lst, v0, depth in ((FRONT, _order_front([r for r in rs if band_of(r) == FRONT], mode), 0.0, s1f), ("rear", _order_rear([r for r in rs if band_of(r) != FRONT], mode), s1f, s2f)):
            if not lst:
                continue
            tot_a = sum(room_area(r) for r in lst)
            u = 0.0
            for r in lst:
                ln = U * room_area(r) / tot_a
                if mode == "wide":
                    x, y, w, d = u, v0, ln, depth
                else:
                    x, y, w, d = v0, u, depth, ln
                placed.append({"id": r.get("id"), "name": r.get("name") or KIND_LABEL.get(r["kind"], "Room"), "kind": r["kind"], "x": _r2(x), "y": _r2(y), "w": _r2(w), "d": _r2(d),
                               "area": _r2(w * d), "band": band, "entered": _r2(room_area(r)), "floor": f})
                u += ln
        out_floors.append({"floor": f, "label": FLOOR_NAMES[f] if f < len(FLOOR_NAMES) else f"Floor {f}", "rooms": placed})
    W, D = (U, S) if mode == "wide" else (S, U)
    ext = []
    for r in outside:
        w, d = float(r.get("w") or 2), float(r.get("d") or 1.5)
        if r["kind"] == "garden":
            if mode == "deep":
                ext.append({"id": r.get("id"), "name": r.get("name") or "Garden", "kind": "garden", "x": _r2((W - w) / 2), "y": _r2(D + 0.3), "w": _r2(w), "d": _r2(d), "area": _r2(w * d), "floor": 0})
        else:
            w = min(w, max(1.2, W - 0.4))
            ext.append({"id": r.get("id"), "name": r.get("name") or "Balcony", "kind": "balcony", "x": _r2(0.3), "y": _r2(-d), "w": _r2(w), "d": _r2(d), "area": _r2(w * d), "floor": 0})
    gia = _r2(U * S * len(floors))
    return {"mode": mode, "W": _r2(W), "D": _r2(D), "floors": out_floors, "ext": ext, "gia": gia, "footprint": _r2(U * S), "stretch": _r2(stretch),
            "front_depth": _r2(s1), "across": _r2(S), "along": _r2(U)}


# ------------------------------------------------------------------ drawing

def _R(x, y, w, h, fill=None, stroke=None, sw=0.06):
    return {"t": "rect", "x": x, "y": y, "w": w, "h": h, "fill": fill, "stroke": stroke, "sw": sw}


def _L(x1, y1, x2, y2, stroke=INK, sw=0.05):
    return {"t": "line", "x1": x1, "y1": y1, "x2": x2, "y2": y2, "stroke": stroke, "sw": sw}


def _T(x, y, s, size=0.27, anchor="middle", bold=False, fill=INK):
    return {"t": "text", "x": x, "y": y, "s": s, "size": size, "anchor": anchor, "bold": bold, "fill": fill}


def _A(cx, cy, r, a0, a1, stroke=INK, sw=0.03):
    return {"t": "arc", "cx": cx, "cy": cy, "r": r, "a0": a0, "a1": a1, "stroke": stroke, "sw": sw}


def _overlap(a0, a1, b0, b1):
    return max(0.0, min(a1, b1) - max(a0, b0))


def _door(prims, r, other, mode):
    """Door on the wall shared by r and other, centred on their overlap. Leaf swings into r."""
    dw = 0.85
    if abs((r["y"] + r["d"]) - other["y"]) < 0.02 or abs(r["y"] - (other["y"] + other["d"])) < 0.02:
        lo, hi = max(r["x"], other["x"]), min(r["x"] + r["w"], other["x"] + other["w"])
        if hi - lo < dw + 0.2:
            return False
        cx = (lo + hi) / 2 - dw / 2
        wall_y = r["y"] + r["d"] if abs((r["y"] + r["d"]) - other["y"]) < 0.02 else r["y"]
        down = wall_y < r["y"] + r["d"] / 2 + 1e-6 and wall_y == r["y"]
        prims.append(_R(cx, wall_y - 0.09, dw, 0.18, "#ffffff", None))
        if down:      # wall at top of r, leaf swings down into r
            prims += [_L(cx, wall_y, cx, wall_y + dw, INK, 0.04), _A(cx, wall_y, dw, 0, 90)]
        else:         # wall at bottom of r, leaf swings up
            prims += [_L(cx, wall_y, cx, wall_y - dw, INK, 0.04), _A(cx, wall_y, dw, 270, 360)]
        return True
    if abs((r["x"] + r["w"]) - other["x"]) < 0.02 or abs(r["x"] - (other["x"] + other["w"])) < 0.02:
        lo, hi = max(r["y"], other["y"]), min(r["y"] + r["d"], other["y"] + other["d"])
        if hi - lo < dw + 0.2:
            return False
        cy = (lo + hi) / 2 - dw / 2
        wall_x = r["x"] + r["w"] if abs((r["x"] + r["w"]) - other["x"]) < 0.02 else r["x"]
        left_wall = wall_x == r["x"]
        prims.append(_R(wall_x - 0.09, cy, 0.18, dw, "#ffffff", None))
        if left_wall:
            prims += [_L(wall_x, cy, wall_x + dw, cy, INK, 0.04), _A(wall_x, cy, dw, 0, 90)]
        else:
            prims += [_L(wall_x, cy, wall_x - dw, cy, INK, 0.04), _A(wall_x, cy, dw, 90, 180)]
        return True
    return False


def _window(prims, x, y, length, horizontal):
    t = 0.3
    if horizontal:
        prims += [_R(x, y - t / 2, length, t, "#ffffff", None), _L(x, y, x + length, y, GLASS, 0.05), _L(x, y - 0.06, x + length, y - 0.06, GLASS, 0.02), _L(x, y + 0.06, x + length, y + 0.06, GLASS, 0.02)]
    else:
        prims += [_R(x - t / 2, y, t, length, "#ffffff", None), _L(x, y, x, y + length, GLASS, 0.05), _L(x - 0.06, y, x - 0.06, y + length, GLASS, 0.02), _L(x + 0.06, y, x + 0.06, y + length, GLASS, 0.02)]


def _furnish(prims, r, doors):
    x, y, w, d, k = r["x"], r["y"], r["w"], r["d"], r["kind"]
    fill, ln = "#ffffff", "#b3b7bd"

    def rect(px, py, pw, ph, f=fill):
        prims.append(_R(px, py, pw, ph, f, ln, 0.03))
    if k == "bedroom":
        double = r["area"] >= 10.5
        bw, bl = (1.5, 2.0) if double else (0.9, 2.0)
        side = doors.get(r["id"] or r["name"], "bottom")
        if d >= bl + 1.0 and w >= bw + 0.5:
            by = y + 0.15 if side == "bottom" else y + d - bl - 0.15
            bx = x + (w - bw) / 2
            rect(bx, by, bw, bl); rect(bx + 0.1, by + (0.1 if side == "bottom" else bl - 0.5), bw - 0.2, 0.4, "#f2f2f2")
        elif w >= bl + 0.9 and d >= bw + 0.4:
            bx = x + 0.15
            rect(bx, y + (d - bw) / 2, bl, bw); rect(bx + 0.1, y + (d - bw) / 2 + 0.1, 0.4, bw - 0.2, "#f2f2f2")
    elif k in ("living", "kdl", "communal"):
        sw_ = 2.1 if w >= 3.6 else 1.6
        if d >= 3.0 and w >= 2.6:
            rect(x + (min(w, 4.4) - sw_) / 2 + 0.2, y + d - 1.1, sw_, 0.9)
        if k == "kdl" and w >= 3.0 and d >= 3.4:
            run = min(3.6, w * 0.7)
            rect(x + w - run - 0.15, y + 0.15, run, 0.6, "#f0f0ee")
            prims.append({"t": "circle", "cx": x + w - run * 0.35 - 0.15, "cy": y + 0.45, "r": 0.13, "stroke": ln, "sw": 0.03})
            rect(x + w - run * 0.7 - 0.15, y + 0.28, 0.5, 0.34, "#e7eef2")
            if w >= 4.4 and d >= 4.4:
                rect(x + w / 2 - 0.5, y + d / 2 - 0.2, 1.6, 0.85)
    elif k == "kitchen":
        if w >= 2.0 and d >= 2.0:
            run = min(3.4, max(1.8, w - 0.3))
            rect(x + 0.15, y + 0.15, run, 0.6, "#f0f0ee")
            prims.append({"t": "circle", "cx": x + 0.15 + run * 0.7, "cy": y + 0.45, "r": 0.13, "stroke": ln, "sw": 0.03})
            rect(x + 0.15 + run * 0.25, y + 0.28, 0.5, 0.34, "#e7eef2")
    elif k in ("bathroom", "ensuite", "wc"):
        long_x = w >= d
        if k == "bathroom" and (w >= 1.9 or d >= 1.9):
            if long_x and w >= 1.9 and d >= 1.45:
                rect(x + 0.1, y + d - 0.8, 1.7, 0.7); rect(x + w - 0.55, y + 0.12, 0.42, 0.62); rect(x + 0.1, y + 0.1, 0.5, 0.4)
            elif not long_x and d >= 1.9 and w >= 1.45:
                rect(x + w - 0.8, y + 0.1, 0.7, 1.7); rect(x + 0.12, y + d - 0.75, 0.62, 0.42); rect(x + 0.1, y + 0.1, 0.4, 0.5)
        elif k in ("ensuite", "bathroom"):
            rect(x + 0.1, y + 0.1, 0.85, 0.85, "#e7eef2")
            if w > 1.6:
                rect(x + w - 0.5, y + d - 0.75, 0.42, 0.62)
        else:
            rect(x + (w - 0.42) / 2, y + 0.12, 0.42, 0.62)
    elif k == "stair":
        n = int(max(w, d) / 0.26)
        for i in range(1, n):
            if d >= w:
                prims.append(_L(x + 0.05, y + i * d / n, x + w - 0.05, y + i * d / n, ln, 0.02))
            else:
                prims.append(_L(x + i * w / n, y + 0.05, x + i * w / n, y + d - 0.05, ln, 0.02))
    elif k == "store":
        prims += [_L(x + 0.05, y + 0.05, x + w - 0.05, y + d - 0.05, ln, 0.02), _L(x + w - 0.05, y + 0.05, x + 0.05, y + d - 0.05, ln, 0.02)]


def draw_floor(g: dict, fl: dict, unit: dict | None = None, ox: float = 0.0, oy: float = 0.0, title: str | None = None, sub: str | None = None) -> tuple[list, tuple]:
    """Drawing primitives for one floor of a fitted unit, offset by (ox, oy). Returns (prims, (x0, y0, x1, y1))."""
    W, D, mode = g["W"], g["D"], g["mode"]
    prims: list = []
    rooms = fl["rooms"]
    ground = fl["floor"] == 0
    attach = (unit or {}).get("attach", "terrace")
    aspect = (unit or {}).get("aspect", "single")
    for e in g["ext"] if ground or unit is None or unit.get("family") != "house" else []:
        if e["kind"] == "garden" and not ground:
            continue
        prims.append(_R(e["x"], e["y"], e["w"], e["d"], FILL[e["kind"]], "#7d9a6b" if e["kind"] == "garden" else "#8aa07c", 0.05))
        if e["kind"] == "balcony":
            prims.append(_L(e["x"], e["y"], e["x"] + e["w"], e["y"], "#6f8a5f", 0.09))
        prims.append(_T(e["x"] + e["w"] / 2, e["y"] + e["d"] / 2 + 0.1, f"{e['name']} {e['area']:.1f} m²", 0.25, "middle", False, "#5a6b50"))
    for r in rooms:
        prims.append(_R(r["x"], r["y"], r["w"], r["d"], FILL.get(r["kind"], "#f4f4f2"), WALL, 0.09))
    # doors
    doors, byid = {}, {}
    hall = [r for r in rooms if r["kind"] in ("hall", "landing")]
    front = [r for r in rooms if r["band"] == "front"]
    for r in rooms:
        if r["kind"] in ("hall", "landing", "stair"):
            continue
        tgt = None
        for h in hall:
            if _door_fits(r, h):
                tgt = h
                break
        if tgt is None and r["band"] != "front":
            nb = [q for q in rooms if q is not r and q["band"] == r["band"] and _door_fits(r, q)]
            tgt = nb[0] if nb else None
        if tgt is None and r["band"] == "front":
            nb = [q for q in front if q is not r and byid.get(id(q)) and _door_fits(r, q)]
            tgt = nb[0] if nb else None
        if tgt is not None and _door(prims, r, tgt, mode):
            byid[id(r)] = True
            doors[r["id"] or r["name"]] = "top" if abs(r["y"] - (tgt["y"] + tgt["d"])) < 0.02 else "bottom" if abs((r["y"] + r["d"]) - tgt["y"]) < 0.02 else "side"
    for r in rooms:
        _furnish(prims, r, doors)
    # outer wall
    prims.append(_R(0, 0, W, D, None, INK, 0.26))
    # windows on the outer walls
    if mode == "wide":
        for r in front:
            if r["kind"] in ("living", "kdl", "bedroom", "study", "communal") and r["w"] >= 1.6:
                _window(prims, r["x"] + r["w"] * 0.2, 0, r["w"] * 0.6, True)
        if aspect == "dual" and front:
            end = max(front, key=lambda r: r["x"])
            _window(prims, W, end["y"] + end["d"] * 0.25, end["d"] * 0.5, False)
            first = min(front, key=lambda r: r["x"])
            _window(prims, 0, first["y"] + first["d"] * 0.25, first["d"] * 0.5, False)
    else:
        for r in rooms:
            if r["kind"] in ("hall", "stair", "store", "landing") and r["kind"] != "hall":
                pass
            if r["y"] < 0.05 and r["kind"] in ("living", "kdl", "bedroom", "study", "kitchen", "hall", "landing") and r["w"] >= 1.4:
                if ground and r["kind"] == "hall":
                    prims += [_R(r["x"] + r["w"] / 2 - 0.5, -0.09, 1.0, 0.18, "#ffffff", None), _L(r["x"] + r["w"] / 2 - 0.5, 0, r["x"] + r["w"] / 2 - 0.5, -1.0, INK, 0.04), _A(r["x"] + r["w"] / 2 - 0.5, 0, 1.0, 270, 360)]
                else:
                    _window(prims, r["x"] + r["w"] * 0.2, 0, r["w"] * 0.6, True)
            if r["y"] + r["d"] > D - 0.05 and r["kind"] in ("living", "kdl", "kitchen", "bedroom", "study") and r["w"] >= 1.4:
                _window(prims, r["x"] + r["w"] * 0.2, D, r["w"] * 0.6, True)
            if attach in ("detached", "semi") and r["x"] < 0.05 and r["kind"] in ("living", "kdl", "bedroom", "kitchen", "study") and r["d"] >= 1.6 and r["y"] > 0.05:
                _window(prims, 0, r["y"] + r["d"] * 0.25, r["d"] * 0.5, False)
    if mode == "wide":
        for r in rooms:
            if r["kind"] == "hall" and r["w"] >= 1.5:
                hx = r["x"] + r["w"] / 2 - 0.45
                prims += [_R(hx, D - 0.09, 0.9, 0.18, "#ffffff", None), _L(hx, D, hx, D + 0.9, INK, 0.04), _A(hx, D, 0.9, 270, 360)]
                break
    # labels
    for r in rooms:
        cx, cy = r["x"] + r["w"] / 2, r["y"] + r["d"] / 2
        small = min(r["w"], r["d"]) < 1.9 or r["area"] < 6
        if r["kind"] == "stair":
            continue
        nm = SHORT.get(r["kind"], r["name"]) if small else r["name"]
        size = 0.27 if not small else 0.22
        lines = [(nm, True)]
        if r["w"] >= 1.5 and r["d"] >= 1.1:
            lines.append((f"{r['w']:.1f} x {r['d']:.1f}", False))
        if r["area"] >= 8:
            lines.append((f"{r['area']:.1f} m²", False))
        y0 = cy - (len(lines) - 1) * size * 0.65
        for i, (s, b) in enumerate(lines):
            prims.append(_T(cx, y0 + i * size * 1.3 + size * 0.35, s, size, "middle", b, INK if b else "#5b6068"))
    # dimensions
    y_dim = -0.7 - max([e["d"] for e in g["ext"] if e["kind"] == "balcony"] or [0]) if mode == "wide" and g["ext"] else (-1.6 if mode == "deep" else -0.8)
    prims += [_L(0, y_dim, W, y_dim, DIM, 0.03), _L(0, y_dim - 0.12, 0, y_dim + 0.12, DIM, 0.03), _L(W, y_dim - 0.12, W, y_dim + 0.12, DIM, 0.03), _T(W / 2, y_dim - 0.14, f"{W:.1f} m", 0.26, "middle", False, DIM)]
    xd = W + 0.8
    prims += [_L(xd, 0, xd, D, DIM, 0.03), _L(xd - 0.12, 0, xd + 0.12, 0, DIM, 0.03), _L(xd - 0.12, D, xd + 0.12, D, DIM, 0.03), _T(xd + 0.18, D / 2 + 0.1, f"{D:.1f} m", 0.26, "start", False, DIM)]
    x0, y0 = -0.4, min(y_dim - 1.1, -2.0)
    x1 = W + 2.4
    y1 = D + 0.5 + max([e["d"] + 0.3 for e in g["ext"] if e["kind"] == "garden"] or [0])
    if title:
        prims.append(_T(0, y0 + 0.45, title, 0.36, "start", True))
    if sub:
        prims.append(_T(0, y0 + 0.95, sub, 0.28, "start", False, "#5b6068"))
    # shift by offset
    for p in prims:
        _shift(p, ox, oy)
    return prims, (x0 + ox, y0 + oy, x1 + ox, y1 + oy)


def _door_fits(a, b):
    if abs((a["y"] + a["d"]) - b["y"]) < 0.02 or abs(a["y"] - (b["y"] + b["d"])) < 0.02:
        return _overlap(a["x"], a["x"] + a["w"], b["x"], b["x"] + b["w"]) >= 1.05
    if abs((a["x"] + a["w"]) - b["x"]) < 0.02 or abs(a["x"] - (b["x"] + b["w"])) < 0.02:
        return _overlap(a["y"], a["y"] + a["d"], b["y"], b["y"] + b["d"]) >= 1.05
    return False


def _shift(p, ox, oy):
    for a, b in (("x", "y"), ("x1", "y1"), ("x2", "y2"), ("cx", "cy")):
        if a in p:
            p[a] += ox
            p[b] += oy


def unit_sheet(unit: dict, g: dict | None = None, gap: float = 1.6) -> tuple[list, tuple]:
    """All floors of a unit side by side, with the unit title above."""
    g = g or fit_unit(unit)
    prims, x = [], 0.0
    box = [0, 0, 0, 0]
    for i, fl in enumerate(g["floors"]):
        title = f"{unit.get('name', 'Unit')}, {g['gia'] * WF:.0f} m\u00b2 GIA" if i == 0 else None
        sub = fl["label"] if len(g["floors"]) > 1 else None
        p, b = draw_floor(g, fl, unit, ox=x, oy=0, title=title, sub=sub)
        prims += p
        box = [min(box[0], b[0]) if i else b[0], min(box[1], b[1]) if i else b[1], max(box[2], b[2]), max(box[3], b[3])]
        x = b[2] + gap
    if len(g["floors"]) == 1:
        pass
    return prims, tuple(box)


# ------------------------------------------------------------------ block and site diagrams

def floor_plate(units: list[dict], geoms: dict, comp: dict, corridor: float = 1.6, core_w: float = 3.8) -> dict:
    """Double-loaded corridor plate for one typical floor. comp maps unit id to the number of that type on the floor."""
    items = []
    for u in units:
        for _ in range(int(comp.get(u["id"], 0))):
            items.append(u)
    items.sort(key=lambda u: -geoms[u["id"]]["W"])
    top, bot, lt, lb = [], [], core_w, 0.0
    for u in items:
        w = geoms[u["id"]]["W"]
        if lt <= lb:
            top.append(u); lt += w
        else:
            bot.append(u); lb += w
    L = max(lt, lb)
    dt = max([geoms[u["id"]]["D"] for u in top] or [0]) or max([geoms[u["id"]]["D"] for u in bot] or [6])
    db = max([geoms[u["id"]]["D"] for u in bot] or [0]) or dt
    net = sum(geoms[u["id"]]["gia"] for u in items)
    gross = (L + 0.4) * (dt + db + corridor + 0.4)
    return {"top": top, "bot": bot, "L": L, "dt": dt, "db": db, "corridor": corridor, "core_w": core_w, "net": net, "gross": gross, "eff": net / gross if gross else 0, "n": len(items)}


def draw_plate(plate: dict, geoms: dict, colour: dict, title: str = "") -> tuple[list, tuple]:
    prims = []
    L, dt, db, c = plate["L"], plate["dt"], plate["db"], plate["corridor"]
    prims.append(_R(0, 0, L, dt + c + db, "#ffffff", INK, 0.22))
    prims.append(_R(0, dt, L, c, "#f3f3f1", None))
    prims.append(_R(0, 0, plate["core_w"], dt, "#e3e3df", WALL, 0.08))
    prims.append(_T(plate["core_w"] / 2, dt / 2 + 0.1, "Core", 0.3, "middle", True))
    x = plate["core_w"]
    for row, y0, dep, top in ((plate["top"], 0.0, dt, True), (plate["bot"], dt + c, db, False)):
        xx = plate["core_w"] if top else 0.0
        for u in row:
            g = geoms[u["id"]]
            w = g["W"]
            prims.append(_R(xx, y0, w, dep, colour.get(u["id"], "#eee"), WALL, 0.08))
            prims.append(_T(xx + w / 2, y0 + dep / 2 - 0.05, u.get("code") or u.get("name", ""), 0.32, "middle", True))
            prims.append(_T(xx + w / 2, y0 + dep / 2 + 0.4, f"{g['gia']:.0f} m²", 0.26, "middle", False, "#4a4f57"))
            xx += w
    prims.append(_T(L / 2, dt + c / 2 + 0.1, "Corridor", 0.24, "middle", False, DIM))
    y1 = dt + c + db
    prims += [_L(0, -0.6, L, -0.6, DIM, 0.03), _T(L / 2, -0.75, f"{L:.1f} m", 0.26, "middle", False, DIM)]
    if title:
        prims.append(_T(0, -1.4, title, 0.36, "start", True))
    return prims, (-0.4, -2.0, L + 0.5, y1 + 0.5)


def plots_strip(units: list[dict], geoms: dict, colour: dict, per_row: int = 12) -> tuple[list, tuple]:
    """Row of plot outlines for houses, grouped by type."""
    prims, x, row_y, maxh = [], 0.0, 0.0, 0.0
    for u in units:
        g = geoms[u["id"]]
        gard = next((r for r in u["rooms"] if r["kind"] == "garden"), None)
        gw, gd = (float(gard["w"]), float(gard["d"])) if gard else (g["W"], 6.0)
        pw = max(g["W"], gw) + 0.6
        ph = g["D"] + gd + 0.9
        n = max(1, min(int(u.get("count") or 1), 6))
        for i in range(n):
            prims.append(_R(x, row_y, pw, ph, "#eef4e8", "#8aa07c", 0.06))
            prims.append(_R(x + (pw - g["W"]) / 2, row_y + 0.3, g["W"], g["D"], colour.get(u["id"], "#eee"), WALL, 0.1))
            if i == 0:
                prims.append(_T(x + pw / 2, row_y + 0.3 + g["D"] / 2 + 0.1, u.get("code") or "", 0.3, "middle", True))
            x += pw
        if int(u.get("count") or 1) > n:
            prims.append(_T(x + 0.2, row_y + ph / 2, f"x {int(u['count'])}", 0.34, "start", True))
            x += 2.2
        maxh = max(maxh, ph)
        x += 0.8
    return prims, (-0.4, -0.4, x, maxh + 0.4)


# ------------------------------------------------------------------ renderers

def to_svg(prims: list, box: tuple, px_per_m: float = 44.0, max_w: float | None = None, bg: str = "#ffffff") -> str:
    x0, y0, x1, y1 = box
    w, h = (x1 - x0), (y1 - y0)
    k = px_per_m
    if max_w and w * k > max_w:
        k = max_w / w
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w * k:.1f} {h * k:.1f}" width="{w * k:.0f}" height="{h * k:.0f}" font-family="Aptos, Calibri, Arial, sans-serif" role="img" style="fill:none;stroke:none">',
           f'<rect width="100%" height="100%" fill="{bg}"/>']
    X = lambda v: f"{(v - x0) * k:.1f}"
    Y = lambda v: f"{(v - y0) * k:.1f}"
    for p in prims:
        t = p["t"]
        if t == "rect":
            f = p.get("fill") or "none"
            s = p.get("stroke")
            out.append(f'<rect x="{X(p["x"])}" y="{Y(p["y"])}" width="{p["w"] * k:.1f}" height="{p["h"] * k:.1f}" fill="{f}"' + (f' stroke="{s}" stroke-width="{max(0.6, p["sw"] * k):.2f}" stroke-linejoin="miter"' if s else "") + "/>")
        elif t == "line":
            out.append(f'<line x1="{X(p["x1"])}" y1="{Y(p["y1"])}" x2="{X(p["x2"])}" y2="{Y(p["y2"])}" stroke="{p["stroke"]}" stroke-width="{max(0.5, p["sw"] * k):.2f}"/>')
        elif t == "circle":
            out.append(f'<circle cx="{X(p["cx"])}" cy="{Y(p["cy"])}" r="{p["r"] * k:.1f}" fill="none" stroke="{p["stroke"]}" stroke-width="{max(0.5, p["sw"] * k):.2f}"/>')
        elif t == "arc":
            a0, a1 = math.radians(p["a0"]), math.radians(p["a1"])
            sx, sy = p["cx"] + p["r"] * math.cos(a0), p["cy"] + p["r"] * math.sin(a0)
            ex, ey = p["cx"] + p["r"] * math.cos(a1), p["cy"] + p["r"] * math.sin(a1)
            out.append(f'<path d="M{X(sx)},{Y(sy)} A{p["r"] * k:.1f},{p["r"] * k:.1f} 0 0 1 {X(ex)},{Y(ey)}" fill="none" stroke="{p["stroke"]}" stroke-width="{max(0.5, p["sw"] * k):.2f}"/>')
        elif t == "text":
            fs = max(6.5, p["size"] * k)
            anchor = {"middle": "middle", "start": "start", "end": "end"}[p["anchor"]]
            out.append(f'<text x="{X(p["x"])}" y="{Y(p["y"])}" font-size="{fs:.1f}" text-anchor="{anchor}" fill="{p["fill"]}"' + (' font-weight="600"' if p["bold"] else "") + f">{escape(p['s'])}</text>")
    out.append("</svg>")
    return "".join(out)


def to_png(prims: list, box: tuple, px_per_m: float = 60.0, bg=(255, 255, 255)) -> bytes:
    from PIL import Image, ImageDraw, ImageFont
    import io
    x0, y0, x1, y1 = box
    k = px_per_m
    W, H = int((x1 - x0) * k) + 2, int((y1 - y0) * k) + 2
    im = Image.new("RGB", (W, H), bg)
    d = ImageDraw.Draw(im)
    X = lambda v: (v - x0) * k
    Y = lambda v: (v - y0) * k

    def col(c):
        return c
    fonts = {}

    def font(sz, bold):
        key = (round(sz), bold)
        if key not in fonts:
            try:
                for cand in (("Aptos-Bold.ttf", "Aptos.ttf"), ("aptos-bold.ttf", "aptos.ttf"), ("Carlito-Bold.ttf", "Carlito-Regular.ttf"), ("calibrib.ttf", "calibri.ttf"), ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf")):
                    try:
                        fonts[key] = ImageFont.truetype(cand[0] if bold else cand[1], max(8, round(sz)))
                        break
                    except Exception:
                        continue
                else:
                    raise OSError("no font")
            except Exception:
                try:
                    fonts[key] = ImageFont.load_default(size=max(8, round(sz)))
                except Exception:
                    fonts[key] = ImageFont.load_default()
        return fonts[key]
    for p in prims:
        t = p["t"]
        if t == "rect":
            box_ = [X(p["x"]), Y(p["y"]), X(p["x"] + p["w"]), Y(p["y"] + p["h"])]
            if p.get("fill"):
                d.rectangle(box_, fill=p["fill"])
            if p.get("stroke"):
                d.rectangle(box_, outline=p["stroke"], width=max(1, round(p["sw"] * k)))
        elif t == "line":
            d.line([X(p["x1"]), Y(p["y1"]), X(p["x2"]), Y(p["y2"])], fill=p["stroke"], width=max(1, round(p["sw"] * k)))
        elif t == "circle":
            d.ellipse([X(p["cx"] - p["r"]), Y(p["cy"] - p["r"]), X(p["cx"] + p["r"]), Y(p["cy"] + p["r"])], outline=p["stroke"], width=1)
        elif t == "arc":
            d.arc([X(p["cx"] - p["r"]), Y(p["cy"] - p["r"]), X(p["cx"] + p["r"]), Y(p["cy"] + p["r"])], p["a0"], p["a1"], fill=p["stroke"], width=max(1, round(p["sw"] * k)))
        elif t == "text":
            f = font(max(9, p["size"] * k * 0.95), p["bold"])
            wd = d.textlength(p["s"], font=f)
            tx = X(p["x"]) - (wd / 2 if p["anchor"] == "middle" else wd if p["anchor"] == "end" else 0)
            d.text((tx, Y(p["y"]) - f.size * 0.85), p["s"], font=f, fill=p["fill"])
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def to_pptx(slide, prims: list, box: tuple, left: float, top: float, width: float, height: float):
    """Draw primitives as native PowerPoint shapes inside the given box (EMU). Doors and window arcs are drawn as lines."""
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Emu, Pt
    x0, y0, x1, y1 = box
    k = min(width / (x1 - x0), height / (y1 - y0))
    ox = left + (width - (x1 - x0) * k) / 2
    oy = top + (height - (y1 - y0) * k) / 2
    X = lambda v: int(ox + (v - x0) * k)
    Y = lambda v: int(oy + (v - y0) * k)
    rgb = lambda c: RGBColor.from_string(c.lstrip("#").upper())
    for p in prims:
        t = p["t"]
        if t == "rect":
            sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Emu(X(p["x"])), Emu(Y(p["y"])), Emu(int(p["w"] * k)), Emu(int(p["h"] * k)))
            if p.get("fill"):
                sh.fill.solid(); sh.fill.fore_color.rgb = rgb(p["fill"])
            else:
                sh.fill.background()
            if p.get("stroke"):
                sh.line.color.rgb = rgb(p["stroke"]); sh.line.width = Emu(max(6350, int(p["sw"] * k)))
            else:
                sh.line.fill.background()
            sh.shadow.inherit = False
        elif t == "line":
            c = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Emu(X(p["x1"])), Emu(Y(p["y1"])), Emu(X(p["x2"])), Emu(Y(p["y2"])))
            c.line.color.rgb = rgb(p["stroke"]); c.line.width = Emu(max(6350, int(p["sw"] * k)))
        elif t == "text":
            sz = max(6.0, p["size"] * k / 12700 * 0.9)
            wbox = int(len(p["s"]) * sz * 0.62 * 12700) + 20000
            hbox = int(sz * 1.5 * 12700)
            lx = X(p["x"]) - (wbox // 2 if p["anchor"] == "middle" else wbox if p["anchor"] == "end" else 0)
            tb = slide.shapes.add_textbox(Emu(lx), Emu(Y(p["y"]) - int(hbox * 0.7)), Emu(wbox), Emu(hbox))
            tf = tb.text_frame
            tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
            tf.word_wrap = False
            tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            para = tf.paragraphs[0]
            para.alignment = {"middle": PP_ALIGN.CENTER, "start": PP_ALIGN.LEFT, "end": PP_ALIGN.RIGHT}[p["anchor"]]
            run = para.add_run(); run.text = p["s"]
            run.font.size = Pt(sz); run.font.bold = bool(p["bold"]); run.font.color.rgb = rgb(p["fill"])
