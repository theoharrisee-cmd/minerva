"""Indicative build cost benchmarks, £ per sq ft of gross internal area.

These figures come from a quick review of public 2026 UK cost guides (ranges of £1,750 to £3,000 per m2 for new
build houses outside London, £2,100 to £2,700 per m2 for regional mid-rise flats, £3,000 to £3,600 per m2 for
London flats). They are not BCIS data and they exclude land, fees, VAT and abnormals. Every figure shown to the
user carries an asterisk, and the footnote below travels with it.
"""
from __future__ import annotations

FOOTNOTE = ("* Indicative only. Ranges are drawn from public 2026 cost guides and rounded, not from a "
            "cost consultant or BCIS. Use them as a starting point and replace them with a quantity surveyor's estimate.")

# £ per sq ft GIA, regional (outside London) base
BASE = {
    "houses": {"label": "New build houses", "low": 165, "mid": 205, "high": 255},
    "flats": {"label": "Flats, low and mid rise", "low": 195, "mid": 225, "high": 250},
    "btr": {"label": "Build to rent blocks", "low": 205, "mid": 235, "high": 265},
    "refurb_light": {"label": "Light refurbishment", "low": 40, "mid": 60, "high": 80},
    "refurb_heavy": {"label": "Conversion or heavy refurbishment", "low": 100, "mid": 135, "high": 180},
}

# Regional multipliers against the regional base
REGION_FACTOR = {
    "London": 1.38, "South East": 1.12, "East of England": 1.05, "South West": 1.05, "East Midlands": 0.98,
    "West Midlands": 0.98, "North West": 0.96, "Yorkshire and the Humber": 0.95, "North East": 0.93,
}

STRATEGY_TYPES = {"develop_sell": ["houses", "flats"], "btr": ["btr"], "value_add": ["refurb_light", "refurb_heavy"]}


def region_factor(region: str | None) -> float:
    return REGION_FACTOR.get(region or "", 1.0)


def table(region: str | None = None) -> list[dict]:
    f = region_factor(region)
    return [{"key": k, "label": v["label"], "low": round(v["low"] * f), "mid": round(v["mid"] * f), "high": round(v["high"] * f)} for k, v in BASE.items()]


def pick(site: dict, strategy: str, region: str | None) -> dict:
    """Best matching benchmark for a site, with the choice explained."""
    rows = {r["key"]: r for r in table(region)}
    if strategy == "btr":
        key = "btr"
    elif strategy == "value_add":
        key = "refurb_heavy" if (site.get("listed") or site.get("conservation_area") or "conver" in (site.get("property_type") or "").lower()) else "refurb_light"
    else:
        mix = site.get("unit_mix") or []
        flats = sum(m.get("count", 0) for m in mix if "flat" in (m.get("type") or "").lower() or "apartment" in (m.get("type") or "").lower())
        houses = sum(m.get("count", 0) for m in mix if "flat" not in (m.get("type") or "").lower() and "apartment" not in (m.get("type") or "").lower())
        if mix:
            key = "flats" if flats > houses else "houses"
        else:
            key = "houses" if (site.get("site_ha") or 0) and (site.get("units") or 0) / max(site.get("site_ha") or 1, 0.1) < 60 else "flats"
    r = rows[key]
    return {**r, "region": region or "England", "factor": region_factor(region), "footnote": FOOTNOTE, "strategy": strategy}
