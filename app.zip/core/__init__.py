"""easyDevelopment core: appraisal, scoring, scraping, planning, documents, intake, Outlook and comparables."""
