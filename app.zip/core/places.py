"""Towns and cities with populations, and travel-time estimates, for demographic and access searches.

The built-in list holds English cities and larger towns with rounded populations (local authority or built-up
area, Census 2021 order of magnitude). Values are approximate. Replace or extend the list with your own CSV
(name, lat, lon, population, kind) from the Data sources page. Travel times are estimates from straight-line
distance and typical speeds; the optional routing check asks an OSRM server for a road time. Standard library only.
"""
from __future__ import annotations

import csv
import io
import json
import re

from . import datasources as ds
from . import geo, store

# name, lat, lon, population (rounded), kind
_BUILTIN = """London,51.5074,-0.1278,8800000,city
Birmingham,52.4862,-1.8904,1145000,city
Leeds,53.8008,-1.5491,812000,city
Bradford,53.7938,-1.7521,546000,city
Sheffield,53.3811,-1.4701,556000,city
Manchester,53.4808,-2.2426,552000,city
Liverpool,53.4084,-2.9916,486000,city
Bristol,51.4545,-2.5879,472000,city
Leicester,52.6369,-1.1398,368000,city
Coventry,52.4068,-1.5197,345000,city
Nottingham,52.9548,-1.1581,323000,city
Newcastle upon Tyne,54.9783,-1.6178,302000,city
Milton Keynes,52.0406,-0.7594,287000,city
Sunderland,54.9069,-1.3838,277000,city
Brighton and Hove,50.8225,-0.1372,277000,city
Salford,53.4875,-2.2901,270000,city
Hull,53.7676,-0.3274,267000,city
Plymouth,50.3755,-4.1427,265000,city
Wolverhampton,52.5870,-2.1288,263000,city
Derby,52.9225,-1.4746,261000,city
Stoke-on-Trent,53.0027,-2.1794,256000,city
Southampton,50.9097,-1.4044,249000,city
Northampton,52.2405,-0.9027,225000,town
Luton,51.8787,-0.4200,225000,town
Swindon,51.5558,-1.7797,232000,town
Portsmouth,50.8198,-1.0880,208000,city
Peterborough,52.5695,-0.2405,216000,city
Warrington,53.3900,-2.5970,210000,town
York,53.9590,-1.0815,202000,city
Bournemouth,50.7192,-1.8808,187000,town
Southend-on-Sea,51.5459,0.7077,180000,city
Reading,51.4543,-0.9781,174000,town
Slough,51.5105,-0.5950,164000,town
Oxford,51.7520,-1.2577,162000,city
Huddersfield,53.6458,-1.7850,162000,town
Bolton,53.5768,-2.4282,195000,town
Blackpool,53.8175,-3.0357,141000,town
Middlesbrough,54.5742,-1.2350,143000,town
Preston,53.7632,-2.7031,147000,city
Ipswich,52.0567,1.1482,145000,town
Norwich,52.6309,1.2974,144000,city
Cambridge,52.2053,0.1218,146000,city
Stockport,53.4106,-2.1575,137000,town
Telford,52.6766,-2.4469,155000,town
Exeter,50.7184,-3.5339,131000,city
Gloucester,51.8642,-2.2382,129000,city
Colchester,51.8959,0.8919,122000,city
Watford,51.6565,-0.3903,102000,town
Basingstoke,51.2665,-1.0924,114000,town
Cheltenham,51.8994,-2.0783,118000,town
Crawley,51.1092,-0.1872,118000,town
Chelmsford,51.7356,0.4685,115000,city
Basildon,51.5761,0.4887,115000,town
High Wycombe,51.6286,-0.7482,125000,town
Woking,51.3190,-0.5590,103000,town
Doncaster,53.5228,-1.1285,158000,town
Wigan,53.5450,-2.6325,107000,town
Rotherham,53.4326,-1.3568,110000,town
Mansfield,53.1472,-1.1975,110000,town
Chesterfield,53.2350,-1.4211,104000,town
Bedford,52.1360,-0.4667,106000,town
Lincoln,53.2307,-0.5406,103000,city
Worcester,52.1936,-2.2216,103000,city
Wakefield,53.6830,-1.4977,110000,city
Gateshead,54.9526,-1.6014,120000,town
Eastbourne,50.7684,0.2905,100000,town
Worthing,50.8148,-0.3728,111000,town
Hastings,50.8543,0.5735,92000,town
Maidstone,51.2704,0.5227,78000,town
Guildford,51.2362,-0.5704,77000,town
Canterbury,51.2802,1.0789,55000,city
Bath,51.3781,-2.3597,94000,city
Chester,53.1934,-2.8931,92000,city
Carlisle,54.8925,-2.9329,76000,city
Durham,54.7761,-1.5733,48000,city
Winchester,51.0632,-1.3080,45000,city
Salisbury,51.0688,-1.7945,45000,city
Harrogate,53.9921,-1.5418,75000,town
Darlington,54.5233,-1.5527,93000,town
Hartlepool,54.6864,-1.2126,93000,town
Grimsby,53.5675,-0.0800,88000,town
Scunthorpe,53.5905,-0.6544,82000,town
Taunton,51.0145,-3.1029,70000,town
Stevenage,51.9038,-0.1966,89000,town
Harlow,51.7772,0.1108,87000,town
Aylesbury,51.8168,-0.8099,75000,town
Bracknell,51.4160,-0.7540,58000,town
Newbury,51.4014,-1.3231,34000,town
Wokingham,51.4112,-0.8339,40000,town
Maidenhead,51.5226,-0.7204,70000,town
Andover,51.2111,-1.4926,52000,town
Tunbridge Wells,51.1324,0.2637,60000,town
Cheshunt,51.7000,-0.0300,55000,town
Redditch,52.3062,-1.9450,86000,town
Kidderminster,52.3880,-2.2490,56000,town
Nuneaton,52.5230,-1.4650,88000,town
Rugby,52.3709,-1.2650,75000,town
Lancaster,54.0466,-2.8007,52000,city
Barnsley,53.5526,-1.4797,91000,town
Halifax,53.7248,-1.8658,88000,town
Truro,50.2632,-5.0510,19000,city
Shrewsbury,52.7073,-2.7541,76000,town
Hereford,52.0565,-2.7160,61000,city
Kettering,52.3981,-0.7266,58000,town
Banbury,52.0629,-1.3398,48000,town
Ashford,51.1465,0.8750,74000,town
Dartford,51.4460,0.2160,64000,town
Swanley,51.3960,0.1740,17000,town
Horsham,51.0629,-0.3260,55000,town"""

_cache: dict = {}


def _custom_path():
    return store.DATA / "places.csv"


def load(force: bool = False) -> list[dict]:
    if _cache.get("v") is not None and not force:
        return _cache["v"]
    src, rows = "built-in", []
    p = _custom_path()
    txt = p.read_text(encoding="utf-8") if p.exists() else None
    if txt:
        try:
            rows = _parse(txt)
            src = "your CSV"
        except Exception:
            rows = []
    if not rows:
        rows = _parse("name,lat,lon,population,kind\n" + _BUILTIN)
        src = "built-in"
    _cache["v"], _cache["src"] = rows, src
    return rows


def source() -> str:
    load()
    return _cache.get("src", "built-in")


def _parse(txt: str) -> list[dict]:
    out = []
    for r in csv.DictReader(io.StringIO(txt.lstrip("﻿"))):
        r = {k.strip().lower(): (v or "").strip() for k, v in r.items() if k}
        try:
            out.append({"name": r["name"], "lat": float(r["lat"]), "lon": float(r["lon"]), "population": int(float(re.sub(r"[^\d.]", "", r["population"]) or 0)), "kind": (r.get("kind") or "town").lower()})
        except (KeyError, ValueError):
            continue
    if not out:
        raise ValueError("No usable rows. Columns needed: name, lat, lon, population, kind")
    return out


def import_csv(text: str) -> int:
    rows = _parse(text)
    _custom_path().write_text(text, encoding="utf-8")
    load(force=True)
    return len(rows)


def reset():
    p = _custom_path()
    if p.exists():
        p.unlink()
    load(force=True)


# ---------------------------------------------------------------- travel time

MODES = {"drive": "Drive", "cycle": "Cycle", "walk": "Walk"}


def minutes(crow_km: float, mode: str = "drive") -> float:
    """Estimated door-to-door minutes from straight-line distance. Road distance is taken as 1.3 times the straight line."""
    if mode == "walk":
        return crow_km * 1.25 / 4.8 * 60
    if mode == "cycle":
        return crow_km * 1.25 / 16 * 60
    road = crow_km * 1.3
    urban = min(road, 6.0)
    rest = max(0.0, road - urban)
    speed2 = 55 if road < 40 else 70
    return urban / 28 * 60 + rest / speed2 * 60 + 2  # two minutes to park or join the road


def reach_km(mins: float, mode: str = "drive") -> float:
    """Straight-line radius in km that fits inside the given minutes (inverse of minutes())."""
    lo, hi = 0.0, 300.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if minutes(mid, mode) < mins:
            lo = mid
        else:
            hi = mid
    return lo


def osrm_minutes(a: tuple[float, float], b: tuple[float, float], mode: str = "drive", base: str = "https://router.project-osrm.org") -> float:
    # The free public OSRM server only carries the car network, and returns car times whatever profile is asked for.
    # So the car route is used for its road distance, and walking and cycling use a steady speed over that distance.
    if mode not in ("drive", "cycle", "walk"):
        raise KeyError(mode)
    js = ds._http(f"{base}/route/v1/driving/{a[1]},{a[0]};{b[1]},{b[0]}?overview=false", timeout=15)
    r = (js.get("routes") or [None])[0]
    if not r:
        raise RuntimeError("no route")
    if mode == "drive":
        return r["duration"] / 60
    speed = {"walk": 4.8, "cycle": 14.0}[mode]
    return r["distance"] / 1000 / speed * 60


# ---------------------------------------------------------------- queries

def within(lat: float, lon: float, min_pop: int, max_min: float, mode: str = "drive", min_min: float = 0, places: list[dict] | None = None) -> list[dict]:
    """Places with at least min_pop residents, reachable within max_min minutes (and no closer than min_min), nearest first."""
    out = []
    for p in places or load():
        if p["population"] < min_pop:
            continue
        d = geo.km(lat, lon, p["lat"], p["lon"])
        m = minutes(d, mode)
        if min_min <= m <= max_min:
            out.append({**p, "km": round(d, 1), "minutes": round(m)})
    out.sort(key=lambda x: x["minutes"])
    return out


def search(c: dict) -> dict:
    """Find towns that match demographic and access criteria.

    c: min_pop, max_pop (the town's own population), city_min_pop, city_max_min, city_min_min, mode,
       optional lat, lon, radius_km to restrict to an area, and kind (any, city, town).
    """
    places = load()
    mode = c.get("mode") or "drive"
    cpop, cmax = int(c.get("city_min_pop") or 0), float(c.get("city_max_min") or 0)
    cmin = float(c.get("city_min_min") or 0)
    lo, hi = int(c.get("min_pop") or 0), int(c.get("max_pop") or 0) or 10 ** 9
    res = []
    for p in places:
        if not (lo <= p["population"] <= hi):
            continue
        if c.get("kind") in ("city", "town") and p["kind"] != c["kind"]:
            continue
        if c.get("lat") is not None and c.get("radius_km") and geo.km(c["lat"], c["lon"], p["lat"], p["lon"]) > float(c["radius_km"]):
            continue
        anchor = None
        if cpop and cmax:
            near = [x for x in within(p["lat"], p["lon"], cpop, cmax, mode, cmin, places) if x["name"] != p["name"]]
            if not near:
                continue
            anchor = near[0]
        item = {**p, "anchor": anchor, "mode": mode}
        if c.get("lat") is not None:
            item["from_centre_km"] = round(geo.km(c["lat"], c["lon"], p["lat"], p["lon"]), 1)
        res.append(item)
    res.sort(key=lambda x: (x["anchor"]["minutes"] if x["anchor"] else 0, -x["population"]))
    zones = []
    if cpop and cmax:
        for p in sorted(places, key=lambda x: -x["population"]):
            if p["population"] >= cpop and (c.get("lat") is None or not c.get("radius_km") or geo.km(c["lat"], c["lon"], p["lat"], p["lon"]) <= float(c["radius_km"]) + reach_km(cmax, mode)):
                zones.append({"name": p["name"], "population": p["population"], "lat": p["lat"], "lon": p["lon"], "radius_km": round(reach_km(cmax, mode), 1), "min_radius_km": round(reach_km(cmin, mode), 1) if cmin else 0})
    return {"count": len(res), "places": res[:200], "zones": zones[:60], "source": source(), "note": "Populations are rounded and travel times are estimates from straight-line distance. Check the routes you rely on."}
