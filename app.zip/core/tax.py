"""Tax and net returns.

The appraisal stays before tax. This module takes its result and works out what is left: stamp duty on the land against the
acquisition allowance, VAT that cannot be recovered, and tax on the profit when the site is held in a company or personally.
Company and personal figures are always shown together and one is chosen as the headline.

Rates were checked in September 2026 against HMRC guidance and secondary summaries. They are held in one place below so they
can be updated. This is a desk view for comparing structures, not tax advice: it ignores group relief, losses, reliefs on
interest, allowances, national insurance and the tax on taking profit out of a company, all of which need an adviser.
"""
from __future__ import annotations

RATES_NOTE = ("Rates used: non-residential SDLT 0% to £150,000, 2% to £250,000, 5% above; corporation tax 19% to £50,000, 25% above £250,000 "
              "with marginal relief between; income tax 45% by default for the personal view. Checked September 2026.")
SDLT_NONRES = [(150_000, 0.0), (250_000, 0.02), (None, 0.05)]
CT_SMALL, CT_MAIN, CT_LOWER, CT_UPPER, CT_MR = 0.19, 0.25, 50_000.0, 250_000.0, 3 / 200
VAT = 0.20
STRUCTURES = {"company": "Company (special purpose vehicle)", "personal": "Personal ownership"}
SDLT_RES = [(125_000, 0.0), (250_000, 0.02), (925_000, 0.05), (1_500_000, 0.10), (None, 0.12)]
SDLT_SURCHARGE = 0.05  # higher rates for additional dwellings and companies buying a dwelling
SDLT_BASES = {"nonres": "Non-residential rates (land or commercial)", "residential": "Residential rates with the 5% higher-rates surcharge (site includes a dwelling)"}
DEFAULTS = {"structure": "company", "personal_rate": 0.45, "associated": 0, "tax_delay": 9, "vat_override": None, "sdlt_basis": "nonres"}


def clean(d: dict | None) -> dict:
    d = d or {}
    out = {}
    if d.get("structure") in STRUCTURES:
        out["structure"] = d["structure"]
    if d.get("personal_rate") not in (None, ""):
        v = float(d["personal_rate"])
        out["personal_rate"] = max(0.0, min(0.6, v / 100 if v > 1 else v))
    if d.get("associated") not in (None, ""):
        out["associated"] = int(max(0, min(20, float(d["associated"]))))
    if d.get("tax_delay") not in (None, ""):
        out["tax_delay"] = int(max(0, min(36, float(d["tax_delay"]))))
    if d.get("sdlt_basis") in SDLT_BASES:
        out["sdlt_basis"] = d["sdlt_basis"]
    if "vat_override" in d:
        out["vat_override"] = None if d["vat_override"] in (None, "") else max(0.0, float(d["vat_override"]))
    return out


def settings(site: dict, defaults: dict | None = None) -> dict:
    """The site's own settings over the defaults chosen at setup, over the built-in defaults."""
    return {**DEFAULTS, **(defaults or {}), **(site.get("tax") or {})}


def sdlt(price: float, basis: str = "nonres") -> float:
    """Stamp duty land tax by slice. 'nonres' for land bought without dwellings; 'residential' adds the higher-rates surcharge on the whole price."""
    bands = SDLT_RES if basis == "residential" else SDLT_NONRES
    tax, lo = (price * SDLT_SURCHARGE if basis == "residential" else 0.0), 0.0
    for hi, r in bands:
        top = price if hi is None else min(price, hi)
        if top > lo:
            tax += (top - lo) * r
        lo = hi if hi is not None else lo
        if hi is None or price <= hi:
            break
    return tax


def corporation_tax(profit: float, associated: int = 0) -> float:
    """Corporation tax on a year's profit, with the small profits rate and marginal relief. Limits are shared by associated companies."""
    if profit <= 0:
        return 0.0
    n = 1 + max(0, associated)
    lo, hi = CT_LOWER / n, CT_UPPER / n
    if profit <= lo:
        return profit * CT_SMALL
    if profit >= hi:
        return profit * CT_MAIN
    return profit * CT_MAIN - CT_MR * (hi - profit)


def vat_leakage(res: dict, strategy: str) -> tuple[float, str]:
    """VAT the scheme cannot recover. New homes for sale are zero-rated, so input tax is recovered. Rented homes and
    refurbishment for resale are not, so VAT on fees (and on refurbishment) is a cost. A desk rule to be replaced by a VAT adviser's view."""
    if strategy == "develop_sell":
        return 0.0, "Sales of new homes are zero-rated, so VAT on costs is recovered."
    if strategy == "btr":
        return VAT * (res.get("fees") or 0), "Rents are exempt, so VAT on professional fees is a cost. Construction of new homes is zero-rated."
    base = (res.get("build") or 0) + (res.get("contingency") or 0) + (res.get("fees") or 0)
    return VAT * base, "Refurbishment and fees carry VAT that an exempt sale or letting does not recover. Some conversions qualify for a reduced rate."


def _net_flows(res: dict, vat: float, tax: float, delay: int) -> list[float]:
    fl = [r["levered"] for r in (res.get("cashflow") or [])]
    if not fl:
        return []
    fl = fl[:] + [0.0] * delay
    if vat:
        fl[max(1, len(fl) // 3)] -= vat
    fl[-1] -= tax
    return fl


def _irr(fl: list[float]) -> float | None:
    """Annual IRR of monthly flows. Tax paid after the last receipt adds a second change of sign, so the rate is bracketed by scanning."""
    if not any(x < 0 for x in fl) or not any(x > 0 for x in fl):
        return None
    npv = lambda r: sum(f / (1 + r) ** i for i, f in enumerate(fl))  # noqa: E731
    grid = [-0.05 + 0.0025 * k for k in range(0, 241)]
    prev = grid[0]
    for r in grid[1:]:
        if npv(prev) * npv(r) <= 0:
            lo, hi = prev, r
            for _ in range(80):
                mid = (lo + hi) / 2
                if npv(lo) * npv(mid) <= 0:
                    hi = mid
                else:
                    lo = mid
            return (1 + (lo + hi) / 2) ** 12 - 1
        prev = r
    return None


def _returns(fl: list[float]) -> dict:
    inv = -sum(x for x in fl if x < 0)
    ret = sum(x for x in fl if x > 0)
    return {"irr": _irr(fl) if fl else None, "multiple": (ret / inv) if inv else None, "equity_profit": sum(fl)}


def compute(site: dict, res: dict, strategy: str, defaults: dict | None = None) -> dict:
    """Net returns for a completed appraisal. Returns {"incomplete": True} when there is nothing to tax."""
    if not res or res.get("incomplete"):
        return {"incomplete": True}
    st = settings(site, defaults)
    pbt = res["profit"]
    vat, vat_note = vat_leakage(res, strategy)
    if st.get("vat_override") is not None:
        vat, vat_note = float(st["vat_override"]), "Set by you."
    taxable = max(0.0, pbt - vat)
    price = res.get("tested_land_price") or 0.0
    sd = sdlt(price, st.get("sdlt_basis", "nonres"))
    allowance = max(0.0, (res.get("land_cost") or price) - price)
    gross = res.get("gdv") or 0.0
    out = {"structure": st["structure"], "structures": STRUCTURES, "settings": st, "rates_note": RATES_NOTE, "pre_tax_profit": pbt,
           "vat": {"amount": vat, "note": vat_note}, "taxable": taxable,
           "sdlt": {"price": price, "calculated": sd, "allowance": allowance, "difference": allowance - sd,
                    "basis": st.get("sdlt_basis", "nonres"), "note": "The acquisition allowance also covers agent and legal fees, so it should sit above the stamp duty alone."}}
    for key, tax in (("company", corporation_tax(taxable, st["associated"])), ("personal", taxable * st["personal_rate"])):
        r = _returns(_net_flows(res, vat, tax, st["tax_delay"]))
        out[key] = {"tax": tax, "effective": (tax / taxable) if taxable else 0.0, "net_profit": pbt - vat - tax,
                    "net_margin": ((pbt - vat - tax) / gross) if gross else None, **r}
    out["headline"] = out[st["structure"]]
    out["pre_tax"] = {"irr": res.get("irr_levered"), "multiple": res.get("equity_multiple"), "equity_profit": res.get("equity_profit")}
    out["caveat"] = ("A desk view for comparing structures. It leaves out losses, group relief, allowances, national insurance and the tax on taking profit "
                     "out of a company. Take advice before choosing a structure.")
    return out
