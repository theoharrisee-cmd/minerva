"""Floor areas from an Energy Performance Certificate data file.

The old EPC API on epc.opendatacommunities.org was retired in May 2026, when the data moved to the "Get energy performance of
buildings data" service, which offers bulk downloads by local authority. This module reads one of those files (a CSV, or a ZIP
that holds CSVs) and keeps only what comparables need: an address key and the floor area in square feet. Sold prices from the
Land Registry are then matched to it by address, which turns a sale price into a price per square foot.

Column names are matched loosely (ADDRESS1, address-1, Address 1 all work), so a small change in the file layout should not break
the import. Files are merged, so several councils can be loaded one after another.
"""
from __future__ import annotations

import csv
import gzip
import io
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import store

SQM_TO_SQFT = 10.7639
PATH = store.DATA / "epc_areas.json.gz"
_cache: dict | None = None


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _col(header: list[str], *names: str) -> int | None:
    flat = [re.sub(r"[^a-z0-9]", "", h.lower()) for h in header]
    for n in names:
        if n in flat:
            return flat.index(n)
    return None


def _read_csv(text: str, into: dict) -> int:
    rd = csv.reader(io.StringIO(text))
    try:
        head = next(rd)
    except StopIteration:
        return 0
    a1, a2, ad = _col(head, "address1", "addressline1"), _col(head, "address2", "addressline2"), _col(head, "address", "fulladdress", "propertyaddress")
    pc, fa = _col(head, "postcode", "propertypostcode"), _col(head, "totalfloorarea", "floorarea", "totalfloorareasqm")
    dt = _col(head, "lodgementdate", "lodgementdatetime", "inspectiondate")
    if pc is None or fa is None or (a1 is None and ad is None):
        return 0
    n = 0
    for row in rd:
        try:
            area_m2 = float(row[fa])
            postcode = row[pc]
            if area_m2 <= 0 or not postcode:
                continue
        except (ValueError, IndexError):
            continue
        when = row[dt][:10] if dt is not None and dt < len(row) else ""
        area = round(area_m2 * SQM_TO_SQFT, 1)
        keys = []
        if ad is not None:
            keys.append(_norm(row[ad] + postcode))
        if a1 is not None:
            keys.append(_norm(row[a1] + (row[a2] if a2 is not None and a2 < len(row) else "") + postcode))
            keys.append(_norm(row[a1] + postcode))
        for k in keys:
            old = into.get(k)
            if old is None or when >= old[1]:
                into[k] = [area, when]
        n += 1
    return n


def load() -> dict:
    global _cache
    if _cache is None:
        try:
            with gzip.open(PATH, "rt") as f:
                _cache = json.load(f)
        except Exception:
            _cache = {"rows": 0, "loaded": "", "files": [], "areas": {}}
    return _cache


def _save(d: dict) -> None:
    global _cache
    with gzip.open(PATH, "wt") as f:
        json.dump(d, f)
    _cache = d


def load_bytes(data: bytes, name: str) -> dict:
    """Read a CSV or a ZIP of CSVs and merge it into the stored index. Returns the status."""
    d = load()
    areas = d["areas"]
    n = 0
    if data[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                low = info.filename.lower()
                if not low.endswith(".csv") or "recommendation" in low or info.file_size == 0:
                    continue
                n += _read_csv(z.read(info).decode("utf-8-sig", "ignore"), areas)
    else:
        n = _read_csv(data.decode("utf-8-sig", "ignore"), areas)
    if not n:
        raise ValueError("No certificates were found in that file. It needs columns for the address, the postcode and the total floor area. Use the certificates file from the bulk download for a local authority.")
    d["rows"] = len(areas)
    d["loaded"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
    d["files"] = (d.get("files") or []) + [{"name": name[:80], "certificates": n, "when": d["loaded"]}]
    d["files"] = d["files"][-12:]
    _save(d)
    return status()


def load_path(path: str) -> dict:
    p = Path(path).expanduser()
    if not p.exists():
        raise ValueError("That file was not found")
    return load_bytes(p.read_bytes(), p.name)


def clear() -> None:
    global _cache
    _cache = {"rows": 0, "loaded": "", "files": [], "areas": {}}
    try:
        PATH.unlink()
    except FileNotFoundError:
        pass


def status() -> dict:
    d = load()
    return {"keys": d["rows"], "loaded": d["loaded"], "files": d["files"]}


def areas() -> dict:
    """{normalised address: floor area sq ft}, the shape comps.attach_areas expects."""
    return {k: v[0] for k, v in load()["areas"].items()}
