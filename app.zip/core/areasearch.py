"""Area search: ranked candidate sites from open data, by map area and criteria.

Candidates come from the brownfield land registers (planning.data.gov.uk) and from PlanIt applications
(consented and pending schemes are acquisition and competitor signals). Constraint layers are fetched once
for the whole search area and each candidate is tested against them locally, so a search costs a handful of
requests rather than one per site and layer. Scores are a screening aid with the workings shown, not a valuation.
"""
from __future__ import annotations

import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

from datetime import date

from . import datasources as ds
from . import geo, places

# constraint layers used to screen candidates: dataset id -> (label, severity 0-3, filter key)
SCREEN = {
    "green-belt": ("Green Belt", 3, "green_belt"), "flood-risk-zone": ("Flood risk zone", 2, "flood"), "site-of-special-scientific-interest": ("SSSI", 3, "sssi"),
    "ancient-woodland": ("Ancient woodland", 3, "ancient_woodland"), "national-park": ("National Park", 3, "national_park"), "area-of-outstanding-natural-beauty": ("National Landscape (AONB)", 3, "aonb"),
    "conservation-area": ("Conservation area", 1, "conservation_area"), "special-protection-area": ("Special Protection Area", 2, "spa"), "special-area-of-conservation": ("Special Area of Conservation", 2, "sac"),
    "listed-building-outline": ("Listed building", 2, "listed"), "air-quality-management-area": ("Air quality management area", 1, "aqma"),
}
JOB = {"running": False, "step": "", "done": 0, "total": 0, "result": None, "error": ""}
_lock = threading.Lock()


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def point_in_ring(x: float, y: float, ring) -> bool:
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def point_in_wkt(x: float, y: float, wkt: str) -> bool:
    for rings in geo._polygons(wkt[wkt.index("("):] if "(" in (wkt or "") else ""):
        if rings and point_in_ring(x, y, rings[0]) and not any(point_in_ring(x, y, h) for h in rings[1:]):
            return True
    return False


def _pick(e: dict, *keys):
    for k in keys:
        v = e.get(k)
        if v not in (None, ""):
            return v
    return None


def brownfield_candidates(b, centre, limit: int = 300) -> list[dict]:
    out, off = [], 0
    while off < limit:
        rows = ds.pdg_area("brownfield-land", b, 100, off)
        for e in rows:
            p = geo.point_of(e.get("point")) or geo.point_of(e.get("geometry"))
            if not p:
                continue
            ha = _f(_pick(e, "hectares", "site-area", "area-hectares")) or geo.ring_area_ha(e.get("geometry"))
            mx, mn = _f(_pick(e, "maximum-net-dwellings", "max-net-dwellings")), _f(_pick(e, "minimum-net-dwellings", "min-net-dwellings"))
            units = int(mx or mn or 0) or None
            perm = str(_pick(e, "planning-permission-status", "permission-status") or "")
            out.append({"key": f"bf-{e.get('entity')}", "source": "Brownfield land register", "name": _pick(e, "name") or f"Brownfield {e.get('reference') or ''}", "address": str(_pick(e, "site-address", "address-text", "address") or ""),
                        "lat": p[1], "lon": p[0], "ha": ha, "units": units, "status": perm, "ref": e.get("reference") or "", "brownfield": True, "consented": "permission" in perm.lower() and "not" not in perm.lower() and "pending" not in perm.lower(),
                        "url": f"{ds.PDG}/entity/{e.get('entity')}", "notes": str(_pick(e, "notes") or "")[:200], "ownership": str(_pick(e, "ownership-status") or "")})
        if len(rows) < 100:
            break
        off += 100
    return out


def pdg_application_candidates(lat, lon, radius_km, min_units: int) -> list[dict]:
    """Fallback when PlanIt cannot be reached: applications published to planning.data.gov.uk, which only some councils supply."""
    from . import schemes
    out = []
    for a in schemes.nearby_applications(lat, lon, radius_km, get_json=lambda url, timeout=20: ds._http(url, timeout=timeout)):
        n = a.get("units")
        if n is None or n < min_units:
            continue
        out.append({"key": a["id"], "source": "planning.data.gov.uk", "name": (a.get("detail") or a["name"])[:90], "address": "", "lat": a["lat"], "lon": a["lon"], "ha": None, "units": n, "status": a["kind"],
                    "ref": a["name"], "brownfield": False, "consented": a["kind"] == "Consented", "url": f"{ds.PDG}/entity/{a['id'][3:]}", "notes": a.get("detail", "")[:220], "pending": a["kind"] == "Submitted",
                    "decided": a.get("date"), "submitted": None})
    return out


def planit_candidates(lat, lon, radius_km, cfg, min_units: int, since: str) -> list[dict]:
    out = []
    tried = failed = 0
    last = None
    for state in ("Permitted", "Undecided"):
        for size in ("Large", "Medium"):
            tried += 1
            try:
                apps = ds.planit(lat, lon, radius_km, cfg, app_state=state, app_size=size, start_date=since, pg_sz=100)
            except Exception as e:
                failed += 1
                last = e
                continue
            for a in apps:
                if a.get("lat") is None:
                    continue
                n = ds.units_of(a["description"])
                if n is not None and n < min_units:
                    continue
                if n is None and size != "Large":
                    continue
                consented = state == "Permitted"
                out.append({"key": f"pi-{a['ref']}", "source": "PlanIt", "name": (a["address"] or a["name"])[:90], "address": a["address"], "lat": a["lat"], "lon": a["lon"], "ha": None, "units": n, "status": f"{state} ({a['lpa']})",
                            "ref": a["ref"], "brownfield": False, "consented": consented, "url": a["url"], "notes": a["description"][:220], "pending": not consented, "decided": a.get("decided"), "submitted": a.get("submitted")})
    if tried and failed == tried:
        raise RuntimeError(str(last)[:100] or "not reachable")
    return out


def dedupe(cands: list[dict], metres: float = 70) -> list[dict]:
    out: list[dict] = []
    for c in cands:
        m = next((o for o in out if geo.km(o["lat"], o["lon"], c["lat"], c["lon"]) * 1000 < metres), None)
        if not m:
            c["sources"] = [c["source"]]
            c["refs"] = [c["ref"]] if c.get("ref") else []
            out.append(c)
            continue
        if c["source"] not in m["sources"]:
            m["sources"].append(c["source"])
        if c.get("ref"):
            m["refs"].append(c["ref"])
        for k in ("ha", "units", "url"):
            if m.get(k) in (None, "") and c.get(k) not in (None, ""):
                m[k] = c[k]
        m["consented"] = m.get("consented") or c.get("consented")
        m["brownfield"] = m.get("brownfield") or c.get("brownfield")
        m["pending"] = m.get("pending") or c.get("pending")
        if c["source"] == "PlanIt" and len(c.get("notes", "")) > len(m.get("notes", "")):
            m["notes"] = c["notes"]
    return out


def load_layers(b, progress=None) -> dict:
    """Fetch each screening layer once for the area. {ds: {"rows": [(wkt, name)], "partial": bool}}"""
    layers: dict = {}

    def one(d):
        rows, off, partial = [], 0, False
        try:
            while off < 300:
                r = ds.pdg_area(d, b, 100, off)
                rows += [(e.get("geometry") or "", e.get("name") or e.get("reference") or "", e) for e in r]
                if len(r) < 100:
                    break
                off += 100
            else:
                partial = True
        except Exception as e:
            return d, {"rows": [], "partial": True, "error": str(e)[:100]}
        return d, {"rows": rows, "partial": partial}
    with ThreadPoolExecutor(max_workers=6) as ex:
        for d, v in ex.map(one, list(SCREEN)):
            layers[d] = v
            if progress:
                progress()
    return layers


def screen(c: dict, layers: dict) -> tuple[list[dict], list[str]]:
    hits, unknown = [], []
    for d, (label, sev, key) in SCREEN.items():
        L = layers.get(d) or {}
        if L.get("error"):
            unknown.append(label)
            continue
        hit = None
        for wkt, name, e in L.get("rows", []):
            if wkt and point_in_wkt(c["lon"], c["lat"], wkt):
                hit = (name, e)
                break
        if hit is None and L.get("partial"):
            try:
                ents = ds.pdg_point(d, c["lat"], c["lon"], 3)
                if ents:
                    hit = (ents[0].get("name") or ents[0].get("reference") or "", ents[0])
            except Exception:
                unknown.append(label)
        if hit:
            lab = label
            if key == "flood":
                lv = str(hit[1].get("flood-risk-level") or "")
                lab = f"Flood zone {lv}" if lv else label
                if lv == "3":
                    sev = 3
            hits.append({"key": key, "label": lab, "name": hit[0], "severity": sev})
    return hits, unknown


def nearest(c: dict, pts: list[tuple[float, float]]) -> float | None:
    return min((geo.km(c["lat"], c["lon"], y, x) * 1000 for x, y in pts), default=None)


def score(c: dict, crit: dict) -> tuple[int, list[str]]:
    s, why = 50.0, []
    lo, hi = crit.get("min_ha"), crit.get("max_ha")
    ha = c.get("ha")
    if ha:
        if (lo is None or ha >= lo) and (hi is None or ha <= hi):
            s += 10 if (lo or hi) else 4
            why.append(f"{ha:.2f} ha" + (" within your range" if (lo or hi) else ""))
        else:
            s -= 12
            why.append(f"{ha:.2f} ha is outside your range")
    elif lo or hi:
        s -= 3
        why.append("Site area not published")
    n = c.get("units")
    if n:
        ok = (crit.get("min_units") is None or n >= crit["min_units"]) and (crit.get("max_units") is None or n <= crit["max_units"])
        s += 8 if ok else -8
        why.append(f"{n} homes recorded" + ("" if ok else ", outside your range"))
        if ha:
            dph = n / ha
            why.append(f"about {dph:.0f} homes per hectare")
    if c.get("brownfield"):
        s += 8
        why.append("On a brownfield land register")
    if c.get("consented"):
        s += 10
        why.append("Has planning permission on record")
    elif c.get("pending"):
        s += 2
        why.append("Application undecided: a competitor or a route to a conditional deal")
    for h in c.get("constraints", []):
        s -= 6 * h["severity"] + 2
        why.append(f"{h['label']}" + (f": {h['name']}" if h.get("name") and h["name"] != h["label"] else ""))
    d = c.get("transport_m")
    if d is not None:
        if d < 400:
            s += 5
            why.append(f"Public transport stop {d:.0f} m away")
        elif d < 900:
            s += 2
            why.append(f"Public transport stop {d:.0f} m away")
        else:
            s -= 2
            why.append(f"Nearest stop {d / 1000:.1f} km away")
    if c.get("place"):
        s += 4
        why.append(f"About {c['place']['minutes']} minutes by {c['place']['mode']} from {c['place']['name']} ({c['place']['population']:,} residents, estimate)")
    if crit.get("centre") and c.get("distance_km") is not None and crit.get("radius_km"):
        s -= 6 * c["distance_km"] / crit["radius_km"]
    return int(max(0, min(100, round(s)))), why


def run(crit: dict, cfg: dict, hmlr_lookup=None) -> dict:
    lat, lon, rad = float(crit["lat"]), float(crit["lon"]), min(25.0, max(0.3, float(crit.get("radius_km") or 3)))
    crit = {**crit, "centre": True, "radius_km": rad}
    b = geo.bbox(lat, lon, rad)
    JOB.update(step="Reading brownfield registers", done=0, total=1)
    srcs = set(crit.get("sources") or ["brownfield", "planit"])
    cands, notes = [], []
    if "brownfield" in srcs:
        try:
            cands += brownfield_candidates(b, (lat, lon))
        except Exception as e:
            notes.append(f"Brownfield registers: {str(e)[:100]}")
    JOB.update(step="Reading planning applications")
    if "planit" in srcs:
        try:
            since = date.today().replace(year=date.today().year - max(1, int(crit.get("years") or 3))).isoformat()
            found = planit_candidates(lat, lon, rad, cfg, int(crit.get("planit_min_units") or 10), since)
            if not found:
                notes.append("PlanIt returned no medium or large applications in this area and period.")
            cands += found
        except Exception as e:
            notes.append(f"PlanIt could not be reached ({str(e)[:100]}). Showing applications from planning.data.gov.uk instead, which only some councils supply.")
            try:
                cands += pdg_application_candidates(lat, lon, min(rad, 5.0), int(crit.get("planit_min_units") or 10))
            except Exception as e2:
                notes.append(f"planning.data.gov.uk applications: {str(e2)[:100]}")
    cands = [c for c in cands if geo.km(lat, lon, c["lat"], c["lon"]) <= rad * 1.02]
    cands = dedupe(cands)
    for c in cands:
        c["distance_km"] = round(geo.km(lat, lon, c["lat"], c["lon"]), 2)
    if crit.get("brownfield_only"):
        cands = [c for c in cands if c.get("brownfield")]
    if crit.get("consented") == "yes":
        cands = [c for c in cands if c.get("consented")]
    elif crit.get("consented") == "no":
        cands = [c for c in cands if not c.get("consented")]
    JOB.update(step="Screening against constraint layers", done=0, total=len(SCREEN) + 1)

    def tick():
        JOB["done"] += 1
    layers = load_layers(b, tick)
    stops = []
    try:
        for e in ds.pdg_area("transport-access-node", b, 100):
            p = geo.point_of(e.get("point") or e.get("geometry"))
            if p:
                stops.append(p)
    except Exception:
        notes.append("Transport nodes could not be read, so access is not scored.")
    unknown_all = set()
    near_pop, near_min = int(crit.get("near_pop") or 0), float(crit.get("near_min") or 0)
    near_mode = crit.get("near_mode") or "drive"
    excl = set(crit.get("exclude") or [])
    kept = []
    for c in cands:
        c["constraints"], unk = screen(c, layers)
        unknown_all.update(unk)
        c["transport_m"] = nearest(c, stops) if stops else None
        if excl and any(h["key"] in excl for h in c["constraints"]):
            continue
        if near_pop and near_min:
            hit = places.within(c["lat"], c["lon"], near_pop, near_min, near_mode, float(crit.get("near_min_min") or 0))
            if not hit:
                continue
            c["place"] = {"name": hit[0]["name"], "population": hit[0]["population"], "minutes": hit[0]["minutes"], "mode": near_mode}
        if crit.get("min_ha") and c.get("ha") is None and crit.get("strict_size"):
            continue
        c["score"], c["why"] = score(c, crit)
        kept.append(c)
    kept.sort(key=lambda c: -c["score"])
    kept = kept[: int(crit.get("limit") or 40)]
    for c in kept:
        c["id"] = "srch-" + re.sub(r"[^a-z0-9]+", "", c["key"].lower())[:24]
        c["constraint_labels"] = [h["label"] for h in c["constraints"]]
    if unknown_all:
        notes.append("Not screened (layer unavailable): " + ", ".join(sorted(unknown_all)) + ".")
    res = {"criteria": {k: v for k, v in crit.items() if k not in ("centre",)}, "count": len(kept), "considered": len(cands), "candidates": kept, "notes": notes, "excluded_by": sorted(excl),
           "layers": {d: {"n": len(v["rows"]), "partial": v["partial"], "error": v.get("error", "")} for d, v in layers.items()}}
    return res


def start(crit: dict, cfg: dict, hmlr_lookup=None) -> bool:
    with _lock:
        if JOB["running"]:
            return False
        JOB.update(running=True, error="", result=None, step="Starting", done=0, total=1)

    def go():
        try:
            JOB["result"] = run(crit, cfg, hmlr_lookup)
        except Exception as e:
            JOB["error"] = str(e)[:300]
        finally:
            JOB.update(running=False, step="Done")
    threading.Thread(target=go, daemon=True).start()
    return True


def to_site(c: dict, strategy: str = "develop_sell") -> dict:
    ps = "Consented" if c.get("consented") else "Allocated" if c.get("brownfield") else "Unknown"
    desc = "; ".join(x for x in (c.get("notes"), f"Sources: {', '.join(c.get('sources') or [c['source']])}", f"Refs: {', '.join(c.get('refs') or [])}" if c.get("refs") else "") if x)
    s = {"id": c.get("id") or "srch-" + uuid.uuid4().hex[:8], "name": c["name"], "address": c.get("address") or "", "lat": c["lat"], "lon": c["lon"], "geo_precision": "point", "source": "Area search",
         "site_ha": c.get("ha"), "units": c.get("units"), "brownfield": bool(c.get("brownfield")), "planning_status": ps, "stage": "Sourced", "strategy": strategy, "description": desc[:500], "url": c.get("url", ""), "listing": False}
    for h in c.get("constraints", []):
        k = {"flood": "flood_zone", "aqma": None}.get(h["key"], h["key"])
        if k == "flood_zone":
            m = re.search(r"Flood zone (\w+)", h["label"])
            s["flood_zone"] = m.group(1) if m else "2"
        elif k:
            s[k] = True
    return s
