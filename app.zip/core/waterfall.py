"""Capital structure views on top of the appraisal.

1. Equity waterfall for a joint venture or fund: capital is contributed pro rata, distributions run through
   hurdle tiers, and the sponsor earns a promote above each hurdle.
2. Lender metrics and covenant tests: loan to cost, loan to GDV, interest cover, debt yield, profit on cost.
"""
from __future__ import annotations

from .appraisal import irr

DEFAULT_TERMS = {
    "sponsor_coinvest": 10.0,      # % of equity contributed by the sponsor
    "tiers": [                     # above each hurdle (IRR, pa %) the sponsor takes this promote (%) until the next hurdle
        {"hurdle": 8.0, "promote": 20.0},
        {"hurdle": 15.0, "promote": 30.0},
    ],
}

DEFAULT_COVENANTS = {
    "max_senior_ltc": 65.0,
    "max_total_ltc": 85.0,
    "max_senior_ltgdv": 65.0,
    "max_total_ltgdv": 75.0,
    "min_profit_on_cost": 15.0,
    "min_icr": 1.5,               # stabilised income to interest, income strategies only
    "min_debt_yield": 8.0,
}


def clean_terms(t: dict | None) -> dict:
    t = t or {}
    tiers = []
    for x in (t.get("tiers") or DEFAULT_TERMS["tiers"]):
        try:
            tiers.append({"hurdle": float(x["hurdle"]), "promote": float(x["promote"])})
        except (KeyError, TypeError, ValueError):
            continue
    tiers.sort(key=lambda x: x["hurdle"])
    if not tiers:
        tiers = [dict(x) for x in DEFAULT_TERMS["tiers"]]
    co = t.get("sponsor_coinvest", DEFAULT_TERMS["sponsor_coinvest"])
    try:
        co = min(100.0, max(0.0, float(co)))
    except (TypeError, ValueError):
        co = DEFAULT_TERMS["sponsor_coinvest"]
    return {"sponsor_coinvest": co, "tiers": tiers}


def run(equity_flows: list[float], terms: dict | None = None) -> dict:
    """Split monthly levered equity flows between investor (LP) and sponsor (GP).

    Every hurdle keeps its own balance: contributions add to it, it compounds at the hurdle rate, and investor
    distributions reduce it. A tier pays out until its balance is cleared; the promote share of each tier's
    distribution goes to the sponsor and the remainder is split pro rata to capital. The final tier has no cap.
    """
    t = clean_terms(terms)
    tiers = t["tiers"]
    co = t["sponsor_coinvest"] / 100.0
    monthly = [(1 + x["hurdle"] / 100.0) ** (1 / 12) - 1 for x in tiers]
    bal = [0.0] * len(tiers)
    lp, gp_cap, gp_prom = [], [], []
    tier_paid = [0.0] * (len(tiers) + 1)
    for i, f in enumerate(equity_flows):
        if i > 0:
            bal = [b * (1 + r) for b, r in zip(bal, monthly)]
        if f < 0:
            c = -f
            bal = [b + c for b in bal]
            lp.append(f * (1 - co))
            gp_cap.append(f * co)
            gp_prom.append(0.0)
            continue
        avail = f
        to_inv = prom = 0.0
        for k, tier in enumerate(tiers):
            if avail <= 1e-9:
                break
            # zone k runs from hurdle k-1 up to hurdle k, so it carries the promote set on hurdle k-1
            p_here = tiers[k - 1]["promote"] / 100.0 if k > 0 else 0.0
            need_inv = max(0.0, bal[k])
            gross_needed = need_inv / (1 - p_here) if p_here < 1 else avail
            pay = min(avail, gross_needed)
            inv_part = pay * (1 - p_here)
            prom += pay * p_here
            to_inv += inv_part
            tier_paid[k] += pay
            bal = [max(0.0, b - inv_part) for b in bal]
            avail -= pay
        if avail > 1e-9:
            p_last = tiers[-1]["promote"] / 100.0
            inv_part = avail * (1 - p_last)
            prom += avail * p_last
            to_inv += inv_part
            tier_paid[-1] += avail
            bal = [max(0.0, b - inv_part) for b in bal]
        lp.append(to_inv * (1 - co))
        gp_cap.append(to_inv * co)
        gp_prom.append(prom)
    sponsor = [a + b for a, b in zip(gp_cap, gp_prom)]

    def stats(flows):
        inv = -sum(x for x in flows if x < 0)
        ret = sum(x for x in flows if x > 0)
        return {"irr": irr(flows), "multiple": (ret / inv) if inv else None, "invested": inv, "returned": ret, "profit": sum(flows)}

    total = stats(list(equity_flows))
    lp_s, gp_s = stats(lp), stats(sponsor)
    promote_total = sum(gp_prom)
    profit = total["profit"]
    return {
        "terms": t, "total": total, "investor": lp_s, "sponsor": gp_s,
        "promote": promote_total, "promote_share_of_profit": (promote_total / profit) if profit > 0 else 0.0,
        "sponsor_share_of_profit": (gp_s["profit"] / profit) if profit > 0 else 0.0,
        "tier_paid": tier_paid,
        "flows": [{"month": i, "total": tf, "investor": a, "sponsor": b} for i, (tf, a, b) in enumerate(zip(equity_flows, lp, sponsor))],
    }


def lender(ap: dict, cov: dict | None = None, strategy: str | None = None, rate_s: float = 0.085, rate_m: float = 0.13) -> dict:
    """Lender metrics and covenant tests from a full appraisal result."""
    c = {**DEFAULT_COVENANTS, **(cov or {})}
    strategy = strategy or ap.get("strategy")
    cost = ap.get("total_cost") or 0.0
    gdv = ap.get("gdv") or 0.0
    senior, mezz = ap.get("senior_peak") or 0.0, ap.get("mezz_peak") or 0.0
    debt = senior + mezz
    interest = ap.get("interest_total") or 0.0
    noi = ap.get("noi") or 0.0
    # Interest on the peak debt balance at the contract rates, used for income cover
    stab_interest = senior * rate_s + mezz * rate_m
    m = {
        "senior": senior, "mezz": mezz, "debt": debt, "interest": interest,
        "senior_ltc": senior / cost * 100 if cost else 0, "total_ltc": debt / cost * 100 if cost else 0,
        "senior_ltgdv": senior / gdv * 100 if gdv else 0, "total_ltgdv": debt / gdv * 100 if gdv else 0,
        "profit_on_cost": (ap.get("profit_on_cost") or 0) * 100,
        "icr": (noi / stab_interest) if stab_interest and strategy != "develop_sell" else None,
        "debt_yield": (noi / debt * 100) if debt and strategy != "develop_sell" else None,
        "sales_cover": ((ap.get("net_value") or 0) / debt) if debt and strategy == "develop_sell" else None,
    }
    tests = [
        ("Senior loan to cost", m["senior_ltc"], c["max_senior_ltc"], "max", "%"),
        ("Total loan to cost", m["total_ltc"], c["max_total_ltc"], "max", "%"),
        ("Senior loan to GDV", m["senior_ltgdv"], c["max_senior_ltgdv"], "max", "%"),
        ("Total loan to GDV", m["total_ltgdv"], c["max_total_ltgdv"], "max", "%"),
        ("Profit on cost", m["profit_on_cost"], c["min_profit_on_cost"], "min", "%"),
    ]
    if m["icr"] is not None:
        tests.append(("Interest cover on stabilised income", m["icr"], c["min_icr"], "min", "x"))
    if m["debt_yield"] is not None:
        tests.append(("Debt yield", m["debt_yield"], c["min_debt_yield"], "min", "%"))
    out = []
    for name, val, lim, kind, unit in tests:
        ok = val <= lim + 1e-9 if kind == "max" else val >= lim - 1e-9
        out.append({"name": name, "value": val, "limit": lim, "kind": kind, "unit": unit, "ok": ok, "headroom": (lim - val) if kind == "max" else (val - lim)})
    return {"metrics": m, "tests": out, "covenants": c, "pass_all": all(t["ok"] for t in out)}
