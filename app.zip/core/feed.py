"""What needs your attention: in-app notifications, and planning news for the home screen."""
from __future__ import annotations

import hashlib
from datetime import date, datetime, timedelta, timezone

from . import schemes

LEVEL_RANK = {"important": 0, "info": 1}


def _d(s):
    try:
        return date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def _h(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:10]


def notifications(sites: list[dict], schemes_: list[dict], seen: set[str], today: date | None = None) -> list[dict]:
    today = today or date.today()
    out = []

    def add(nid, level, kind, title, detail, site=None, when=""):
        out.append({"id": nid, "level": level, "kind": kind, "title": title, "detail": detail, "site_id": (site or {}).get("id", ""), "site_name": (site or {}).get("name", ""),
                    "when": when or datetime.now(timezone.utc).isoformat(timespec="seconds"), "seen": nid in seen})

    for s in sites:
        if s.get("stage") == "Rejected":
            continue
        for e in (s.get("events") or [])[-30:]:
            nid = "ev:" + e["id"]
            n = {"id": nid, "level": e.get("level", "info"), "kind": e.get("kind", "activity"), "title": e["title"], "detail": e.get("detail", ""), "site_id": s["id"], "site_name": s.get("name", ""),
                 "when": e.get("ts", ""), "seen": bool(e.get("seen")) or nid in seen}
            out.append(n)
        items = s.get("dd") or []
        over = [i for i in items if i.get("due") and i["due"] < today.isoformat() and i.get("status") not in ("Done", "Not applicable")]
        if over:
            add("dd:" + s["id"] + ":" + _h(*sorted(i["id"] for i in over)), "important", "diligence", f"{len(over)} diligence item{'s' if len(over) != 1 else ''} overdue", "; ".join(i["item"] for i in over[:3]), s)
        issues = [i for i in items if i.get("status") == "Issue"]
        if issues:
            add("ddi:" + s["id"] + ":" + _h(*sorted(i["id"] for i in issues)), "important", "diligence", f"{len(issues)} open diligence issue{'s' if len(issues) != 1 else ''}", "; ".join(i["item"] for i in issues[:3]), s)
        for p in s.get("parcels") or []:
            nd = _d(p.get("next_date"))
            if nd and nd < today and p.get("status") not in ("Option signed", "Contracted", "Declined"):
                add(f"land:{s['id']}:{p['id']}:{p['next_date']}", "info", "land", f"Landowner follow-up overdue: {p.get('owner') or p.get('ref') or 'parcel'}", p.get("next_action") or "No next action recorded", s)
        dates = [(k.get("date"), k.get("event")) for k in s.get("key_dates") or []]
        if s.get("bid_deadline") and s.get("stage") in ("Sourced", "Screened", "Appraised", "Offer"):
            dates.append((s["bid_deadline"], "Bid deadline"))
        for d, ev in dates:
            dd = _d(d)
            if dd is None:
                continue
            days = (dd - today).days
            if 0 <= days <= 14:
                add(f"date:{s['id']}:{d}:{ev}", "important" if days <= 7 else "info", "date", f"{ev} in {days} day{'s' if days != 1 else ''}", f"{dd:%d %B %Y}", s)
    for sc in schemes_ or []:
        m = _d(sc.get("debt_maturity"))
        if m and sc.get("debt_drawn") and 0 <= (m - today).days <= 365:
            days = (m - today).days
            add(f"debt:{sc['id']}:{sc['debt_maturity']}", "important" if days <= 180 else "info", "debt", f"Facility matures in {days // 30} months: {sc.get('name', '')}", f"{m:%d %B %Y}")
    out.sort(key=lambda n: n["when"], reverse=True)
    out.sort(key=lambda n: (n["seen"], LEVEL_RANK.get(n["level"], 1)))
    return out


# ---------------------------------------------------------------- planning news

DECIDED = ("Granted", "Refused", "Appeal allowed", "Appeal dismissed", "Withdrawn")


def on_file(sites: list[dict]) -> list[dict]:
    """Applications and consultee positions already recorded against each site."""
    out = []
    for s in sites:
        if s.get("stage") == "Rejected":
            continue
        for a in s.get("planning_history") or []:
            dec = _d(a.get("decided"))
            sub = _d(a.get("submitted"))
            when = dec or sub
            if not when:
                continue
            kind = a.get("status") if a.get("status") in DECIDED else "Pending" if a.get("status") in ("Submitted", "Validated", "Pending") else a.get("status") or "Application"
            out.append({"id": f"file:{s['id']}:{a.get('ref')}", "site_id": s["id"], "site_name": s.get("name", ""), "kind": kind, "ref": a.get("ref", ""), "text": (a.get("description") or "")[:200],
                        "date": when.isoformat(), "lpa": a.get("lpa", ""), "distance_km": 0.0, "source": "On file", "own": True})
        for c in s.get("consultees") or []:
            cd = _d(c.get("date"))
            if cd:
                out.append({"id": f"cons:{s['id']}:{c.get('body')}:{c.get('date')}", "site_id": s["id"], "site_name": s.get("name", ""), "kind": f"{c.get('body')}: {c.get('stance')}", "ref": "",
                            "text": c.get("summary", ""), "date": cd.isoformat(), "lpa": "", "distance_km": 0.0, "source": "On file", "own": True})
    return out


def fetch_nearby(site: dict, radius_km: float = 1.0, get_json=None) -> list[dict]:
    apps = schemes.nearby_applications(site["lat"], site["lon"], radius_km, get_json)
    out = []
    for a in apps:
        d = schemes.km(site["lat"], site["lon"], a["lat"], a["lon"])
        out.append({"id": f"pdg:{site['id']}:{a['id']}", "site_id": site["id"], "site_name": site.get("name", ""), "kind": a["kind"] if a["kind"] != "Submitted" else "Pending", "ref": a["name"],
                    "text": a.get("detail", ""), "date": str(a.get("date") or "")[:10], "lpa": "", "distance_km": round(d, 2), "source": "planning.data.gov.uk", "own": False})
    return out


def merge(sites: list[dict], live: dict[str, list[dict]], limit: int = 40, days: int = 400, today: date | None = None) -> list[dict]:
    today = today or date.today()
    cutoff = (today - timedelta(days=days)).isoformat()
    items = on_file(sites)
    for lst in live.values():
        items += lst
    seen, out = set(), []
    for i in sorted(items, key=lambda x: x["date"] or "0000", reverse=True):
        if not i["date"] or i["date"] < cutoff or i["id"] in seen:
            continue
        seen.add(i["id"])
        out.append(i)
    return out[:limit]
