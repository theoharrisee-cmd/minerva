"""Value and build cost by home type.

Sale values come from sold prices near the site (HM Land Registry, matched to detached, semi-detached,
terraced and flat), converted to £ per sq ft where floor areas were matched from EPC, otherwise to a
value from the median price for the type. Build cost per type moves the benchmark rate for houses,
low and mid rise flats, tall blocks and build to rent, scaled to the build cost already set in the appraisal.
"""
from __future__ import annotations

from . import costs

SQM_TO_SQFT = 10.7639
MIN_SALES = 5


def sale_class(u: dict) -> str:
    """Land Registry property class for a unit type."""
    if u["family"] != "house":
        return "Flat / maisonette"
    if u["beds"] >= 4 or u.get("attach") == "detached":
        return "Detached"
    if u.get("attach") in ("semi", "semi-detached"):
        return "Semi-detached"
    if u["beds"] >= 3 and u.get("attach") not in ("terrace", "terraced"):
        return "Semi-detached"
    return "Terraced"


def cost_class(u: dict, strategy: str, floors: int) -> str:
    if u["family"] == "house":
        return "houses"
    if strategy == "btr" or u["family"] in ("room", "cluster"):
        return "btr"
    return "flats"


def evidence(site: dict) -> dict:
    lr = site.get("land_registry") or {}
    sm = lr.get("summary") or {}
    rows = {r["type"]: r for r in sm.get("by_type", [])}
    return {"rows": rows, "overall_psf": sm.get("median_psf"), "flats_psf": sm.get("median_psf_flats"), "n": sm.get("n", 0), "sector": lr.get("sector", ""), "months": lr.get("months"),
            "newbuild_price": sm.get("new_build_median_price"), "hpi": ((site.get("data_pack") or {}).get("hpi") or {})}


def price_units(typ: dict, calc: dict, site: dict, premium_pct: float = 0.0) -> list[dict]:
    ev = evidence(site)
    out = []
    for u in typ["units"]:
        if not u["count"]:
            continue
        p = calc["per"][u["id"]]
        cls = sale_class(u)
        row = ev["rows"].get(cls)
        psf, basis = None, ""
        if row and row.get("median_psf") and row.get("psf_n", 0) >= MIN_SALES:
            psf = row["median_psf"]
            basis = f"{row['psf_n']} {cls.lower()} sales with floor areas, median £{psf:,.0f} per sq ft"
        elif row and row.get("count", 0) >= MIN_SALES and row.get("median_price"):
            basis = f"{row['count']} {cls.lower()} sales, median price £{row['median_price']:,.0f} (no floor areas matched)"
            val = row["median_price"]
            out.append({"id": u["id"], "name": u["name"], "class": cls, "sale_psf": round(val / p["gia_sqft"]) if p["gia_sqft"] else None, "sale_value": round(val * (1 + premium_pct / 100), -2), "basis": basis, "grade": "medium"})
            continue
        elif cls.startswith("Flat") and ev["flats_psf"]:
            psf, basis = ev["flats_psf"], "median £ per sq ft of flats sold nearby"
        elif ev["overall_psf"]:
            psf, basis = ev["overall_psf"], "median £ per sq ft of all sales nearby (few sales of this type)"
        if psf is None:
            hp = ev["hpi"].get({"Detached": "detached", "Semi-detached": "semi", "Terraced": "terraced", "Flat / maisonette": "flat"}[cls])
            if hp:
                out.append({"id": u["id"], "name": u["name"], "class": cls, "sale_psf": round(hp / p["gia_sqft"]) if p["gia_sqft"] else None, "sale_value": round(hp * (1 + premium_pct / 100), -2),
                            "basis": f"UK House Price Index average for {cls.lower()} in the council area", "grade": "low"})
            else:
                out.append({"id": u["id"], "name": u["name"], "class": cls, "sale_psf": None, "sale_value": None, "basis": "No sold price evidence on file. Run Market > Land Registry sales for this site.", "grade": "none"})
            continue
        grade = "high" if "with floor areas" in basis else "medium" if "median £ per sq ft of flats" in basis else "low"
        out.append({"id": u["id"], "name": u["name"], "class": cls, "sale_psf": round(psf * (1 + premium_pct / 100)), "sale_value": round(psf * (1 + premium_pct / 100) * p["gia_sqft"], -2), "basis": basis, "grade": grade})
    return out


def build_rates(typ: dict, calc: dict, site: dict, strategy: str, region: str | None, assumed_psf: float) -> list[dict]:
    rows = {r["key"]: r for r in costs.table(region)}
    key = costs.pick(site, strategy, region)["key"]
    index = assumed_psf / rows[key]["mid"] if rows.get(key, {}).get("mid") else 1.0
    floors = calc["alloc"]["floors"] if calc.get("alloc") else 1
    out = []
    for u in typ["units"]:
        if not u["count"]:
            continue
        c = cost_class(u, strategy, floors)
        bench = rows[c]["mid"]
        if c == "flats" and floors > 6:
            bench = rows["flats"]["high"]
        if u["family"] == "cluster":
            bench *= 1.05
        rate = round(bench * index)
        out.append({"id": u["id"], "name": u["name"], "class": rows[c]["label"] + (" (over six storeys)" if c == "flats" and floors > 6 else ""), "build_psf": rate, "benchmark": bench, "index": round(index, 2)})
    return out


def apply(typ: dict, prices: list[dict], rates: list[dict], what: str = "both", overwrite: bool = False) -> int:
    n = 0
    pm = {p["id"]: p for p in prices}
    rm = {r["id"]: r for r in rates}
    for u in typ["units"]:
        if what in ("both", "price") and pm.get(u["id"], {}).get("sale_value") and (overwrite or not u.get("sale_value") or u.get("auto_price")):
            u["sale_value"], u["auto_price"] = pm[u["id"]]["sale_value"], True
            n += 1
        if what in ("both", "build") and rm.get(u["id"]) and (overwrite or not u.get("build_psf") or u.get("auto_build")):
            u["build_psf"], u["auto_build"] = rm[u["id"]]["build_psf"], True
            n += 1
    return n


def weighted_build_psf(mix: list[dict], default: float) -> float:
    """Average £ per sq ft across unit types, weighted by floor area. Falls back to the default for types with no rate."""
    tot = w = 0.0
    for m in mix:
        area = float(m.get("nsa_sqft") or 0) * m.get("count", 0)
        if area:
            tot += area
            w += area * float(m.get("build_psf") or default)
    return w / tot if tot else default
