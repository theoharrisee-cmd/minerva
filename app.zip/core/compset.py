"""Comparable evidence engine.

Takes the sold prices pulled from HM Land Registry, places them on a map, and adjusts each sale to the subject home:
for time (house price growth), for new build against second-hand, for distance from the site and, where a floor area is
known, for size (by using the sale's price per sq ft). Every adjustment is a visible, editable factor, and every sale
can be switched off. The adjusted value per home type can then be written into the appraisal through the homes schedule.

Adjustment factors are desk assumptions until you replace them with an agent's or valuer's view; the defaults are shown
against each one. Coordinates come from postcodes.io and are for the postcode, not the property.
"""
from __future__ import annotations

import hashlib
import math
import statistics
from concurrent.futures import ThreadPoolExecutor
from datetime import date

from . import datasources as ds
from . import geo as geo_mod
from .marketmix import sale_class

MIN_COMPS = 3
DEFAULT_ADJ = {"newbuild_premium": 0.10, "distance_pct_km": 0.0, "max_km": 3.0, "max_months": 36, "growth_pa": None}
LABELS = {"newbuild_premium": "New build premium on second-hand sales (%)", "distance_pct_km": "Value lost per km from the site (%)",
          "max_km": "Furthest sale to use (km)", "max_months": "Oldest sale to use (months)", "growth_pa": "Price growth to bring old sales to today (% a year)"}


def sale_id(x: dict) -> str:
    return hashlib.sha1(f"{x.get('saon')}|{x.get('paon')}|{x.get('street')}|{x.get('postcode')}|{x.get('date')}|{x.get('price')}".encode()).hexdigest()[:10]


def geocode(postcodes: list[str], limit: int = 80) -> dict:
    """postcode -> (lat, lon), via postcodes.io. Failures are skipped."""
    from urllib.parse import quote

    def one(pc):
        try:
            js = ds._http("https://api.postcodes.io/postcodes/" + quote(pc), ttl=90 * 86400)
            r = js.get("result") or {}
            if r.get("latitude") is not None and r.get("longitude") is not None:
                return pc, (float(r["latitude"]), float(r["longitude"]))
        except Exception:
            pass
        return pc, None
    pcs = sorted({p for p in postcodes if p})[:limit]
    with ThreadPoolExecutor(max_workers=8) as ex:
        return {pc: ll for pc, ll in ex.map(one, pcs) if ll}


def km(a_lat, a_lon, b_lat, b_lon) -> float:
    x, y = geo_mod.to_xy(a_lat, a_lon, b_lat, b_lon)
    return math.hypot(x, y) / 1000.0


def ingest(site: dict, res: dict, geocoder=None) -> dict:
    """Store the pulled sales on the site with ids, coordinates and distance. Keeps the user's adjustments and exclusions."""
    old = site.get("comp_set") or {}
    sales = []
    for x in (res.get("sales") or [])[:300]:
        sales.append({**x, "id": sale_id(x)})
    pts = (geocoder or geocode)([x["postcode"] for x in sales]) if sales else {}
    lat, lon = site.get("lat"), site.get("lon")
    for x in sales:
        ll = pts.get(x["postcode"])
        if ll:
            x["lat"], x["lon"] = ll
            if lat is not None and lon is not None:
                x["dist_km"] = round(km(lat, lon, ll[0], ll[1]), 2)
    site["comp_set"] = {"sales": sales, "sector": res.get("sector"), "months": res.get("months"), "fetched": res.get("fetched") or date.today().isoformat(),
                        "adj": old.get("adj") or {}, "off": old.get("off") or [], "geocoded": len(pts)}
    return site["comp_set"]


def factors(site: dict) -> dict:
    """The adjustment factors in force, with the growth default taken from the local house price index."""
    cs = site.get("comp_set") or {}
    a = {**DEFAULT_ADJ, **{k: v for k, v in (cs.get("adj") or {}).items() if v is not None}}
    src = {k: ("set" if k in (cs.get("adj") or {}) and (cs.get("adj") or {})[k] is not None else "default") for k in DEFAULT_ADJ}
    if a["growth_pa"] is None:
        h = ((site.get("data_pack") or {}).get("hpi") or {}).get("annual")
        a["growth_pa"] = float(h) / 100 if h is not None else 0.0
        src["growth_pa"] = "house price index" if h is not None else "default"
    return {"values": a, "source": src, "labels": LABELS}


def clean_adj(d: dict | None) -> dict:
    out = {}
    d = d or {}
    for k, lo, hi in (("newbuild_premium", -0.3, 0.5), ("distance_pct_km", 0, 0.2), ("growth_pa", -0.3, 0.3)):
        if d.get(k) not in (None, ""):
            v = float(d[k])
            v = v / 100 if abs(v) > 1 else v
            out[k] = max(lo, min(hi, v))
    for k, lo, hi in (("max_km", 0.2, 50), ("max_months", 3, 120)):
        if d.get(k) not in (None, ""):
            out[k] = max(lo, min(hi, float(d[k])))
    return out


def _months_since(iso: str, today: date) -> float:
    try:
        y, m, d = (int(x) for x in iso[:10].split("-"))
        return max(0.0, ((today - date(y, m, d)).days) / 30.4)
    except Exception:
        return 0.0


def adjust_one(x: dict, cls: str, sqft: float, f: dict, today: date) -> dict | None:
    """One sale brought to the subject: the running value and each step, or None when the sale is out of range."""
    v = f["values"]
    age = _months_since(x["date"], today)
    if age > v["max_months"]:
        return None
    if x.get("dist_km") is not None and x["dist_km"] > v["max_km"]:
        return None
    steps = []
    if x.get("psf") and sqft:
        val = x["psf"] * sqft
        steps.append(("Sold at £%d per sq ft, applied to %s sq ft" % (x["psf"], f"{sqft:,.0f}"), val - x["price"]))
    else:
        val = x["price"]
    g = (1 + v["growth_pa"]) ** (age / 12) - 1
    if g:
        steps.append((f"Time: {age:.0f} months at {v['growth_pa'] * 100:.1f}% a year", val * g))
        val *= 1 + g
    if not x.get("new_build") and v["newbuild_premium"]:
        steps.append((f"New build premium {v['newbuild_premium'] * 100:.0f}%", val * v["newbuild_premium"]))
        val *= 1 + v["newbuild_premium"]
    if x.get("dist_km") and v["distance_pct_km"]:
        d = -min(0.5, v["distance_pct_km"] * x["dist_km"])
        steps.append((f"Distance {x['dist_km']:.1f} km", val * d))
        val *= 1 + d
    w = 1 / (1 + (x.get("dist_km") or 1.0)) * 1 / (1 + age / 12)
    return {"id": x["id"], "adjusted": val, "steps": [{"label": l, "value": d} for l, d in steps], "weight": w, "age": age}


def _wmedian(vals: list[tuple[float, float]]) -> float:
    vals = sorted(vals)
    tot = sum(w for _, w in vals)
    acc = 0.0
    for v, w in vals:
        acc += w
        if acc >= tot / 2:
            return v
    return vals[-1][0]


def value_for(site: dict, cls: str, sqft: float, today: date | None = None) -> dict:
    """Adjusted value of a home of this class and size from the comparables that are switched on."""
    today = today or date.today()
    cs = site.get("comp_set") or {}
    f = factors(site)
    off = set(cs.get("off") or [])
    rows, used = [], []
    for x in cs.get("sales") or []:
        if x.get("type") != cls:
            continue
        adj = adjust_one(x, cls, sqft, f, today)
        if adj is None:
            rows.append({**_slim(x), "status": "out of range", "included": False})
            continue
        inc = x["id"] not in off
        rows.append({**_slim(x), **adj, "status": "used" if inc else "switched off", "included": inc})
        if inc:
            used.append((adj["adjusted"], adj["weight"]))
    out = {"class": cls, "n": len(used), "sqft": sqft, "rows": rows}
    if len(used) >= MIN_COMPS:
        vs = sorted(v for v, _ in used)
        out.update(value=_wmedian(used), low=vs[len(vs) // 4], high=vs[(3 * len(vs)) // 4] if len(vs) > 3 else vs[-1],
                   psf=_wmedian(used) / sqft if sqft else None)
        spread = (out["high"] - out["low"]) / out["value"] if out["value"] else 0
        out["confidence"] = "high" if len(used) >= 8 and spread < 0.2 else "medium" if len(used) >= 5 else "low"
    return out


def _slim(x: dict) -> dict:
    return {k: x.get(k) for k in ("id", "paon", "saon", "street", "postcode", "price", "date", "type", "new_build", "psf", "sqft", "lat", "lon", "dist_km", "tenure")}


def state(site: dict, typ: dict | None, calc: dict | None, today: date | None = None) -> dict:
    """Everything the comparables panel shows: map points, factors and a value per home type in the schedule."""
    cs = site.get("comp_set")
    if not cs or not cs.get("sales"):
        return {"has": False}
    f = factors(site)
    subjects = []
    if typ and calc:
        seen = {}
        for u in typ["units"]:
            if not u.get("count"):
                continue
            cls = sale_class(u)
            sq = calc["per"][u["id"]]["gia_sqft"]
            seen.setdefault(cls, []).append((u, sq))
        for cls, lst in seen.items():
            sq = sum(s for _, s in lst) / len(lst)
            r = value_for(site, cls, sq, today)
            subjects.append({**{k: v for k, v in r.items() if k != "rows"}, "units": [u["name"] for u, _ in lst], "rows": r["rows"]})
    else:
        for cls in sorted({x["type"] for x in cs["sales"] if x["type"] != "Other"}):
            sq = 0
            r = value_for(site, cls, sq, today)
            subjects.append({**{k: v for k, v in r.items() if k != "rows"}, "units": [], "rows": r["rows"]})
    return {"has": True, "sector": cs.get("sector"), "fetched": cs.get("fetched"), "n": len(cs["sales"]), "geocoded": cs.get("geocoded", 0), "factors": f,
            "subjects": subjects, "off": cs.get("off") or [], "site": {"lat": site.get("lat"), "lon": site.get("lon")},
            "note": "Adjustments are desk assumptions. Coordinates are for the postcode, not the property."}


def override_prices(prices: list[dict], site: dict, typ: dict, calc: dict) -> int:
    """Replace the median-based value for a home type with the adjusted comparable value when there is enough evidence."""
    if not (site.get("comp_set") or {}).get("sales"):
        return 0
    n = 0
    per = {u["id"]: u for u in typ["units"]}
    for p in prices:
        u = per.get(p["id"])
        if not u:
            continue
        sq = calc["per"][p["id"]]["gia_sqft"]
        r = value_for(site, sale_class(u), sq)
        if r.get("value"):
            p.update(sale_value=round(r["value"], -2), sale_psf=round(r["psf"]) if r.get("psf") else None, grade="high" if r["confidence"] != "low" else "medium",
                     basis=f"{r['n']} adjusted comparables (range £{r['low']:,.0f} to £{r['high']:,.0f}), set on the Market tab")
            n += 1
    return n
