"""Policy checks on a typology, and the scheme facts quoted in planning replies.

Standards used:
* Nationally Described Space Standard (MHCLG, 2015): minimum GIA, bedroom areas and widths, built-in storage.
* Building Regulations Approved Document M: M4(1), M4(2) and M4(3) categories.
* London Plan pack: 90% M4(2) and 10% M4(3), private outdoor space of 5 m2 plus 1 m2 per additional person
  with a minimum depth of 1.5 m, cycle parking by dwelling size, affordable housing threshold of 35%.
* England pack: local plans set most numeric targets, so the values here are typical figures and are editable.
A check reports against the pack in force for the site. Anything a check cannot test without a site layout is
listed separately."""
from __future__ import annotations

import math

from . import floorplan as fp
from . import typology as T

PACKS = {
    "england": {
        "label": "England, national policy and typical local plan values",
        "m42_share": 0.40, "m43_share": 0.0, "outdoor_flat_base": 5.0, "outdoor_per_extra_person": 1.0, "outdoor_min_depth": 1.5,
        "garden_depth": 10.0, "garden_area": {1: 40, 2: 50, 3: 70, 4: 90, 5: 100},
        "parking": {"basis": "minimum", "per_bed": {0: 1.0, 1: 1.0, 2: 1.5, 3: 2.0, 4: 2.5, 5: 3.0}},
        "cycle": {"studio": 1.0, "1b": 1.0, "2b": 2.0}, "affordable_pct": 0.30, "tenure": "25% of affordable homes as First Homes, with the balance split between social rent and shared ownership as the local plan sets",
        "space_standard": "Nationally Described Space Standard", "coliving_min": 18.0, "coliving_communal_per_person": 4.0,
    },
    "london": {
        "label": "London Plan",
        "m42_share": 0.90, "m43_share": 0.10, "outdoor_flat_base": 5.0, "outdoor_per_extra_person": 1.0, "outdoor_min_depth": 1.5,
        "garden_depth": 10.0, "garden_area": {1: 40, 2: 50, 3: 70, 4: 90, 5: 100},
        "parking": {"basis": "maximum", "per_unit": 0.75, "per_bed": {0: 0.75, 1: 0.75, 2: 0.75, 3: 0.75, 4: 0.75, 5: 0.75}},
        "cycle": {"studio": 1.0, "1b": 1.5, "2b": 2.0}, "affordable_pct": 0.35, "tenure": "30% low-cost rent, 30% intermediate and 40% determined by the borough",
        "space_standard": "Nationally Described Space Standard as applied by the London Plan", "coliving_min": 18.0, "coliving_communal_per_person": 4.0,
    },
}

PACK_FIELDS = [("m42_share", "M4(2) share of homes", "%"), ("m43_share", "M4(3) share of homes", "%"), ("outdoor_flat_base", "Flat outdoor space, one or two people (m2)", ""),
               ("garden_depth", "Minimum garden depth (m)", ""), ("affordable_pct", "Affordable housing target", "%"), ("parking_per_unit", "Parking per home", "")]


def pack_for(typ: dict) -> dict:
    p = dict(PACKS[typ["policy"]["pack"]])
    ov = typ["policy"].get("overrides") or {}
    for k in ("m42_share", "m43_share", "affordable_pct", "outdoor_flat_base", "garden_depth"):
        if k in ov:
            try:
                v = float(ov[k])
                p[k] = v / 100 if k.endswith("share") or k == "affordable_pct" else v
            except (TypeError, ValueError):
                pass
    if "parking_per_unit" in ov:
        try:
            v = float(ov["parking_per_unit"])
            par = dict(p["parking"]); par["per_bed"] = {b: v for b in range(0, 7)}; par["per_unit"] = v; p["parking"] = par
        except (TypeError, ValueError):
            pass
    return p


def _c(area, cid, title, status, detail, **kw):
    d = {"id": cid, "area": area, "title": title, "status": status, "detail": detail}
    d.update(kw)
    return d


def _bedroom_issues(u: dict, g: dict) -> list[str]:
    fl = {r["id"]: r for f in g["floors"] for r in f["rooms"]}
    beds = [(r, fl.get(r["id"])) for r in u["rooms"] if r["kind"] == "bedroom" and fl.get(r["id"])]
    beds.sort(key=lambda x: -x[1]["area"])
    doubles = max(0, min(len(beds), u["persons"] - u["beds"])) if u["beds"] else 0
    issues = []
    for i, (r, fr) in enumerate(beds):
        w = min(fr["w"], fr["d"])
        if i < doubles:
            need_w = 2.75 if i == 0 else 2.55
            if fr["area"] < 11.5:
                issues.append(f"{r['name']} is {fr['area']:.1f} m2, double bedrooms need 11.5 m2")
            if w < need_w - 0.005:
                issues.append(f"{r['name']} is {w:.2f} m wide, the {'main double' if i == 0 else 'other double'} needs {need_w} m")
        else:
            if fr["area"] < 7.5:
                issues.append(f"{r['name']} is {fr['area']:.1f} m2, single bedrooms need 7.5 m2")
            if w < 2.15 - 0.005:
                issues.append(f"{r['name']} is {w:.2f} m wide, single bedrooms need 2.15 m")
    return issues


def check(typ: dict, calc: dict, site: dict | None = None, assumptions: dict | None = None) -> dict:
    site = site or {}
    a = assumptions or {}
    pk = pack_for(typ)
    units = [u for u in typ["units"] if u["count"] > 0]
    n = sum(u["count"] for u in units)
    out: list[dict] = []
    if not n:
        return {"checks": [], "counts": {"pass": 0, "warn": 0, "fail": 0, "info": 0}, "pack": pk["label"], "not_tested": NOT_TESTED}
    # --- space
    fails, warns, oks = [], [], []
    for u in units:
        if u["family"] not in ("house", "flat"):
            continue
        g = calc["geoms"][u["id"]]
        gia = calc["per"][u["id"]]["gia"]
        mn = T.ndss_min(u["beds"], u["persons"], u["storeys"])
        if mn is None:
            continue
        if gia < mn - 0.05:
            fails.append((u, f"{u['name']}: {gia:.1f} m2 against {mn:.0f} m2 required ({mn - gia:.1f} m2 short), affects {u['count']} homes"))
        elif gia < mn * 1.02:
            warns.append((u, f"{u['name']}: {gia:.1f} m2 against {mn:.0f} m2, within 2% of the minimum"))
        else:
            oks.append(u)
    total_std = sum(1 for u in units if u["family"] in ("house", "flat"))
    if total_std:
        if fails:
            out.append(_c("Space", "ndss_gia", "Gross internal area", "fail", "; ".join(d for _u, d in fails), units=[u["name"] for u, _d in fails], source="NDSS Table 1"))
        elif warns:
            out.append(_c("Space", "ndss_gia", "Gross internal area", "warn", "; ".join(d for _u, d in warns), source="NDSS Table 1"))
        else:
            out.append(_c("Space", "ndss_gia", "Gross internal area", "pass", f"Every house and flat type meets the minimum GIA for its bedspaces and storeys ({sum(u['count'] for u in oks)} homes).", source="NDSS Table 1"))
    bed_issues, stor_issues, ceil_issues = [], [], []
    for u in units:
        if u["family"] not in ("house", "flat"):
            continue
        g = calc["geoms"][u["id"]]
        for s in _bedroom_issues(u, g):
            bed_issues.append(f"{u['name']}: {s}")
        stor = sum(r["area"] for f in g["floors"] for r in f["rooms"] if r["kind"] == "store")
        need = T.storage_min(u["beds"])
        if stor < need - 0.05:
            stor_issues.append(f"{u['name']}: {stor:.1f} m2 of built-in storage against {need:.1f} m2")
        if (u.get("ceiling_m") or 2.5) < 2.5:
            ceil_issues.append(f"{u['name']}: ceiling height {u['ceiling_m']} m")
    if any(u["family"] in ("house", "flat") for u in units):
        out.append(_c("Space", "ndss_bedrooms", "Bedroom sizes and widths", "fail" if bed_issues else "pass",
                      "; ".join(bed_issues[:6]) + ("." if bed_issues else "") if bed_issues else "Bedrooms meet the area and width minimums.", source="NDSS"))
        out.append(_c("Space", "ndss_storage", "Built-in storage", "fail" if stor_issues else "pass", "; ".join(stor_issues[:5]) if stor_issues else "Built-in storage meets the minimum for each home type.", source="NDSS Table 1"))
        out.append(_c("Space", "ndss_ceiling", "Ceiling height", "fail" if ceil_issues else "pass", "; ".join(ceil_issues) if ceil_issues else "Floor to ceiling height is 2.5 m or more.", source="NDSS"))
    rooms_units = [u for u in units if u["family"] in ("room", "cluster")]
    for u in rooms_units:
        gia = calc["per"][u["id"]]["gia"]
        per_person = gia / max(1, u["persons"])
        if u["code"].startswith("CARE") or "care" in u["name"].lower():
            out.append(_c("Space", "care_room_" + u["id"], f"{u['name']}", "info", f"{gia:.1f} m2 per bedroom including en-suite. There is no national statutory minimum. Check the operator's brief and the provider's registration standards.", source="Operator brief"))
        elif u["family"] == "cluster":
            out.append(_c("Space", "cluster_" + u["id"], f"{u['name']}", "info", f"{gia:.1f} m2 per cluster, {per_person:.1f} m2 per student before shared amenity space.", source="Operator brief"))
        else:
            ok = gia >= pk["coliving_min"]
            out.append(_c("Space", "coliving_" + u["id"], f"{u['name']}: private room", "pass" if ok else "fail",
                          f"{gia:.1f} m2 including en-suite against {pk['coliving_min']:.0f} m2 for a single-occupancy shared living room (London Plan policy H16 guidance).", source="London Plan H16"))
    for u in rooms_units:
        if u["family"] == "room" and "co-living" in u["name"].lower():
            sh = u.get("shared_sqm") or typ.get("shared_sqm") or 0
            need = pk["coliving_communal_per_person"] * u["persons"]
            out.append(_c("Space", "coliving_comm", "Shared living communal space", "pass" if sh >= need else "fail", f"{sh:.1f} m2 of communal space per resident against {need:.1f} m2 (4 m2 per resident guidance).", source="London Plan H16"))
            break
    stretched = [u["name"] for u in units if calc["per"][u["id"]]["stretch"] > 0.08]
    if stretched:
        out.append(_c("Space", "plan_balance", "Floors balance", "warn", "Room sizes differ from the footprint on some floors, so the plans stretch rooms to close them: " + ", ".join(stretched) + ". Adjust the room sizes so each floor adds up to the same area.", source="Typology"))
    # --- accessibility
    m42 = sum(u["count"] for u in units if u["m4"] == "M4(2)")
    m43 = sum(u["count"] for u in units if u["m4"] == "M4(3)")
    unset = sum(u["count"] for u in units if u["m4"] == "")
    s42, s43 = (m42 + m43) / n, m43 / n
    need42, need43 = pk["m42_share"], pk["m43_share"]
    ok42, ok43 = s42 + 1e-9 >= need42, s43 + 1e-9 >= need43
    txt = f"{m42 + m43} of {n} homes ({s42:.0%}) are M4(2) or M4(3) and {m43} ({s43:.0%}) are M4(3). Target: {need42:.0%} M4(2) or M4(3)" + (f", of which {need43:.0%} M4(3)." if need43 else ".")
    if unset:
        txt = f"{unset} homes have no accessibility category yet. " + txt
        out.append(_c("Accessibility", "m4", "Accessible and adaptable homes", "info" if ok42 and ok43 or unset else "fail", txt, source="Approved Document M, " + pk["label"]))
    else:
        out.append(_c("Accessibility", "m4", "Accessible and adaptable homes", "pass" if ok42 and ok43 else "fail", txt, source="Approved Document M, " + pk["label"]))
    if calc["flats"] and typ["block"]["floors"] > 1:
        out.append(_c("Accessibility", "lift", "Step-free access above ground", "pass", f"Blocks of {typ['block']['floors']} storeys are drawn with a core that carries a lift, which M4(2) requires above the entrance floor.", source="Approved Document M"))
    # --- outdoor space
    bad = []
    for u in units:
        g = calc["geoms"][u["id"]]
        if u["family"] == "flat":
            need = pk["outdoor_flat_base"] + pk["outdoor_per_extra_person"] * max(0, u["persons"] - 2)
            have = sum(e["area"] for e in g["ext"] if e["kind"] == "balcony")
            depth = min([min(e["w"], e["d"]) for e in g["ext"] if e["kind"] == "balcony"] or [0])
            if have < need - 0.05:
                bad.append(f"{u['name']}: {have:.1f} m2 of private outdoor space against {need:.1f} m2")
            elif have and depth < pk["outdoor_min_depth"] - 0.005:
                bad.append(f"{u['name']}: balcony {depth:.1f} m deep against {pk['outdoor_min_depth']} m")
        elif u["family"] == "house":
            gard = [e for e in g["ext"] if e["kind"] == "garden"]
            need = pk["garden_area"].get(min(u["beds"], 5), 100)
            have = sum(e["area"] for e in gard)
            depth = max([e["d"] for e in gard] or [0])
            if have < need - 0.05:
                bad.append(f"{u['name']}: garden {have:.0f} m2 against {need} m2")
            elif depth < pk["garden_depth"] - 0.05:
                bad.append(f"{u['name']}: garden {depth:.1f} m deep against {pk['garden_depth']:.0f} m")
    if any(u["family"] in ("flat", "house") for u in units):
        out.append(_c("Outdoor space", "outdoor", "Private outdoor space", "fail" if bad else "pass", "; ".join(bad[:6]) if bad else "Each flat has a balcony and each house a garden that meets the standard for its size.", source=pk["label"]))
    # --- aspect
    apts = [u for u in units if T.apartment(u)]
    if apts:
        tot = sum(u["count"] for u in apts)
        single = sum(u["count"] for u in apts if u["aspect"] == "single")
        big_single = [u["name"] for u in apts if u["aspect"] == "single" and u["beds"] >= 3]
        status = "warn" if big_single else "info"
        out.append(_c("Design", "aspect", "Dual aspect", status, f"{tot - single} of {tot} apartments ({(tot - single) / tot:.0%}) are dual aspect." + (f" Single-aspect homes with three or more bedrooms: {', '.join(big_single)}. London Plan D6 and most design guides resist these." if big_single else " Single aspect is acceptable where the design justifies it and the aspect is not north-facing."), source="London Plan D6"))
    # --- mix and tenure
    mixb = T.mix_by_beds(typ)
    mix_text = ", ".join(f"{v} {k}" for k, v in mixb.items() if v)
    aff = a.get("affordable_pct")
    tgt = pk["affordable_pct"]
    if aff is not None:
        st = "pass" if aff + 1e-9 >= tgt else "warn"
        out.append(_c("Mix and tenure", "affordable", "Affordable housing", st,
                      f"The appraisal assumes {aff:.0%} affordable housing against a policy expectation of {tgt:.0%}. " + ("" if st == "pass" else "A viability case is needed to support the lower offer. ") + f"Tenure: {pk['tenure']}.", source=pk["label"]))
    out.append(_c("Mix and tenure", "mix", "Housing mix", "info", f"{mix_text}. Compare with the mix in the local housing need assessment and the local plan policy.", source="Local plan"))
    # --- parking and cycling
    par = pk["parking"]
    req = sum(u["count"] * par["per_bed"].get(min(u["beds"], 5), par["per_bed"][5]) for u in units)
    prov = typ["site"].get("parking")
    if par["basis"] == "maximum":
        if prov is None:
            out.append(_c("Parking and cycling", "parking", "Car parking", "info", f"Up to {req:.0f} spaces ({req / n:.2f} per home) depending on public transport accessibility. Enter the spaces provided to test it.", source=pk["label"]))
        else:
            out.append(_c("Parking and cycling", "parking", "Car parking", "pass" if prov <= req + 0.01 else "warn", f"{prov:.0f} spaces provided ({prov / n:.2f} per home) against a ceiling of {req:.0f} ({req / n:.2f} per home). Ceilings fall where public transport is better.", source=pk["label"]))
    else:
        if prov is None:
            out.append(_c("Parking and cycling", "parking", "Car parking", "info", f"Typical local standard needs about {req:.0f} spaces ({req / n:.2f} per home). Enter the spaces provided to test it.", source="Local parking standard"))
        else:
            out.append(_c("Parking and cycling", "parking", "Car parking", "pass" if prov >= req - 0.01 else "warn", f"{prov:.0f} spaces provided ({prov / n:.2f} per home) against about {req:.0f} at the typical standard ({req / n:.2f} per home).", source="Local parking standard"))
    cyc = 0.0
    for u in apts:
        c = pk["cycle"]["studio"] if u["beds"] == 0 or u["persons"] <= 1 else pk["cycle"]["1b"] if u["beds"] == 1 else pk["cycle"]["2b"]
        cyc += u["count"] * c
    if apts:
        cyc_short = 2 if 5 <= calc["flats"] <= 40 else (calc["flats"] // 40 if calc["flats"] > 40 else 0)
        pc = typ["site"].get("cycle")
        need = math.ceil(cyc + cyc_short)
        if pc is None:
            out.append(_c("Parking and cycling", "cycle", "Cycle parking", "info", f"About {need} spaces for the flats ({math.ceil(cyc)} long stay and {cyc_short} short stay). Enter the spaces provided to test it.", source="London Plan T5"))
        else:
            out.append(_c("Parking and cycling", "cycle", "Cycle parking", "pass" if pc >= need else "fail", f"{pc:.0f} spaces provided against {need}.", source="London Plan T5"))
    out.append(_c("Parking and cycling", "ev", "Electric vehicle charging", "info", "Approved Document S requires a charge point for every new dwelling with associated parking. London Plan T6.1 asks for 20% active and 80% passive provision on other developments.", source="Approved Document S"))
    # --- density
    if calc["density"]:
        d = calc["density"]
        band = "rural or edge of settlement" if d < 30 else "suburban" if d < 50 else "urban" if d < 120 else "central urban"
        out.append(_c("Density", "density", "Density", "info", f"{n} homes on {site.get('site_ha')} ha is {d:.0f} dwellings per hectare, in the range typical of {band} schemes. Set it against the policy for the location.", source="Local plan"))
    else:
        out.append(_c("Density", "density", "Density", "info", "Add the site area in hectares to calculate dwellings per hectare.", source="Local plan"))
    # --- safety
    if calc["flats"]:
        F = typ["block"]["floors"]
        height = (F - 1) * 3.0
        if F >= 7 or height >= 18:
            out.append(_c("Safety", "hrb", "Higher-risk building", "warn", f"A block of {F} storeys has its top storey about {height:.0f} m above ground. At 18 m or 7 storeys with two or more homes it is a higher-risk building under the Building Safety Act, so gateway 2 approval applies, and a second staircase applies to residential blocks with a storey 18 m or more above ground from 30 September 2026 unless the transitional rules protect the scheme.", source="Building Safety Act, Approved Document B"))
        else:
            out.append(_c("Safety", "hrb", "Higher-risk building", "pass", f"A block of {F} storeys is below the 18 m and 7 storey thresholds for a higher-risk building.", source="Building Safety Act"))
    counts = {k: sum(1 for c in out if c["status"] == k) for k in ("pass", "warn", "fail", "info")}
    return {"checks": out, "counts": counts, "pack": pk["label"], "not_tested": NOT_TESTED, "requirements": {"parking": req, "cycle": math.ceil(cyc) if apts else 0}}


NOT_TESTED = ["Separation between facing windows (commonly 21 m) and to blank gables (commonly 12 m)", "Daylight and sunlight to homes and neighbours (BRE guidance)",
              "Overlooking and privacy between plots", "Refuse collection, servicing and fire service access", "Biodiversity net gain of at least 10%", "Sustainable drainage and flood routing",
              "Play space (10 m2 per child under the London Plan)", "Noise and air quality effects on facades"]


# ------------------------------------------------------------------ facts for replies and reports

def facts(typ: dict, calc: dict, result: dict, site: dict | None = None) -> dict:
    site = site or {}
    units = [u for u in typ["units"] if u["count"] > 0]
    n = calc["units"]
    if not n:
        return {}
    by = {c["id"]: c for c in result["checks"]}
    houses, flats = calc["houses"], calc["flats"]
    mix = ", ".join(f"{u['count']} x {u['name'].lower()}" for u in units)
    m43 = sum(u["count"] for u in units if u["m4"] == "M4(3)")
    m42 = sum(u["count"] for u in units if u["m4"] == "M4(2)")
    fl = {c["id"]: c for c in result["checks"]}
    space_fail = fl.get("ndss_gia", {}).get("status") == "fail"
    avg = calc["net_sqm"] / n if n else 0
    F = typ["block"]["floors"]
    parts = []
    if houses:
        parts.append(f"{houses} house{'s' if houses != 1 else ''}")
    if flats:
        parts.append(f"{flats} flat{'s' if flats != 1 else ''}" if units and any(u["family"] == "flat" for u in units) else f"{flats} rooms or clusters")
    par = typ["site"].get("parking")
    d = {
        "units": n, "houses": houses, "flats": flats, "mix": mix, "mix_by_beds": T.mix_by_beds(typ), "avg_gia": round(avg, 1),
        "units_phrase": f"{n} homes ({' and '.join(parts)})" if parts else f"{n} homes",
        "ndss_all_pass": not space_fail and fl.get("ndss_bedrooms", {}).get("status") != "fail",
        "ndss_note": fl.get("ndss_gia", {}).get("detail", ""), "m42": m42, "m43": m43, "m42_share": round((m42 + m43) / n, 3), "m43_share": round(m43 / n, 3),
        "parking": par, "parking_ratio": round(par / n, 2) if par else None, "density": calc["density"], "storeys": F if flats else None,
        "efficiency": calc["efficiency"], "gross_sqm": calc["gross_sqm"], "checks": [{"id": c["id"], "status": c["status"], "title": c["title"], "detail": c["detail"], "area": c["area"]} for c in result["checks"] if c["status"] in ("fail", "warn")],
    }
    d["space_sentence"] = ("Every home type meets the Nationally Described Space Standard for gross internal area, bedroom size and storage, and the average home is " + f"{avg:.0f} m2."
                           if d["ndss_all_pass"] else "[space standard position]")
    acc = by.get("m4", {})
    lift = ", with a lift to every floor of the flatted blocks" if flats and typ["block"]["floors"] > 1 else ""
    if acc.get("status") == "pass":
        d["access_sentence"] = f"{m42 + m43} of {n} homes ({(m42 + m43) / n:.0%}) are designed to Building Regulations M4(2) or M4(3), and {m43} ({m43 / n:.0%}) to M4(3){lift}."
    else:
        d["access_sentence"] = "[accessible homes position]"
    out = fl.get("outdoor", {})
    d["outdoor_sentence"] = ("Every flat has a private balcony or terrace and every house a private garden that meets the size standard." if out.get("status") == "pass" else "[outdoor space position]")
    d["parking_sentence"] = f"{par:.0f} parking spaces ({par / n:.2f} per home)" if par else "[parking ratio]"
    d["density_sentence"] = f"a density of {calc['density']:.0f} dwellings per hectare" if calc["density"] else "[density]"
    d["height_sentence"] = f"blocks of up to {F} storeys" if flats else ""
    return d
