"""Rightmove, Zoopla and OnTheMarket listings, without scraping them.

Those portals block automated reading and have no open feed, so listings arrive two ways that are within their terms:

1. Saved-search alert emails. Each portal emails new listings that match a search you saved on their site. If Outlook is
   connected, the alert emails are found, split into one card per property, and shown for you to add.
2. A pasted link and the text copied from the listing page. The link is kept, and the text is read for price, size and planning.

Cards are read by pattern from the email's HTML, so a redesign of an email can break this. Alert emails carry only what the
portal chose to show (usually price, address, bedrooms and a photo), so an added listing starts as a lead to be enriched, and it
is flagged when the alert does not say whether a site suits development.
"""
from __future__ import annotations

import re
from html import unescape
from html.parser import HTMLParser
from urllib.parse import parse_qs, unquote, urlparse

from . import intake, scrapers

SOURCES = {
    "rightmove": {"name": "Rightmove", "host": r"rightmove\.co\.uk|rightmove\.com|rmove\.me", "id": r"/properties/(\d{6,})|[?&]propertyId=(\d{6,})|/property-(?:for-sale|to-rent)/[^\s\"']*?-(\d{6,})"},
    "zoopla": {"name": "Zoopla", "host": r"zoopla\.co\.uk|zpg\.co\.uk", "id": r"/details/(\d{6,})|/for-sale/details/(\d{6,})|[?&]listing_id=(\d{6,})"},
    "onthemarket": {"name": "OnTheMarket", "host": r"onthemarket\.com", "id": r"/details/(\d{6,})"},
}
ALERT_SENDER = re.compile(r"rightmove|zoopla|onthemarket|zpg", re.I)
PRICE = re.compile(r"(?:£\s?|\b(?:guide price|offers?\s+(?:over|in excess of|in the region of|around|invited)|asking price)[:\s]*(?:£\s?)?)([\d,]{5,})(?:\s?(?:pcm|pw|per month))?", re.I)
POSTCODE = re.compile(r"\b([A-Z]{1,2}\d[A-Z\d]?)\s?(\d[A-Z]{2})\b")
LINK_ID = re.compile(r"(?:^|[/=&-])(\d{6,10})(?:[/?&#]|$)")


def source_of(url: str) -> str | None:
    host = urlparse(url).netloc.lower()
    for k, v in SOURCES.items():
        if re.search(v["host"], host):
            return k
    return None


def listing_id(url: str, src: str | None = None) -> str | None:
    """The portal's number for the listing. Tracking links often carry the real address in a query parameter."""
    src = src or source_of(url)
    cands = [url]
    q = parse_qs(urlparse(url).query)
    for vals in q.values():
        for v in vals:
            if v.startswith("http"):
                cands.append(unquote(v))
    for c in cands:
        s = source_of(c) or src
        if not s:
            continue
        m = re.search(SOURCES[s]["id"], c)
        if m:
            return next(g for g in m.groups() if g)
    return None


def canonical(src: str, lid: str) -> str:
    return {"rightmove": f"https://www.rightmove.co.uk/properties/{lid}", "zoopla": f"https://www.zoopla.co.uk/for-sale/details/{lid}/",
            "onthemarket": f"https://www.onthemarket.com/details/{lid}/"}[src]


class _Cards(HTMLParser):
    """Collect each link to a property with the text that follows it, up to the next property link."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.cards: list[dict] = []
        self.cur: dict | None = None
        self.skip = 0
        self.href = None
        self.img = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in ("script", "style"):
            self.skip += 1
        if tag == "a" and a.get("href"):
            url = unescape(a["href"])
            src = source_of(url)
            lid = listing_id(url, src) if (src or re.search(r"track|click|redirect|link", url, re.I)) else None
            if lid:
                real = src or next((source_of(unquote(v)) for vs in parse_qs(urlparse(url).query).values() for v in vs if v.startswith("http") and source_of(unquote(v))), None)
                if real and (not self.cur or self.cur["id"] != lid):
                    self.cur = {"source": real, "id": lid, "text": [], "image": ""}
                    self.cards.append(self.cur)
        if tag == "img" and a.get("src") and self.cur and not self.cur["image"] and re.search(r"\.(jpe?g|png)|/image|media", a["src"], re.I):
            self.cur["image"] = a["src"]
        if tag in ("br", "p", "div", "tr", "td", "li", "h1", "h2", "h3", "h4") and self.cur:
            self.cur["text"].append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.skip = max(0, self.skip - 1)

    def handle_data(self, d):
        if self.cur and not self.skip:
            self.cur["text"].append(d)


def _bits(text: str) -> dict:
    text = re.sub(r"[ \t\xa0]+", " ", text)
    # a price often sits on the same line as the title in an email, so put it on its own line
    text = PRICE.sub(lambda m: "\n" + m.group(0) + "\n", text)
    lines = [l.strip(" |-•" + "\u2013\u2014") for l in text.split("\n") if l.strip(" |-•" + "\u2013\u2014")]
    full = " \n".join(lines)
    pm = PRICE.search(full)
    price = float(pm.group(1).replace(",", "")) if pm else None
    rent = bool(pm and re.search(r"pcm|pw|per month", pm.group(0), re.I))
    pc = POSTCODE.search(full.upper())
    beds = re.search(r"(\d+)\s*bed", full, re.I)
    # a line that is ONLY a bed-count badge (with an optional bare property type) is dropped; one that goes on to give an
    # address or description ("2 bed flat, Manchester M1 2AB") is kept, since that is the only place that text appears
    bed_badge = re.compile(r"^\d+\s*[-\u2013\u2014]?\s*bed(?:room)?s?(?:\s+(?:house|flat|apartment|maisonette|bungalow|terrace(?:d)?|semi-detached|detached|cottage|studio))?\.?$", re.I)
    body = [l for l in lines if not PRICE.search(l) and not bed_badge.match(l)
            and not re.match(r"^(?:view|see|save|new|reduced|added|your saved|properties for you|guide price|asking price|offers?\s+(?:over|in excess of|in the region of|around|invited)|oiro|poa)\b", l, re.I)
            and re.search(r"[A-Za-z]{3}", l)]
    # the title comes first in every alert layout; a short first line is the address, a long one is a description
    addr = next((l for l in body if 6 <= len(l) <= 120), body[0] if body else "")
    desc = " ".join(l for l in body if l != addr)[:500]
    return {"price": None if rent else price, "rent": rent, "postcode": f"{pc.group(1)} {pc.group(2)}" if pc else "", "beds": int(beds.group(1)) if beds else None, "address": addr[:140], "summary": desc}


def parse_alert(html: str, text: str = "", sender: str = "") -> list[dict]:
    """One card per property from an alert email's HTML."""
    p = _Cards()
    try:
        p.feed(html or "")
    except Exception:
        pass
    seen, out = set(), []
    if not p.cards:
        plain = text or ("" if re.search(r"<\s*(?:a|div|table|p|br)\b", html or "", re.I) else html)
        if plain:
            return parse_text(plain)
    for c in p.cards:
        key = (c["source"], c["id"])
        raw = "".join(c["text"])
        if key in seen:
            # a second link to the same property (photo then title) adds text to the first card
            first = next(o for o in out if (o["source"], o["id"]) == key)
            first["_raw"] += "\n" + raw
            continue
        seen.add(key)
        out.append({"source": c["source"], "id": c["id"], "image": c["image"], "_raw": raw})
    return _finish(out)


def _finish(out: list[dict]) -> list[dict]:
    res = []
    for o in out:
        b = _bits(o.pop("_raw"))
        cls = scrapers.classify(f"{b['address']} {b['summary']}")
        res.append({**o, "source_name": SOURCES[o["source"]]["name"], "url": canonical(o["source"], o["id"]), **b, "property_type": cls.get("property_type"),
                    "strategy": cls.get("strategy"), "planning_status": cls.get("planning_status"), "site_ha": cls.get("site_ha"), "existing_sqft": cls.get("existing_sqft"),
                    "development_signal": bool(re.search(r"\b(land|plot|plots|site|development|planning|consent|stpp|acre|hectare|redevelop|block of|conversion|depot|yard)\b", f"{b['address']} {b['summary']}", re.I))})
    return res


URL_RE = re.compile(r"https?://[^\s<>\")\]]+")


def parse_text(text: str) -> list[dict]:
    """The same cards from a plain text alert: each property link closes a block of text, so the lines above it (back to the previous link) are the card."""
    text = text or ""
    out, seen, last = [], set(), 0
    for m in URL_RE.finditer(text):
        url = m.group(0).rstrip(".,;")
        src = source_of(url)
        lid = listing_id(url, src) if src else None
        if not lid:
            continue
        if (src, lid) not in seen:
            seen.add((src, lid))
            out.append({"source": src, "id": lid, "image": "", "_raw": text[last:m.start()]})
        last = m.end()
    return _finish(out)


def to_site(card: dict) -> dict:
    """A site record from one alert card. It is a lead: only what the alert stated is filled in."""
    lid = f"{card['source']}-{card['id']}"
    site = {"id": lid, "source_id": card["source"], "source": card["source_name"], "name": card.get("address") or f"{card['source_name']} listing {card['id']}", "address": card.get("address") or "",
            "postcode": card.get("postcode") or "", "asking_price": card.get("price"), "url": card["url"], "property_type": card.get("property_type") or "Unknown",
            "strategy": card.get("strategy") or "develop_sell", "planning_status": card.get("planning_status") or "Unknown", "description": (card.get("summary") or "")[:400],
            "stage": "Sourced", "listing": True, "from_alert": True}
    for k in ("site_ha", "existing_sqft"):
        if card.get(k):
            site[k] = card[k]
    if card.get("beds"):
        site["bedrooms"] = card["beds"]
    if not card.get("development_signal"):
        site["intake_missing"] = ["whether the property suits development: the alert does not say"]
    g = scrapers.geocode_text(f"{site['postcode']} {site['address']}")
    if g:
        site["lat"], site["lon"], site["geo_precision"] = g
    return site


def from_paste(url: str, text: str) -> dict:
    """A site record from a pasted link and the copied listing text. The link alone cannot be read, so text is required."""
    src = source_of(url or "")
    lid = listing_id(url, src) if url else None
    if not (text or "").strip():
        raise ValueError("Paste the description from the listing page as well. Rightmove and Zoopla do not allow their pages to be read automatically, so the link alone gives nothing to work from.")
    d = intake.heuristic(text, "", "")
    site = intake.to_site(d, SOURCES[src]["name"] if src else "Pasted listing")
    site.update(listing=True, deal=False, stage="Sourced")
    if url:
        site["url"] = canonical(src, lid) if (src and lid) else url
    if src and lid:
        site["id"] = f"{src}-{lid}"
        site["source_id"] = src
    return site


def is_alert_sender(sender: str, subject: str = "") -> bool:
    return bool(ALERT_SENDER.search(sender or "")) or bool(re.search(r"new (?:properties|listings|homes)|saved search|property alert", subject or "", re.I) and ALERT_SENDER.search(subject or ""))
