"""Land assembly: parcels, owners, approaches and the letter to send."""
from __future__ import annotations

import uuid
from datetime import date

PARCEL_STATUS = ["Not approached", "Approached", "In talks", "Heads agreed", "Option signed", "Contracted", "Declined"]
OWNER_TYPES = ["Individual", "Company", "Council or public body", "Trust or charity", "Unknown"]
SECURED = ("Option signed", "Contracted")
LIVE = ("Approached", "In talks", "Heads agreed")


def clean_parcel(p: dict) -> dict:
    def f(k):
        try:
            return float(p[k]) if p.get(k) not in (None, "") else None
        except (TypeError, ValueError):
            return None
    log = []
    for e in p.get("log") or []:
        if str(e.get("note", "")).strip():
            log.append({"date": str(e.get("date") or date.today().isoformat())[:10], "type": str(e.get("type") or "Note"), "note": str(e["note"]).strip()})
    return {"id": p.get("id") or "pcl-" + uuid.uuid4().hex[:6], "ref": str(p.get("ref") or ""), "address": str(p.get("address") or ""), "owner": str(p.get("owner") or ""),
            "owner_type": p.get("owner_type") if p.get("owner_type") in OWNER_TYPES else "Unknown", "title_no": str(p.get("title_no") or ""),
            "area_ha": f("area_ha"), "status": p.get("status") if p.get("status") in PARCEL_STATUS else "Not approached", "ask": f("ask"), "offer": f("offer"),
            "deal_type": str(p.get("deal_type") or ""), "ransom": bool(p.get("ransom")),
            "contact_name": str(p.get("contact_name") or ""), "contact_email": str(p.get("contact_email") or ""), "contact_phone": str(p.get("contact_phone") or ""),
            "next_action": str(p.get("next_action") or ""), "next_date": str(p.get("next_date") or ""), "log": log}


def summary(site: dict) -> dict:
    ps = site.get("parcels") or []
    total = sum(p.get("area_ha") or 0 for p in ps)
    secured = sum(p.get("area_ha") or 0 for p in ps if p["status"] in SECURED)
    agreed = sum(p.get("area_ha") or 0 for p in ps if p["status"] == "Heads agreed")
    price = sum((p.get("offer") or p.get("ask") or 0) for p in ps if p["status"] != "Declined")
    live_area = sum(p.get("area_ha") or 0 for p in ps if p["status"] != "Declined")
    target = site.get("site_ha") or total
    today = date.today().isoformat()
    return {"n": len(ps), "area": total, "target_ha": target, "secured_ha": secured, "agreed_ha": agreed,
            "secured_pct": (secured / target * 100) if target else 0, "committed_pct": ((secured + agreed) / target * 100) if target else 0,
            "blended_per_ha": (price / live_area) if live_area else None, "price_total": price,
            "declined": sum(1 for p in ps if p["status"] == "Declined"), "ransom": sum(1 for p in ps if p.get("ransom") and p["status"] not in SECURED),
            "overdue": sum(1 for p in ps if p.get("next_date") and p["next_date"] < today and p["status"] not in SECURED + ("Declined",)),
            "unapproached": sum(1 for p in ps if p["status"] == "Not approached")}


def letter(site: dict, parcel: dict, investor: dict) -> dict:
    who = investor.get("name") or "[your name]"
    firm = investor.get("firm") or "[your firm]"
    owner = parcel.get("contact_name") or parcel.get("owner") or "the owner"
    greeting = f"Dear {owner}," if parcel.get("contact_name") or parcel.get("owner") else "Dear Sir or Madam,"
    addr = parcel.get("address") or site.get("address") or site.get("name") or "the land"
    body = (f"{greeting}\n\n"
            f"I am writing about {addr}. {firm} develops homes in this part of England and we are interested in the land you own"
            f"{' at ' + site['name'] if site.get('name') and site['name'] not in addr else ''}.\n\n"
            "We would like to talk about buying the land or agreeing an option over it, whichever suits you better. "
            "We can move quickly, cover your reasonable legal and surveyor costs, and keep any planning work in your name if you prefer that. "
            "An initial conversation carries no commitment on either side.\n\n"
            "If you are open to a call or a short meeting, please reply to this letter or contact me directly.\n\n"
            f"Yours sincerely,\n{who}\n{firm}")
    return {"to": parcel.get("contact_email") or "", "subject": f"Land at {addr}", "body": body}
