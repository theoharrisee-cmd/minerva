"""Planning strategy: a recommended route to consent and the case to make, drawn only from what is on file.

Inputs are the site's data checks, the homes schedule policy checks, consultee positions, the five year track record and
the planning status. The complexity score and route are rule-based and shown with their workings, so they are a prompt for
a conversation with the planning consultant, not a forecast. Nothing here is a statement about the council's current policy.
"""
from __future__ import annotations

import io
from datetime import date

from . import suggest

BODY_MITIGATION = [
    (("highway", "transport", "access"), "Transport assessment, junction modelling and a scheme for a second access, agreed with the highway authority before submission."),
    (("landscape", "visual", "design"), "Landscape and visual impact assessment and a massing study that steps built form back from the skyline."),
    (("natural england", "ecolog", "biodiversity", "sang"), "Habitats regulations screening, a mitigation strategy (SANG and monitoring payments) and a biodiversity net gain plan."),
    (("water", "drainage", "sewer", "lead local flood", "llfa", "environment agency"), "Drainage strategy and a capacity study with the utility, with a phasing condition where reinforcement is needed."),
    (("education", "school"), "Early discussion of the contribution and any land reserved for school expansion."),
    (("heritage", "conservation", "historic"), "Heritage statement and design that responds to the setting, tested at pre-application."),
    (("housing", "affordable"), "A tenure and mix proposal that meets policy, supported by a viability note if it does not."),
    (("environmental health", "noise", "air", "contamina"), "Noise, air quality and ground condition reports with the mitigation the environmental health team asks for."),
]
CHECK_FIX = {
    "ndss_gia": "Enlarge the shortfall homes or change the mix so every home meets the Nationally Described Space Standard.",
    "plan_balance": "Rebalance plot and street coverage, or state the open space and drainage provision explicitly.",
    "outdoor": "Add balconies, terraces or communal space so each home has private outdoor space.",
    "affordable": "Adjust the affordable mix or tenure split to match policy.",
    "parking": "Revisit parking provision against the local standard.",
    "density": "Test a density range that fits the surrounding character.",
}


def _mitigation(body: str, text: str = "") -> str:
    t = f"{body} {text}".lower()
    for keys, m in BODY_MITIGATION:
        if any(k in t for k in keys):
            return m
    return "Meet the officer before submission and agree the scope of any further assessment."


def _flags(site: dict, pack: dict) -> dict:
    f = dict(pack.get("flags") or {})
    for k in ("green_belt", "heritage", "flood_zone", "trees", "brownfield"):
        if site.get(k) and k not in f:
            f[k] = site[k]
    hit = lambda *ids: any(x.get("id") in ids and x.get("status") == "hit" for x in pack.get("items", []))
    return {"green_belt": bool(f.get("green_belt") or hit("green-belt")), "flood": str(f.get("flood_zone") or ""),
            "heritage": hit("conservation-area", "listed-building-outline", "world-heritage-site", "scheduled-monument", "park-and-garden") or bool(f.get("heritage")),
            "landscape": hit("national-park", "area-of-outstanding-natural-beauty"),
            "ecology": hit("site-of-special-scientific-interest", "special-protection-area", "special-area-of-conservation", "ancient-woodland", "ramsar"),
            "trees": hit("tree-preservation-zone") or bool(f.get("trees")), "brownfield": bool(site.get("brownfield")) or hit("brownfield-land"),
            "aqma": hit("air-quality-management-area")}


def build(site: dict, pack: dict, track: dict | None, policy: dict | None, a: dict, ap: dict | None = None, today: date | None = None) -> dict:
    today = today or date.today()
    fl = _flags(site, pack or {})
    units = int(site.get("units") or 0) or max(1, round(float(site.get("site_ha") or 0) * a["density_dph"]))
    status = str(site.get("planning_status") or "")
    cons = site.get("consultees") or []
    objects = [c for c in cons if str(c.get("stance", "")).lower().startswith("object")]
    supports = [c for c in cons if str(c.get("stance", "")).lower() in ("support", "no objection", "supports")]
    checks = (policy or {}).get("checks") or []
    fails = [c for c in checks if c.get("status") == "fail"]
    warns = [c for c in checks if c.get("status") == "warn"]

    # ---- complexity score with its workings
    fac: list[tuple[str, float]] = []
    if units >= 10 or float(site.get("site_ha") or 0) >= 0.5:
        fac.append((f"Major development ({units} homes)", 2))
    if units >= 50:
        fac.append(("Large scheme, likely to go to committee", 1))
    if fl["green_belt"]:
        fac.append(("Green Belt", 2 if fl["brownfield"] else 3))
    if fl["heritage"]:
        fac.append(("Heritage designation", 2))
    if fl["landscape"]:
        fac.append(("Protected landscape", 2))
    if fl["ecology"]:
        fac.append(("Protected habitat", 2))
    if fl["flood"] == "3":
        fac.append(("Flood Zone 3", 2))
    elif fl["flood"] == "2":
        fac.append(("Flood Zone 2", 1))
    for k, lbl in (("trees", "Protected trees"), ("aqma", "Air quality management area")):
        if fl[k]:
            fac.append((lbl, 1))
    if objects:
        fac.append((f"{len(objects)} consultee objection{'s' if len(objects) > 1 else ''} on file", min(4, 2 * len(objects))))
    if fails:
        fac.append((f"{len(fails)} policy check{'s' if len(fails) > 1 else ''} failing", min(3, len(fails))))
    if track and track.get("ok"):
        r = track.get("approval_rate")
        if r is not None and r < 0.6:
            fac.append((f"Low nearby approval rate ({r:.0%})", 2))
        elif r is not None and r < 0.75:
            fac.append((f"Approval rate {r:.0%} nearby", 1))
        if (track.get("median_days") or 0) > 300:
            fac.append((f"Slow decisions (median {track['median_days']:.0f} days)", 1))
    if status == "Allocated":
        fac.append(("Site is allocated in the local plan", -1))
    if status == "Consented":
        fac.append(("Consent already granted", -3))
    if status in ("Refused", "Appeal"):
        fac.append((f"Planning status is {status.lower()}", 2))
    score = max(0, round(sum(p for _, p in fac)))
    level = "Low" if score <= 2 else "Medium" if score <= 5 else "High"

    # ---- route
    layout_done = bool((site.get("layout") or {}).get("ok")) and bool(site.get("typology"))
    detail = "a full application" if layout_done else "an outline application with access, then reserved matters"
    if status == "Consented":
        route = {"title": "Implement the consent and discharge conditions", "summary": "Planning is in place. Focus on pre-commencement conditions and, if the scheme changes, a section 73 variation or non-material amendment.",
                 "steps": ["List the pre-commencement conditions and who signs each off", "Check the consent expiry date and the CIL liability notice", "Take advice before any change to the approved scheme"]}
    elif fl["green_belt"] and status != "Allocated" and not fl["brownfield"]:
        route = {"title": "Pre-application first, with a Green Belt case", "summary": "Do not submit cold. Test with the council whether the land can be treated as grey belt or whether very special circumstances exist, and consider promoting the site through the local plan in parallel.",
                 "steps": ["Commission a Green Belt assessment of the parcel", "Request pre-application advice under a planning performance agreement", "Set a decision point: proceed, promote through the plan, or walk away"]}
    elif level == "High":
        route = {"title": "Pre-application under a planning performance agreement, then " + detail, "summary": "Complexity is high. Agree a timetable and a single officer team early, resolve the objections on file before submission, and hold appeal costs as a contingency.",
                 "steps": ["Agree a planning performance agreement with the council", "Resolve the objections on file at pre-application", "Brief the ward members before submission", "Hold a contingency for an appeal"]}
    elif level == "Medium" or units >= 10:
        route = {"title": "Pre-application, then " + detail, "summary": "A major scheme with manageable constraints. One or two pre-application meetings should settle the main issues.",
                 "steps": ["Request pre-application advice", "Commission the reports the constraints call for", "Submit once the officer view is broadly supportive"]}
    else:
        route = {"title": "Submit " + detail, "summary": "A small scheme with few constraints. Pre-application is optional, but worth it if the officer is unknown.",
                 "steps": ["Check the validation list for the council", "Submit with the standard reports"]}

    # ---- arguments from what is on file
    args = []
    prec = (track or {}).get("precedents") or []
    if prec and track.get("approved"):
        n = min(3, len(prec))
        refs = ", ".join(p.get("ref", "") for p in prec[:n])
        args.append({"text": f"{track['approved']} major applications were approved within {track.get('radius_km', 8):.0f} km in the last five years ({track['approval_rate']:.0%} of those decided). Nearest comparable approvals: {refs}.",
                     "source": "PlanIt, five year record", "strength": "Strong" if track["approval_rate"] >= 0.75 else "Moderate"})
    if status == "Allocated":
        args.append({"text": "The site is allocated for development in the local plan, so the principle of development is established.", "source": "Planning status on file", "strength": "Strong"})
    if fl["brownfield"]:
        args.append({"text": "The site is previously developed land, which national policy supports for redevelopment.", "source": "Brownfield land register or site record", "strength": "Moderate"})
    if checks:
        ok = sum(1 for c in checks if c.get("status") == "pass")
        if ok:
            args.append({"text": f"The schedule meets {ok} of {len(checks)} policy checks, including space standards where the check passes.", "source": "Homes schedule policy checks", "strength": "Moderate"})
    if any(c.get("id") == "affordable" and c.get("status") == "pass" for c in checks):
        args.append({"text": "The affordable housing offer meets the policy in the pack.", "source": "Homes schedule policy checks", "strength": "Moderate"})
    if supports:
        args.append({"text": f"{len(supports)} consultee{'s' if len(supports) > 1 else ''} support or do not object: " + ", ".join(c["body"] for c in supports[:4]) + ".", "source": "Consultee register", "strength": "Moderate"})

    # ---- likely officer concerns and how to meet them
    concerns = []
    for c in objects:
        concerns.append({"topic": c["body"], "detail": c.get("summary", ""), "level": "High", "source": "Consultee register", "mitigation": _mitigation(c["body"], c.get("summary", ""))})
    for c in fails + warns:
        concerns.append({"topic": c.get("title") or c.get("id"), "detail": c.get("detail") or "", "level": "High" if c["status"] == "fail" else "Medium", "source": "Homes schedule",
                         "mitigation": CHECK_FIX.get(c.get("id"), "Adjust the schedule until the check passes, or explain the departure.")})
    seen = {x["topic"] for x in concerns}
    for r in suggest.rules(site, pack or {}, track, a):
        if r["id"] in ("track", "bng"):
            continue
        if r["title"] not in seen:
            concerns.append({"topic": r["title"], "detail": r["why"], "level": r["level"], "source": "Data checks", "mitigation": _mitigation(r["title"], r["why"])})
    if track and track.get("refused"):
        concerns.append({"topic": "Nearby refusals", "detail": f"{track['refused']} major applications were refused nearby. Refusal reasons are not published in PlanIt.", "level": "Medium",
                         "source": "PlanIt, five year record", "mitigation": "Read the decision notices for the refused schemes before pre-application and design against their reasons."})
    order = {"High": 0, "Medium": 1, "Low": 2}
    concerns.sort(key=lambda c: order.get(c["level"], 3))

    # ---- timeline
    pre = 3 if route["title"].startswith(("Pre-application", "Do not")) or level != "Low" else 0
    determ = round(track["months_to_decide"]) if track and track.get("months_to_decide") else 3
    committee = 1 if units >= 50 or level == "High" else 0
    total = pre + 1 + determ + committee
    stages = [{"stage": "Pre-application (desk allowance)", "months": pre}, {"stage": "Validation", "months": 1},
              {"stage": "Determination" + (" (local median)" if track and track.get("months_to_decide") else " (13 week target for major)"), "months": determ}]
    if committee:
        stages.append({"stage": "Committee cycle and section 106 (desk allowance)", "months": committee})
    if status == "Consented":
        total, stages = 0, []

    actions = []
    needs = {"Flood Zone": "Flood risk assessment and sequential test", "Heritage": "Heritage statement", "Protected habitat": "Ecology survey and habitats regulations screening",
             "Protected trees": "Arboricultural report", "Protected landscape": "Landscape and visual impact assessment", "Green Belt": "Green Belt assessment",
             "Air quality": "Air quality assessment"}
    for r in suggest.rules(site, pack or {}, track, a):
        for k, v in needs.items():
            if r["title"].startswith(k) and v not in actions:
                actions.append(v)
    if fl["brownfield"] and "Phase 1 contamination assessment" not in actions:
        actions.append("Phase 1 contamination assessment")
    if units >= 10:
        actions += ["Transport statement", "Drainage strategy", "Statement of community involvement", "Design and access statement"]
    return {"score": score, "level": level, "factors": [{"label": l, "points": p} for l, p in fac], "route": route, "arguments": args, "concerns": concerns,
            "timeline": {"stages": stages, "total_months": total, "assumed_months": a.get("planning_months"), "differs": bool(total and abs(total - (a.get("planning_months") or 0)) >= 2)},
            "reports": actions, "units": units, "status": status or "Not stated", "layout_done": layout_done,
            "caveat": "Rule-based from what is on file. It is a starting point for a conversation with the planning consultant, not advice on the council's current policy."}


def docx(pack: dict, st: dict) -> bytes:
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor

    from .committee import _borders, _fix_width, _shade, fdate

    s = pack["site"]
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(1.9)
    sec.top_margin = sec.bottom_margin = Cm(1.5)
    base = doc.styles["Normal"]
    base.font.name, base.font.size = "Aptos", Pt(10)
    base.paragraph_format.space_after = Pt(4)

    def para(text, bold=False, size=None, color=None):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.bold = bold
        if size:
            r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
        return p

    def table(rows, widths, header=True):
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        _borders(t)
        _fix_width(t, widths)
        for i, r in enumerate(rows):
            for j, v in enumerate(r):
                c = t.cell(i, j)
                c.text = ""
                run = c.paragraphs[0].add_run(str(v))
                run.font.size = Pt(9)
                c.paragraphs[0].paragraph_format.space_after = Pt(0)
                if header and i == 0:
                    run.bold = True
                    _shade(c, "EDEDED")
        doc.add_paragraph().paragraph_format.space_after = Pt(2)

    t = doc.add_table(rows=1, cols=1)
    _fix_width(t, [17.2])
    c = t.cell(0, 0)
    _shade(c, "FF6600")
    c.text = ""
    r = c.paragraphs[0].add_run("Planning strategy")
    r.bold, r.font.size, r.font.color.rgb = True, Pt(9), RGBColor(255, 255, 255)
    p = c.add_paragraph()
    r = p.add_run(s.get("name", "Site"))
    r.bold, r.font.size, r.font.color.rgb = True, Pt(17), RGBColor(255, 255, 255)
    para(f"Prepared {fdate(date.today().isoformat())}. {st['caveat']}", size=8.5, color="666666")
    para("Recommended route", bold=True, size=12)
    para(st["route"]["title"], bold=True)
    para(st["route"]["summary"])
    for i, x in enumerate(st["route"]["steps"], 1):
        para(f"{i}. {x}")
    para(f"Complexity: {st['level']} ({st['score']} points)", bold=True, size=12)
    table([("Factor", "Points")] + [(f["label"], f"{f['points']:+g}") for f in st["factors"]] if st["factors"] else [("Factor", "Points"), ("None identified", "0")], [14, 3.2])
    if st["timeline"]["stages"]:
        para(f"Route to consent: about {st['timeline']['total_months']} months", bold=True, size=12)
        table([("Stage", "Months")] + [(x["stage"], x["months"]) for x in st["timeline"]["stages"]], [14, 3.2])
    if st["arguments"]:
        para("The case to make", bold=True, size=12)
        table([("Argument", "Source", "Strength")] + [(x["text"], x["source"], x["strength"]) for x in st["arguments"]], [10.5, 4, 2.7])
    if st["concerns"]:
        para("Likely concerns and how to meet them", bold=True, size=12)
        table([("Topic", "Concern", "Response")] + [(x["topic"], x["detail"], x["mitigation"]) for x in st["concerns"]], [3.2, 6.5, 7.5])
    if st["reports"]:
        para("Reports to commission", bold=True, size=12)
        para(", ".join(st["reports"]) + ".")
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
