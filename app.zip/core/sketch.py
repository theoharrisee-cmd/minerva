"""Map sketches: points, routes and areas drawn on the site map, kept with the site and drawn on the map image in reports.

Each item has a category (access, phase, acquire, constraint, note), a label and coordinates as [lon, lat]. The category sets the
colour and the line style, and the label is always written next to the item, so the sketch does not depend on colour alone.
"""
from __future__ import annotations

import math
import uuid

CATS = {
    "access": {"label": "Access and routes", "colour": "#1E6FD9", "dash": True},
    "phase1": {"label": "Phase 1", "colour": "#0E8F5B", "dash": False},
    "phase2": {"label": "Phase 2", "colour": "#7A4FD6", "dash": False},
    "acquire": {"label": "Land to acquire", "colour": "#D9822B", "dash": True},
    "constraint": {"label": "Constraint", "colour": "#C0392B", "dash": True},
    "note": {"label": "Note", "colour": "#555555", "dash": False},
}
KINDS = ("point", "line", "area")
MAX_ITEMS = 40
MAX_POINTS = 200


def clean(items) -> list[dict]:
    out = []
    for it in (items or [])[:MAX_ITEMS]:
        if not isinstance(it, dict) or it.get("kind") not in KINDS:
            continue
        pts = []
        for p in (it.get("coords") or [])[:MAX_POINTS]:
            try:
                lon, lat = float(p[0]), float(p[1])
            except (TypeError, ValueError, IndexError):
                continue
            if -8.7 <= lon <= 2.0 and 49.8 <= lat <= 60.9:
                pts.append([round(lon, 6), round(lat, 6)])
        need = {"point": 1, "line": 2, "area": 3}[it["kind"]]
        if len(pts) < need:
            continue
        if it["kind"] == "point":
            pts = pts[:1]
        cat = it.get("cat") if it.get("cat") in CATS else "note"
        out.append({"id": str(it.get("id") or "sk-" + uuid.uuid4().hex[:6])[:20], "kind": it["kind"], "cat": cat, "label": str(it.get("label") or "").strip()[:60], "coords": pts})
    return out


def _len_m(coords) -> float:
    t = 0.0
    for a, b in zip(coords, coords[1:]):
        dx = (b[0] - a[0]) * 111320 * math.cos(math.radians((a[1] + b[1]) / 2))
        dy = (b[1] - a[1]) * 110574
        t += math.hypot(dx, dy)
    return t


def _area_ha(coords) -> float:
    la0 = sum(c[1] for c in coords) / len(coords)
    xy = [((c[0]) * 111320 * math.cos(math.radians(la0)), c[1] * 110574) for c in coords]
    a = sum(p[0] * xy[(i + 1) % len(xy)][1] - xy[(i + 1) % len(xy)][0] * p[1] for i, p in enumerate(xy))
    return abs(a) / 2 / 1e4


def measure(item: dict) -> str:
    if item["kind"] == "line":
        return f"{_len_m(item['coords']):,.0f} m"
    if item["kind"] == "area":
        return f"{_area_ha(item['coords']):.2f} ha"
    return ""


def state(site: dict) -> dict:
    items = (site.get("sketch") or {}).get("items") or []
    return {"items": [{**i, "measure": measure(i)} for i in items], "cats": CATS}


def save(site: dict, items) -> list[dict]:
    site["sketch"] = {"items": clean(items)}
    if not site["sketch"]["items"]:
        site.pop("sketch")
        return []
    return site["sketch"]["items"]


def draw(d, P, items, font=None, w: int = 1200, h: int = 700) -> None:
    """Draw the sketch on a Pillow ImageDraw in RGBA mode. P maps (lon, lat) to picture pixels."""
    def rgba(hexc, a=255):
        hexc = hexc.lstrip("#")
        return (int(hexc[0:2], 16), int(hexc[2:4], 16), int(hexc[4:6], 16), a)

    def dashed(pts, col, width=4, on=14, off=9):
        for a, b in zip(pts, pts[1:]):
            L = math.hypot(b[0] - a[0], b[1] - a[1])
            if not L:
                continue
            t = 0.0
            while t < L:
                t2 = min(L, t + on)
                d.line([(a[0] + (b[0] - a[0]) * t / L, a[1] + (b[1] - a[1]) * t / L), (a[0] + (b[0] - a[0]) * t2 / L, a[1] + (b[1] - a[1]) * t2 / L)], fill=col, width=width)
                t += on + off

    used = []
    for it in items or []:
        c = CATS[it["cat"]]
        col = rgba(c["colour"])
        pts = [P(x, y) for x, y in it["coords"]]
        if it["kind"] == "area":
            d.polygon(pts, fill=rgba(c["colour"], 60))
            (dashed if c["dash"] else lambda p, cl, width=4: d.line(p, fill=cl, width=width))(pts + [pts[0]], col)
        elif it["kind"] == "line":
            (dashed if c["dash"] else lambda p, cl, width=4: d.line(p, fill=cl, width=width))(pts, col, 5)
            d.polygon([(pts[-1][0], pts[-1][1] - 7), (pts[-1][0] + 7, pts[-1][1]), (pts[-1][0], pts[-1][1] + 7), (pts[-1][0] - 7, pts[-1][1])], fill=col)
        else:
            x, y = pts[0]
            d.polygon([(x, y - 11), (x + 9, y), (x, y + 11), (x - 9, y)], fill=col, outline=(255, 255, 255, 255))
        if it["label"]:
            cx = sum(p[0] for p in pts) / len(pts)
            cy = sum(p[1] for p in pts) / len(pts) - (14 if it["kind"] == "point" else 0)
            tw = d.textlength(it["label"], font=font) if font else 7 * len(it["label"])
            d.rectangle([cx - tw / 2 - 4, cy - 9, cx + tw / 2 + 4, cy + 10], fill=(255, 255, 255, 225))
            d.text((cx - tw / 2, cy - 8), it["label"], fill=(20, 20, 20, 255), font=font)
        if it["cat"] not in used:
            used.append(it["cat"])
    if used:
        rows = len(used)
        d.rectangle([12, 12, 226, 18 + 24 * rows], fill=(255, 255, 255, 230))
        for k, cat in enumerate(used):
            y = 26 + 24 * k
            col = rgba(CATS[cat]["colour"])
            if CATS[cat]["dash"]:
                d.line([(22, y), (32, y)], fill=col, width=4)
                d.line([(38, y), (48, y)], fill=col, width=4)
            else:
                d.line([(22, y), (48, y)], fill=col, width=4)
            d.text((58, y - 8), CATS[cat]["label"], fill=(20, 20, 20, 255), font=font)
