"""Shared pieces of the homes schedule for the site report, investor deck and committee paper."""
from __future__ import annotations

from . import floorplan, typology


def schedule(h: dict) -> tuple[list[list], list[str]]:
    """Schedule of accommodation as table rows (header first) and the total line."""
    typ, calc = h["typ"], h["calc"]
    rows = [["Type", "Homes", "Beds", "People", "GIA m²", "Standard m²"]]
    for u in typ["units"]:
        if not u["count"]:
            continue
        p = calc["per"][u["id"]]
        std = typology.ndss_min(u["beds"], u["persons"], u["storeys"]) if u["family"] in ("house", "flat") else None
        rows.append([f'{u["code"]} {u["name"]}', str(u["count"]), str(u["beds"]), str(u["persons"]), f'{p["gia"]:.1f}', f"{std}" if std else "n/a"])
    tot = [f'{calc["units"]} homes', f'{calc["net_sqm"]:,.0f} m² net ({calc["net_sqft"]:,.0f} sq ft)', f'{calc["gross_sqm"]:,.0f} m² gross ({calc["gross_sqft"]:,.0f} sq ft)']
    if calc.get("efficiency"):
        tot.append(f'{calc["efficiency"]:.0%} net to gross')
    if calc.get("density"):
        tot.append(f'{calc["density"]:.1f} homes per hectare')
    return rows, tot


def sheets(h: dict, limit: int = 6) -> list[tuple[str, list, tuple]]:
    """Unit plan sheets (title, primitives, box), largest count first."""
    typ, calc = h["typ"], h["calc"]
    out = []
    for u in sorted([x for x in typ["units"] if x["count"]], key=lambda x: -x["count"])[:limit]:
        prims, box = floorplan.unit_sheet(u, calc["geoms"][u["id"]])
        out.append((f'{u["code"]} {u["name"]}, {calc["per"][u["id"]]["gia"]:.0f} m² GIA, {u["count"]} homes', prims, box))
    return out


def block(h: dict):
    calc, typ = h["calc"], h["typ"]
    if not calc.get("plate"):
        return None
    colours = {u["id"]: floorplan.TYPE_COLOURS[i % len(floorplan.TYPE_COLOURS)] for i, u in enumerate(typ["units"])}
    p = calc["plate"]
    return floorplan.draw_plate(p, calc["geoms"], colours, f"Typical floor, {p['n']} homes, {p['eff']:.0%} net to gross")


def findings(h: dict) -> list[dict]:
    return [c for c in (h.get("policy") or {}).get("checks", []) if c["status"] in ("fail", "warn")]


def counts_line(h: dict) -> str:
    c = (h.get("policy") or {}).get("counts") or {}
    return f'{c.get("pass", 0)} checks met, {c.get("warn", 0)} to confirm, {c.get("fail", 0)} not met against the {(h.get("policy") or {}).get("pack", "policy")} pack.'
