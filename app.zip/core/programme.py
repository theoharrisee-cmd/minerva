"""Build programme and monthly cash flow.

A programme sets when money moves: how long planning and pre-construction take, when the land is paid for, how
professional fees are phased, when statutory payments fall, how long construction runs and how sales are released.
It replaces the standard timing in the appraisal cash flow, so IRR, peak equity and the cost of delay all follow.

Only the fields you set are stored on the site; anything you leave alone follows the appraisal assumptions, so a
planning-time suggestion or a track record allowance still flows through.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date

LAND_MODES = {"completion": "Buy at the start (unconditional)",
              "conditional": "Conditional contract: deposit now, balance on planning grant"}
STATUTORY = {"start": "On starting on site", "practical": "At practical completion"}

DEFAULTS = {"precon_months": 4, "fees_pre_pct": 0.35, "presale_pct": 0.0, "land_mode": "completion", "land_deposit_pct": 0.10,
            "statutory_at": "start", "start": ""}

LABELS = {"planning_months": "Planning to grant (months)", "precon_months": "Pre-construction (months)", "build_months": "Construction (months)",
          "sales_months": "Sales or lettings period (months)", "presale_pct": "Sold before practical completion (%)",
          "land_mode": "Land payment", "land_deposit_pct": "Deposit on a conditional contract (%)",
          "fees_pre_pct": "Professional fees paid before construction (%)", "statutory_at": "S106 and CIL paid", "start": "Programme start (month)"}


def _n(x, lo, hi, d):
    try:
        return max(lo, min(hi, float(x)))
    except (TypeError, ValueError):
        return d


def clean(p: dict | None) -> dict:
    """Validate what the user sent, keeping only fields that were set."""
    p = p or {}
    out = {}
    for k, lo, hi in (("planning_months", 0, 84), ("precon_months", 0, 36), ("build_months", 1, 120), ("sales_months", 1, 60)):
        if p.get(k) not in (None, ""):
            out[k] = int(round(_n(p[k], lo, hi, lo)))
    for k in ("presale_pct", "land_deposit_pct", "fees_pre_pct"):
        if p.get(k) not in (None, ""):
            v = float(p[k])
            out[k] = _n(v / 100 if v > 1 else v, 0.0, 1.0, DEFAULTS[k])
    if p.get("land_mode") in LAND_MODES:
        out["land_mode"] = p["land_mode"]
    if p.get("statutory_at") in STATUTORY:
        out["statutory_at"] = p["statutory_at"]
    st = str(p.get("start") or "")[:7]
    if len(st) == 7 and st[4] == "-" and st[:4].isdigit() and st[5:].isdigit() and 1 <= int(st[5:]) <= 12:
        out["start"] = st
    return out


def active(site: dict) -> bool:
    return bool(site.get("programme"))


def effective(site: dict, a: dict, strategy: str | None = None) -> dict:
    """Every programme field with its value and where it came from."""
    user = clean(site.get("programme"))
    strategy = strategy or site.get("strategy") or "develop_sell"
    e = {"planning_months": int(round(a["planning_months"])), "build_months": int(round(a["build_months"])),
         "sales_months": max(1, int(round(a["sales_months"]))), **DEFAULTS}
    src = {k: "assumption" for k in ("planning_months", "build_months", "sales_months")}
    src.update({k: "default" for k in DEFAULTS})
    if not user:
        e["precon_months"] = 0  # no programme saved: the standard timing has no separate pre-construction stage
    for k, v in user.items():
        e[k] = v
        src[k] = "set"
    if strategy != "develop_sell":
        e["presale_pct"] = 0.0
    e["sales_eff"] = max(1.0, e["sales_months"] * (1 - e["presale_pct"]))
    e["deferred"] = e["land_mode"] == "conditional"
    e["source"] = src
    return e


def timeline(e: dict) -> dict:
    """Month numbers for each stage. Month 0 is exchange of the land contract."""
    g, pre, bm, sm = int(e["planning_months"]), int(e["precon_months"]), int(e["build_months"]), int(e["sales_months"])
    b0 = g + pre + 1
    pc = g + pre + bm
    return {"grant": g, "build_start": b0, "pc": pc, "end": pc + sm, "n": pc + sm + 1}


def month_label(start: str, i: int) -> str:
    if not start:
        return f"M{i}"
    y, m = int(start[:4]), int(start[5:7])
    t = y * 12 + (m - 1) + i
    return f"{['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][t % 12]} {t // 12}"


def default_start() -> str:
    d = date.today()
    y, m = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
    return f"{y:04d}-{m:02d}"


def _scurve(n: int) -> list[float]:
    if n <= 1:
        return [1.0]
    S = lambda x: 3 * x * x - 2 * x ** 3
    return [S((i + 1) / n) - S(i / n) for i in range(n)]


def flows(res: dict, a: dict, e: dict) -> tuple[list[float], list[dict]]:
    """Monthly unlevered flow and its lines: land, fees, build, statutory, receipts."""
    tl = timeline(e)
    g, b0, pc, n = tl["grant"], tl["build_start"], tl["pc"], tl["n"]
    bm = int(e["build_months"])
    sm = int(e["sales_months"])
    lines = [{"land": 0.0, "fees": 0.0, "build": 0.0, "statutory": 0.0, "receipts": 0.0} for _ in range(n)]
    land = res["land_cost"]
    if e["land_mode"] == "conditional":
        lines[0]["land"] -= land * e["land_deposit_pct"]
        lines[g]["land"] -= land * (1 - e["land_deposit_pct"])
    else:
        lines[0]["land"] -= land
    fees = res.get("fees", 0.0)
    pre_months = list(range(1, g + e["precon_months"] + 1)) or [0]
    for m in pre_months:
        lines[m]["fees"] -= fees * e["fees_pre_pct"] / len(pre_months)
    build_like = res.get("build", 0.0) + res.get("contingency", 0.0)
    for i, w in enumerate(_scurve(bm)):
        lines[b0 + i]["build"] -= build_like * w
        lines[b0 + i]["fees"] -= fees * (1 - e["fees_pre_pct"]) * w
    stat = res.get("s106", 0.0) + res.get("cil", 0.0)
    lines[b0 if e["statutory_at"] == "start" else pc]["statutory"] -= stat
    nv = res["net_value"]
    if res["strategy"] == "develop_sell":
        pre = nv * e["presale_pct"]
        lines[pc]["receipts"] += pre
        for i in range(sm):
            lines[pc + 1 + i]["receipts"] += (nv - pre) / sm
    else:
        lines[n - 1]["receipts"] += nv
    flows_ = [sum(v for v in l.values()) for l in lines]
    return flows_, lines


def gantt(e: dict) -> list[dict]:
    tl = timeline(e)
    rows = [{"id": "planning", "label": "Planning to grant", "start": 0, "end": tl["grant"]}]
    if e["precon_months"]:
        rows.append({"id": "precon", "label": "Pre-construction", "start": tl["grant"] + 1, "end": tl["build_start"] - 1})
    rows.append({"id": "build", "label": "Construction", "start": tl["build_start"], "end": tl["pc"]})
    rows.append({"id": "sales", "label": "Sales or lettings", "start": tl["pc"] + 1, "end": tl["end"]})
    return rows


def delay_table(site: dict, a: dict, strategy: str, deltas=(0, 3, 6, 12), appraise=None) -> dict:
    """What planning delay costs, holding the land price fixed at the base case."""
    base = appraise(site, a, strategy)
    fixed = base["tested_land_price"]
    rows = []
    for d in deltas:
        st, aa = site, a
        if active(site):
            st = deepcopy(site)
            eff = effective(site, a, strategy)
            st["programme"] = {**(site.get("programme") or {}), "planning_months": eff["planning_months"] + d}
        else:
            aa = {**a, "planning_months": a["planning_months"] + d}
        r = base if d == 0 else appraise(st, aa, strategy, land_price=fixed)
        rows.append({"delay": d, "profit": r["profit"], "profit_on_gdv": r["profit_on_gdv"], "profit_on_cost": r["profit_on_cost"],
                     "irr_levered": r.get("irr_levered"), "peak_equity": r.get("peak_equity"), "interest": r.get("land_finance", 0) + r.get("build_finance", 0),
                     "cost": base["profit"] - r["profit"]})
    last = rows[-1]
    per = (last["cost"] / last["delay"]) if last["delay"] else 0.0
    return {"rows": rows, "per_month": per}


START_VALUES = {"precon_months": 4, "fees_pre_pct": 0.35}


def state(site: dict, a: dict, strategy: str, ap: dict, appraise) -> dict:
    """Everything the Programme tab shows."""
    e = effective(site, a, strategy)
    tl = timeline(e)
    start = e["start"] or default_start()
    rows = ap["cashflow"]
    cum, cume = 0.0, 0.0
    out = []
    for r in rows:
        cum += r["unlevered"]
        cume += r["levered"]
        out.append({**r, "label": month_label(start, r["month"]), "cum": cum, "cum_equity": cume})
    return {"programme": e, "labels": LABELS, "land_modes": LAND_MODES, "statutory": STATUTORY, "timeline": tl, "gantt": gantt(e), "start": start,
            "rows": out, "custom": active(site), "peak_month": min(out, key=lambda r: r["cum_equity"])["month"] if out else 0,
            "delay": delay_table(site, a, strategy, appraise=appraise) if not ap.get("incomplete") or ap.get("rlv") else None,
            "dated": bool(e["start"]), "start_values": START_VALUES}
