"""Parses API_REQUIREMENTS.md into sections the UI can render as cards and tables, so the answer to
"what needs an API key to work" lives in the app itself, not only in a file on disk. One source of truth:
this reads the same file a developer would open, so the in-app page can never drift from it.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
MD_PATH = ROOT / "API_REQUIREMENTS.md"


def _cells(line: str) -> list[str]:
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def _is_rule(line: str) -> bool:
    return bool(re.match(r"^\s*\|?[\s:|-]+\|?\s*$", line)) and "-" in line


def load(text: str | None = None) -> dict:
    """{'title': str, 'sections': [{'heading': str, 'level': int, 'paragraphs': [str], 'table': {'headers': [...], 'rows': [[...]]} | None}]}"""
    src = text if text is not None else (MD_PATH.read_text() if MD_PATH.exists() else "")
    lines = src.splitlines()
    title = ""
    sections: list[dict] = []
    cur: dict | None = None
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("# "):
            title = line[2:].strip()
        elif line.startswith("## "):
            cur = {"heading": line[3:].strip(), "level": 2, "paragraphs": [], "table": None}
            sections.append(cur)
        elif line.strip().startswith("|") and i + 1 < len(lines) and _is_rule(lines[i + 1]):
            headers = _cells(line)
            rows = []
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                rows.append(_cells(lines[j]))
                j += 1
            if cur is None:
                cur = {"heading": "", "level": 2, "paragraphs": [], "table": None}
                sections.append(cur)
            cur["table"] = {"headers": headers, "rows": rows}
            i = j - 1
        elif line.strip():
            if cur is None:
                cur = {"heading": "", "level": 2, "paragraphs": [], "table": None}
                sections.append(cur)
            cur["paragraphs"].append(line.strip())
        i += 1
    return {"title": title, "sections": sections, "source": "API_REQUIREMENTS.md", "available": MD_PATH.exists()}
