"""Appraisal adjustments suggested by what the data checks found at a site.

Each rule reads the site's data pack (and planning track record) and proposes changes to the appraisal
assumptions, with the reason and the effect on profit. Nothing changes until the user accepts a
suggestion, and every accepted change can be reverted. Allowances are indicative desk values, not
consultant estimates, and are meant to be replaced by real quotes as they arrive.
"""
from __future__ import annotations

NOTE = "Indicative desk allowance. Replace it with a consultant's or contractor's figure when you have one."


def _hit(pack: dict, item_id: str) -> dict | None:
    return next((x for x in pack.get("items", []) if x.get("id") == item_id and x.get("status") == "hit"), None)


def _any(pack: dict, *ids) -> list[dict]:
    return [h for h in (_hit(pack, i) for i in ids) if h]


def rules(site: dict, pack: dict, track: dict | None, a: dict) -> list[dict]:
    out: list[dict] = []
    flags = pack.get("flags", {})
    units = int(site.get("units") or 0) or max(1, round(float(site.get("site_ha") or 0) * a["density_dph"]))

    def add(rid, title, why, changes, level="Medium"):
        out.append({"id": rid, "title": title, "why": why, "changes": [{"key": k, "delta": d, "label": lbl} for k, d, lbl in changes], "level": level, "note": NOTE})

    fz = flags.get("flood_zone") or site.get("flood_zone")
    if str(fz) == "3":
        add("flood3", "Flood Zone 3", "The site is in Flood Zone 3. Expect a flood risk assessment, the sequential and exception tests, raised floor levels and sustainable drainage.",
            [("external_pct", 0.03, "Flood resilience and drainage"), ("contingency_pct", 0.01, "Higher design risk"), ("planning_months", 4, "Sequential and exception tests")], "High")
    elif str(fz) == "2":
        add("flood2", "Flood Zone 2", "The site is in Flood Zone 2. A flood risk assessment and resilient design are usually required.", [("external_pct", 0.01, "Flood resilience and drainage")])
    if _any(pack, "coal") or any(x.get("id", "").startswith("layer-coal") and x.get("status") == "hit" for x in pack.get("items", [])):
        add("coal", "Coal mining risk area", "The Coal Authority layer returned a result at this point. A coal mining risk assessment and, often, ground stabilisation are needed.", [("external_pct", 0.02, "Mining remediation")], "High")
    if site.get("brownfield") or _hit(pack, "brownfield-land"):
        add("brownfield", "Previously developed land", "Brownfield sites usually carry remediation and demolition costs that only ground investigation will size.", [("external_pct", 0.03, "Remediation and demolition allowance")])
    elif site.get("site_ha") or units:
        add("bng", "Biodiversity net gain", "Greenfield development in England must deliver a 10 per cent biodiversity net gain, on site or by credits.", [("s106_per_unit", 1500, "Credits or habitat works per home")], "Low")
    if _hit(pack, "tree-preservation-zone") or flags.get("trees"):
        add("trees", "Tree preservation", "Protected trees constrain the layout and need an arboricultural report.", [("external_pct", 0.005, "Tree protection and design"), ("planning_months", 1, "Arboricultural work")], "Low")
    eco = _any(pack, "site-of-special-scientific-interest", "special-protection-area", "special-area-of-conservation", "ancient-woodland", "ramsar", "national-nature-reserve", "local-nature-reserve")
    if eco:
        add("ecology", "Protected habitat", f"{eco[0]['label']} at this point. Expect ecological surveys, a habitats regulations assessment and mitigation payments.", [("s106_per_unit", 2000, "Mitigation contribution per home"), ("planning_months", 6, "Surveys and assessment")], "High")
    if _any(pack, "conservation-area", "listed-building-outline", "world-heritage-site", "scheduled-monument", "park-and-garden"):
        add("heritage", "Heritage constraint", "A heritage designation applies. Expect a heritage statement, sensitive design and longer negotiation.", [("fees_pct", 0.01, "Specialist advisers"), ("planning_months", 3, "Negotiation with the conservation officer")])
    if _any(pack, "national-park", "area-of-outstanding-natural-beauty"):
        add("landscape", "Protected landscape", "National Park or National Landscape policy gives great weight to conserving character. Design and materials add cost and time.", [("external_pct", 0.01, "Materials and landscape"), ("planning_months", 4, "Landscape and visual assessment")], "High")
    if _hit(pack, "green-belt") or flags.get("green_belt"):
        add("greenbelt", "Green Belt", "Development is inappropriate unless very special circumstances or the grey belt tests are met. Plan for a long, uncertain route.", [("planning_months", 12, "Green Belt case")], "High")
    if _hit(pack, "air-quality-management-area"):
        add("aqma", "Air quality management area", "An air quality assessment and mitigation are likely.", [("s106_per_unit", 500, "Mitigation per home")], "Low")
    acc = (site.get("suggest") or {}).get("accepted", {})
    if track and track.get("ok") and str(site.get("planning_status") or "") not in ("Consented",) and track.get("months_to_decide"):
        m = round(track["months_to_decide"] + 3)
        delta = acc["track"]["changes"][0]["delta"] if "track" in acc else m - a.get("planning_months", 0)
        if delta != 0:
            add("track", "Council determination time", f"Over the last five years the median time to decide a major application nearby was {track['median_days']:.0f} days ({track['months_to_decide']:.0f} months). Allow for pre-application and validation time on top.",
                [("planning_months", delta, f"{m} months to consent in total")], "Medium")
    return out


def with_state(items: list[dict], site: dict) -> list[dict]:
    acc = (site.get("suggest") or {}).get("accepted", {})
    for it in items:
        it["accepted"] = it["id"] in acc
    return items


def apply(site: dict, item: dict, base: dict) -> None:
    """Add the item's changes to the site's own assumptions. base is the assumption set in force before the change."""
    st = site.setdefault("suggest", {"accepted": {}})
    if item["id"] in st["accepted"]:
        return
    ovr = site.setdefault("ovr", {})
    for c in item["changes"]:
        cur = ovr.get(c["key"], base.get(c["key"], 0))
        ovr[c["key"]] = round(cur + c["delta"], 6)
    st["accepted"][item["id"]] = {"title": item["title"], "changes": [{"key": c["key"], "delta": c["delta"]} for c in item["changes"]]}


def revert(site: dict, rid: str, base: dict) -> bool:
    st = (site.get("suggest") or {}).get("accepted", {})
    if rid not in st:
        return False
    ovr = site.setdefault("ovr", {})
    for c in st[rid]["changes"]:
        if c["key"] in ovr:
            ovr[c["key"]] = round(ovr[c["key"]] - c["delta"], 6)
            if abs(ovr[c["key"]] - base.get(c["key"], 0)) < 1e-9:
                del ovr[c["key"]]
    del st[rid]
    return True
