"""Comparable schemes near a site: built schemes from Land Registry new build sales, consented schemes from
planning.data.gov.uk where the council publishes them, schemes you add by hand, your own portfolio, and other
sites you track. Each item carries units, density and a sales price where the source gives one."""
from __future__ import annotations

import math
import re
import statistics
import uuid

from . import net

PDG = "https://www.planning.data.gov.uk"
KINDS = ["Built", "Under construction", "Consented", "Submitted", "Refused"]


def km(a_lat, a_lon, b_lat, b_lon) -> float:
    r = 6371.0
    p1, p2 = math.radians(a_lat), math.radians(b_lat)
    dp, dl = p2 - p1, math.radians(b_lon - a_lon)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def geocode_postcodes(pcs: list[str], post=None) -> dict[str, tuple[float, float]]:
    """Bulk lookup through postcodes.io (100 per request)."""
    out: dict[str, tuple[float, float]] = {}
    pcs = sorted({p.strip().upper() for p in pcs if p})
    post = post or (lambda url, payload: net.post_json(url, payload, {}, timeout=20))
    for i in range(0, len(pcs), 100):
        try:
            js = post("https://api.postcodes.io/postcodes", {"postcodes": pcs[i:i + 100]})
        except Exception:
            continue
        for r in js.get("result", []):
            res = r.get("result")
            if res and res.get("latitude") is not None:
                out[r["query"].upper()] = (res["latitude"], res["longitude"])
    return out


def built_from_sales(sales: list[dict], geo: dict) -> list[dict]:
    """Cluster new build sales by postcode unit into candidate built schemes."""
    groups: dict[str, list[dict]] = {}
    for s in sales:
        if s.get("new_build") and s.get("postcode") in geo:
            groups.setdefault(s["postcode"], []).append(s)
    out = []
    for pc, xs in groups.items():
        prices = [x["price"] for x in xs]
        psf = [x["psf"] for x in xs if x.get("psf")]
        street = next((x["street"] for x in xs if x.get("street")), "")
        types = sorted({x["type"] for x in xs})
        out.append({"id": f"lr-{pc.replace(' ', '')}", "source": "Land Registry", "kind": "Built", "name": f"New build sales, {street or pc}".strip(), "postcode": pc,
                    "lat": geo[pc][0], "lon": geo[pc][1], "units": len(xs), "units_note": f"{len(xs)} new build sale{'s' if len(xs) != 1 else ''} recorded",
                    "density": None, "price": statistics.median(prices), "psf": statistics.median(psf) if psf else None,
                    "date": max(x["date"] for x in xs), "detail": ", ".join(types)})
    return out


def _bbox_wkt(lat, lon, rkm):
    dlat = rkm / 111.0
    dlon = rkm / (111.0 * max(0.2, math.cos(math.radians(lat))))
    w, e, s, n = lon - dlon, lon + dlon, lat - dlat, lat + dlat
    return f"POLYGON(({w} {s},{e} {s},{e} {n},{w} {n},{w} {s}))"


_UNITS = re.compile(r"\b(\d{1,4})\s*(?:no\.?\s*)?(?:new\s+)?(?:residential\s+)?(dwellings?|homes?|units?|flats?|apartments?|houses?)\b", re.I)


def nearby_applications(lat: float, lon: float, radius_km: float = 2.0, get_json=None) -> list[dict]:
    """Planning applications published to planning.data.gov.uk inside a box around the site (coverage varies by council)."""
    get_json = get_json or net.get_json
    from urllib.parse import quote
    url = f"{PDG}/entity.json?dataset=planning-application&geometry={quote(_bbox_wkt(lat, lon, radius_km))}&geometry_relation=intersects&limit=60"
    js = get_json(url, timeout=20)
    out = []
    for e in js.get("entities", []):
        desc = e.get("description") or e.get("name") or ""
        m = _UNITS.search(desc)
        pt = re.match(r"POINT\s*\(\s*([-\d.]+)\s+([-\d.]+)\s*\)", e.get("point") or "")
        if not pt:
            continue
        plon, plat = float(pt.group(1)), float(pt.group(2))
        dec = (e.get("decision") or e.get("planning-decision") or "").lower()
        kind = "Consented" if re.search(r"approv|grant|permit", dec) else "Refused" if re.search(r"refus|reject", dec) else "Submitted"
        out.append({"id": f"pd-{e.get('entity')}", "source": "planning.data.gov.uk", "kind": kind, "name": e.get("reference") or "Application", "lat": plat, "lon": plon,
                    "units": int(m.group(1)) if m and m.group(2).lower().startswith(("dwell", "home", "unit", "flat", "apart", "house")) else None,
                    "units_note": "", "density": None, "price": None, "psf": None, "date": e.get("decision-date") or e.get("entry-date") or "", "detail": desc[:200]})
    return out


def clean_manual(d: dict, geo=None) -> dict:
    o = {"id": d.get("id") or "man-" + uuid.uuid4().hex[:6], "source": d.get("source") or "Added by you", "kind": d.get("kind") if d.get("kind") in KINDS else "Consented",
         "name": str(d.get("name") or "Scheme").strip(), "postcode": str(d.get("postcode") or "").strip().upper(), "detail": str(d.get("detail") or ""), "date": str(d.get("date") or "")}
    for k in ("units", "density", "price", "psf", "lat", "lon", "site_ha"):
        try:
            o[k] = float(d[k]) if d.get(k) not in (None, "") else None
        except (TypeError, ValueError):
            o[k] = None
    if o["units"] and o.get("site_ha") and not o["density"]:
        o["density"] = round(o["units"] / o["site_ha"], 1)
    if o["lat"] is None and o["postcode"] and geo and o["postcode"] in geo:
        o["lat"], o["lon"] = geo[o["postcode"]]
    o["units_note"] = ""
    return o


def assemble(site: dict, sales: list[dict] | None, geo: dict, manual: list[dict], other_sites: list[dict], portfolio: list[dict], apps: list[dict], radius_km: float = 3.0) -> dict:
    items = []
    if sales:
        items += built_from_sales(sales, geo)
    items += apps
    items += [m for m in manual if m.get("lat") is not None]
    for s in other_sites:
        if s["id"] != site["id"] and s.get("lat") is not None:
            items.append({"id": f"site-{s['id']}", "source": "Your sites", "kind": "Consented" if s.get("planning_status") == "Consented" else "Submitted", "name": s.get("name", ""), "lat": s["lat"], "lon": s["lon"],
                          "units": s.get("units"), "units_note": "", "density": round(s["units"] / s["site_ha"], 1) if s.get("units") and s.get("site_ha") else None, "price": None,
                          "psf": s.get("sales_psf"), "date": "", "detail": f"Tracked site, stage {s.get('stage', '')}", "postcode": s.get("postcode", "")})
    for p in portfolio:
        if p.get("lat") is not None:
            items.append({"id": f"own-{p['id']}", "source": "Your portfolio", "kind": "Built" if p["status"] in ("Complete, selling", "Stabilised", "Sold") else "Under construction", "name": p["name"], "lat": p["lat"], "lon": p["lon"],
                          "units": p.get("units"), "units_note": "", "density": None, "price": None, "psf": None, "date": "", "detail": p["status"], "postcode": ""})
    out = []
    for it in items:
        if it.get("lat") is None or site.get("lat") is None:
            continue
        d = km(site["lat"], site["lon"], it["lat"], it["lon"])
        if d <= radius_km:
            out.append({**it, "distance_km": round(d, 2)})
    out.sort(key=lambda x: x["distance_km"])
    with_units = [x for x in out if x.get("units") and x["kind"] != "Refused" and x["source"] != "Land Registry"]
    dens = [x["density"] for x in out if x.get("density")]
    psf = [x["psf"] for x in out if x.get("psf")]
    return {"items": out, "summary": {"n": len(out), "units": sum(x["units"] for x in with_units), "median_density": statistics.median(dens) if dens else None,
                                      "median_psf": statistics.median(psf) if psf else None, "radius_km": radius_km,
                                      "by_kind": {k: sum(1 for x in out if x["kind"] == k) for k in KINDS if any(x["kind"] == k for x in out)}}}
