"""Investment committee paper as a Word document (python-docx)."""
from __future__ import annotations

import io
from datetime import date

from . import costs

ORANGE = "FF6600"
GREY = "EDEDED"


def money(x, dp=2):
    if x is None:
        return "n/a"
    a = abs(x)
    if a >= 1e6:
        return f"£{x / 1e6:,.{dp}f}m"
    if a >= 1e3:
        return f"£{x / 1e3:,.0f}k"
    return f"£{x:,.0f}"


def pct(x, dp=1):
    return "n/a" if x is None else f"{x * 100:.{dp}f}%"


def fdate(s):
    try:
        d = date.fromisoformat(str(s)[:10])
        return f"{d.day} {d:%b %Y}"
    except Exception:
        return str(s or "")


def verdict(a: dict | None, flags: list[dict]) -> tuple[str, str]:
    if not a or a.get("incomplete"):
        miss = ", ".join((a or {}).get("missing") or ["site details"])
        return "Needs data", f"The appraisal cannot be relied on until {miss} is added."
    hi = [f for f in flags if f.get("severity") == "High"]
    if a["viable"] and not hi:
        return "Pursue", "The scheme meets the return target at the asking price and no high severity risks are open."
    if a["viable"]:
        return "Pursue with conditions", "Returns meet the target at the asking price, but high severity risks need to be resolved before commitment."
    if a["max_bid"] > 0:
        return "Renegotiate", f"Returns fall short of the target at the asking price. The ceiling that meets the target is {money(a['max_bid'])}."
    return "Pass", "No positive land value remains once the target return is met."


def _shade(cell, hex_):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_)
    tcPr.append(shd)


def _borders(table):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tbl = table._tbl
    pr = tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "single")
        e.set(qn("w:sz"), "4")
        e.set(qn("w:color"), "D0D0D0")
        b.append(e)
    pr.append(b)


def _fix_width(table, widths_cm):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm
    pr = table._tbl.tblPr
    for old in pr.findall(qn("w:tblW")):
        pr.remove(old)
    w = OxmlElement("w:tblW")
    w.set(qn("w:w"), str(int(sum(widths_cm) * 567)))
    w.set(qn("w:type"), "dxa")
    pr.append(w)
    lay = OxmlElement("w:tblLayout")
    lay.set(qn("w:type"), "fixed")
    pr.append(lay)
    for j, x in enumerate(widths_cm):
        table.columns[j].width = Cm(x)


def build(pack: dict) -> bytes:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt, RGBColor

    s, ev, pl, st, dd, inv = pack["site"], pack["ev"], pack["planning"], pack.get("structure") or {}, pack.get("dd") or {}, pack.get("investor") or {}
    a = ev.get("appraisal") or {}
    full = pack.get("full") or a
    flags = ev.get("flags") or []
    strat_label = pack["strategies"].get(ev["strategy"], ev["strategy"])
    vd, why = verdict(a, flags)

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2)
    sec.top_margin, sec.bottom_margin = Cm(1.8), Cm(1.8)
    base = doc.styles["Normal"]
    base.font.name, base.font.size = "Arial", Pt(10)
    base.paragraph_format.space_after = Pt(6)
    for name, size in (("Heading 1", 13), ("Heading 2", 11)):
        h = doc.styles[name]
        h.font.name, h.font.size, h.font.bold, h.font.italic = "Arial", Pt(size), True, False
        h.font.color.rgb = RGBColor(0, 0, 0)
        h.paragraph_format.space_before, h.paragraph_format.space_after = Pt(14), Pt(4)

    def para(text="", bold=False, size=None, color=None, after=None, align=None):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.bold = bold
        if size:
            r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
        if after is not None:
            p.paragraph_format.space_after = Pt(after)
        if align:
            p.alignment = align
        return p

    def table(rows, header=True, widths=None, align_right=(), bold_first_col=False, font=9):
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        _borders(t)
        t.autofit = False
        widths = widths or [17.0 / len(rows[0])] * len(rows[0])
        _fix_width(t, widths)
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                c = t.cell(i, j)
                c.text = ""
                p = c.paragraphs[0]
                p.paragraph_format.space_after = Pt(1)
                r = p.add_run(str(val))
                r.font.size = Pt(font)
                if header and i == 0:
                    r.bold = True
                    _shade(c, GREY)
                if bold_first_col and j == 0 and not (header and i == 0):
                    r.bold = True
                if j in align_right and not (header and i == 0 and False):
                    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                if widths:
                    c.width = Cm(widths[j])
        doc.add_paragraph().paragraph_format.space_after = Pt(2)
        return t

    # ---------- masthead
    band = doc.add_table(rows=1, cols=1)
    c = band.cell(0, 0)
    _shade(c, ORANGE)
    c.text = ""
    r = c.paragraphs[0].add_run("easyDevelopment")
    r.bold, r.font.size, r.font.color.rgb = True, Pt(14), RGBColor(255, 255, 255)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    para("Investment committee paper", bold=True, size=20, after=2)
    para(s.get("name", "Site"), bold=True, size=14, after=2)
    para(s.get("address", ""), color="595959", after=8)
    who = " · ".join(x for x in [inv.get("name"), inv.get("firm")] if x)
    table([["Date", f"{date.today().day} {date.today():%B %Y}"], ["Strategy", strat_label], ["Prepared by", who or "Not stated"], ["Status", "Draft for committee discussion"]], header=False, widths=[4, 13], bold_first_col=True)

    # ---------- 1 recommendation
    doc.add_heading("1. Recommendation", 1)
    table([["Recommendation", vd], ["Basis", why]] + ([["Offer", f"Open at {money(a['opening_offer'])}. Hold a ceiling of {money(a['walk_away'])}."]] if a and not a.get("incomplete") and a.get("max_bid", 0) > 0 else []), header=False, widths=[4, 13], bold_first_col=True)
    hi = [f for f in flags if f.get("severity") == "High"]
    if hi:
        para("High severity risks to resolve before commitment: " + "; ".join(f["flag"] for f in hi) + ".")

    # ---------- 2 proposal
    doc.add_heading("2. The proposal", 1)
    if a and not a.get("incomplete"):
        rows = [["Measure", "Value"], ["Units", f"{a['units']}"], ["Gross development value", money(a["gdv"])], ["Land price tested", money(a["asking"])],
                ["Total cost including finance", money(a["total_cost"])], ["Profit at asking", f"{money(a['profit'])} ({pct(a['profit_on_gdv'] if a['profit_basis'] == 'gdv' else a['profit_on_cost'])} on {'GDV' if a['profit_basis'] == 'gdv' else 'cost'}; target {pct(a['target_profit'], 0)})"],
                ["Residual land value (maximum bid)", money(a["rlv"])], ["Levered IRR", pct(a.get("irr_levered"))], ["Equity multiple", f"{a['equity_multiple']:.2f}x"],
                ["Peak equity", money(a["peak_equity"])], ["Hold period", f"{a['months_land']:.0f} months from acquisition to final receipt"]]
        if ev["strategy"] != "develop_sell":
            rows.insert(6, ["Yield on cost", pct(a["yield_on_cost"], 2)])
        table(rows, widths=[7, 10], bold_first_col=True)
    else:
        para(why)
    if s.get("description"):
        para(s["description"])

    # ---------- 3 site and market
    doc.add_heading("3. Site and market", 1)
    facts = [("Property type", s.get("property_type")), ("Tenure", s.get("tenure")), ("Existing use", s.get("existing_use")), ("Site area", f"{s['site_ha']} ha" if s.get("site_ha") else ""),
             ("Existing floor area", f"{s['existing_sqft']:,.0f} sq ft" if s.get("existing_sqft") else ""), ("Local authority", s.get("la")), ("Vendor", s.get("vendor")),
             ("Marketing", s.get("marketing")), ("Bid deadline", fdate(s.get("bid_deadline")) if s.get("bid_deadline") else ""), ("Agent", (pack.get("contact") or {}).get("firm")),
             ("Utilities", s.get("utilities")), ("Access", s.get("access"))]
    facts = [[k, v] for k, v in facts if v]
    if facts:
        table(facts, header=False, widths=[4.5, 12.5], bold_first_col=True)
    lr = s.get("land_registry")
    if lr:
        sm = lr["summary"]
        para(f"HM Land Registry sales in {lr['sector']} (pulled {fdate(lr['fetched'])}): {sm['n']} sales, of which {sm['new_build_n']} new build. "
             + (f"Median £{sm['median_psf']:.0f} per sq ft" + (f" and £{sm['median_psf_flats']:.0f} for flats." if sm.get("median_psf_flats") else ".") if sm.get("median_psf") else "Floor areas were not matched, so no £ per sq ft is quoted."))
    if s.get("comps"):
        table([["Type", "Evidence", "Detail", "Metric", "Date"]] + [[c["kind"], c["address"], c["detail"], c["metric"], c["date"]] for c in s["comps"]], widths=[2.5, 4.5, 5.5, 2.5, 2])
    para(f"The appraisal uses £{s.get('sales_psf') or pack['assumptions']['sales_psf']:.0f} per sq ft for sales" + (f" and £{s.get('rent_psf') or pack['assumptions']['rent_psf']:.1f} per sq ft for rent." if ev["strategy"] != "develop_sell" else "."))
    sc = pack.get("scheme_comps")
    if sc and sc.get("summary", {}).get("n"):
        m = sc["summary"]
        para(f"Nearby schemes within {m['radius_km']:g} km: {m['n']} recorded" + (f", median density {m['median_density']:.0f} units per ha" if m.get("median_density") else "") + (f", median £{m['median_psf']:.0f} per sq ft" if m.get("median_psf") else "") + ".")
        table([["Scheme", "Status", "Units", "Density", "Distance", "Source"]] + [[x["name"], x["kind"], x.get("units") or "", f"{x['density']:.0f}/ha" if x.get("density") else "", f"{x['distance_km']:.1f} km", x["source"]] for x in sc["items"][:8]], widths=[6, 2.6, 1.6, 2, 2, 3])

    # ---------- 4 planning
    doc.add_heading("4. Planning position", 1)
    ro = pl.get("read_out") or {}
    para(f"Status: {ro.get('status') or s.get('planning_status') or 'Unknown'}. Planning risk: {ro.get('risk') or 'not assessed'}." + (f" Permission expires {fdate(ro['permission_expiry'])}." if ro.get("permission_expiry") else ""))
    for x in ro.get("points", []):
        d = next((d for d in (s.get("docs") or []) if d["id"] == x.get("doc")), None)
        para(f"{x['level']}: {x['text']}" + (f" (source: {d.get('title') or d['name']})" if d else ""), after=2)
    an = pl.get("analysis")
    if an:
        para(f"Document analysis ({an.get('_engine', 'keyword screen')}, {an.get('n_docs', '')} documents): {an.get('summary', '')}")
        if an.get("approval_likelihood") is not None:
            para(f"Approval likelihood: {an['approval_likelihood']}%. {an.get('likelihood_rationale') or ''}")
    apps = pl.get("apps") or []
    if apps:
        doc.add_heading("Application record", 2)
        table([["Reference", "Status", "Submitted", "Decided", "Description"]] + [[h.get("ref", ""), h.get("status", ""), fdate(h.get("submitted")), fdate(h.get("decided")), h.get("description", "")] for h in apps], widths=[2.8, 2.5, 2.2, 2.2, 7.3])
    cons = pl.get("consultees") or []
    if cons:
        doc.add_heading("Consultee responses", 2)
        table([["Consultee", "Stance", "Summary", "Date"]] + [[c.get("body", ""), c.get("stance", ""), c.get("summary", ""), fdate(c.get("date"))] for c in cons], widths=[3, 2.6, 9.3, 2.1])

    # ---------- 5 risks
    doc.add_heading("5. Key risks", 1)
    docname = lambda i: next((d.get("title") or d["name"] for d in (s.get("docs") or []) if d["id"] == i), "")
    risk_rows = [["Risk", "Severity", "Mitigation", "Source"]]
    for f in flags:
        risk_rows.append([f"{f['flag']}. {f.get('why', '')}", f["severity"], f.get("mitigation", ""), ""])
    for x in ro.get("points", []):
        if x.get("level") in ("High", "Medium"):
            risk_rows.append([x["text"], x["level"], "", docname(x.get("doc")) or "Planning record"])
    for x in (an or {}).get("constraints", []):
        risk_rows.append([f"{x.get('item', '')}. {x.get('note', '')}", x.get("severity", ""), "", docname(x.get("source_doc")) or x.get("source_ref", "")])
    for i in [x for x in dd.get("items", []) if x["status"] == "Issue"]:
        risk_rows.append([f"Diligence issue: {i['item']}. {i.get('note', '')}", "Open", "", "Diligence tracker"])
    if len(risk_rows) > 1:
        table(risk_rows, widths=[7, 1.8, 5.5, 2.7])
    else:
        para("No risks are recorded on the file. That reflects the data held, not a clean bill of health.")

    # ---------- 6 appraisal
    doc.add_heading("6. Financial appraisal", 1)
    if a and not a.get("incomplete"):
        table([["Cost line", "Amount", "Share of GDV"]] + [[n, money(v), pct(v / a["gdv"]) if a["gdv"] else ""] for n, v in [
            ("Land and acquisition costs", a["land_cost"]), ("Land finance", a["land_finance"]), ("Build or refurbishment", a["build"]), ("Contingency", a["contingency"]),
            ("Professional fees", a["fees"]), ("S106 and CIL", a["s106"] + a["cil"]), ("Build finance", a["build_finance"]), ("Sales costs", a["sales_costs"]), ("Total cost", a["total_cost"])]] + [["Gross development value", money(a["gdv"]), "100.0%"]], widths=[8, 4.5, 4.5], align_right=(1, 2))
        keyA = pack["assumptions"]
        table([["Assumption", "Value"], ["Build cost per sq ft GIA", f"£{keyA['build_psf']:.0f}"], ["Affordable housing", pct(keyA["affordable_pct"], 0)], ["S106 per unit", money(keyA["s106_per_unit"])],
               ["Contingency and fees", f"{pct(keyA['contingency_pct'], 1)} and {pct(keyA['fees_pct'], 1)} of build"], ["Build period", f"{keyA['build_months']:.0f} months"], ["Planning period", f"{keyA['planning_months']:.0f} months"],
               ["Finance rate", pct(keyA["finance_rate"])], ["Exit yield", pct(keyA["exit_yield"], 2)] if ev["strategy"] != "develop_sell" else ["Sales period", f"{keyA['sales_months']:.0f} months"]], widths=[8, 9])

    # ---------- 7 sensitivities
    sens = pack.get("sens")
    if sens:
        doc.add_heading("7. Sensitivities", 1)
        para(f"Profit on {a['profit_basis'].upper() if a['profit_basis'] == 'gdv' else 'cost'} with the land price held at {money(a.get('asking') or a.get('rlv'))}. Rows: {sens['ylabel']}. Columns: {sens['xlabel']}. Target {pct(a['target_profit'], 0)}.")
        hdr = [""] + [f"{x * 100:+.0f}%" for x in sens["x"]]
        table([hdr] + [[f"{y * 100:+.0f}%"] + [f"{v * 100:.1f}%" for v in row] for y, row in zip(sens["y"], sens["z"])], align_right=tuple(range(1, len(hdr))), font=8.5)

    # ---------- 8 funding
    doc.add_heading("8. Funding requirement", 1)
    if a and not a.get("incomplete"):
        A = pack["assumptions"]
        rows = [["Item", "Amount"], ["Peak equity requirement", money(a["peak_equity"])], ["Senior debt at peak", f"{money(full.get('senior_peak'))} at {pct(A['finance_rate'])}, {pct(A['ltc'], 0)} of cost"]]
        if A.get("mezz_ltc"):
            rows.append(["Mezzanine at peak", f"{money(full.get('mezz_peak'))} at {pct(A['mezz_rate'])}"])
        rows += [["Arrangement fee", money(a.get("debt_fee"))], ["Cost of equity", pct(A["cost_of_equity"])], ["NPV of equity at that rate", money(a.get("npv_equity"))]]
        table(rows, widths=[7, 10], bold_first_col=True)
        if inv.get("active") and inv.get("fund_size"):
            share = a["peak_equity"] / (inv["fund_size"] * 1e6) * 100
            para(f"Peak equity is {share:.1f}% of the {inv['fund_size']:g}m fund. {('This is above the ' + str(inv.get('max_deal_pct_fund')) + '% single deal limit.') if inv.get('max_deal_pct_fund') and share > inv['max_deal_pct_fund'] else ''}".strip())
        fit = ev.get("fit") or {}
        if fit.get("active") and fit.get("checks"):
            doc.add_heading("Fit with mandate", 2)
            table([["Test", "Result", "Detail"]] + [[k["name"], "Pass" if k["ok"] is True else "Fail" if k["ok"] is False else "n/a", k["detail"]] for k in fit["checks"]], widths=[4.5, 1.8, 10.7])
    lender = st.get("lender")
    if lender:
        doc.add_heading("Lender tests", 2)
        table([["Covenant", "Position", "Limit", "Result"]] + [[t["name"], f"{t['value']:.1f}{t['unit']}", f"{'max' if t['kind'] == 'max' else 'min'} {t['limit']:.1f}{t['unit']}", "Pass" if t["ok"] else "Breach"] for t in lender["tests"]], widths=[7, 3.3, 3.7, 3])
    wf = st.get("waterfall")
    if wf:
        doc.add_heading("Equity waterfall", 2)
        t = wf["terms"]
        para(f"Sponsor co-invests {t['sponsor_coinvest']:.0f}% of equity. " + " ".join(f"Above {x['hurdle']:.1f}% IRR the sponsor takes {x['promote']:.0f}%." for x in t["tiers"]))
        table([["", "Invested", "Returned", "Profit", "IRR", "Multiple"]] + [[n, money(w["invested"]), money(w["returned"]), money(w["profit"]), pct(w["irr"]), f"{w['multiple']:.2f}x" if w["multiple"] else "n/a"] for n, w in (("All equity", wf["total"]), ("Investor", wf["investor"]), ("Sponsor", wf["sponsor"]))], widths=[3.5, 3, 3, 3, 2.2, 2.3], align_right=(1, 2, 3, 4, 5))
        para(f"Promote paid to the sponsor: {money(wf['promote'])}, which is {wf['promote_share_of_profit'] * 100:.0f}% of total equity profit.")

    # ---------- 9 build cost
    bc = pack.get("cost_benchmark")
    if bc:
        doc.add_heading("9. Build cost check", 1)
        para(f"Benchmark for {bc['label'].lower()} in {bc['region']}: £{bc['low']}* to £{bc['high']}* per sq ft, midpoint £{bc['mid']}*. The appraisal uses £{pack['assumptions']['build_psf']:.0f} per sq ft before externals.")
        para(costs.FOOTNOTE, size=8.5, color="595959")

    # ---------- 10 diligence
    doc.add_heading("10. Due diligence status", 1)
    if dd.get("summary"):
        sm = dd["summary"]
        para(f"{sm['done']} of {sm['total']} items complete ({sm['pct']}%). {sm['issues']} flagged as issues and {sm['overdue']} overdue.")
        open_items = [i for i in dd["items"] if i["status"] not in ("Done", "Not applicable")]
        if open_items:
            table([["Category", "Item", "Status", "Owner", "Due"]] + [[i["category"], i["item"], i["status"], i.get("owner", ""), fdate(i.get("due"))] for i in open_items[:25]], widths=[2.8, 8.2, 2.3, 2, 1.7], font=8.5)
    else:
        para("The diligence tracker has not been opened for this site.")

    # ---------- 11 next steps
    doc.add_heading("11. Next steps", 1)
    steps = [x for x in (an or {}).get("next_steps", [])]
    if vd in ("Pursue", "Pursue with conditions") and a and not a.get("incomplete"):
        steps = [f"Submit an offer at {money(a['opening_offer'])}, with authority to go to {money(a['walk_away'])}."] + steps
    if vd == "Renegotiate":
        steps = [f"Go back to the agent with an offer no higher than {money(a['max_bid'])}, or find cost or value evidence that closes the gap."] + steps
    if hi:
        steps.append("Close out the high severity risks in section 5 before exchange.")
    steps.append("Commission a quantity surveyor's cost plan and an independent valuation.")
    for i, x in enumerate(steps, 1):
        para(f"{i}. {x}", after=2)

    # ---------- appendix
    if s.get("docs"):
        doc.add_heading("Appendix: documents on file", 1)
        table([["Document", "Category", "Date"]] + [[d.get("title") or d["name"], d["category"], fdate(d.get("date"))] for d in s["docs"]], widths=[9, 5, 3])
    para("Figures marked * are indicative. Appraisal outputs depend on the assumptions shown and on data held at the date above.", size=8.5, color="595959")

    # footer with page label
    for section in doc.sections:
        fp = section.footer.paragraphs[0]
        fp.text = f"easyDevelopment · {s.get('name', '')} · Draft for committee discussion"
        for r in fp.runs:
            r.font.size = Pt(8)
            r.font.color.rgb = RGBColor(0x59, 0x59, 0x59)

    bio = io.BytesIO()
    doc.save(bio)
    return bio.getvalue()
