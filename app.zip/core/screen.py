"""Screen search results for viability, and put a search in the context of the investor's mandate and portfolio.

For each candidate the screen finds the council area (postcodes.io), reads the local UK House Price Index, builds a
default schedule of homes, prices each home type from the index and runs the appraisal with no land price, so the
result is the residual land value: what a developer could pay and still make the target return. Allowances for the
constraints found in the area search (flood, heritage, ecology and so on) come from the same rules as the Suggested
adjustments card. Values rest on the council-wide average price, so treat them as a ranking aid, not a valuation.
"""
from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor

from . import areasearch, datasources as ds, investor as inv, marketmix, suggest, typology
from .appraisal import appraise

JOB = {"running": False, "step": "", "done": 0, "total": 0, "results": {}, "error": ""}
_lock = threading.Lock()
_HPI: dict[str, dict | None] = {}

CONSTRAINT_ITEMS = {"green_belt": "green-belt", "sssi": "site-of-special-scientific-interest", "ancient_woodland": "ancient-woodland", "national_park": "national-park", "aonb": "area-of-outstanding-natural-beauty",
                    "conservation_area": "conservation-area", "spa": "special-protection-area", "sac": "special-area-of-conservation", "listed": "listed-building-outline", "aqma": "air-quality-management-area"}

REGION_CENTRES = {"London": (51.5074, -0.1278, "London"), "South East": (51.4543, -0.9781, "Reading"), "South West": (51.4545, -2.5879, "Bristol"), "East of England": (52.2053, 0.1218, "Cambridge"),
                  "East Midlands": (52.9548, -1.1581, "Nottingham"), "West Midlands": (52.4862, -1.8904, "Birmingham"), "North West": (53.4808, -2.2426, "Manchester"),
                  "Yorkshire and the Humber": (53.8008, -1.5491, "Leeds"), "North East": (54.9783, -1.6178, "Newcastle upon Tyne")}


def _hpi(district: str) -> dict | None:
    if district not in _HPI:
        try:
            _HPI[district] = ds.hpi(district)
        except Exception:
            _HPI[district] = None
    return _HPI[district]


def _pack_from(c: dict, hpi: dict | None) -> dict:
    items = [{"id": CONSTRAINT_ITEMS[h["key"]], "status": "hit", "label": h["label"]} for h in c.get("constraints", []) if h["key"] in CONSTRAINT_ITEMS]
    flags = {}
    for h in c.get("constraints", []):
        if h["key"] == "flood":
            flags["flood_zone"] = "3" if h["label"].endswith("3") else "2"
    return {"items": items, "flags": flags, "hpi": hpi or {}}


def screen_one(c: dict, strategy: str, base: dict, investor_profile: dict | None = None, pipeline: list[dict] | None = None) -> dict:
    out: dict = {"id": c["id"], "ok": False}
    try:
        g = ds.geography(c["lat"], c["lon"])
    except Exception as e:
        return {**out, "error": f"No council area found: {str(e)[:80]}"}
    hpi = _hpi(g.get("district") or "")
    site = areasearch.to_site(c, strategy)
    site["postcode"] = g.get("postcode") or ""
    site["la"] = g.get("district") or ""
    pack = _pack_from(c, hpi)
    site["data_pack"] = pack
    if hpi is None:
        return {**out, "error": "No house price index for the council area", "district": g.get("district"), "region": inv.region_of(site)}
    typ = typology.normalise(typology.default_typology(site), site)
    calc = typology.analyse(typ, site)
    prices = marketmix.price_units(typ, calc, site, 0.0)
    rates = marketmix.build_rates(typ, calc, site, strategy, inv.region_of(site), base["build_psf"])
    marketmix.apply(typ, prices, rates, "both", True)
    typology.apply_to_site(site, typ)
    a = dict(base)
    allowances = []
    for it in suggest.rules(site, pack, None, a):
        for ch in it["changes"]:
            a[ch["key"]] = a.get(ch["key"], 0) + ch["delta"]
        allowances.append(it["title"])
    try:
        ap = appraise(site, a, strategy)
    except Exception as e:
        return {**out, "error": f"Appraisal failed: {str(e)[:80]}"}
    if [m for m in ap.get("missing", []) if m != "asking price"]:
        return {**out, "error": "Not enough information to appraise"}
    ha = c.get("ha") or (site["units"] / a["density_dph"] if site.get("units") else None)
    rlv = ap["rlv"]
    fit = None
    if investor_profile and investor_profile.get("active"):
        f = inv.mandate_fit(site, {"strategy": strategy, "appraisal": None}, investor_profile)
        fit = {"score": f["score"], "label": f["label"], "hard_fail": f.get("hard_fail"), "fails": [k["name"] for k in f["checks"] if k["ok"] is False]}
    region = inv.region_of(site)
    return {"id": c["id"], "ok": True, "district": g.get("district"), "region": region, "postcode": site["postcode"], "units": ap["units"], "gia_sqft": round(ap["gia"]), "gdv": round(ap["gdv"]),
            "avg_price": round(ap["gdv"] / ap["units"]) if ap["units"] else None, "rlv": round(rlv), "rlv_raw": round(ap["rlv_raw"]), "rlv_per_home": round(rlv / ap["units"]) if ap["units"] else None,
            "rlv_per_ha": round(rlv / ha) if ha else None, "viable": rlv > 0, "allowances": allowances, "planning_months": round(a.get("planning_months", 0)), "index_month": hpi.get("month"),
            "basis": "Council-wide average prices from the UK House Price Index, default housing mix, build cost benchmark and no land price.", "fit": fit, "concentration": concentration(pipeline or [], region, ap["units"], strategy)}


def concentration(pipeline: list[dict], region: str | None, units: int, strategy: str) -> dict | None:
    live = [s for s in pipeline if s.get("stage") not in ("Rejected", "Lost", "Passed")]
    if len(live) < 3 or not region:
        return None
    here = [s for s in live if inv.region_of(s) == region]
    same_strat = [s for s in live if s.get("strategy") == strategy]
    share = len(here) / len(live)
    msg = []
    if share >= 0.4:
        msg.append(f"{len(here)} of your {len(live)} live sites are already in {region} ({share:.0%})")
    if len(same_strat) / len(live) >= 0.7:
        msg.append(f"{len(same_strat)} of {len(live)} use the same strategy")
    return {"share": round(share, 2), "n_region": len(here), "n_live": len(live), "text": "; ".join(msg)} if msg else {"share": round(share, 2), "n_region": len(here), "n_live": len(live), "text": ""}


def start(cands: list[dict], strategy: str, base: dict, investor_profile: dict | None, pipeline: list[dict], limit: int = 25) -> bool:
    with _lock:
        if JOB["running"]:
            return False
        rows = cands[:limit]
        JOB.update(running=True, error="", step="Screening", done=0, total=len(rows), results={})

    def go():
        try:
            with ThreadPoolExecutor(4) as ex:
                futs = [ex.submit(screen_one, c, strategy, base, investor_profile, pipeline) for c in rows]
                for f in futs:
                    try:
                        r = f.result()
                    except Exception as e:
                        r = {"id": "?", "ok": False, "error": str(e)[:80]}
                    JOB["results"][r["id"]] = r
                    JOB["done"] += 1
        except Exception as e:
            JOB["error"] = str(e)[:200]
        finally:
            JOB.update(running=False, step="Done")
    threading.Thread(target=go, daemon=True).start()
    return True


def mandate_criteria(p: dict) -> dict:
    """Search criteria implied by the investor profile."""
    ex = {"green_belt": "green_belt", "flood_zone_3": "flood", "listed": "listed", "conservation_area": "conservation_area"}
    excl = ["sssi", "ancient_woodland", "national_park"] + [ex[k] for k in p.get("exclusions", []) if k in ex]
    c = {"exclude": sorted(set(excl))}
    if p.get("min_units"):
        c["min_units"] = int(p["min_units"])
    if p.get("max_units"):
        c["max_units"] = int(p["max_units"])
    if p.get("planning_tolerance") == "Consented":
        c["consented"] = "yes"
    regions = [{"region": r, "lat": REGION_CENTRES[r][0], "lon": REGION_CENTRES[r][1], "town": REGION_CENTRES[r][2]} for r in p.get("regions", []) if r in REGION_CENTRES]
    return {"criteria": c, "regions": regions, "strategy": (p.get("strategies") or ["develop_sell"])[0]}
