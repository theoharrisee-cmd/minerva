"""Funding and lender view.

Sets the debt package against the programme: how much senior and mezzanine debt, at what cost, drawn how, and what it
does to returns. Terms live in the appraisal assumptions (loan to cost, rates, arrangement fee) so every number in the
app agrees. Two extras are held on the site: how the facility draws (pro rata with equity, or equity first) and an exit fee.
"""
from __future__ import annotations

import io
from datetime import date

from . import programme, waterfall

EXTRA_KEYS = ("draw_mode", "exit_fee_pct")
ASSUMPTION_KEYS = ("ltc", "mezz_ltc", "finance_rate", "mezz_rate", "debt_fee_pct")
DRAW_MODES = {"pro_rata": "Pro rata with equity", "equity_first": "Equity first, then mezzanine, then senior"}

PACKAGES = [
    ("No debt", {"ltc": 0.0, "mezz_ltc": 0.0}),
    ("Senior 50% of cost", {"ltc": 0.50, "mezz_ltc": 0.0}),
    ("Senior 60% of cost", {"ltc": 0.60, "mezz_ltc": 0.0}),
    ("Senior 60% and mezzanine 10%", {"ltc": 0.60, "mezz_ltc": 0.10}),
]


def clean(d: dict | None) -> tuple[dict, dict]:
    """Split what the user sent into assumption overrides and site-level extras."""
    d = d or {}
    ovr, extra = {}, {}
    for k in ASSUMPTION_KEYS:
        if d.get(k) in (None, ""):
            continue
        v = float(d[k])
        if k in ("ltc", "mezz_ltc"):
            v = v / 100 if v > 1 else v
            v = max(0.0, min(0.9, v))
        else:
            v = v / 100 if v > 0.5 else v
            v = max(0.0, min(0.5, v))
        ovr[k] = v
    if d.get("draw_mode") in DRAW_MODES:
        extra["draw_mode"] = d["draw_mode"]
    if d.get("exit_fee_pct") not in (None, ""):
        v = float(d["exit_fee_pct"])
        extra["exit_fee_pct"] = max(0.0, min(0.1, v / 100 if v > 0.1 else v))
    if (ovr.get("ltc", 0) + ovr.get("mezz_ltc", 0)) > 0.9:
        raise ValueError("Senior and mezzanine loan to cost cannot together exceed 90%")
    return ovr, extra


def sources_uses(ap: dict) -> dict:
    fin = ap.get("land_finance", 0) + ap.get("build_finance", 0)
    uses = [("Land and acquisition costs", ap["land_cost"]), ("Construction and contingency", ap.get("build", 0) + ap.get("contingency", 0)),
            ("Professional fees", ap.get("fees", 0)), ("S106 and CIL", ap.get("s106", 0) + ap.get("cil", 0)),
            ("Finance: interest", ap.get("interest_total", 0)), ("Finance: arrangement and exit fees", (ap.get("debt_fee") or 0) + (ap.get("exit_fees") or 0))]
    if ap.get("strategy") == "develop_sell":
        uses.append(("Sales and marketing costs", ap.get("sales_costs", 0)))
    total = sum(v for _, v in uses)
    senior, mezz = ap.get("senior_peak", 0), ap.get("mezz_peak", 0)
    eq = ap.get("peak_equity", 0)
    return {"uses": [{"label": l, "value": v} for l, v in uses], "total_uses": total,
            "sources": [{"label": "Senior debt (peak)", "value": senior}, {"label": "Mezzanine (peak)", "value": mezz}, {"label": "Equity (peak)", "value": eq}],
            "note": "Debt is repaid from sales receipts, so the peak balances are what the lenders fund, and total uses include interest and fees rolled into the balances."}


def compare(site: dict, a: dict, strategy: str, appraise) -> list[dict]:
    """The same scheme under other debt packages, land price held fixed."""
    base = appraise(site, a, strategy)
    fixed = base["tested_land_price"]
    out = []
    for name, over in PACKAGES + [("Current package", {})]:
        r = appraise(site, {**a, **over}, strategy, land_price=fixed)
        out.append({"name": name, "ltc": over.get("ltc", a["ltc"]), "mezz_ltc": over.get("mezz_ltc", a.get("mezz_ltc", 0)),
                    "profit": r["profit"], "equity_profit": r.get("equity_profit"), "irr_levered": r.get("irr_levered"), "irr_unlevered": r.get("irr_unlevered"), "equity_multiple": r.get("equity_multiple"),
                    "peak_equity": r.get("peak_equity"), "interest": r.get("interest_total"), "current": name == "Current package"})
    return out


def state(site: dict, a: dict, strategy: str, ap: dict, appraise, cov: dict | None = None) -> dict:
    e = ap.get("programme") or programme.effective(site, a, strategy)
    tl = programme.timeline(e)
    start = e.get("start") or programme.default_start()
    lend = waterfall.lender(ap, cov, strategy, a["finance_rate"], a.get("mezz_rate", 0.13))
    rows = []
    cum_draw = 0.0
    for r in ap["cashflow"]:
        cum_draw += r.get("draw", 0.0)
        rows.append({"month": r["month"], "label": programme.month_label(start, r["month"]), "draw": r.get("draw", 0.0), "debt": r.get("debt", 0.0),
                     "equity": min(0.0, r["levered"]), "cum_draw": cum_draw})
    budget = -sum(r["unlevered"] for r in ap["cashflow"] if r["unlevered"] < 0)
    senior_commit = a["ltc"] * budget
    mezz_commit = a.get("mezz_ltc", 0.0) * budget
    tenor = tl["end"] + 6
    dev = strategy == "develop_sell"
    return {
        "terms": {"ltc": a["ltc"], "mezz_ltc": a.get("mezz_ltc", 0.0), "finance_rate": a["finance_rate"], "mezz_rate": a.get("mezz_rate", 0.13),
                  "debt_fee_pct": a.get("debt_fee_pct", 0.0), "exit_fee_pct": a.get("exit_fee_pct", 0.0), "draw_mode": a.get("draw_mode", "pro_rata")},
        "draw_modes": DRAW_MODES, "lender": lend, "sources_uses": sources_uses(ap), "compare": compare(site, a, strategy, appraise),
        "schedule": rows, "peak_debt": max((r["debt"] for r in rows), default=0.0),
        "request": {"senior": senior_commit, "mezz": mezz_commit, "tenor_months": tenor, "budget": budget,
                    "repayment": "Sales receipts, with a cash sweep" if dev else "Sale or refinance at stabilisation"},
        "returns": {"irr_unlevered": ap.get("irr_unlevered"), "irr_levered": ap.get("irr_levered"), "equity_multiple": ap.get("equity_multiple"),
                    "peak_equity": ap.get("peak_equity"), "interest": ap.get("interest_total"), "fees": (ap.get("debt_fee") or 0) + (ap.get("exit_fees") or 0)},
        "prog_custom": programme.active(site), "start": start,
    }


def termsheet(pack: dict, fs: dict) -> bytes:
    """One page request to a lender, in Word, with the borrower details left as bracketed placeholders."""
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor

    from .committee import _borders, _fix_width, _shade, fdate, money

    s, ap = pack["site"], pack["full"]
    t, rq, ln = fs["terms"], fs["request"], fs["lender"]
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2)
    sec.top_margin = sec.bottom_margin = Cm(1.6)
    base = doc.styles["Normal"]
    base.font.name, base.font.size = "Aptos", Pt(10)
    base.paragraph_format.space_after = Pt(4)

    def para(text="", bold=False, size=None, color=None):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.bold = bold
        if size:
            r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
        return p

    def table(rows, widths):
        tb = doc.add_table(rows=len(rows), cols=2)
        _borders(tb)
        _fix_width(tb, widths)
        for i, (k, v) in enumerate(rows):
            for j, val in enumerate((k, v)):
                c = tb.cell(i, j)
                c.text = ""
                r = c.paragraphs[0].add_run(str(val))
                r.font.size = Pt(9.5)
                c.paragraphs[0].paragraph_format.space_after = Pt(0)
                if j == 0:
                    r.bold = True
                    _shade(c, "EDEDED")
        doc.add_paragraph().paragraph_format.space_after = Pt(2)

    tb = doc.add_table(rows=1, cols=1)
    _fix_width(tb, [17])
    c = tb.cell(0, 0)
    _shade(c, "FF6600")
    c.text = ""
    r = c.paragraphs[0].add_run("Request for indicative development finance terms")
    r.bold, r.font.size, r.font.color.rgb = True, Pt(14), RGBColor(255, 255, 255)
    p = c.add_paragraph()
    r = p.add_run(f"{s.get('name', 'Site')} · {s.get('postcode') or s.get('address') or ''}")
    r.font.size, r.font.color.rgb = Pt(10), RGBColor(255, 255, 255)
    para(f"Prepared {fdate(date.today().isoformat())}. Figures are the sponsor's current appraisal and will be refined with the lender's valuer and monitoring surveyor.", size=8.5, color="666666")

    para("Project", bold=True, size=11)
    units = ap.get("units")
    table([("Borrower", "[Special purpose vehicle name and company number]"), ("Sponsor", "[Sponsor name and track record]"),
           ("Site", f"{s.get('name', '')}, {s.get('address') or s.get('postcode') or ''}"), ("Scheme", f"{units:,} homes, {ap.get('gia', 0):,.0f} sq ft gross" if units else "To be confirmed"),
           ("Planning", s.get("planning_status") or "To be confirmed"), ("Gross development value", money(ap.get("gdv"))),
           ("Total cost including land", money(ap.get("total_cost"))), ("Profit on cost", f"{(ap.get('profit_on_cost') or 0) * 100:.1f}%")], [5, 12])
    para("Facility requested", bold=True, size=11)
    rows = [("Senior facility", f"{money(rq['senior'])} ({t['ltc'] * 100:.0f}% of cost, {ln['metrics']['senior_ltgdv']:.0f}% of GDV at peak)")]
    if rq["mezz"] > 0:
        rows.append(("Mezzanine facility", f"{money(rq['mezz'])} ({t['mezz_ltc'] * 100:.0f}% of cost)"))
    rows += [("Drawdown", fs["draw_modes"].get(t["draw_mode"], "")), ("Term", f"{rq['tenor_months']} months from first drawdown, including a six month sales tail"),
             ("Repayment", rq["repayment"]), ("Interest", f"{t['finance_rate'] * 100:.2f}% all-in on senior, rolled up"
              + (f"; {t['mezz_rate'] * 100:.2f}% on mezzanine" if rq["mezz"] > 0 else "")),
             ("Arrangement fee", f"{t['debt_fee_pct'] * 100:.2f}%"), ("Exit fee", f"{t['exit_fee_pct'] * 100:.2f}%"),
             ("Security", "First legal charge over the site, debenture and share charge over the borrower, and sponsor guarantee [to be agreed]")]
    table(rows, [5, 12])
    para("Programme", bold=True, size=11)
    e = ap.get("programme") or programme.effective(s, pack["assumptions"], ap.get("strategy"))
    if e:
        tl = programme.timeline(e)
        table([("Planning to grant", f"{e['planning_months']} months"), ("Pre-construction", f"{e['precon_months']} months"),
               ("Construction", f"{e['build_months']} months, practical completion in month {tl['pc']}"), ("Sales or lettings", f"{e['sales_months']} months")], [5, 12])
    para("Key ratios", bold=True, size=11)
    tests = [(x["name"], f"{x['value']:.1f}{x['unit']} against {x['limit']:.1f}{x['unit']} ({'within' if x['ok'] else 'outside'} the limit)") for x in ln["tests"]]
    table(tests or [("Ratios", "Not available")], [7, 10])
    para("Information available on request", bold=True, size=11)
    para("Appraisal with sensitivities, programme and cash flow, planning documents, site report, title and ownership, sponsor accounts and schedule of experience. "
         "Please send indicative terms, credit approval timing and the valuer and monitoring surveyor you would appoint.")
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
