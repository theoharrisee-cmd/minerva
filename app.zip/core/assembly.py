"""From a site to the land around it: title polygons, who owns them, who is assembling, and who is in trouble.

Sources: HM Land Registry title polygons (INSPIRE index, through planning.data.gov.uk), the CCOD and OCOD files
already loaded for company owned titles, and Companies House for the owning companies. The INSPIRE polygons carry
no title number and no owner, so a polygon cannot be tied to a title with certainty. Candidate owners are the
company owned titles at the postcodes around the site, ranked by how well the address fits. An official copy of the
register (£7) confirms the owner of any one parcel.
"""
from __future__ import annotations

import re
from datetime import date

from . import datasources as ds, geo, hmlr
from .areasearch import point_in_wkt


def site_ring(site: dict):
    """Ring of the site boundary as (lon, lat) points: the drawn boundary if there is one, otherwise None."""
    b = site.get("boundary")
    return [tuple(p) for p in b["ring"]] if b and b.get("ring") else None


def title_polygons(site: dict, radius_m: int = 250, limit: int = 80, fetch=None) -> list[dict]:
    """Registered title polygons within radius_m of the site, nearest first, marking the one under the site and those adjoining it."""
    lat, lon = site["lat"], site["lon"]
    fetch = fetch or ds.pdg_area
    b = geo.bbox(lat, lon, radius_m / 1000)
    ents = fetch("title-boundary", b, 200)
    ring0 = site_ring(site)
    out = []
    for e in ents:
        wkt = e.get("geometry") or ""
        ring = geo.polygon_of(wkt)
        if not ring:
            continue
        ha = geo.ring_area_ha(wkt)
        cen = geo.point_of(wkt)
        under = point_in_wkt(lon, lat, wkt)
        d = 0.0 if under else geo.dist_to_ring_m(lat, lon, ring)
        adj = False
        if ring0:
            a0 = geo.ring_to_xy(ring0, lat, lon)
            a1 = geo.ring_to_xy(ring, lat, lon)
            adj = any(geo.seg_dist(x, y, *a1[i], *a1[(i + 1) % len(a1)]) < 3 for x, y in a0 for i in range(len(a1))) or any(point_in_wkt(x, y, wkt) for x, y in ring0)
        out.append({"ref": str(e.get("reference") or e.get("entity") or ""), "ha": ha, "lat": cen[1] if cen else None, "lon": cen[0] if cen else None, "wkt": wkt, "distance_m": round(d), "under_site": under, "adjoins": adj})
    out.sort(key=lambda p: (not p["under_site"], not p["adjoins"], p["distance_m"]))
    return out[:limit]


def nearby_postcodes(lat: float, lon: float, radius_m: int = 300, limit: int = 30, fetch=None) -> list[str]:
    if fetch:
        return list(fetch(lat, lon, radius_m, limit))
    js = ds._http("https://api.postcodes.io/postcodes?" + ds._q(lon=lon, lat=lat, radius=min(2000, radius_m), limit=limit), ttl=30 * 86400)
    return [r["postcode"] for r in (js.get("result") or []) if r.get("postcode")]


def _fit(site_addr: str, row_addr: str) -> int:
    a = {t for t in re.sub(r"[^a-z0-9 ]", "", (site_addr or "").lower()).split() if len(t) > 2}
    b = {t for t in re.sub(r"[^a-z0-9 ]", "", (row_addr or "").lower()).split() if len(t) > 2}
    return len(a & b)


def owners(site: dict, radius_m: int = 300, postcodes=None, lookup=None) -> dict:
    """Company owned titles around the site, grouped by proprietor. Needs CCOD or OCOD data loaded."""
    if hmlr.meta()["rows"] == 0:
        return {"loaded": False, "titles": [], "groups": []}
    lookup = lookup or hmlr.by_postcode
    pcs = postcodes if postcodes is not None else nearby_postcodes(site["lat"], site["lon"], radius_m)
    own_pc = hmlr.norm_pc(site.get("postcode") or "")
    if own_pc and own_pc not in {hmlr.norm_pc(p) for p in pcs}:
        pcs = [site["postcode"], *pcs]
    titles = []
    for pc in dict.fromkeys(pcs):
        for r in lookup(pc):
            titles.append({**r, "fit": _fit(site.get("address", ""), r["address"]), "same_postcode": hmlr.norm_pc(pc) == own_pc})
    seen = set()
    uniq = []
    for t in sorted(titles, key=lambda t: (-t["same_postcode"], -t["fit"])):
        k = (t["title"], t["proprietor"])
        if k not in seen:
            seen.add(k)
            uniq.append(t)
    groups: dict[str, dict] = {}
    for t in uniq:
        g = groups.setdefault(hmlr._pkey(t["proprietor"]), {"proprietor": t["proprietor"], "company_no": t["company_no"], "category": t["category"], "nearby": 0, "titles": []})
        g["nearby"] += 1
        g["titles"].append(t["title"])
    for k, g in groups.items():
        try:
            g["total"] = len(hmlr.portfolio_of(g["proprietor"], 500))
        except Exception:
            g["total"] = g["nearby"]
        g["assembler"] = g["nearby"] >= 3
    gl = sorted(groups.values(), key=lambda g: (-g["nearby"], g["proprietor"]))
    return {"loaded": True, "titles": uniq[:80], "groups": gl[:25], "postcodes": len(set(pcs))}


def distress(co: dict, today: date | None = None) -> list[dict]:
    """Signals from a Companies House profile that a company owner may be a willing or forced seller."""
    today = today or date.today()
    out = []
    st = (co.get("status") or "").lower()
    if st and st != "active":
        out.append({"level": "High", "text": f"Company status is {st.replace('-', ' ')}"})
    if co.get("accounts_overdue"):
        out.append({"level": "Medium", "text": "Accounts are overdue"})
    ch = co.get("charges") or []
    live = [c for c in ch if (c.get("status") or "").lower() in ("outstanding", "part-satisfied")]
    if live:
        lenders = sorted({c.get("entitled") for c in live if c.get("entitled")})
        out.append({"level": "Low", "text": f"{len(live)} outstanding charge{'s' if len(live) != 1 else ''}" + (f" in favour of {', '.join(lenders[:2])}" if lenders else "")})
    new = [c for c in live if (c.get("created") or "") >= today.replace(year=today.year - 1).isoformat()]
    if len(new) >= 2:
        out.append({"level": "Medium", "text": f"{len(new)} charges registered in the last year"})
    if co.get("created") and co["created"] >= today.replace(year=today.year - 2).isoformat():
        out.append({"level": "Low", "text": f"Incorporated {co['created']}, so a recent vehicle for this land"})
    return out


def build(site: dict, cfg: dict | None = None, radius_m: int = 250, fetch_polys=None, lookup=None, pcs=None, company=None) -> dict:
    """Polygons, owner candidates, groups and Companies House signals for the site. Each step fails softly and says so."""
    notes = []
    polys = []
    try:
        polys = title_polygons(site, radius_m, fetch=fetch_polys)
        if not polys:
            notes.append("No title polygons were returned for this area.")
    except Exception as e:
        notes.append(f"Title polygons: {str(e)[:100]}")
    own = {"loaded": False, "titles": [], "groups": []}
    try:
        own = owners(site, radius_m + 50, pcs, lookup)
        if not own["loaded"]:
            notes.append("Load the CCOD and OCOD files on the Data sources page to see company owned titles.")
    except Exception as e:
        notes.append(f"Ownership: {str(e)[:100]}")
    key = (cfg or {}).get("ch_key")
    if company is None and key:
        company = lambda no: hmlr.company(no, key)  # noqa: E731
    if company:
        for g in own["groups"][:8]:
            no = g.get("company_no")
            if not no:
                continue
            try:
                co = company(no)
                g["company"] = {k: co.get(k) for k in ("name", "status", "created", "office", "has_charges", "url")}
                g["distress"] = distress(co)
            except Exception as e:
                g["distress_error"] = str(e)[:80]
    elif own["groups"]:
        notes.append("Add a Companies House key on the Data sources page to check the owning companies for charges and distress.")
    under = [p for p in polys if p["under_site"]]
    tot = sum(p["ha"] or 0 for p in under)
    return {"built": date.today().isoformat(), "radius_m": radius_m, "polygons": polys, "owners": own, "under_site_ha": round(tot, 2) if tot else None,
            "adjoining": sum(1 for p in polys if p["adjoins"] and not p["under_site"]), "notes": notes,
            "caveat": "Title polygons carry no owner. Owners shown are company owned titles at nearby postcodes; buy the official copy to confirm who owns a parcel."}


def to_parcels(site: dict, assembly: dict, refs: list[str], owner_by_ref: dict | None = None) -> int:
    """Add chosen polygons to the site's land assembly list. Returns the number added."""
    import uuid
    have = {p.get("ref") for p in site.get("parcels", [])}
    n = 0
    for p in assembly["polygons"]:
        if p["ref"] in refs and p["ref"] not in have:
            o = (owner_by_ref or {}).get(p["ref"]) or {}
            site.setdefault("parcels", []).append({"id": "p-" + uuid.uuid4().hex[:6], "ref": p["ref"], "address": "", "owner": o.get("proprietor", ""), "owner_type": "Company" if o.get("company_no") else "Unknown", "title_no": o.get("title", ""),
                                                   "area_ha": p["ha"], "status": "Not approached", "ask": None, "offer": None, "notes": "From the registered title polygon" + ("; owner is a candidate from CCOD, not confirmed" if o else ""), "lat": p["lat"], "lon": p["lon"]})
            n += 1
    return n
