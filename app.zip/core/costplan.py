"""Read a quantity surveyor's cost plan (Excel or CSV) and map it onto the appraisal.

The plan is read row by row: a description, an amount, and any total rows. Each line is given a kind (construction, contingency,
professional fees, levies and so on) from its wording, and you review and change those before anything is used. Construction
lines add up to the build cost, contingency and fees become percentages of it, and lines that do not belong in a build cost
(land, finance, sales costs, VAT) are left out. Total rows are used only to check the sum. Nothing is written until you apply it.
"""
from __future__ import annotations

import csv
import io
import re
from datetime import datetime, timezone

from . import portfolio

SQM_TO_SQFT = 10.7639
KINDS = {"construction": "Construction", "contingency": "Contingency", "fees": "Professional fees", "levies": "S106 and CIL", "vat": "VAT",
         "land": "Land and acquisition", "finance": "Finance", "sales": "Sales and marketing", "total": "Total row"}
INCLUDED = ("construction", "contingency", "fees")
RULES = [
    ("total", r"^\s*(?:sub\s*-?\s*totals?|grand\s+totals?|totals?|summary)\b|\btotal\b(?!\s+(?:fee|prelim))"),
    ("contingency", r"contingenc|risk\s+(?:allowance|register|provision)|design\s+development\s+allowance"),
    ("fees", r"professional\s+fees?|consultants?|design\s+fees?|\bfees?\b|architect|structural\s+engineer|project\s+manage|planning\s+fees?"),
    ("levies", r"\bs\.?106\b|section\s+106|\bcil\b|levy|planning\s+obligation|highways?\s+contribution"),
    ("vat", r"\bvat\b"),
    ("land", r"\bland\b|acquisition|stamp\s+duty|\bsdlt\b|purchase\s+price"),
    ("finance", r"financ|interest|arrangement\s+fee|funding\s+cost"),
    ("sales", r"marketing|sales\s+agent|sales\s+legal|show\s*home|letting\s+agent"),
]
GROUPS = [("Substructure", r"substructure|foundation|piling|ground\s+floor\s+slab"), ("Superstructure", r"superstructure|frame|upper\s+floors?|roof|stairs?|external\s+walls?|windows?|external\s+doors?|internal\s+(?:walls?|doors?)"),
          ("Finishes and fittings", r"finish|fittings?|furnish|joinery|kitchens?|bathrooms?|decoration"), ("Services", r"services|mechanical|electrical|m\s*&\s*e|\bmep\b|plumbing|heating|lifts?|ventilation"),
          ("External works", r"external\s+works|site\s+works|landscap|drainage|roads?|utilities|surfacing|boundary|externals?"), ("Abnormals", r"abnormal|remediation|demolition|contamination|enabling|diversion"),
          ("Preliminaries and overheads", r"prelim|overhead|profit|\bohp\b|\bo\s*&\s*p\b|main\s+contractor")]


def _classify(label: str) -> str:
    for kind, pat in RULES:
        if re.search(pat, label, re.I):
            return kind
    return "construction"


def _group(label: str, heading: str) -> str:
    for g, pat in GROUPS:
        if re.search(pat, label, re.I) or re.search(pat, heading, re.I):
            return g
    return "Other construction"


def _grids(data: bytes, name: str) -> list[dict]:
    if name.lower().endswith((".csv", ".txt")):
        txt = data.decode("utf-8-sig", "ignore")
        try:
            dialect = csv.Sniffer().sniff(txt[:4000], delimiters=",;\t")
        except csv.Error:
            dialect = csv.excel
        rows = [r for r in csv.reader(io.StringIO(txt), dialect)]
        return [{"name": "CSV", "rows": rows}] if rows else []
    return portfolio.read_grids(data, max_rows=600, max_cols=30)


def _find_area(rows: list[list]) -> float | None:
    for r in rows[:80]:
        for j, c in enumerate(r):
            s = str(c or "")
            if re.search(r"\bgifa\b|\bgia\b|gross\s+internal|gross\s+floor\s+area|\bgfa\b", s, re.I):
                unit = re.search(r"sq\.?\s*ft|ft2|ft²|sqft", s, re.I) and "ft" or (re.search(r"m2|m²|sq\.?\s*m|sqm", s, re.I) and "m") or None
                for c2 in r[j + 1:j + 5]:
                    v = portfolio._to_number(c2)
                    if v and 30 <= v <= 5_000_000:
                        cellunit = unit or ("ft" if re.search(r"sq\.?\s*ft|ft2|ft²|sqft", " ".join(str(x or "") for x in r), re.I) else "m")
                        return v * (SQM_TO_SQFT if cellunit == "m" else 1)
    return None


def _header(rows: list[list]):
    for i, r in enumerate(rows[:40]):
        cells = [str(c or "").strip().lower() for c in r]
        if sum(1 for c in cells if c) >= 2 and any(re.search(r"total|amount|cost|£|value|sum", c) for c in cells) and any(re.search(r"description|element|item|works|trade|section", c) for c in cells):
            return i
    return None


def _columns(rows, hi):
    head = [str(c or "").strip().lower() for c in rows[hi]] if hi is not None else []
    width = max(len(r) for r in rows)
    body = rows[(hi + 1) if hi is not None else 0:]
    nums = {j: 0 for j in range(width)}
    texts = {j: 0 for j in range(width)}
    sums = {j: 0.0 for j in range(width)}
    for r in body[:400]:
        for j in range(min(width, len(r))):
            v = portfolio._to_number(r[j])
            if v is not None and not isinstance(r[j], bool):
                nums[j] += 1
                sums[j] += abs(v)
            elif isinstance(r[j], str) and len(r[j].strip()) > 2:
                texts[j] += 1
    label = max(texts, key=lambda j: (texts[j], -j)) if any(texts.values()) else 0
    cand = [j for j in range(width) if nums[j] >= 2 and j != label]
    rate = re.compile(r"per|/\s*m|/\s*sq|psf|rate|%|m2|m²|sqm|sq\s*m|sq\s*ft|qty|quantity")
    good = [j for j in cand if j < len(head) and re.search(r"total|amount|cost|£|value|sum", head[j]) and not rate.search(head[j])]
    if good:
        tot = [j for j in good if re.search(r"total", head[j])]
        amount = (tot or good)[-1]
    else:
        ok = [j for j in cand if not (j < len(head) and rate.search(head[j]))] or cand
        amount = max(ok, key=lambda j: sums[j]) if ok else None
    return label, amount, head


def parse_sheet(grid: dict) -> dict:
    rows = grid["rows"]
    hi = _header(rows)
    label_c, amt_c, head = _columns(rows, hi)
    if amt_c is None:
        return {"sheet": grid["name"], "items": [], "area_sqft": _find_area(rows), "warnings": ["No column of amounts was found on this sheet."]}
    scale = portfolio._scale_of(head[amt_c] if amt_c < len(head) else "")
    items, heading = [], ""
    for i, r in enumerate(rows[(hi + 1) if hi is not None else 0:], start=(hi + 2) if hi is not None else 1):
        if amt_c >= len(r) and label_c >= len(r):
            continue
        label = re.sub(r"\s+", " ", str((r[label_c] if label_c < len(r) else "") or "")).strip()
        raw = r[amt_c] if amt_c < len(r) else None
        v = portfolio._to_number(raw)
        if not label:
            continue
        if v is None or v == 0:
            if len(label) < 70 and not re.search(r"\d{4,}", label):
                heading = label
            continue
        v = v * scale
        kind = _classify(label)
        items.append({"i": len(items), "row": i, "label": label[:120], "amount": round(v, 2), "kind": kind, "group": _group(label, heading) if kind == "construction" else "", "heading": heading[:60], "on": kind in INCLUDED})
    return {"sheet": grid["name"], "items": items, "area_sqft": _find_area(rows), "warnings": [], "columns": {"amount": head[amt_c] if amt_c < len(head) else f"column {amt_c + 1}"}}


def parse(data: bytes, name: str, sheet: str | None = None) -> dict:
    grids = _grids(data, name)
    if not grids:
        raise ValueError("The file is empty")
    parsed = [parse_sheet(g) for g in grids]
    pick = next((p for p in parsed if p["sheet"] == sheet), None) if sheet else None
    if pick is None:
        pick = max(parsed, key=lambda p: sum(1 for x in p["items"] if x["kind"] == "construction"))
    pick["sheets"] = [{"name": p["sheet"], "lines": len(p["items"])} for p in parsed]
    if not pick["items"]:
        raise ValueError("No cost lines were found. The plan needs a description column and a column of amounts.")
    return pick


def summarise(plan: dict, site_gia: float | None = None) -> dict:
    items = plan.get("items") or []
    tot = lambda k: sum(x["amount"] for x in items if x["on"] and x["kind"] == k)
    build, cont, fees, lev = tot("construction"), tot("contingency"), tot("fees"), tot("levies")
    area = plan.get("area_sqft") or site_gia or None
    total_rows = [x for x in items if x["kind"] == "total"]
    warnings = list(plan.get("warnings") or [])
    for t in total_rows:
        if re.search(r"construction|building\s+works|works\s+cost|base\s+build|total\s+works", t["label"], re.I) and build and abs(build - 2 * t["amount"]) < 0.05 * t["amount"]:
            warnings.append(f"The construction lines add up to about twice the row \"{t['label']}\". Some lines may be counted under a heading and again as a subtotal. Switch one level off.")
            break
    recon = None
    cand = [t for t in total_rows if re.search(r"construction|building\s+works|works\s+cost|total\s+works|base\s+build", t["label"], re.I)]
    if cand and build:
        recon = {"label": cand[0]["label"], "plan": cand[0]["amount"], "lines": build, "diff": build - cand[0]["amount"]}
    if not recon:
        grand = [t for t in total_rows if not re.search(r"sub\s*-?\s*total", t["label"], re.I)]
        if grand:
            g = max(grand, key=lambda t: abs(t["amount"]))
            allon = sum(x["amount"] for x in items if x["on"] and x["kind"] != "total")
            if allon:
                recon = {"label": g["label"], "plan": g["amount"], "lines": allon, "diff": allon - g["amount"], "scope": "all lines"}
                if abs(allon - g["amount"]) > 0.02 * abs(g["amount"]):
                    warnings.append(f"The lines that are switched on add up to {allon:,.0f} but the row \"{g['label']}\" says {g['amount']:,.0f}. Check for lines that are missing, switched off or counted twice.")
    neg = [x for x in items if x["on"] and x["amount"] < 0]
    if neg:
        warnings.append(f"{len(neg)} line(s) are negative (for example \"{neg[0]['label']}\"). Brackets are read as credits. Check that a saving is meant to reduce the build cost.")
    groups: dict[str, float] = {}
    for x in items:
        if x["on"] and x["kind"] == "construction":
            groups[x["group"] or "Other construction"] = groups.get(x["group"] or "Other construction", 0) + x["amount"]
    return {"build": build, "contingency": cont, "fees": fees, "levies": lev, "contingency_pct": (cont / build) if build and cont else None, "fees_pct": (fees / build) if build and fees else None,
            "area_sqft": area, "psf": (build / area) if area and build else None, "groups": [{"group": g, "amount": v} for g, v in sorted(groups.items(), key=lambda kv: -kv[1])],
            "reconciliation": recon, "warnings": warnings, "excluded": sum(x["amount"] for x in items if not x["on"] and x["kind"] != "total")}


def ingest(site: dict, data: bytes, name: str, sheet: str | None = None) -> dict:
    plan = parse(data, name, sheet)
    prev = (site.get("costplan") or {}).get("applied")
    site["costplan"] = {"file": name, "sheet": plan["sheet"], "sheets": plan["sheets"], "items": plan["items"], "area_sqft": plan["area_sqft"], "columns": plan.get("columns"),
                        "warnings": plan["warnings"], "when": datetime.now(timezone.utc).isoformat(timespec="minutes"), "applied": prev}
    return site["costplan"]


def review(site: dict, rows: list[dict] | None, area_sqft) -> dict:
    """Store the changes made in the review table: each line's kind and whether it is used."""
    cp = site.get("costplan")
    if not cp:
        raise ValueError("No cost plan has been uploaded for this site")
    by = {r.get("i"): r for r in rows or []}
    for x in cp["items"]:
        r = by.get(x["i"])
        if not r:
            continue
        if r.get("kind") in KINDS:
            x["kind"] = r["kind"]
            x["group"] = x["group"] or (_group(x["label"], x.get("heading", "")) if x["kind"] == "construction" else "")
        if "on" in r:
            x["on"] = bool(r["on"]) and x["kind"] != "total"
        if x["kind"] == "total":
            x["on"] = False
    if area_sqft not in (None, ""):
        cp["area_sqft"] = max(0.0, float(area_sqft)) or None
    return cp


def apply(site: dict, base: dict) -> dict:
    """Write the plan into the appraisal: the build cost, and contingency and fee percentages where the plan states them."""
    cp = site.get("costplan")
    if not cp:
        raise ValueError("No cost plan has been uploaded for this site")
    sm = summarise(cp, site.get("gia_sqft"))
    if not sm["build"]:
        raise ValueError("No construction lines are switched on")
    ap = cp.get("applied") or {}
    prev = ap.get("previous") or {"build_cost_total": site.get("build_cost_total"), "ovr": {k: (site.get("ovr") or {}).get(k) for k in ("contingency_pct", "fees_pct")}}
    site["build_cost_total"] = round(sm["build"], 2)
    ovr = site.setdefault("ovr", {})
    wrote = ["build_cost_total"]
    for k in ("contingency_pct", "fees_pct"):
        if sm.get(k) is not None:
            ovr[k] = round(sm[k], 6)
            wrote.append(k)
    if sm["area_sqft"] and not site.get("gia_sqft"):
        site["gia_sqft"] = round(sm["area_sqft"])
        wrote.append("gia_sqft")
    cp["applied"] = {"when": datetime.now(timezone.utc).isoformat(timespec="minutes"), "build": sm["build"], "contingency_pct": sm["contingency_pct"], "fees_pct": sm["fees_pct"], "wrote": wrote, "previous": prev}
    return cp["applied"]


def clear(site: dict) -> bool:
    cp = site.get("costplan") or {}
    ap = cp.get("applied")
    if not ap:
        return False
    prev = ap.get("previous") or {}
    if prev.get("build_cost_total") is None:
        site.pop("build_cost_total", None)
    else:
        site["build_cost_total"] = prev["build_cost_total"]
    ovr = site.setdefault("ovr", {})
    for k in ("contingency_pct", "fees_pct"):
        v = (prev.get("ovr") or {}).get(k)
        if v is None:
            ovr.pop(k, None)
        else:
            ovr[k] = v
    if "gia_sqft" in (ap.get("wrote") or []):
        site.pop("gia_sqft", None)
    cp["applied"] = None
    return True


def state(site: dict, bench: dict | None = None) -> dict:
    cp = site.get("costplan")
    if not cp:
        return {"has": False}
    sm = summarise(cp, site.get("gia_sqft"))
    check = None
    if bench and sm["psf"]:
        lo, hi = bench["low"] * 0.75, bench["high"] * 1.25
        check = {"psf": sm["psf"], "low": bench["low"], "mid": bench["mid"], "high": bench["high"], "label": bench["label"],
                 "verdict": "well below the indicative range" if sm["psf"] < lo else "well above the indicative range" if sm["psf"] > hi else "within a reasonable distance of the indicative range"}
    return {"has": True, "file": cp["file"], "sheet": cp["sheet"], "sheets": cp.get("sheets") or [], "when": cp.get("when"), "items": cp["items"], "kinds": KINDS,
            "summary": sm, "applied": cp.get("applied"), "benchmark": check, "columns": cp.get("columns") or {}}
