"""Shortlist, activity log and email alerts.

A shortlisted site is checked for: price changes and withdrawal on its listing page, new or changed planning
applications on the site (planning.data.gov.uk, where the council publishes to it), key dates coming up, and
anything you or a colleague record against the site in the app. Each finding becomes an event. Unsent events
go out in a digest email when SMTP settings are present."""
from __future__ import annotations

import html as htmllib
import json
import re
import smtplib
import ssl
import threading
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage

from . import net

PDG = "https://www.planning.data.gov.uk"

DEFAULT_SETTINGS = {
    "enabled": False, "interval_hours": 6, "to": "", "from": "",
    "smtp_host": "", "smtp_port": 587, "smtp_user": "", "smtp_password": "", "smtp_tls": True,
    "digest_min_level": "info",   # info | important
    "last_run": "", "last_sent": "", "last_error": "",
}

LEVELS = {"info": 0, "important": 1}
_GONE = re.compile(r"\b(sold stc|sold subject to contract|under offer|sale agreed|sstc|no longer available|no longer on the market|withdrawn from sale|has been sold)\b", re.I)
_PRICE = re.compile(r"(?:guide price|asking price|offers (?:in excess of|over|around|invited)|price)\D{0,40}£\s?([\d][\d,\.]*)\s?(m\b|million)?", re.I)


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def add_event(site: dict, kind: str, title: str, detail: str = "", level: str = "info", key: str | None = None) -> dict | None:
    ev = site.setdefault("events", [])
    if key and any(e.get("key") == key for e in ev):
        return None
    e = {"id": uuid.uuid4().hex[:8], "ts": now(), "kind": kind, "title": title, "detail": detail, "level": level, "sent": False, "seen": False, "key": key or ""}
    ev.append(e)
    del ev[:-200]
    return e


def start(site: dict) -> None:
    site["watch"] = {"on": True, "since": now(), "last_check": "", "snap": snapshot(site), "dates_notified": []}
    add_event(site, "shortlist", "Added to shortlist", "You will be told about price changes, planning activity and key dates.", "info")


def stop(site: dict) -> None:
    if site.get("watch"):
        site["watch"]["on"] = False


def watched(site: dict) -> bool:
    return bool((site.get("watch") or {}).get("on"))


def note_change(site: dict, kind: str, title: str, detail: str = "", level: str = "info") -> None:
    """Record something done in the app against a watched site."""
    if watched(site):
        add_event(site, kind, title, detail, level)


def snapshot(site: dict) -> dict:
    return {"price": site.get("asking_price"), "stage": site.get("stage"), "planning_status": site.get("planning_status"),
            "apps": {a.get("ref", ""): a.get("status", "") for a in site.get("planning_history", [])},
            "listing": "unknown", "pd": {}}


def _money(x):
    return f"£{x:,.0f}" if x else "not stated"


def _page_price(text: str):
    m = _PRICE.search(text)
    if not m:
        return None
    try:
        v = float(m.group(1).replace(",", "").rstrip("."))
    except ValueError:
        return None
    if m.group(2):
        v *= 1e6
    return v if v >= 10000 else None


def check_listing(site: dict, fetch=net.fetch) -> list[dict]:
    out = []
    url = site.get("url")
    if not url or site.get("demo") or site.get("demo_rich") or not site.get("listing"):
        return out
    snap = site["watch"]["snap"]
    try:
        body = fetch(url, delay=1.0, ttl=0, use_cache=False)
    except net.Blocked as e:
        return [add_event(site, "listing_check", "Listing page could not be read", str(e), "info", key=f"blk-{date.today().isocalendar()[:2]}")]
    except Exception as e:
        msg = str(e)
        if "404" in msg or "410" in msg:
            return [add_event(site, "listing_gone", "Listing page has been removed", "The agent's page no longer loads. The site may have been withdrawn or sold.", "important", key="gone-404")]
        return out
    low = re.sub(r"\s+", " ", re.sub(r"(?is)<(script|style).*?</\1>", " ", body))
    text = htmllib.unescape(re.sub(r"<[^>]+>", " ", low))
    state = "live"
    m = _GONE.search(text)
    if m:
        state = m.group(1).lower()
    prev = snap.get("listing", "unknown")
    if state != prev and not (prev == "unknown" and state == "live"):
        if state != "live":
            out.append(add_event(site, "listing_status", f"Listing marked '{state}'", "The agent's page now carries this status.", "important"))
        else:
            out.append(add_event(site, "listing_status", "Listing is live again", "The agent's page no longer shows a sold or under offer status.", "important"))
    snap["listing"] = state
    price = _page_price(text)
    if price and site.get("asking_price") and abs(price - site["asking_price"]) / site["asking_price"] > 0.005 and snap.get("seen_price") != price:
        out.append(add_event(site, "price_change", f"Price now {_money(price)}", f"Held on file: {_money(site['asking_price'])}. The appraisal still uses the held price until you update it under Details.", "important", key=f"pr-{int(price)}"))
    if price:
        snap["seen_price"] = price
    return [e for e in out if e]


def check_planning(site: dict, get_json=net.get_json) -> list[dict]:
    out = []
    if site.get("lat") is None or site.get("demo_rich") or site.get("demo"):
        return out
    snap = site["watch"]["snap"]
    try:
        d = get_json(f"{PDG}/entity.json?dataset=planning-application&longitude={site['lon']}&latitude={site['lat']}&geometry_relation=intersects&limit=25", timeout=15)
    except Exception as e:
        snap["pd_error"] = str(e)[:120]
        return out
    snap.pop("pd_error", None)
    seen = snap.setdefault("pd", {})
    first = not seen and not snap.get("pd_primed")
    for ent in d.get("entities", []):
        ref = ent.get("reference") or ent.get("entity")
        if not ref:
            continue
        cur = {k: ent.get(k) for k in ("name", "description", "decision", "decision-date", "planning-decision", "entry-date", "start-date") if ent.get(k)}
        label = ent.get("description") or ent.get("name") or ""
        old = seen.get(str(ref))
        if old is None and not first:
            out.append(add_event(site, "planning_new", f"New planning application {ref}", label[:240], "important", key=f"pn-{ref}"))
        elif old is not None and old != cur:
            dec = cur.get("decision") or cur.get("planning-decision") or "updated"
            out.append(add_event(site, "planning_change", f"Planning application {ref} changed", f"Decision: {dec}. {label[:200]}", "important", key=f"pc-{ref}-{json.dumps(cur, sort_keys=True)[:60]}"))
        seen[str(ref)] = cur
    snap["pd_primed"] = True
    return [e for e in out if e]


def check_dates(site: dict, today: date | None = None) -> list[dict]:
    today = today or date.today()
    out = []
    dl = site.get("bid_deadline")
    items = [(k.get("date"), k.get("event")) for k in site.get("key_dates", [])]
    if dl:
        items.append((dl, "Bid deadline"))
    for d, ev in items:
        try:
            dd = date.fromisoformat(str(d)[:10])
        except ValueError:
            continue
        days = (dd - today).days
        long_dated = bool(re.search(r"expir|lapse", str(ev), re.I))
        window = 90 if long_dated else 14
        if 0 <= days <= window:
            out.append(add_event(site, "date", f"{ev} in {days} day{'s' if days != 1 else ''}", f"{dd:%d %B %Y}", "important" if days <= 7 or long_dated else "info", key=f"dt-{d}-{ev}"))
    return [e for e in out if e]


def check_site(site: dict, fetch=net.fetch, get_json=net.get_json, today: date | None = None) -> list[dict]:
    if not watched(site):
        return []
    w = site["watch"]
    w.setdefault("snap", snapshot(site))
    found = []
    found += check_listing(site, fetch)
    found += check_planning(site, get_json)
    found += check_dates(site, today)
    w["last_check"] = now()
    return found


# ------------------------------------------------------------------ digest and email

def pending(sites: list[dict], min_level: str = "info") -> list[tuple[dict, dict]]:
    lo = LEVELS.get(min_level, 0)
    return [(s, e) for s in sites for e in s.get("events", []) if not e.get("sent") and LEVELS.get(e.get("level", "info"), 0) >= lo and watched(s)]


def build_digest(items: list[tuple[dict, dict]], app_name: str = "easyDevelopment") -> tuple[str, str, str]:
    by: dict[str, list] = {}
    for s, e in items:
        by.setdefault(s["id"], []).append((s, e))
    n_sites, n_ev = len(by), len(items)
    subject = f"{app_name}: {n_ev} update{'s' if n_ev != 1 else ''} on {n_sites} shortlisted site{'s' if n_sites != 1 else ''}"
    lines, rows = [], []
    for sid, lst in by.items():
        s = lst[0][0]
        lines.append(f"{s.get('name', 'Site')} ({s.get('address', '')})")
        rows.append(f"<h3 style='margin:18px 0 6px;font-size:15px'>{htmllib.escape(s.get('name', 'Site'))}</h3><div style='color:#6E6E6E;font-size:12px;margin-bottom:6px'>{htmllib.escape(s.get('address', ''))}</div><ul style='padding-left:18px;margin:0'>")
        for _, e in lst:
            ts = e["ts"][:16].replace("T", " ")
            lines.append(f"  - {e['title']}" + (f": {e['detail']}" if e.get("detail") else "") + f" ({ts} UTC)")
            rows.append(f"<li style='margin:4px 0'><b>{htmllib.escape(e['title'])}</b>" + (f"<br><span style='color:#3D3D3D'>{htmllib.escape(e['detail'])}</span>" if e.get("detail") else "") + f"<br><span style='color:#8A8A8A;font-size:12px'>{ts} UTC</span></li>")
        rows.append("</ul>")
        lines.append("")
    text = f"Updates on your shortlist\n\n" + "\n".join(lines) + f"\nOpen {app_name} to see the full record. Planning data comes from planning.data.gov.uk where the council publishes to it, so check the council register for anything critical."
    body = ("<div style='font-family:Helvetica,Arial,sans-serif;max-width:600px;margin:auto;color:#111'>"
            "<div style='background:#FF6600;color:#fff;font-weight:800;padding:12px 16px;border-radius:8px;font-size:18px'>" + htmllib.escape(app_name) + "</div>"
            "<h2 style='font-size:17px;margin:18px 0 0'>Updates on your shortlist</h2>" + "".join(rows) +
            "<p style='color:#6E6E6E;font-size:12px;margin-top:22px'>Planning data comes from planning.data.gov.uk where the council publishes to it. Check the council register for anything critical.</p></div>")
    return subject, text, body


def send_email(cfg: dict, subject: str, text: str, html_body: str | None = None, smtp_factory=None) -> None:
    if not (cfg.get("smtp_host") and cfg.get("to")):
        raise ValueError("Add an SMTP server and a recipient address first")
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = cfg.get("from") or cfg.get("smtp_user") or cfg["to"]
    msg["To"] = cfg["to"]
    msg.set_content(text)
    if html_body:
        msg.add_alternative(html_body, subtype="html")
    port = int(cfg.get("smtp_port") or 587)
    if smtp_factory:
        srv = smtp_factory(cfg["smtp_host"], port)
    elif port == 465:
        srv = smtplib.SMTP_SSL(cfg["smtp_host"], port, timeout=30, context=ssl.create_default_context())
    else:
        srv = smtplib.SMTP(cfg["smtp_host"], port, timeout=30)
    try:
        if port != 465 and cfg.get("smtp_tls", True):
            srv.starttls(context=ssl.create_default_context())
        if cfg.get("smtp_user"):
            srv.login(cfg["smtp_user"], cfg.get("smtp_password", ""))
        srv.send_message(msg)
    finally:
        try:
            srv.quit()
        except Exception:
            pass


def run_all(sites: list[dict], cfg: dict, fetch=net.fetch, get_json=net.get_json, smtp_factory=None, send: bool = True) -> dict:
    found = 0
    for s in sites:
        try:
            found += len(check_site(s, fetch, get_json))
        except Exception as e:  # one bad site must not stop the rest
            add_event(s, "check_error", "Check failed", str(e)[:200], "info", key=f"err-{date.today()}")
    cfg["last_run"] = now()
    sent = 0
    if send and cfg.get("enabled") and cfg.get("smtp_host") and cfg.get("to"):
        items = pending(sites, cfg.get("digest_min_level", "info"))
        if items:
            subject, text, body = build_digest(items)
            try:
                send_email(cfg, subject, text, body, smtp_factory)
                for _, e in items:
                    e["sent"] = True
                sent = len(items)
                cfg["last_sent"] = now()
                cfg["last_error"] = ""
            except Exception as e:
                cfg["last_error"] = str(e)[:200]
    return {"new_events": found, "emailed": sent, "error": cfg.get("last_error", "")}


class Scheduler(threading.Thread):
    """Runs the checks every N hours while the app is up."""

    def __init__(self, tick, get_cfg):
        super().__init__(daemon=True)
        self.tick, self.get_cfg, self._stop_evt = tick, get_cfg, threading.Event()

    def run(self):
        while not self._stop_evt.wait(120):
            cfg = self.get_cfg()
            if not cfg.get("enabled"):
                continue
            try:
                last = datetime.fromisoformat(cfg["last_run"]) if cfg.get("last_run") else None
            except ValueError:
                last = None
            if last is None or datetime.now(timezone.utc) - last >= timedelta(hours=max(1, float(cfg.get("interval_hours") or 6))):
                try:
                    self.tick()
                except Exception:
                    pass

    def stop(self):
        self._stop_evt.set()
