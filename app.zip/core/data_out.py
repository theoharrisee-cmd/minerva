"""Site data for outputs: constraints, ownership, nearby applications, access and a location map.

Shared by the site report, the committee paper, the investor deck and the site brief so they all say the same thing.
"""
from __future__ import annotations

from . import staticmap, track


def _items(site: dict) -> list[dict]:
    return (site.get("data_pack") or {}).get("items", [])


def constraints(site: dict) -> tuple[list[list], str]:
    """Rows of findings (header first) and a line naming what was checked and found clear."""
    its = [x for x in _items(site) if x.get("group") in ("Planning and policy", "Environment and risk")]
    hits = [x for x in its if x["status"] == "hit"]
    clear = [x for x in its if x["status"] == "clear"]
    rows = [["Constraint", "Finding", "Source"]] + [[x["label"], (x.get("value") or "Found") + (f". {x['detail']}" if x.get("detail") else ""), x.get("source", "")] for x in hits[:24]]
    line = ""
    if clear:
        line = "Checked and clear: " + ", ".join(x["label"] for x in clear[:14]) + ("." if len(clear) <= 14 else f" and {len(clear) - 14} more.")
    return rows, line


def ownership(site: dict) -> list[list]:
    """Rows of [Item, Detail]."""
    rows = []
    r = site.get("title_register")
    if r:
        rows.append(["Registered title", f"{r['title']}, {r.get('tenure') or 'tenure not stated'}" + (f", title {r['class'].lower()}" if r.get("class") else "") + (f", £{r['price']:,.0f} paid {r.get('price_date', '')}" if r.get("price") else "")])
        rows.append(["Proprietors", "; ".join(p["name"] + (f" ({p['company_no']})" if p.get("company_no") else "") for p in r["proprietors"]) or "none read"])
        if r.get("charges"):
            rows.append(["Registered charges", "; ".join(f"{c.get('chargee') or 'chargee not read'} ({c.get('date', '')})" for c in r["charges"][:4])])
        if r.get("restrictions") or r.get("covenants"):
            rows.append(["Restrictions and covenants", f"{len(r.get('restrictions', []))} restriction(s) and {len(r.get('covenants', []))} covenant(s) on the register. Read the official copy before exchange."])
    a = site.get("assembly")
    if a:
        if a.get("under_site_ha"):
            rows.append(["Title area under the site", f"{a['under_site_ha']} ha across the registered title polygons; {a.get('adjoining', 0)} adjoining title(s)"])
        for g in ((a.get("owners") or {}).get("groups") or [])[:5]:
            sig = "; ".join(x["text"] for x in g.get("distress", []))
            rows.append([g["proprietor"], f"{g['nearby']} title(s) nearby, {g.get('total', g['nearby'])} in all" + (f". {sig}" if sig else "")])
    if not rows:
        rows.append(["Ownership", "Not researched. Import the official copy of the register or run the land map on the Data tab."])
    return rows


def applications(site: dict, limit: int = 8) -> tuple[list[list], list[str]]:
    apps = (site.get("data_pack") or {}).get("planit") or []
    rows = [["Reference", "Address and proposal", "Status", "Submitted", "km"]] + [[a["ref"], f"{a['address']}: {(a.get('description') or '')[:110]}", a.get("state", ""), a.get("submitted", ""), str(a.get("distance_km", ""))] for a in apps[:limit]]
    lines = []
    tr = site.get("track")
    if tr and tr.get("ok"):
        lines.append(f"Over the last {tr['years']} years, {tr['approved']} of {tr['approved'] + tr['refused']} decided residential major applications within {tr['radius_km']:g} km were approved" + (f" ({tr['approval_rate']:.0%})" if tr.get("approval_rate") is not None else "")
                     + (f", with a median {tr['median_days']:.0f} days to a decision." if tr.get("median_days") else "."))
        fx = track.facts(tr)
        if fx:
            lines.append(fx["precedent_sentence"])
    return (rows if len(rows) > 1 else []), lines


def access(site: dict) -> list[list]:
    its = [x for x in _items(site) if x.get("group") == "Infrastructure and access" and x["status"] != "error"]
    return [["Measure", "Result"]] + [[x["label"], (x.get("value") or "") + (f". {x['detail']}" if x.get("detail") else "")] for x in its[:10]] if its else []


def bundle(site: dict, cache_dir=None, use_tiles: bool = True) -> dict:
    p = site.get("data_pack")
    has = bool(p or site.get("assembly") or site.get("title_register") or site.get("track"))
    if not has:
        return {}
    crow, cline = constraints(site)
    arow, alines = applications(site)
    return {"checked": (p or {}).get("checked", "")[:10], "map": staticmap.for_site(site, cache_dir, use_tiles=use_tiles), "constraints": crow if len(crow) > 1 else [], "constraints_line": cline, "ownership": ownership(site),
            "applications": arow, "record_lines": alines, "access": access(site), "hpi": (p or {}).get("hpi") or {}, "geography": (p or {}).get("geography") or {}}
