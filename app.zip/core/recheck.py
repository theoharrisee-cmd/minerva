"""Monthly deeper re-check of shortlisted sites.

The routine checks (listing, planning dataset, key dates) run every few hours. This pass runs about once a month
per site and looks for slower moving things: new planning applications nearby, active flood warnings, changes to
company owned titles at and around the site, the house price index for the council area, and the local planning
approval rate. Each finding becomes an event on the site, and the first run only records a baseline.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from . import datasources as ds, hmlr, track, watch

CADENCE_DAYS = 30


def due(site: dict, today: date | None = None, days: int = CADENCE_DAYS) -> bool:
    if not watch.watched(site) or site.get("lat") is None:
        return False
    last = ((site.get("watch") or {}).get("deep") or {}).get("last")
    if not last:
        return True
    return ((today or date.today()) - date.fromisoformat(last[:10])).days >= days


def _postcodes(site: dict) -> list[str]:
    pcs = {site.get("postcode") or ""}
    for t in ((site.get("assembly") or {}).get("owners") or {}).get("titles", [])[:60]:
        pcs.add(t.get("postcode") or "")
    return [p for p in pcs if p]


def run(site: dict, cfg: dict | None = None, today: date | None = None, planit=None, flood=None, hpi=None, tracker=None, changes=None) -> list[dict]:
    """Run every check for one site. Injectable sources keep it testable. Returns the events created."""
    today = today or date.today()
    planit, flood, hpi, tracker, changes = planit or ds.planit, flood or ds.ea_flood, hpi or ds.hpi, tracker or track.fetch, changes or hmlr.changes_for
    w = site.setdefault("watch", {})
    d = w.setdefault("deep", {})
    first = not d.get("last")
    out: list[dict] = []
    errors = []

    def ev(kind, title, detail="", level="important", key=None):
        if first:
            return
        e = watch.add_event(site, kind, title, detail, level, key)
        if e:
            out.append(e)

    # 1. flood warnings
    try:
        items = flood(site["lat"], site["lon"])
        w_it = next((x for x in items if x.get("id") == "ea-warnings"), None)
        active = w_it["status"] == "hit" if w_it else False
        if active and not d.get("flood_active"):
            ev("flood", "Flood warning near the site", w_it.get("detail") or w_it.get("value", ""), "important", f"fl-{today.isoformat()[:7]}")
        d["flood_active"] = active
    except Exception as e:
        errors.append(f"flood: {str(e)[:60]}")

    # 2. new applications nearby, since the last pass (or the last 60 days on the first)
    try:
        since = (d.get("last") or (today - timedelta(days=60)).isoformat())[:10]
        rows = planit(site["lat"], site["lon"], 0.8, cfg or {}, start_date=since, pg_sz=60)
        seen = set(d.get("apps") or [])
        new = [r for r in rows if r["ref"] and r["ref"] not in seen]
        big = [r for r in new if (ds.units_of(r["description"]) or 0) >= 10 or r.get("size") in ("Large",)]
        for r in (big or new)[:4]:
            ev("planning_nearby", f"New application {r['ref']} within 800 m", f"{r['address']}: {(r['description'] or '')[:180]}", "important" if r in big else "info", f"pnb-{r['ref']}")
        if len(new) > len(big or new[:4]) + 0 and len(new) > 4:
            ev("planning_nearby", f"{len(new) - 4} more applications nearby", "See the Data tab for the full list.", "info", f"pnb-more-{today.isoformat()[:7]}")
        d["apps"] = sorted(seen | {r["ref"] for r in rows if r["ref"]})[-300:]
    except Exception as e:
        errors.append(f"planning: {str(e)[:60]}")

    # 3. company owned titles at and around the site
    try:
        pcs = _postcodes(site)
        if pcs and hmlr.meta()["rows"]:
            for c in changes(pcs, d.get("last") or ""):
                if c["kind"] == "Transferred":
                    ev("title_change", f"Title {c['title']} changed hands", f"{c['old']} to {c['new']} ({c['address']})", "important", f"tc-{c['title']}-{c['loaded']}")
                elif c["kind"] == "New title":
                    ev("title_change", f"New company title {c['title']}", f"{c['new']} ({c['address']})", "info", f"tc-{c['title']}-{c['loaded']}")
                else:
                    ev("title_change", f"Title {c['title']} has left the company register", f"Previously {c['old']}. It may have been sold to an individual.", "info", f"tc-{c['title']}-{c['loaded']}")
    except Exception as e:
        errors.append(f"titles: {str(e)[:60]}")

    # 4. house price index for the council area
    try:
        dist = (site.get("data_pack") or {}).get("geography", {}).get("district") or site.get("la")
        if dist:
            h = hpi(dist)
            prev = d.get("hpi")
            if prev and h.get("month") != prev.get("month") and h.get("avg") and prev.get("avg"):
                chg = (h["avg"] - prev["avg"]) / prev["avg"] * 100
                ann = h.get("annual")
                if abs(chg) >= 1.0 or (ann is not None and prev.get("annual") is not None and abs(ann - prev["annual"]) >= 1.0):
                    ev("index", f"House prices in {dist} moved {chg:+.1f}%", f"Average £{h['avg']:,.0f} in {h['month']}" + (f", {ann:+.1f}% over the year" if ann is not None else "") + ". Re-run the market pricing on the Homes tab.", "important" if abs(chg) >= 2 else "info", f"hpi-{h['month']}")
            d["hpi"] = {k: h.get(k) for k in ("month", "avg", "annual")}
    except Exception as e:
        errors.append(f"index: {str(e)[:60]}")

    # 5. local planning record
    try:
        old = site.get("track") if site.get("track", {}).get("ok") else None
        if old or first:
            tr = tracker(site, cfg or {}, years=5, radius_km=(old or {}).get("radius_km", 8.0))
            if tr.get("ok"):
                if old and old.get("approval_rate") is not None and tr.get("approval_rate") is not None and abs(tr["approval_rate"] - old["approval_rate"]) >= 0.10:
                    ev("track", f"Local approval rate moved to {tr['approval_rate']:.0%}", f"It was {old['approval_rate']:.0%} at the last check. Median time to decide is {tr['median_days'] or 0:.0f} days.", "important", f"tr-{today.isoformat()[:7]}")
                site["track"] = tr
    except Exception as e:
        errors.append(f"track: {str(e)[:60]}")

    d["last"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
    d["errors"] = errors
    if first:
        watch.add_event(site, "recheck", "Monthly checks set up", "The next deeper check will report new applications nearby, flood warnings, changes to company owned titles and moves in the house price index.", "info", key="deep-baseline")
    return out
