"""Registry and connectors for open and licensed data.

Every source has a plain record (what it is, who publishes it, the licence, how it is reached) and,
where a connector exists, a test and a per-site check. Endpoints that could not be verified from the
build environment are marked so on the Data page and are switched on only after a successful test.
Standard library only.
"""
from __future__ import annotations

import base64
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone

from . import geo, net, store

PDG = "https://www.planning.data.gov.uk"
OGL = "Open Government Licence v3.0"
UA = "easyDevelopment/0.7 (personal property research; contact via user)"

GROUPS = ["Planning and policy", "Environment and risk", "Market and demographics", "Infrastructure and access", "Land and ownership"]

# planning.data.gov.uk datasets checked at a point. key is the risk flag written to the site where one exists.
# weight: how strongly a hit counts against a site in area search (negative = a constraint, positive = a plus).
PDG_SETS: list[dict] = [
    # planning and policy
    {"id": "conservation-area", "group": GROUPS[0], "label": "Conservation area", "flag": "conservation_area", "weight": -2},
    {"id": "listed-building-outline", "group": GROUPS[0], "label": "Listed building", "flag": "listed", "weight": -2},
    {"id": "tree-preservation-zone", "group": GROUPS[0], "label": "Tree preservation zone", "flag": "trees", "weight": -1},
    {"id": "article-4-direction-area", "group": GROUPS[0], "label": "Article 4 direction", "flag": "article4", "weight": -1},
    {"id": "brownfield-land", "group": GROUPS[0], "label": "Brownfield land register", "flag": "brownfield", "weight": 3},
    {"id": "green-belt", "group": GROUPS[0], "label": "Green Belt", "flag": "green_belt", "weight": -4},
    {"id": "world-heritage-site", "group": GROUPS[0], "label": "World Heritage Site", "flag": None, "weight": -3},
    {"id": "world-heritage-site-buffer-zone", "group": GROUPS[0], "label": "World Heritage Site buffer zone", "flag": None, "weight": -2},
    {"id": "park-and-garden", "group": GROUPS[0], "label": "Registered park or garden", "flag": None, "weight": -2},
    {"id": "battlefield", "group": GROUPS[0], "label": "Registered battlefield", "flag": None, "weight": -2},
    {"id": "scheduled-monument", "group": GROUPS[0], "label": "Scheduled monument", "flag": None, "weight": -3},
    {"id": "central-activities-zone", "group": GROUPS[0], "label": "Central activities zone", "flag": None, "weight": 0},
    {"id": "infrastructure-project", "group": GROUPS[0], "label": "Nationally significant infrastructure project", "flag": None, "weight": -1},
    {"id": "development-plan-boundary", "group": GROUPS[0], "label": "Development plan boundary", "flag": None, "weight": 0},
    # environment and risk
    {"id": "flood-risk-zone", "group": GROUPS[1], "label": "Flood risk zone", "flag": "flood_zone", "weight": -2},
    {"id": "flood-storage-area", "group": GROUPS[1], "label": "Flood storage area", "flag": None, "weight": -2},
    {"id": "ancient-woodland", "group": GROUPS[1], "label": "Ancient woodland", "flag": "ancient_woodland", "weight": -3},
    {"id": "site-of-special-scientific-interest", "group": GROUPS[1], "label": "Site of Special Scientific Interest", "flag": "sssi", "weight": -4},
    {"id": "special-protection-area", "group": GROUPS[1], "label": "Special Protection Area", "flag": "spa", "weight": -2},
    {"id": "special-area-of-conservation", "group": GROUPS[1], "label": "Special Area of Conservation", "flag": "sac", "weight": -2},
    {"id": "ramsar", "group": GROUPS[1], "label": "Ramsar site", "flag": None, "weight": -3},
    {"id": "local-nature-reserve", "group": GROUPS[1], "label": "Local nature reserve", "flag": None, "weight": -2},
    {"id": "national-nature-reserve", "group": GROUPS[1], "label": "National nature reserve", "flag": None, "weight": -3},
    {"id": "national-park", "group": GROUPS[1], "label": "National Park", "flag": "national_park", "weight": -3},
    {"id": "area-of-outstanding-natural-beauty", "group": GROUPS[1], "label": "National Landscape (AONB)", "flag": "aonb", "weight": -3},
    {"id": "agricultural-land-classification", "group": GROUPS[1], "label": "Agricultural land classification", "flag": None, "weight": 0},
    {"id": "air-quality-management-area", "group": GROUPS[1], "label": "Air quality management area", "flag": None, "weight": -1},
    # infrastructure and access
    {"id": "transport-access-node", "group": GROUPS[3], "label": "Public transport access node", "flag": None, "weight": 1, "near": True},
    {"id": "educational-establishment", "group": GROUPS[3], "label": "School or college", "flag": None, "weight": 0, "near": True},
    # land
    {"id": "title-boundary", "group": GROUPS[4], "label": "Registered title boundary (HM Land Registry INSPIRE)", "flag": None, "weight": 0, "parcel": True},
]
PDG_BY_ID = {d["id"]: d for d in PDG_SETS}

# Reference sources: what each is, and how easyDevelopment uses it. kind: live | key | upload | discover | link
SOURCES: list[dict] = [
    {"id": "pdg", "group": GROUPS[0], "name": "planning.data.gov.uk datasets", "publisher": "DLUHC / MHCLG", "kind": "live", "licence": OGL,
     "note": "Constraint and policy geography. Which datasets are live is read from the platform at run time; councils supply some datasets patchily.", "test": "pdg", "default_on": True},
    {"id": "planit", "group": GROUPS[0], "name": "PlanIt planning applications", "publisher": "PlanIt (Andrew Speakman), scraped from council registers", "kind": "live", "licence": "Free for non-commercial use with attribution; check terms for commercial use",
     "note": "Live applications across most English councils: status, size, decision dates. Used for nearby schemes, planning news and area search.", "test": "planit", "default_on": True, "url": "https://www.planit.org.uk/api/"},
    {"id": "levy-schedules", "group": GROUPS[0], "name": "CIL charging schedules by council", "publisher": "DLUHC / MHCLG (planning.data.gov.uk)", "kind": "live", "licence": OGL, "test": "levies", "default_on": True,
     "note": "Finds each council's CIL charging schedule document, which the Planning tab then reads for rates.", "url": "https://www.planning.data.gov.uk/dataset/community-infrastructure-levy-schedule"},
    {"id": "lpa-registers", "group": GROUPS[0], "name": "Council planning registers", "publisher": "Local planning authorities", "kind": "link", "licence": "Council terms",
     "note": "Deep links to the register for each site, already shown on the Planning tab.", "default_on": True},
    {"id": "nhle", "group": GROUPS[0], "name": "National Heritage List for England", "publisher": "Historic England", "kind": "link", "licence": OGL, "url": "https://historicengland.org.uk/listing/the-list/",
     "note": "Listed buildings are checked through planning.data.gov.uk; the List has grade, description and legal extent.", "default_on": True},
    {"id": "gov-guidance", "group": GROUPS[0], "name": "Planning practice guidance and NPPF", "publisher": "GOV.UK", "kind": "link", "licence": OGL, "url": "https://www.gov.uk/guidance/national-planning-policy-framework",
     "note": "Used by the reply generator for cited guidance.", "default_on": True},
    {"id": "postcodes", "group": GROUPS[0], "name": "Postcodes.io (ONS Postcode Directory, OS Open Names)", "publisher": "Ideal Postcodes, ONS data", "kind": "live", "licence": OGL,
     "note": "Council, ward, LSOA, MSOA, region and constituency for a point. Drives the local authority and geography for every site.", "test": "postcodes", "default_on": True},
    {"id": "ea-flood", "group": GROUPS[1], "name": "Environment Agency flood monitoring", "publisher": "Environment Agency", "kind": "live", "licence": OGL,
     "note": "Live flood warnings and river gauges near a site. Flood zones themselves come from planning.data.gov.uk.", "test": "ea", "default_on": True,
     "url": "https://environment.data.gov.uk/flood-monitoring/doc/reference"},
    {"id": "ea-ltfr", "group": GROUPS[1], "name": "Long term flood risk (rivers, sea, surface water, reservoirs)", "publisher": "Environment Agency", "kind": "link", "licence": OGL,
     "url": "https://check-long-term-flood-risk.service.gov.uk/postcode", "note": "Surface water and reservoir risk have no point API in the registry; link opened for the site postcode.", "default_on": True},
    {"id": "coal", "group": GROUPS[1], "name": "Coal mining risk areas", "publisher": "Coal Authority", "kind": "discover", "licence": OGL,
     "wms": "https://map.bgs.ac.uk/arcgis/services/CoalAuthority/coalauthority_planning/MapServer/WMSServer", "default_on": False,
     "note": "WMS endpoint from the published Coal Authority planning service. Test it, pick the layers on the Data page, then switch it on. A formal Coal Authority report is still needed for any site in a coal area.",
     "url": "https://mapapps2.bgs.ac.uk/coalauthority/home.html"},
    {"id": "bgs", "group": GROUPS[1], "name": "Geology (bedrock and superficial)", "publisher": "British Geological Survey", "kind": "discover", "licence": "BGS OGL",
     "wms": "https://map.bgs.ac.uk/arcgis/services/BGS_Detailed_Geology/MapServer/WMSServer", "default_on": False,
     "note": "Published WMS. Test it and choose the layers on the Data page.", "url": "https://www.bgs.ac.uk/map-viewers/geology-of-britain-viewer/"},
    {"id": "magic", "group": GROUPS[1], "name": "MAGIC map (Natural England, Defra, Forestry Commission)", "publisher": "Defra family", "kind": "link", "licence": OGL, "url": "https://magic.defra.gov.uk/MagicMap.aspx",
     "note": "Priority habitats, SSSI impact risk zones, nutrient neutrality catchments, Countryside Stewardship. Opened at the site location.", "default_on": True},
    {"id": "ne-arcgis", "group": GROUPS[1], "name": "Natural England open data (ArcGIS layers)", "publisher": "Natural England", "kind": "discover", "licence": OGL, "default_on": False,
     "note": "Add the FeatureServer layer URL from Natural England's open data site (for example SSSI impact risk zones or priority habitats) as a custom layer on the Data page.",
     "url": "https://naturalengland-defra.opendata.arcgis.com/"},
    {"id": "lidar", "group": GROUPS[1], "name": "LiDAR terrain and surface models", "publisher": "Environment Agency", "kind": "link", "licence": OGL, "url": "https://environment.data.gov.uk/survey",
     "note": "Levels and site topography for early massing.", "default_on": True},
    {"id": "lr-ppd", "group": GROUPS[2], "name": "Price Paid Data", "publisher": "HM Land Registry", "kind": "live", "licence": OGL, "test": "ppd", "default_on": True,
     "note": "Every residential sale in England and Wales since 1995. Used for comparables, new build clusters and scheme evidence.", "url": "https://landregistry.data.gov.uk/app/ppd"},
    {"id": "lr-hpi", "group": GROUPS[2], "name": "UK House Price Index", "publisher": "HM Land Registry, ONS, Registers of Scotland", "kind": "live", "licence": OGL, "test": "hpi", "default_on": True,
     "note": "Average price and annual change for the council area, by property type."},
    {"id": "epc", "group": GROUPS[2], "name": "Energy Performance Certificates", "publisher": "DLUHC", "kind": "upload", "licence": OGL, "default_on": True, "url": "https://get-energy-performance-data.communities.gov.uk/",
     "note": "Floor areas that turn sold prices into £ per sq ft. The old EPC API closed in May 2026, so download the certificates file for a council from the new service and load it in Settings."},
    {"id": "nomis", "group": GROUPS[2], "name": "Census 2021 and labour market", "publisher": "ONS via Nomis", "kind": "live", "licence": OGL, "test": "nomis", "default_on": True,
     "note": "Population, tenure and households for the site's LSOA. The table is found by search at run time, so it survives renumbering."},
    {"id": "voa", "group": GROUPS[2], "name": "Business rates valuations", "publisher": "Valuation Office Agency", "kind": "link", "licence": OGL, "url": "https://www.tax.service.gov.uk/business-rates-find/search",
     "note": "Rateable values and floor areas for commercial buildings on value-add sites.", "default_on": True},
    {"id": "osm", "group": GROUPS[3], "name": "OpenStreetMap (Overpass)", "publisher": "OpenStreetMap contributors", "kind": "live", "licence": "ODbL", "test": "osm", "default_on": True,
     "note": "Stations, bus stops, schools, GPs and shops within walking distance. Attribution required."},
    {"id": "osrm", "group": GROUPS[3], "name": "Road routing (OSRM)", "publisher": "Project OSRM public demo server, OpenStreetMap data", "kind": "live", "licence": "ODbL data; the demo server is for light use",
     "note": "Drive times in area search and place matching. The public server only carries the car network, so walking and cycling times are worked out from the road distance at a steady speed.", "test": "osrm", "default_on": True, "url": "https://project-osrm.org/"},
    {"id": "naptan", "group": GROUPS[3], "name": "Public transport access nodes", "publisher": "DfT NaPTAN via planning.data.gov.uk", "kind": "live", "licence": OGL,
     "note": "Checked through planning.data.gov.uk and OpenStreetMap.", "default_on": True},
    {"id": "ofcom", "group": GROUPS[3], "name": "Broadband and mobile coverage", "publisher": "Ofcom", "kind": "link", "licence": "Ofcom terms", "url": "https://checker.ofcom.org.uk/",
     "note": "Connectivity for BTR, co-living and commercial conversions.", "default_on": True},
    {"id": "dno", "group": GROUPS[3], "name": "Electricity network capacity", "publisher": "Distribution network operators", "kind": "link", "licence": "DNO terms",
     "url": "https://www.energynetworks.org/customers/find-my-network-operator", "note": "Grid capacity for heat pumps, EV charging and large schemes; each DNO publishes its own map.", "default_on": True},
    {"id": "hmlr-ccod", "group": GROUPS[4], "name": "UK companies that own property in England and Wales (CCOD)", "publisher": "HM Land Registry", "kind": "key", "licence": "HMLR licence (free with registration)",
     "note": "Title number, tenure, address, price paid and company proprietors. Free monthly file by API key or by upload.", "test": "hmlr", "default_on": True,
     "url": "https://use-land-property-data.service.gov.uk/datasets/ccod"},
    {"id": "hmlr-ocod", "group": GROUPS[4], "name": "Overseas companies that own property (OCOD)", "publisher": "HM Land Registry", "kind": "key", "licence": "HMLR licence (free with registration)",
     "note": "Same fields for overseas-registered owners.", "url": "https://use-land-property-data.service.gov.uk/datasets/ocod", "default_on": True},
    {"id": "hmlr-inspire", "group": GROUPS[4], "name": "INSPIRE index polygons (freehold land parcels)", "publisher": "HM Land Registry", "kind": "live", "licence": OGL, "default_on": True,
     "note": "Freehold parcel outlines. Read through planning.data.gov.uk title-boundary for a point or an area; the bulk GML by council is also published.",
     "url": "https://use-land-property-data.service.gov.uk/datasets/inspire"},
    {"id": "hmlr-oc1", "group": GROUPS[4], "name": "Official copy of the register (OC1)", "publisher": "HM Land Registry", "kind": "upload", "licence": "£7 per title, paid to HMLR",
     "note": "Owner names and addresses, charges and covenants are not in any free dataset. Buy the official copy and import the PDF: proprietors, price, charges and restrictions are read into the site.", "default_on": True,
     "url": "https://www.gov.uk/get-information-about-property-and-land"},
    {"id": "companies-house", "group": GROUPS[4], "name": "Companies House", "publisher": "Companies House", "kind": "key", "licence": OGL, "test": "ch", "default_on": True,
     "note": "Status, filing history and registered charges for a company that owns land. Free key.", "url": "https://developer.company-information.service.gov.uk/"},
    {"id": "title-api", "group": GROUPS[4], "name": "Paid title data provider (your account)", "publisher": "Your provider", "kind": "key", "licence": "Per your contract", "default_on": False,
     "note": "Configure the request URL, header and field paths for the provider you subscribe to. Nothing is assumed about any specific vendor."},
]
SRC_BY_ID = {s["id"]: s for s in SOURCES}

# ---------------------------------------------------------------- http

_get_override = None  # tests replace this


def _http(url: str, headers: dict | None = None, timeout: int = 15, ttl: int = 0, text: bool = False):
    if _get_override:
        return _get_override(url, headers or {}, text)
    cp = net._cache_path(url + json.dumps(headers or {}, sort_keys=True)) if ttl else None
    if cp and cp.exists() and time.time() - cp.stat().st_mtime < ttl:
        d = json.loads(cp.read_text())["body"]
        return d
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json, */*", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode(r.headers.get_content_charset() or "utf-8", "ignore")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"cannot connect ({e.reason})")
    body = raw if text else json.loads(raw)
    if cp:
        cp.write_text(json.dumps({"url": url, "body": body}))
    return body


def _q(**kw) -> str:
    return urllib.parse.urlencode({k: v for k, v in kw.items() if v is not None})


# ---------------------------------------------------------------- settings

def settings() -> dict:
    """User data settings from the profile."""
    return store.load_profile().get("data", {}) or {}


def default_settings() -> dict:
    return {"off": [], "extra_pdg": [], "layers": [], "wms": {}, "planit_contact": "", "hmlr_key": "", "ch_key": "",
            "title_api": {"url": "", "header": "Authorization", "key": "", "owner_path": "", "method": "GET"}}


def merged(cfg: dict | None) -> dict:
    d = default_settings()
    for k, v in (cfg or {}).items():
        if isinstance(v, dict) and isinstance(d.get(k), dict):
            d[k] = {**d[k], **v}
        else:
            d[k] = v
    return d


# ---------------------------------------------------------------- planning.data.gov.uk

def discover_pdg(force: bool = False) -> dict:
    """Datasets published on the platform. Cached for a day. Returns {ok, datasets: {slug: name}, error}."""
    cp = store.DATA / "pdg_datasets.json"
    if not force and cp.exists() and time.time() - cp.stat().st_mtime < 86400:
        try:
            return json.loads(cp.read_text())
        except Exception:
            pass
    try:
        js = _http(f"{PDG}/dataset.json?limit=1000", timeout=20)
    except Exception as e:
        return {"ok": False, "datasets": {}, "error": str(e)}
    rows = js.get("datasets") if isinstance(js, dict) else js
    out = {}
    for r in rows or []:
        if isinstance(r, dict):
            slug = r.get("dataset") or r.get("slug") or r.get("name")
            if slug:
                out[str(slug)] = r.get("name") or r.get("text") or str(slug)
    res = {"ok": bool(out), "datasets": out, "error": "" if out else "the dataset list was empty or in an unexpected shape", "when": datetime.now(timezone.utc).isoformat(timespec="minutes")}
    if out:
        try:
            cp.write_text(json.dumps(res))
        except Exception:
            pass
    return res


def active_pdg(cfg: dict, disc: dict | None = None) -> list[dict]:
    """Datasets to check for a site: the registry (minus any switched off, and minus any the platform does not publish) plus the user's extras."""
    disc = disc if disc is not None else discover_pdg()
    have = disc.get("datasets") or {}
    off = set(cfg.get("off") or [])
    out = []
    for d in PDG_SETS:
        if d["id"] in off:
            continue
        if have and d["id"] not in have:
            continue
        out.append(d)
    for slug in cfg.get("extra_pdg") or []:
        if slug not in PDG_BY_ID and (not have or slug in have):
            out.append({"id": slug, "group": GROUPS[0], "label": have.get(slug, slug).replace("-", " ").capitalize() if isinstance(have.get(slug), str) else slug, "flag": None, "weight": 0, "extra": True})
    return out


def _attrs(e: dict) -> dict:
    out = {}
    for k, v in e.items():
        if v in (None, "") or k in ("entity", "name", "reference", "geometry", "point", "prefix", "typology", "dataset", "organisation-entity", "entry-date", "start-date", "end-date", "quality", "notes", "documentation-url", "document-url", "json"):
            continue
        if any(t in k for t in ("grade", "level", "category", "status", "type", "decision", "designation", "class", "hectares", "site-area", "dwellings", "stop-type", "operator", "school", "phase")):
            out[k] = v
    return out


def pdg_point(ds: str, lat: float, lon: float, limit: int = 5) -> list[dict]:
    js = _http(f"{PDG}/entity.json?" + _q(dataset=ds, longitude=lon, latitude=lat, geometry_relation="intersects", limit=limit), timeout=15)
    return js.get("entities", []) if isinstance(js, dict) else []


def pdg_area(ds: str, b, limit: int = 100, offset: int = 0) -> list[dict]:
    js = _http(f"{PDG}/entity.json?" + _q(dataset=ds, geometry=geo.bbox_wkt(b), geometry_relation="intersects", limit=limit, offset=offset), timeout=25)
    return js.get("entities", []) if isinstance(js, dict) else []


def pdg_check(ds: dict, lat: float, lon: float) -> dict:
    """One dataset at a point, or the nearest features for 'near' datasets."""
    base = {"group": ds["group"], "source": "planning.data.gov.uk", "id": ds["id"], "label": ds["label"], "flag": ds.get("flag"), "weight": ds.get("weight", 0),
            "url": f"{PDG}/dataset/{ds['id']}"}
    try:
        if ds.get("near"):
            b = geo.bbox(lat, lon, 1.2)
            ents = pdg_area(ds["id"], b, 60)
            pts = []
            for e in ents:
                p = geo.point_of(e.get("point") or e.get("geometry"))
                if p:
                    pts.append((geo.km(lat, lon, p[1], p[0]), e))
            pts.sort(key=lambda t: t[0])
            if not pts:
                return {**base, "status": "clear", "value": "None within 1.2 km", "detail": ""}
            d0, e0 = pts[0]
            return {**base, "status": "info", "value": f"{len(pts)} within 1.2 km, nearest {d0 * 1000:.0f} m", "detail": "; ".join(f"{(e.get('name') or e.get('reference') or '')} ({d * 1000:.0f} m)" for d, e in pts[:5])}
        ents = pdg_point(ds["id"], lat, lon)
        if ds.get("parcel"):
            if not ents:
                return {**base, "status": "clear", "value": "No registered title polygon at this point", "detail": ""}
            wkt = ents[0].get("geometry") or ""
            ha = geo.ring_area_ha(wkt)
            return {**base, "status": "info", "value": f"Title polygon found" + (f", about {ha:.2f} ha" if ha else ""), "detail": ents[0].get("reference") or "", "area_ha": ha}
        if not ents:
            return {**base, "status": "clear", "value": "None at this point", "detail": ""}
        names = [e.get("name") or e.get("reference") or "" for e in ents]
        at = {}
        for e in ents:
            at.update(_attrs(e))
        val = ", ".join(n for n in names if n)[:140] or "Present"
        if at:
            val += " (" + ", ".join(f"{k.replace('-', ' ')}: {v}" for k, v in list(at.items())[:2]) + ")"
        return {**base, "status": "hit", "value": val, "detail": "", "entities": [{"name": e.get("name") or e.get("reference"), "reference": e.get("reference"), "attrs": _attrs(e), "flood": e.get("flood-risk-level")} for e in ents]}
    except Exception as e:
        return {**base, "status": "error", "value": "Not checked", "detail": str(e)[:120]}


# ---------------------------------------------------------------- other live connectors

def geography(lat: float, lon: float) -> dict:
    js = _http(f"https://api.postcodes.io/postcodes?" + _q(lon=lon, lat=lat, limit=1), ttl=30 * 86400)
    r = (js.get("result") or [None])[0]
    if not r:
        raise RuntimeError("no postcode near this point")
    return {"postcode": r.get("postcode"), "district": r.get("admin_district"), "ward": r.get("admin_ward"), "county": r.get("admin_county"), "region": r.get("region"), "country": r.get("country"),
            "lsoa": r.get("lsoa"), "msoa": r.get("msoa"), "constituency": r.get("parliamentary_constituency"), "codes": r.get("codes") or {}, "rural_urban": r.get("rural_urban") if "rural_urban" in r else None}


def ea_flood(lat: float, lon: float) -> list[dict]:
    out = []
    js = _http("https://environment.data.gov.uk/flood-monitoring/id/floods?" + _q(lat=lat, long=lon, dist=5))
    items = js.get("items", [])
    out.append({"group": GROUPS[1], "source": "Environment Agency", "id": "ea-warnings", "label": "Active flood alerts and warnings within 5 km", "status": "hit" if items else "clear",
                "value": f"{len(items)} active" if items else "None active", "detail": "; ".join(f"{i.get('severity', '')}: {i.get('description', '')}" for i in items[:4]), "weight": -1 if items else 0, "flag": None,
                "url": "https://check-for-flooding.service.gov.uk/"})
    try:
        st = _http("https://environment.data.gov.uk/flood-monitoring/id/stations?" + _q(lat=lat, long=lon, dist=3, _limit=20))
        rows = st.get("items", [])
        out.append({"group": GROUPS[1], "source": "Environment Agency", "id": "ea-gauges", "label": "River and rainfall gauges within 3 km", "status": "info", "value": f"{len(rows)} stations",
                    "detail": "; ".join(sorted({(r.get("riverName") or r.get("label") or "") for r in rows if r.get("riverName") or r.get("label")})[:4]), "weight": 0, "flag": None})
    except Exception:
        pass
    return out


def overpass(lat: float, lon: float, radius_m: int = 1200) -> list[dict]:
    q = f"""[out:json][timeout:20];(
node(around:{radius_m},{lat},{lon})[railway~"station|halt|tram_stop"];
node(around:{radius_m},{lat},{lon})[highway=bus_stop];
nwr(around:{radius_m},{lat},{lon})[amenity~"school|kindergarten|doctors|clinic|hospital|pharmacy"];
nwr(around:{radius_m},{lat},{lon})[shop~"supermarket|convenience"];
nwr(around:{radius_m},{lat},{lon})[leisure=park];
);out center 300;"""
    js = _http("https://overpass-api.de/api/interpreter?" + _q(data=q), timeout=30, ttl=7 * 86400)
    els = js.get("elements", [])

    def pt(e):
        if "lat" in e:
            return e["lat"], e["lon"]
        c = e.get("center") or {}
        return c.get("lat"), c.get("lon")

    groups = {"Rail, metro or tram stop": [], "Bus stops": [], "Schools": [], "Doctors and hospitals": [], "Pharmacies": [], "Supermarkets and convenience stores": [], "Parks": []}
    for e in els:
        t, la = e.get("tags") or {}, pt(e)
        if la[0] is None:
            continue
        d = geo.km(lat, lon, la[0], la[1]) * 1000
        nm = t.get("name") or ""
        if t.get("railway"):
            groups["Rail, metro or tram stop"].append((d, nm))
        elif t.get("highway") == "bus_stop":
            groups["Bus stops"].append((d, nm))
        elif t.get("amenity") in ("school", "kindergarten"):
            groups["Schools"].append((d, nm))
        elif t.get("amenity") in ("doctors", "clinic", "hospital"):
            groups["Doctors and hospitals"].append((d, nm))
        elif t.get("amenity") == "pharmacy":
            groups["Pharmacies"].append((d, nm))
        elif t.get("shop"):
            groups["Supermarkets and convenience stores"].append((d, nm))
        elif t.get("leisure") == "park":
            groups["Parks"].append((d, nm))
    out = []
    for k, v in groups.items():
        v.sort()
        if v:
            out.append({"group": GROUPS[3], "source": "OpenStreetMap", "id": "osm-" + k[:6].lower(), "label": k, "status": "info", "value": f"{len(v)} within {radius_m} m, nearest {v[0][0]:.0f} m" + (f" ({v[0][1]})" if v[0][1] else ""),
                        "detail": "; ".join(f"{n or 'unnamed'} {d:.0f} m" for d, n in v[:4]), "weight": 0, "flag": None, "count": len(v), "nearest_m": round(v[0][0])})
        else:
            out.append({"group": GROUPS[3], "source": "OpenStreetMap", "id": "osm-" + k[:6].lower(), "label": k, "status": "clear", "value": f"None mapped within {radius_m} m", "detail": "", "weight": 0, "flag": None, "count": 0})
    return out


def planit_ua(cfg: dict) -> dict:
    c = (cfg or {}).get("planit_contact") or ""
    return {"User-Agent": f"easyDevelopment/0.7 (personal property research; {c})" if c else UA}


def planit(lat: float, lon: float, radius_km: float = 0.8, cfg: dict | None = None, **kw) -> list[dict]:
    """Applications near a point from PlanIt. kw: app_state, app_size, start_date, pg_sz, sort."""
    p = {"lat": lat, "lng": lon, "krad": radius_km, "pg_sz": kw.get("pg_sz", 60), "sort": kw.get("sort", "-start_date"), "select": "name,uid,address,description,app_state,app_size,app_type,start_date,decided_date,area_name,location_x,location_y,url,link"}
    for k in ("app_state", "app_size", "start_date", "end_date", "app_type", "pg"):
        if kw.get(k):
            p[k] = kw[k]
    js = _http("https://www.planit.org.uk/api/applics/json?" + _q(**p), headers=planit_ua(cfg or {}), timeout=25, ttl=3600)
    out = []
    for r in js.get("records", []) if isinstance(js, dict) else []:
        x, y = r.get("location_x"), r.get("location_y")
        state = (r.get("app_state") or "").strip()
        out.append({"ref": r.get("uid") or r.get("name") or "", "name": r.get("name") or "", "address": r.get("address") or "", "description": r.get("description") or "", "state": state, "size": r.get("app_size") or "",
                    "type": r.get("app_type") or "", "submitted": (r.get("start_date") or "")[:10], "decided": (r.get("decided_date") or "")[:10], "lpa": r.get("area_name") or "", "url": r.get("link") or r.get("url") or "",
                    "lat": y, "lon": x, "distance_km": round(geo.km(lat, lon, y, x), 2) if x is not None and y is not None else None})
    return out


UNITS_RE = re.compile(r"\b(\d{1,4})\s*(?:no\.?\s*)?(?:x\s*)?(?:new\s+|residential\s+|affordable\s+)*(dwellings?|homes?|units?|flats?|apartments?|houses?|bedroom)\b", re.I)


def units_of(text: str) -> int | None:
    best = None
    for m in UNITS_RE.finditer(text or ""):
        if m.group(2).lower() == "bedroom":
            continue
        n = int(m.group(1))
        if 1 < n < 3000:
            best = max(best or 0, n)
    return best


def planit_summary(apps: list[dict]) -> dict:
    by: dict[str, int] = {}
    for a in apps:
        by[a["state"] or "Unknown"] = by.get(a["state"] or "Unknown", 0) + 1
    big = [a for a in apps if a.get("size") in ("Large", "Medium") or (units_of(a["description"]) or 0) >= 10]
    return {"n": len(apps), "by_state": by, "major": len(big)}


def hpi(district: str) -> dict:
    slug = re.sub(r"[^a-z0-9]+", "-", (district or "").lower()).strip("-")
    if not slug:
        raise RuntimeError("no council area")
    today = date.today().replace(day=1)
    last = ""
    for back in range(2, 8):
        d = (today - timedelta(days=30 * back))
        ym = f"{d.year}-{d.month:02d}"
        try:
            js = _http(f"https://landregistry.data.gov.uk/data/ukhpi/region/{slug}/month/{ym}.json", ttl=7 * 86400)
        except Exception as e:
            last = str(e)
            continue
        it = ((js.get("result") or {}).get("primaryTopic")) or {}
        if it:
            return {"month": ym, "avg": it.get("averagePrice"), "annual": it.get("percentageAnnualChange"), "monthly": it.get("percentageChange"), "index": it.get("housePriceIndex"),
                    "detached": it.get("averagePriceDetached"), "semi": it.get("averagePriceSemiDetached"), "terraced": it.get("averagePriceTerraced"), "flat": it.get("averagePriceFlatMaisonette"),
                    "newbuild": it.get("averagePriceNewBuild"), "slug": slug}
    raise RuntimeError(f"no index found for {slug}" + (f" ({last})" if last else ""))


def nomis_find(term: str) -> list[dict]:
    js = _http("https://www.nomisweb.co.uk/api/v01/dataset/def.sdmx.json?" + _q(search=f"*{term}*"), ttl=30 * 86400)
    kf = ((js.get("structure") or {}).get("keyfamilies") or {}).get("keyfamily") or []
    return [{"id": k.get("id"), "name": ((k.get("name") or {}).get("value")) if isinstance(k.get("name"), dict) else k.get("name")} for k in kf if k.get("id")]


def nomis_census(lsoa_code: str) -> list[dict]:
    """Tenure and household counts for one LSOA from Census 2021 (table found by search)."""
    out = []
    for term, label in (("TS054", "Tenure"), ("TS001", "Usual residents")):
        try:
            found = nomis_find(term)
            if not found:
                continue
            ds = found[0]["id"]
            js = _http(f"https://www.nomisweb.co.uk/api/v01/dataset/{ds}.data.json?" + _q(geography=lsoa_code, measures=20100, select="geography_name,c2021_tenure_9_name,obs_value" if term == "TS054" else "geography_name,obs_value", uid="0x"), ttl=30 * 86400)
            obs = js.get("obs") or []
            if term == "TS054":
                vals = {}
                for o in obs:
                    nm = (o.get("c2021_tenure_9_name") or {}).get("description") if isinstance(o.get("c2021_tenure_9_name"), dict) else None
                    v = (o.get("obs_value") or {}).get("value")
                    if nm and v is not None:
                        vals[nm] = v
                tot = vals.get("Total: All households") or sum(v for k, v in vals.items() if not k.startswith("Total"))
                if tot:
                    own = vals.get("Owns outright", 0) + vals.get("Owns with a mortgage or loan or shared ownership", 0) + vals.get("Owns: Owns outright", 0)
                    rent = sum(v for k, v in vals.items() if "rent" in k.lower() and not k.startswith("Total"))
                    out.append({"group": GROUPS[2], "source": "ONS Census 2021", "id": "census-tenure", "label": "Households and tenure (LSOA)", "status": "info", "value": f"{int(tot):,} households, {rent / tot:.0%} renting" if rent else f"{int(tot):,} households",
                                "detail": "; ".join(f"{k}: {int(v):,}" for k, v in list(vals.items())[:9]), "weight": 0, "flag": None})
            else:
                if obs:
                    v = (obs[0].get("obs_value") or {}).get("value")
                    if v is not None:
                        out.append({"group": GROUPS[2], "source": "ONS Census 2021", "id": "census-pop", "label": "Usual residents (LSOA)", "status": "info", "value": f"{int(v):,}", "detail": "", "weight": 0, "flag": None})
        except Exception:
            continue
    return out


# ---------------------------------------------------------------- generic map services

def wms_layers(url: str) -> list[dict]:
    txt = _http(url + ("&" if "?" in url else "?") + _q(service="WMS", request="GetCapabilities"), timeout=25, text=True, ttl=7 * 86400)
    if not isinstance(txt, str):
        raise RuntimeError("unexpected response")
    root = ET.fromstring(txt)
    out = []
    for el in root.iter():
        if el.tag.split("}")[-1] == "Layer":
            nm = next((c.text for c in el if c.tag.split("}")[-1] == "Name"), None)
            ti = next((c.text for c in el if c.tag.split("}")[-1] == "Title"), None)
            if nm:
                out.append({"name": nm, "title": ti or nm})
    return out


def wms_info(url: str, layers: list[str], lat: float, lon: float) -> str:
    d = 0.0004
    p = {"service": "WMS", "version": "1.1.1", "request": "GetFeatureInfo", "layers": ",".join(layers), "query_layers": ",".join(layers), "srs": "EPSG:4326", "bbox": f"{lon - d},{lat - d},{lon + d},{lat + d}",
         "width": 101, "height": 101, "x": 50, "y": 50, "info_format": "text/plain", "feature_count": 5, "styles": ""}
    return _http(url + ("&" if "?" in url else "?") + _q(**p), timeout=20, text=True)


def arcgis_query(layer_url: str, lat: float, lon: float) -> list[dict]:
    js = _http(layer_url.rstrip("/") + "/query?" + _q(geometry=f"{lon},{lat}", geometryType="esriGeometryPoint", inSR=4326, spatialRel="esriSpatialRelIntersects", outFields="*", returnGeometry="false", f="json"), timeout=20)
    if isinstance(js, dict) and js.get("error"):
        raise RuntimeError(str((js["error"] or {}).get("message", "service error"))[:100])
    return [f.get("attributes") or {} for f in (js.get("features") or [])]


def wfs_query(url: str, type_name: str, lat: float, lon: float) -> list[dict]:
    d = 0.0002
    js = _http(url + ("&" if "?" in url else "?") + _q(service="WFS", version="2.0.0", request="GetFeature", typeNames=type_name, outputFormat="application/json", count=5,
                                                     bbox=f"{lat - d},{lon - d},{lat + d},{lon + d},urn:ogc:def:crs:EPSG::4326"), timeout=25)
    return [f.get("properties") or {} for f in (js.get("features") or [])]


def layer_check(layer: dict, lat: float, lon: float) -> dict:
    base = {"group": layer.get("group") or GROUPS[1], "source": layer.get("name", "Custom layer"), "id": "layer-" + re.sub(r"\W+", "", layer.get("name", "x").lower())[:20], "label": layer.get("name", "Custom layer"), "flag": None,
            "weight": float(layer.get("weight") or 0), "url": layer.get("url", "")}
    try:
        k = layer.get("type")
        if k == "arcgis":
            rows = arcgis_query(layer["url"], lat, lon)
        elif k == "wfs":
            rows = wfs_query(layer["url"], layer.get("layer", ""), lat, lon)
        else:
            txt = wms_info(layer["url"], [x for x in (layer.get("layer") or "").split(",") if x], lat, lon)
            body = re.sub(r"\s+", " ", txt or "").strip()
            empty = (not body) or bool(re.search(r"no features|search returned no results|^\W*$", body, re.I))
            return {**base, "status": "clear" if empty else "hit", "value": "None at this point" if empty else body[:160], "detail": "" if empty else body[:400]}
        field = layer.get("field") or ""
        if not rows:
            return {**base, "status": "clear", "value": "None at this point", "detail": ""}
        vals = [str(r.get(field)) for r in rows if field and r.get(field) not in (None, "")] or [", ".join(f"{k}: {v}" for k, v in list(r.items())[:3]) for r in rows[:2]]
        return {**base, "status": "hit", "value": "; ".join(vals)[:160], "detail": ""}
    except Exception as e:
        return {**base, "status": "error", "value": "Not checked", "detail": str(e)[:120]}


# ---------------------------------------------------------------- links

def links(site: dict, geog: dict | None = None) -> list[dict]:
    pc = (site.get("postcode") or (geog or {}).get("postcode") or "").strip()
    out = []
    for sid in ("ea-ltfr", "magic", "coal", "nhle", "voa", "ofcom", "dno", "lidar", "hmlr-oc1", "hmlr-inspire"):
        s = SRC_BY_ID[sid]
        u = s.get("url", "")
        if sid == "magic" and site.get("lat") is not None:
            e, n = geo.to_osgb(site["lat"], site["lon"])
            u = f"https://magic.defra.gov.uk/MagicMap.aspx?x={e}&y={n}&scale=5000"
        out.append({"id": sid, "name": s["name"], "group": s["group"], "url": u, "note": s["note"]})
    out.append({"id": "ch-search", "name": "Companies House search", "group": GROUPS[4], "url": "https://find-and-update.company-information.service.gov.uk/", "note": "Search for the company shown as proprietor in CCOD or the register."})
    if pc:
        out.append({"id": "ppd", "name": "Price paid for this postcode", "group": GROUPS[2], "url": "https://landregistry.data.gov.uk/app/ppd?" + _q(postcode=pc), "note": "Every registered sale."})
        out.append({"id": "epc-find", "name": "Energy certificates for this postcode", "group": GROUPS[2], "url": "https://find-energy-certificate.service.gov.uk/find-a-certificate/search-by-postcode?" + _q(postcode=pc), "note": ""})
    return out


# ---------------------------------------------------------------- enrichment

def enrich(site: dict, cfg: dict | None = None, hmlr_lookup=None) -> dict:
    """Run every enabled connector for a site with coordinates. Returns the data pack stored on the site."""
    cfg = merged(cfg if cfg is not None else settings())
    lat, lon = site.get("lat"), site.get("lon")
    if lat is None or lon is None:
        raise ValueError("The site needs coordinates: add a postcode")
    disc = discover_pdg()
    sets = active_pdg(cfg, disc)
    jobs = []
    off = set(cfg["off"])
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {}
        for d in sets:
            futs[ex.submit(pdg_check, d, lat, lon)] = ("pdg", d["id"])
        geog_f = ex.submit(geography, lat, lon) if "postcodes" not in off else None
        if "ea-flood" not in off:
            futs[ex.submit(ea_flood, lat, lon)] = ("multi", "ea-flood")
        if "osm" not in off:
            futs[ex.submit(overpass, lat, lon)] = ("multi", "osm")
        pl_f = ex.submit(planit, lat, lon, 0.8, cfg) if "planit" not in off else None
        for layer in cfg["layers"]:
            if layer.get("on", True):
                futs[ex.submit(layer_check, layer, lat, lon)] = ("one", layer.get("name"))
        for sid in ("coal", "bgs"):
            lay = (cfg.get("wms") or {}).get(sid)
            if lay and lay.get("on") and lay.get("layer") and sid not in off:
                futs[ex.submit(layer_check, {"type": "wms", "url": SRC_BY_ID[sid]["wms"], "layer": lay["layer"], "name": SRC_BY_ID[sid]["name"], "group": SRC_BY_ID[sid]["group"], "weight": lay.get("weight", 0)}, lat, lon)] = ("one", sid)
        items, errors = [], []
        for f, (kind, sid) in futs.items():
            try:
                r = f.result(timeout=90)
            except Exception as e:
                errors.append(f"{sid}: {str(e)[:100]}")
                continue
            for x in (r if isinstance(r, list) else [r]):
                items.append(x)
                if x.get("status") == "error":
                    errors.append(f"{x.get('label')}: {x.get('detail')}")
        geog = None
        if geog_f:
            try:
                geog = geog_f.result(timeout=30)
            except Exception as e:
                errors.append(f"Postcodes.io: {str(e)[:100]}")
        apps, pl_err = [], ""
        if pl_f:
            try:
                apps = pl_f.result(timeout=40)
            except Exception as e:
                pl_err = str(e)[:100]
                errors.append(f"PlanIt: {pl_err}")
    # market and demographics that depend on geography
    hpi_raw: dict = {}
    if geog:
        items.append({"group": GROUPS[0], "source": "Postcodes.io", "id": "geo", "label": "Local authority and ward", "status": "info", "value": f"{geog.get('district') or ''}, {geog.get('ward') or ''}", "detail": f"LSOA {geog.get('lsoa') or ''}; MSOA {geog.get('msoa') or ''}; {geog.get('region') or ''}", "weight": 0, "flag": None})
        jobs = []
        with ThreadPoolExecutor(max_workers=3) as ex:
            if "lr-hpi" not in off and geog.get("district"):
                jobs.append(("hpi", ex.submit(hpi, geog["district"])))
            if "nomis" not in off and (geog.get("codes") or {}).get("lsoa"):
                jobs.append(("nomis", ex.submit(nomis_census, geog["codes"]["lsoa"])))
            for k, f in jobs:
                try:
                    r = f.result(timeout=60)
                except Exception as e:
                    errors.append(f"{k}: {str(e)[:100]}")
                    continue
                if k == "hpi":
                    hpi_raw = r
                    items.append({"group": GROUPS[2], "source": "HM Land Registry UKHPI", "id": "hpi", "label": f"House price index, {geog['district']} ({r['month']})", "status": "info",
                                  "value": f"Average £{r['avg']:,.0f}, {r['annual']:+.1f}% on the year" if r.get("avg") is not None and r.get("annual") is not None else "Available", "weight": 0, "flag": None,
                                  "detail": "; ".join(f"{n} £{r[k2]:,.0f}" for n, k2 in (("Detached", "detached"), ("Semi", "semi"), ("Terraced", "terraced"), ("Flat", "flat"), ("New build", "newbuild")) if r.get(k2))})
                else:
                    items.extend(r)
    if apps:
        sm = planit_summary(apps)
        items.append({"group": GROUPS[0], "source": "PlanIt", "id": "planit", "label": "Applications within 800 m (latest 60)", "status": "info", "value": f"{sm['n']} recorded, {sm['major']} medium or large", "detail": ", ".join(f"{k}: {v}" for k, v in sm["by_state"].items()),
                      "weight": 0, "flag": None, "url": "https://www.planit.org.uk/"})
    elif "planit" not in off and not pl_err:
        items.append({"group": GROUPS[0], "source": "PlanIt", "id": "planit", "label": "Applications within 800 m", "status": "clear", "value": "None recorded", "detail": "", "weight": 0, "flag": None})
    if hmlr_lookup and "hmlr-ccod" not in off:
        try:
            pc = site.get("postcode") or (geog or {}).get("postcode") or ""
            hits = hmlr_lookup(pc, site) if pc else []
            if hits is not None:
                items.append({"group": GROUPS[4], "source": "HM Land Registry CCOD/OCOD", "id": "ccod", "label": "Company-owned titles at this postcode", "status": "hit" if hits else "clear",
                              "value": f"{len(hits)} title{'s' if len(hits) != 1 else ''}" if hits else "None in the loaded data", "detail": "; ".join(f"{h['proprietor']} ({h['title']})" for h in hits[:4]), "weight": 0, "flag": None, "titles": hits[:20]})
        except Exception as e:
            errors.append(f"CCOD: {str(e)[:100]}")
    order = {g: i for i, g in enumerate(GROUPS)}
    items.sort(key=lambda x: (order.get(x["group"], 9), {"hit": 0, "info": 1, "clear": 2, "error": 3}.get(x["status"], 4), x["label"]))
    flags = {}
    for x in items:
        if x.get("status") == "hit" and x.get("flag"):
            if x["flag"] == "flood_zone":
                lv = [str(e.get("flood")) for e in x.get("entities", []) if e.get("flood")]
                flags["flood_zone"] = max(lv) if lv else "2"
            elif x["flag"] != "article4":
                flags[x["flag"]] = True
    if any(k in flags for k in ("sssi", "spa", "sac", "ancient_woodland")):
        flags["ecology_designation"] = True
    if any(k in flags for k in ("national_park", "aonb")):
        flags["protected_landscape"] = True
    area = next((x.get("area_ha") for x in items if x.get("id") == "title-boundary" and x.get("area_ha")), None)
    return {"checked": datetime.now(timezone.utc).isoformat(timespec="minutes"), "items": items, "errors": errors[:20], "geography": geog, "flags": flags, "title_area_ha": area,
            "hpi": hpi_raw, "planit": apps[:40], "links": links(site, geog), "counts": {"hit": sum(1 for x in items if x["status"] == "hit"), "clear": sum(1 for x in items if x["status"] == "clear"), "error": sum(1 for x in items if x["status"] == "error"),
                                                                        "datasets": len(sets)}, "platform_listed": bool(disc.get("datasets"))}


# ---------------------------------------------------------------- tests for the Data page

def test_all(cfg: dict | None = None, workers: int = 6) -> dict:
    """Run every live test once, in parallel, and return {id: result}."""
    from concurrent.futures import ThreadPoolExecutor
    ids = sorted({s["test"] for s in SOURCES if s.get("test")})
    cfg = cfg if cfg is not None else settings()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        res = list(ex.map(lambda i: test(i, cfg), ids))
    return dict(zip(ids, res))


def test(sid: str, cfg: dict | None = None) -> dict:
    """Try one source with a known point (central London). Returns {ok, ms, detail}."""
    cfg = merged(cfg if cfg is not None else settings())
    t0 = time.time()
    lat, lon = 51.5074, -0.1278
    try:
        if sid == "pdg":
            d = discover_pdg(force=True)
            if not d["ok"]:
                raise RuntimeError(d["error"])
            have = set(d["datasets"])
            miss = [x["id"] for x in PDG_SETS if x["id"] not in have]
            det = f"{len(have)} datasets published" + (f"; {len(miss)} in the registry are not on the platform: {', '.join(miss[:6])}" if miss else "; every registry dataset is present")
        elif sid == "planit":
            r = planit(lat, lon, 0.5, cfg, pg_sz=3)
            det = f"{len(r)} applications returned"
        elif sid == "postcodes":
            g = geography(lat, lon)
            det = f"{g.get('district')}, {g.get('region')}"
        elif sid == "ea":
            r = ea_flood(lat, lon)
            det = "; ".join(x["value"] for x in r)
        elif sid == "ppd":
            from . import comps
            r = _http(comps.SPARQL + "?" + _q(query='ASK { ?s ?p ?o }'), headers={"Accept": "application/sparql-results+json"}, timeout=20)
            det = "SPARQL endpoint answered" if isinstance(r, dict) else "endpoint reachable"
        elif sid == "levies":
            from . import levies
            rows = levies._csv_rows(f"{levies.FILES}/dataset/{levies.DATASET}.csv")
            det = f"{len(rows)} charging schedules listed"
            if not rows:
                raise RuntimeError("the schedule file was empty")
        elif sid == "osrm":
            from . import places
            m = places.osrm_minutes((51.5074, -0.1278), (51.4545, -0.9781), "drive")
            det = f"London to Reading by car: {m:.0f} minutes"
        elif sid == "hpi":
            r = hpi("Westminster")
            det = f"Westminster {r['month']}: average £{r['avg']:,.0f}" if r.get("avg") else "index returned"
        elif sid == "nomis":
            f = nomis_find("TS054")
            det = f"{len(f)} matching tables, first {f[0]['id']}" if f else "no table found for TS054"
            if not f:
                raise RuntimeError(det)
        elif sid == "osm":
            r = overpass(lat, lon, 400)
            det = f"{sum(x.get('count', 0) for x in r)} features within 400 m"
        elif sid == "hmlr":
            k = cfg.get("hmlr_key")
            if not k:
                return {"ok": None, "ms": 0, "detail": "No API key set. Upload a CCOD or OCOD file instead, or add a key from your Use land and property data account."}
            js = _http("https://use-land-property-data.service.gov.uk/api/v1/datasets/ccod", headers={"Authorization": k})
            det = "key accepted" if js else "empty response"
        elif sid == "ch":
            k = cfg.get("ch_key")
            if not k:
                return {"ok": None, "ms": 0, "detail": "No key set. Register free at developer.company-information.service.gov.uk."}
            js = _http("https://api.company-information.service.gov.uk/company/00000006", headers={"Authorization": "Basic " + base64.b64encode(f"{k}:".encode()).decode()})
            det = f"key accepted ({js.get('company_name', '')})"
        elif sid in ("coal", "bgs"):
            ls = wms_layers(SRC_BY_ID[sid]["wms"])
            det = f"{len(ls)} layers listed"
            if not ls:
                raise RuntimeError("no layers listed")
        else:
            return {"ok": None, "ms": 0, "detail": "Reference link only. Nothing to test."}
        return {"ok": True, "ms": int((time.time() - t0) * 1000), "detail": det}
    except Exception as e:
        return {"ok": False, "ms": int((time.time() - t0) * 1000), "detail": str(e)[:200]}
