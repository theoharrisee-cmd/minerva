"""Change history for each site: what was changed, when, and what it did to the numbers.

A version is saved whenever a saved change alters the appraisal inputs: price, scheme, assumptions, programme or funding.
Comparing two versions lists each change and attributes the movement in profit to groups of inputs, applied in a fixed
order (scheme, pricing, assumptions, programme, funding), so the parts add up to the whole. The order matters when
inputs interact, so read the split as a guide to what moved the answer, not as exact accounting.
"""
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone

KEEP = 60
GROUPS = [
    ("scheme", "Scheme", ("units", "site_ha", "unit_mix", "existing_sqft", "gia_sqft", "build_cost_total", "strategy")),
    ("pricing", "Price and values", ("asking_price", "sales_psf", "rent_psf")),
    ("assumptions", "Assumptions", ("ovr",)),
    ("programme", "Programme", ("programme",)),
    ("funding", "Funding terms", ("funding",)),
    ("tax", "Tax settings", ("tax",)),
    ("status", "Status", ("planning_status", "stage")),
]
KEYS = [k for _, _, ks in GROUPS for k in ks]
FIELD_LABELS = {"units": "Homes", "site_ha": "Site area (ha)", "unit_mix": "Unit mix", "existing_sqft": "Existing floor area (sq ft)", "gia_sqft": "Gross floor area (sq ft)",
                "build_cost_total": "Build cost (total)", "strategy": "Strategy", "asking_price": "Asking price", "sales_psf": "Sales value (£ psf)", "rent_psf": "Rent (£ psf)",
                "planning_status": "Planning status", "stage": "Stage"}
PATH_LABELS = [("/api/site", "Site details edited"), ("/api/model", "Appraisal assumptions changed"), ("/api/suggest/apply", "Suggestion applied"), ("/api/suggest/revert", "Suggestion reverted"),
               ("/api/homes/market", "Market pricing applied"), ("/api/typology", "Homes schedule changed"), ("/api/programme", "Programme changed"), ("/api/funding", "Funding terms changed"),
               ("/api/compset", "Comparable adjustments changed"), ("/api/layout", "Layout applied"), ("/api/comps/apply", "Sales value set from comparables"), ("/api/site/boundary", "Boundary drawn"),
               ("/api/strategy", "Planning period set from strategy"), ("/api/scenario", "Scenario changed"), ("/api/units", "Unit mix changed"),
               ("/api/tax", "Tax settings changed"), ("/api/levies", "Council levy figure applied"), ("/api/costplan", "Cost plan applied or cleared")]


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def label_for(path: str) -> str:
    best = ""
    for p, l in PATH_LABELS:
        if path.startswith(p) and len(p) > len(best):
            best = p
    return dict(PATH_LABELS).get(best, "Edited")


def inputs_of(site: dict) -> dict:
    return {k: deepcopy(site[k]) for k in KEYS if site.get(k) not in (None, {}, [], "")}


def sig(inp: dict) -> str:
    return hashlib.sha1(json.dumps(inp, sort_keys=True, default=str).encode()).hexdigest()[:12]


def headline(ev: dict | None) -> dict:
    a = (ev or {}).get("appraisal") or {}
    keys = ("units", "gdv", "total_cost", "profit", "profit_on_gdv", "profit_on_cost", "rlv", "irr_levered", "irr_unlevered", "peak_equity", "equity_multiple", "yield_on_cost", "viable", "incomplete", "asking")
    h = {k: a.get(k) for k in keys}
    h["score"] = ((ev or {}).get("score") or {}).get("total") if isinstance((ev or {}).get("score"), dict) else (ev or {}).get("score")
    return h


def record(site: dict, label: str, evaluate) -> dict | None:
    """Save a version if the inputs changed since the last one. `evaluate(site)` returns the standard evaluation."""
    inp = inputs_of(site)
    sg = sig(inp)
    h = site.setdefault("history", [])
    if h and h[-1]["sig"] == sg:
        return None
    snap = {"t": now(), "label": label, "sig": sg, "inputs": inp, "headline": headline(evaluate(site))}
    h.append(snap)
    if len(h) > KEEP:
        del h[1:len(h) - KEEP + 1]
    return snap


def ensure(site: dict, evaluate) -> None:
    """Make sure there is a baseline to compare against before the first change."""
    if not site.get("history"):
        record(site, "Before the first recorded change", evaluate)


def _fmt(v) -> str:
    if v is None:
        return "not set"
    if isinstance(v, float):
        return f"{v:,.4g}" if abs(v) < 10 else f"{v:,.0f}"
    if isinstance(v, int):
        return f"{v:,}"
    return str(v)


PCT_KEYS = {"finance_rate", "mezz_rate", "exit_yield", "ltc", "mezz_ltc", "efficiency", "purchaser_costs", "target_profit_gdv", "target_profit_cost_btr",
            "target_profit_cost_va", "cost_of_equity", "offer_discount", "uplift_pct", "personal_rate", "affordable_pct", "contingency_pct", "fees_pct", "external_pct"}


def _fmt_key(k: str, v) -> str:
    if isinstance(v, (int, float)) and not isinstance(v, bool) and (k.endswith("_pct") or k in PCT_KEYS):
        return f"{v * 100:.2f}".rstrip("0").rstrip(".") + "%"
    return _fmt(v)


def _mix_summary(m) -> str:
    m = m or []
    return f"{sum(int(x.get('count') or 0) for x in m)} homes in {len(m)} types, value £{sum(int(x.get('count') or 0) * float(x.get('sale_value') or 0) for x in m):,.0f}"


def changes(old: dict, new: dict, labels: dict | None = None) -> list[dict]:
    """Field by field differences between two input sets."""
    from . import programme
    labels = labels or {}
    special = {"programme": {k: "Programme: " + v.replace(" (months)", "").replace(" (%)", "") for k, v in programme.LABELS.items()},
               "funding": {"draw_mode": "Drawdown method", "exit_fee_pct": "Exit fee"},
               "tax": {"structure": "Ownership structure", "personal_rate": "Personal tax rate", "associated": "Associated companies", "tax_delay": "Months from exit to tax payment", "vat_override": "Irrecoverable VAT"}}
    out = []
    for gid, gname, keys in GROUPS:
        for k in keys:
            a, b = old.get(k), new.get(k)
            if a == b:
                continue
            if k in ("ovr", "programme", "funding", "tax"):
                a, b = a or {}, b or {}
                for kk in sorted(set(a) | set(b)):
                    if a.get(kk) != b.get(kk):
                        out.append({"group": gid, "group_label": gname, "field": kk, "label": (special.get(k, {}).get(kk) or labels.get(kk) or kk.replace("_", " ").capitalize()), "old": _fmt_key(kk, a.get(kk)), "new": _fmt_key(kk, b.get(kk))})
            elif k == "unit_mix":
                out.append({"group": gid, "group_label": gname, "field": k, "label": "Unit mix", "old": _mix_summary(a), "new": _mix_summary(b)})
            else:
                out.append({"group": gid, "group_label": gname, "field": k, "label": FIELD_LABELS.get(k, k), "old": _fmt(a), "new": _fmt(b)})
    return out


def attribute(site: dict, old: dict, new: dict, profit_of) -> list[dict]:
    """Split the change in profit across the groups that changed. `profit_of(inputs)` returns profit or None."""
    cur = deepcopy(old)
    p_prev = profit_of(cur)
    parts = []
    for gid, gname, keys in GROUPS:
        if gid == "tax" or not any(old.get(k) != new.get(k) for k in keys):
            continue  # tax settings do not change the profit before tax
        for k in keys:
            if k in new:
                cur[k] = deepcopy(new[k])
            else:
                cur.pop(k, None)
        p = profit_of(cur)
        parts.append({"group": gid, "label": gname, "profit_change": (p - p_prev) if (p is not None and p_prev is not None) else None})
        if p is not None:
            p_prev = p
    return parts


def diff(site: dict, a: dict, b: dict, profit_of, labels: dict | None = None) -> dict:
    ch = changes(a["inputs"], b["inputs"], labels)
    ha, hb = a["headline"], b["headline"]
    metrics = []
    for k, lbl, kind in (("gdv", "Gross development value", "money"), ("total_cost", "Total cost", "money"), ("profit", "Profit", "money"), ("profit_on_gdv", "Profit on GDV", "pct"),
                         ("rlv", "Residual land value", "money"), ("irr_levered", "Levered IRR", "pct"), ("peak_equity", "Peak equity", "money"), ("units", "Homes", "num")):
        va, vb = ha.get(k), hb.get(k)
        metrics.append({"key": k, "label": lbl, "kind": kind, "a": va, "b": vb, "delta": (vb - va) if (va is not None and vb is not None) else None})
    return {"a": {"t": a["t"], "label": a["label"]}, "b": {"t": b["t"], "label": b["label"]}, "changes": ch, "metrics": metrics,
            "attribution": attribute(site, a["inputs"], b["inputs"], profit_of), "same": not ch}


def timeline(site: dict) -> list[dict]:
    """Versions and events, newest first, with the change in profit between versions."""
    out = []
    prev = None
    for i, s in enumerate(site.get("history") or []):
        p = s["headline"].get("profit")
        out.append({"kind": "version", "index": i, "t": s["t"], "title": s["label"], "profit": p, "delta": (p - prev) if (p is not None and prev is not None) else None,
                    "profit_on_gdv": s["headline"].get("profit_on_gdv"), "incomplete": s["headline"].get("incomplete")})
        prev = p if p is not None else prev
    for e in site.get("events") or []:
        out.append({"kind": "event", "t": e.get("ts", ""), "title": e.get("title", ""), "detail": e.get("detail", ""), "level": e.get("level", "info")})
    out.sort(key=lambda x: (x["t"], x.get("index", -1)), reverse=True)
    return out
