"""Due diligence checklist and tracker, seeded from the deal's own data."""
from __future__ import annotations

import uuid
from datetime import date

STATUSES = ["Not started", "Requested", "In progress", "Done", "Issue", "Not applicable"]

# (category, item, needed-when predicate key)
TEMPLATE = [
    ("Title and legal", "Office copy of title and title plan", None),
    ("Title and legal", "Restrictive covenants, easements and rights reviewed", None),
    ("Title and legal", "Ransom strips and third party access rights checked", None),
    ("Title and legal", "Overage or clawback provisions identified", None),
    ("Title and legal", "Existing leases, licences and occupiers confirmed", None),
    ("Title and legal", "Heads of terms agreed with vendor", None),
    ("Planning", "Planning history and decision notices collected", "planning"),
    ("Planning", "Officer reports and consultee responses reviewed", "planning"),
    ("Planning", "Conditions schedule reviewed, pre-commencement conditions costed", "consented"),
    ("Planning", "S106 heads of terms and CIL liability confirmed", None),
    ("Planning", "Permission expiry and commencement strategy confirmed", "consented"),
    ("Planning", "Pre-application meeting held or scheduled", "unconsented"),
    ("Technical", "Phase 1 ground investigation (desk study)", None),
    ("Technical", "Phase 2 intrusive investigation", "contamination"),
    ("Technical", "Flood risk assessment and drainage strategy", "flood"),
    ("Technical", "Ecology survey and biodiversity net gain plan", "ecology"),
    ("Technical", "Arboricultural survey", "trees"),
    ("Technical", "Utilities capacity confirmed: power, water, sewers, broadband", None),
    ("Technical", "Highways access and transport review", None),
    ("Technical", "Structural survey and heritage impact review", "heritage"),
    ("Technical", "Topographical survey", None),
    ("Commercial", "Independent valuation of land and completed scheme", None),
    ("Commercial", "Sales and rental evidence checked against appraisal", None),
    ("Commercial", "Build cost estimate from a quantity surveyor", None),
    ("Commercial", "Agent and buyer or lessee feedback gathered", None),
    ("Commercial", "Registered provider or affordable housing offer received", None),
    ("Funding", "Equity approval from investment committee", None),
    ("Funding", "Debt terms received from at least two lenders", None),
    ("Funding", "Insurance and warranty quotes obtained", None),
    ("Funding", "Tax and SDLT structuring advice", None),
    ("Programme", "Contractor procurement route agreed", None),
    ("Programme", "Programme signed off with build and sales periods", None),
]


def _needed(site: dict, key: str | None) -> bool:
    if key is None:
        return True
    ps = (site.get("planning_status") or "").lower()
    return {
        "planning": bool(site.get("planning_history")) or ps in ("consented", "refused", "pre-app", "allocated"),
        "consented": ps == "consented",
        "unconsented": ps not in ("consented",),
        "contamination": bool(site.get("contamination") or site.get("brownfield")),
        "flood": str(site.get("flood_zone") or "1") in ("2", "3") or (site.get("site_ha") or 0) >= 1,
        "ecology": bool(site.get("trees")) or (site.get("site_ha") or 0) >= 1,
        "trees": bool(site.get("trees")),
        "heritage": bool(site.get("listed") or site.get("conservation_area")),
    }.get(key, True)


def seed(site: dict) -> list[dict]:
    """Create the default checklist and mark what the file already evidences."""
    docs = site.get("docs") or []
    cats = {d.get("category") for d in docs}
    names = " ".join((d.get("name") or "").lower() + " " + (d.get("title") or "").lower() for d in docs)
    items = []
    for cat, text, key in TEMPLATE:
        st = "Not started" if _needed(site, key) else "Not applicable"
        note = ""
        low = text.lower()
        if "decision notices" in low and ("Decision notice" in cats):
            st, note = "Done", "Decision notice on file."
        elif "officer reports" in low and ("Officer report" in cats and "Consultee response" in cats):
            st, note = "Done", "Officer report and consultee responses on file."
        elif "s106" in low and "S106 / obligations" in cats:
            st, note = "In progress", "Obligation documents on file. Confirm figures."
        elif "flood risk" in low and "flood" in names:
            st, note = "In progress", "Flood document on file."
        elif "ecology" in low and "ecolog" in names:
            st, note = "In progress", "Ecology document on file."
        elif "phase 1" in low and ("phase 1" in names or "desk study" in names):
            st, note = "In progress", "Phase 1 document on file."
        elif "expiry" in low and site.get("key_dates"):
            st, note = "In progress", "Key dates recorded."
        items.append({"id": uuid.uuid4().hex[:8], "category": cat, "item": text, "status": st, "owner": "", "due": "", "note": note, "custom": False})
    return items


def summary(items: list[dict]) -> dict:
    live = [i for i in items if i.get("status") != "Not applicable"]
    done = sum(1 for i in live if i["status"] == "Done")
    issues = [i for i in live if i["status"] == "Issue"]
    today = date.today().isoformat()
    overdue = [i for i in live if i.get("due") and i["due"] < today and i["status"] != "Done"]
    return {"total": len(live), "done": done, "pct": round(done / len(live) * 100) if live else 0, "issues": len(issues), "overdue": len(overdue),
            "open_issues": [i["item"] for i in issues]}


def clean(items: list[dict]) -> list[dict]:
    out = []
    for i in items or []:
        if not str(i.get("item", "")).strip():
            continue
        st = i.get("status") if i.get("status") in STATUSES else "Not started"
        out.append({"id": i.get("id") or uuid.uuid4().hex[:8], "category": i.get("category") or "Other", "item": str(i["item"]).strip(), "status": st,
                    "owner": str(i.get("owner") or ""), "due": str(i.get("due") or ""), "note": str(i.get("note") or ""), "custom": bool(i.get("custom"))})
    return out
