"""Site brief: a short Word document that puts everything known about one site in one place."""
from __future__ import annotations

import io
from datetime import date

from .committee import _borders, _fix_width, _shade, fdate, money, pct, verdict


def build(pack: dict) -> bytes:
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor

    s, ev, pl = pack["site"], pack["ev"], pack["planning"]
    a = ev.get("appraisal") or {}
    ok = a and not a.get("incomplete")
    flags = ev.get("flags") or []
    vd, why = verdict(a, flags)
    dt = pack.get("data") or {}
    hm = pack.get("homes")
    lay = pack.get("layout")
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(1.8)
    sec.top_margin = sec.bottom_margin = Cm(1.5)
    base = doc.styles["Normal"]
    base.font.name, base.font.size = "Aptos", Pt(9.5)
    base.paragraph_format.space_after = Pt(4)
    for name, size in (("Heading 1", 12.5), ("Heading 2", 10.5)):
        h = doc.styles[name]
        h.font.name, h.font.size, h.font.bold, h.font.italic = "Aptos", Pt(size), True, False
        h.font.color.rgb = RGBColor(0, 0, 0)
        h.paragraph_format.space_before, h.paragraph_format.space_after = Pt(10), Pt(3)

    def para(text="", bold=False, size=None, color=None, after=None):
        p = doc.add_paragraph()
        r = p.add_run(text)
        r.bold = bold
        if size:
            r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor.from_string(color)
        if after is not None:
            p.paragraph_format.space_after = Pt(after)
        return p

    def table(rows, widths, right=(), font=8.5, header=True):
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        _borders(t)
        _fix_width(t, widths)
        for i, r in enumerate(rows):
            for j, v in enumerate(r):
                c = t.cell(i, j)
                c.text = ""
                run = c.paragraphs[0].add_run(str(v))
                run.font.size = Pt(font)
                c.paragraphs[0].paragraph_format.space_after = Pt(0)
                if header and i == 0:
                    run.bold = True
                    _shade(c, "EDEDED")
                if j in right:
                    c.paragraphs[0].alignment = 2
        doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # masthead
    t = doc.add_table(rows=1, cols=1)
    _fix_width(t, [17.4])
    c = t.cell(0, 0)
    _shade(c, "FF6600")
    c.text = ""
    r = c.paragraphs[0].add_run("Site brief")
    r.bold, r.font.size, r.font.color.rgb = True, Pt(9), RGBColor(255, 255, 255)
    p = c.add_paragraph()
    r = p.add_run(s.get("name", "Site"))
    r.bold, r.font.size, r.font.color.rgb = True, Pt(18), RGBColor(255, 255, 255)
    p = c.add_paragraph()
    r = p.add_run(" · ".join(x for x in (s.get("address"), s.get("postcode")) if x))
    r.font.size, r.font.color.rgb = Pt(9.5), RGBColor(255, 255, 255)
    para(f"Prepared {fdate(date.today().isoformat())} from the data held in easyDevelopment. Sources and dates are stated against each section.", size=8.5, color="666666")

    if dt.get("map"):
        doc.add_picture(io.BytesIO(dt["map"]), width=Cm(17.4))

    # facts and verdict
    strat = pack["strategies"].get(ev["strategy"], ev["strategy"])
    facts = [["Site area", f"{s['site_ha']} ha" if s.get("site_ha") else "not recorded", "Homes", str(s.get("units") or (a.get("units") if ok else "") or "not recorded")],
             ["Planning status", s.get("planning_status") or "Unknown", "Strategy", strat],
             ["Asking price", money(s.get("asking_price")) if s.get("asking_price") else "not stated", "Stage", s.get("stage") or ""],
             ["Vendor or agent", s.get("vendor") or (pack.get("contact") or {}).get("name") or "not recorded", "Score", f"{ev['score']['score']} ({ev['score']['grade']})"]]
    table(facts, [3.2, 5.5, 3.0, 5.7], header=False)
    para(f"{vd}. {why}", bold=True, size=10)

    doc.add_heading("Appraisal", 1)
    if ok:
        table([["Gross development value", money(a["gdv"]), "Total cost", money(a["total_cost"])],
               ["Profit", f"{money(a['profit'])} ({pct(a['profit_on_gdv'])} of GDV)", "Residual land value", money(a["rlv"])],
               ["Levered IRR", pct(a.get("irr_levered")), "Equity multiple", f"{a['equity_multiple']:.2f}x" if a.get("equity_multiple") else "n/a"]], [4.2, 4.6, 4.2, 4.4], header=False)
    else:
        para("The appraisal is incomplete: " + ", ".join(a.get("missing") or ["site details"]) + " needed.")
    acc = (s.get("suggest") or {}).get("accepted") or {}
    if acc:
        para("Allowances applied from the data checks: " + "; ".join(v["title"] for v in acc.values()) + ". These are indicative desk values.", size=8.5, color="666666")

    doc.add_heading("Planning", 1)
    ro = pl.get("read_out") or {}
    para(f"{ro.get('status') or s.get('planning_status') or 'Unknown'}. Planning risk: {ro.get('risk') or 'not assessed'}." + (f" Permission expires {fdate(ro['permission_expiry'])}." if ro.get("permission_expiry") else ""))
    for x in (ro.get("points") or [])[:5]:
        para(f"{x['level']}: {x['text']}", size=9, after=2)
    for ln in dt.get("record_lines", []):
        para(ln, size=9, after=2)

    if dt.get("constraints"):
        doc.add_heading("Constraints", 1)
        table(dt["constraints"], [5, 9.2, 3.2])
        if dt.get("constraints_line"):
            para(dt["constraints_line"], size=8.5, color="666666")
    doc.add_heading("Ownership and title", 1)
    table([["Item", "Detail"]] + dt.get("ownership", [["Ownership", "Not researched."]]), [4.4, 13])
    if dt.get("applications"):
        doc.add_heading("Applications nearby", 1)
        table(dt["applications"], [2.4, 8.8, 2.2, 2.6, 1.4], right=(4,), font=8)
    if dt.get("access"):
        doc.add_heading("Access and amenities", 1)
        table(dt["access"], [6, 11.4])

    if hm:
        from . import homes_out
        rows, tot = homes_out.schedule(hm)
        doc.add_heading("Homes", 1)
        para(", ".join(tot) + ".")
        table(rows, [6.6, 1.8, 1.5, 1.8, 2.8, 2.9], right=(1, 2, 3, 4, 5))
        para(homes_out.counts_line(hm), size=8.5, color="666666")
    if lay:
        from . import layout as _lay
        doc.add_heading("Layout test", 1)
        para(f"{lay['homes']} houses fit at {lay['density_dph']} homes per hectare. {lay['note'].capitalize()}.")
        try:
            doc.add_picture(io.BytesIO(_lay.to_png(lay)), width=Cm(15))
        except ImportError:
            pass
    if flags:
        doc.add_heading("Risks", 1)
        table([["Risk", "Severity", "Mitigation"]] + [[f["flag"], f["severity"], f.get("mitigation", "")] for f in flags[:6]], [5.4, 2, 10])
    an = (pl.get("analysis") or {}) if isinstance(pl, dict) else {}
    steps = an.get("next_steps") or []
    if steps:
        doc.add_heading("Next steps", 1)
        for x in steps[:6]:
            para("• " + str(x), after=1)
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()
