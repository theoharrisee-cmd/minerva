"""HM Land Registry ownership data and related owner look-ups (standard library only).

Free: CCOD and OCOD (company and overseas company owners), by API key from the Use land and property data
service or by upload, indexed locally so a postcode, title number or company name is instant.
Paid per title: the official copy of the register. Import the PDF and it is read into the site.
Optional: any paid title data provider, configured by URL template and field paths.
"""
from __future__ import annotations

import base64
import csv
import io
import json
import re
import sqlite3
import threading
import zipfile
from datetime import date, datetime, timezone
from pathlib import Path

from . import datasources as ds
from . import store

DB = store.DATA / "hmlr.sqlite"
_lock = threading.Lock()
STATUS = {"running": False, "dataset": "", "rows": 0, "message": "", "error": ""}
SIZE_LIMIT = 6_000_000_000

FIELDS = {
    "title number": "title", "tenure": "tenure", "property address": "address", "district": "district", "county": "county", "region": "region", "postcode": "postcode",
    "multiple address indicator": "multi", "price paid": "price", "date proprietor added": "added",
}


def norm_pc(pc: str) -> str:
    return re.sub(r"\s+", "", (pc or "").upper())


def outward(pc: str) -> str:
    n = norm_pc(pc)
    return n[:-3] if len(n) > 4 else n


def _db() -> sqlite3.Connection:
    c = sqlite3.connect(DB, timeout=30)
    c.execute("""create table if not exists titles(title text, tenure text, address text, district text, county text, region text, postcode text, pc text, outw text, price real,
                 proprietor text, pkey text, company_no text, category text, paddr text, added text, dataset text, country text)""")
    c.execute("create table if not exists meta(dataset text primary key, rows integer, loaded text, source text)")
    c.execute("create table if not exists changes(dataset text, loaded text, kind text, title text, pc text, address text, old text, new text)")
    c.execute("create table if not exists diffs(dataset text, loaded text, added integer, removed integer, transferred integer, watched integer)")
    for i, col in (("i_pc", "pc"), ("i_out", "outw"), ("i_p", "pkey"), ("i_t", "title"), ("i_c", "company_no")):
        c.execute(f"create index if not exists {i} on titles({col})")
    return c


def _pkey(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", (s or "").lower()).strip()


def _num(x):
    try:
        return float(re.sub(r"[^\d.]", "", x)) if x not in (None, "") else None
    except ValueError:
        return None


def load_stream(fh, dataset: str, source: str = "upload", progress=None) -> int:
    """Load CCOD or OCOD CSV text lines into the local index, replacing that dataset."""
    rd = csv.reader(fh)
    head = next(rd)
    idx = {re.sub(r"\s+", " ", h.strip().lstrip("\ufeff").lower()): i for i, h in enumerate(head)}
    if "title number" not in idx:
        raise ValueError("This does not look like a CCOD or OCOD file: no 'Title Number' column")
    with _lock:
        c = _db()
        had = c.execute("select rows from meta where dataset=?", (dataset,)).fetchone()
        if had:
            c.execute("drop table if exists prev")
            c.execute("create temp table prev as select title, pkey, pc, proprietor from titles where dataset=?", (dataset,))
            c.execute("create index prev_i on prev(title, pkey)")
        c.execute("delete from titles where dataset=?", (dataset,))
        n = 0
        batch = []

        def g(row, key):
            i = idx.get(key)
            return row[i].strip() if i is not None and i < len(row) else ""

        for row in rd:
            if not row:
                continue
            base = {v: g(row, k) for k, v in FIELDS.items()}
            pc = base["postcode"]
            for k in range(1, 5):
                name = g(row, f"proprietor name ({k})")
                if not name:
                    continue
                addr = ", ".join(x for x in (g(row, f"proprietor ({k}) address (1)"), g(row, f"proprietor ({k}) address (2)"), g(row, f"proprietor ({k}) address (3)")) if x)
                batch.append((base["title"], base["tenure"], base["address"], base["district"], base["county"], base["region"], pc, norm_pc(pc), outward(pc), _num(base["price"]),
                              name, _pkey(name), g(row, f"company registration no. ({k})"), g(row, f"proprietorship category ({k})"), addr, base["added"], dataset, g(row, f"country incorporated ({k})")))
            if len(batch) >= 5000:
                c.executemany("insert into titles values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", batch)
                n += len(batch)
                batch = []
                STATUS["rows"] = n
        if batch:
            c.executemany("insert into titles values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", batch)
            n += len(batch)
        now = datetime.now(timezone.utc).isoformat(timespec="minutes")
        c.execute("insert or replace into meta values(?,?,?,?)", (dataset, n, now, source))
        if had:
            STATUS["diff"] = _diff(c, dataset, now)
        c.commit()
        c.close()
    STATUS["rows"] = n
    return n


def watch_postcodes() -> set[str]:
    try:
        return {norm_pc(x) for x in (WATCH() or []) if x}
    except Exception:
        return set()


WATCH = lambda: []  # replaced by the server with a function returning the postcodes of watched sites


def _diff(c, dataset: str, now: str) -> dict:
    """Compare the freshly loaded file with the one it replaced. Totals for everything, detail for watched postcodes only."""
    c.execute("create temp table if not exists newp as select title, pkey from titles where 0")
    c.execute("delete from newp")
    c.execute("insert into newp select title, pkey from titles where dataset=?", (dataset,))
    c.execute("create index if not exists newp_i on newp(title, pkey)")
    added = c.execute("select count(*) from newp n where not exists (select 1 from prev p where p.title=n.title and p.pkey=n.pkey)").fetchone()[0]
    gone = c.execute("select count(*) from prev p where not exists (select 1 from newp n where p.title=n.title and p.pkey=n.pkey)").fetchone()[0]
    watch = watch_postcodes()
    kept = 0
    transferred = 0
    if watch:
        marks = ",".join("?" * len(watch))
        arr = list(watch)
        new_rows = c.execute(f"select t.title, t.pc, t.address, t.proprietor from titles t where t.dataset=? and t.pc in ({marks}) and not exists (select 1 from prev p where p.title=t.title and p.pkey=t.pkey)", [dataset, *arr]).fetchall()
        old_rows = c.execute(f"select p.title, p.pc, p.proprietor from prev p where p.pc in ({marks}) and not exists (select 1 from newp n where n.title=p.title and n.pkey=p.pkey)", arr).fetchall()
        old_by_title = {}
        for title, pc, name in old_rows:
            old_by_title.setdefault(title, []).append((pc, name))
        seen_new = set()
        for title, pc, addr, name in new_rows:
            seen_new.add(title)
            if title in old_by_title:
                c.execute("insert into changes values(?,?,?,?,?,?,?,?)", (dataset, now, "Transferred", title, pc, addr, "; ".join(n for _, n in old_by_title[title]), name))
                transferred += 1
            else:
                c.execute("insert into changes values(?,?,?,?,?,?,?,?)", (dataset, now, "New title", title, pc, addr, "", name))
            kept += 1
        for title, lst in old_by_title.items():
            if title not in seen_new:
                c.execute("insert into changes values(?,?,?,?,?,?,?,?)", (dataset, now, "Left the register", title, lst[0][0], "", "; ".join(n for _, n in lst), ""))
                kept += 1
    c.execute("insert into diffs values(?,?,?,?,?,?)", (dataset, now, added, gone, transferred, kept))
    c.execute("drop table if exists prev")
    return {"dataset": dataset, "loaded": now, "added": added, "removed": gone, "watched_changes": kept}


def changes_for(postcodes, since: str = "") -> list[dict]:
    """Recorded register changes at the given postcodes since an ISO timestamp (kinds: New title, Transferred, Left the register)."""
    pcs = [norm_pc(x) for x in postcodes if x]
    if not pcs or not DB.exists():
        return []
    with _lock:
        c = _db()
        marks = ",".join("?" * len(pcs))
        rows = c.execute(f"select dataset, loaded, kind, title, pc, address, old, new from changes where pc in ({marks}) and loaded >= ? order by loaded desc", [*pcs, since or ""]).fetchall()
        c.close()
    return [dict(zip(("dataset", "loaded", "kind", "title", "pc", "address", "old", "new"), r)) for r in rows]


def last_diff() -> dict | None:
    if not DB.exists():
        return None
    with _lock:
        c = _db()
        r = c.execute("select dataset, loaded, added, removed, transferred, watched from diffs order by loaded desc limit 1").fetchone()
        c.close()
    return dict(zip(("dataset", "loaded", "added", "removed", "transferred", "watched"), r)) if r else None


def load_bytes(data: bytes, name: str, dataset: str | None = None, source: str = "upload") -> tuple[str, int]:
    """CSV or ZIP containing the CSV. Dataset (ccod or ocod) is taken from the name when not given."""
    ds_ = dataset or ("ocod" if "ocod" in name.lower() else "ccod")
    if data[:2] == b"PK":
        z = zipfile.ZipFile(io.BytesIO(data))
        nm = next((n for n in z.namelist() if n.lower().endswith(".csv")), None)
        if not nm:
            raise ValueError("The zip has no CSV inside")
        with z.open(nm) as f:
            return ds_, load_stream(io.TextIOWrapper(f, encoding="utf-8-sig", errors="replace", newline=""), ds_, source)
    return ds_, load_stream(io.StringIO(data.decode("utf-8-sig", "replace"), newline=""), ds_, source)


def load_path(path: str, dataset: str | None = None) -> tuple[str, int]:
    p = Path(path).expanduser()
    if not p.exists():
        raise FileNotFoundError(f"No file at {path}")
    ds_ = dataset or ("ocod" if "ocod" in p.name.lower() else "ccod")
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as z:
            nm = next((n for n in z.namelist() if n.lower().endswith(".csv")), None)
            if not nm:
                raise ValueError("The zip has no CSV inside")
            with z.open(nm) as f:
                return ds_, load_stream(io.TextIOWrapper(f, encoding="utf-8-sig", errors="replace", newline=""), ds_, "path")
    with open(p, encoding="utf-8-sig", errors="replace", newline="") as f:
        return ds_, load_stream(f, ds_, "path")


def api_files(key: str, dataset: str) -> list[dict]:
    """List the files HMLR offers for a dataset with the account's API key."""
    js = ds._http(f"https://use-land-property-data.service.gov.uk/api/v1/datasets/{dataset}", headers={"Authorization": key})
    res = (js.get("result") or js) if isinstance(js, dict) else {}
    return [{"name": r.get("file_name") or r.get("name") or "", "url": r.get("download_url") or r.get("url") or "", "size": r.get("file_size") or r.get("size")} for r in (res.get("resources") or []) if isinstance(r, dict)]


def api_fetch(key: str, dataset: str) -> tuple[str, int]:
    """Download the latest full file for ccod or ocod and index it."""
    import urllib.request
    files = api_files(key, dataset)
    full = [f for f in files if f["url"] or f["name"]]
    full = [f for f in full if "COU" not in f["name"].upper()] or full  # skip change-only update files
    if not full:
        raise RuntimeError("HMLR returned no files for this dataset")
    f = sorted(full, key=lambda x: x["name"])[-1]
    url = f["url"]
    if not url:
        js = ds._http(f"https://use-land-property-data.service.gov.uk/api/v1/datasets/{dataset}/{f['name']}", headers={"Authorization": key})
        url = (js.get("result") or js).get("download_url") if isinstance(js, dict) else ""
    if not url:
        raise RuntimeError("HMLR did not return a download link")
    req = urllib.request.Request(url, headers={"User-Agent": ds.UA})
    with urllib.request.urlopen(req, timeout=600) as r:
        data = r.read(SIZE_LIMIT)
    return load_bytes(data, f["name"] or dataset, dataset, source="HMLR API")


def start_api_fetch(key: str, datasets=("ccod", "ocod")):
    if STATUS["running"]:
        return False

    def run():
        STATUS.update(running=True, error="", message="")
        try:
            for d in datasets:
                STATUS.update(dataset=d, rows=0, message=f"Downloading {d.upper()}")
                api_fetch(key, d)
            STATUS["message"] = "Loaded"
        except Exception as e:
            STATUS["error"] = str(e)[:300]
        finally:
            STATUS["running"] = False
    threading.Thread(target=run, daemon=True).start()
    return True


def meta() -> dict:
    if not DB.exists():
        return {"datasets": [], "rows": 0}
    with _lock:
        c = _db()
        rows = c.execute("select dataset, rows, loaded, source from meta").fetchall()
        c.close()
    return {"datasets": [{"dataset": r[0], "rows": r[1], "loaded": r[2], "source": r[3]} for r in rows], "rows": sum(r[1] for r in rows)}


COLS = ("title", "tenure", "address", "district", "postcode", "price", "proprietor", "company_no", "category", "paddr", "added", "dataset", "country")


def _rows(sql, args):
    if not DB.exists():
        return []
    with _lock:
        c = _db()
        cur = c.execute(sql, args)
        out = [dict(zip(COLS, r)) for r in cur.fetchall()]
        c.close()
    return out


SEL = "select title, tenure, address, district, postcode, price, proprietor, company_no, category, paddr, added, dataset, country from titles"


def by_postcode(pc: str, limit: int = 200) -> list[dict]:
    return _rows(SEL + " where pc=? limit ?", (norm_pc(pc), limit))


def by_outward(out: str, limit: int = 500) -> list[dict]:
    return _rows(SEL + " where outw=? limit ?", (norm_pc(out), limit))


def by_proprietor(q: str, limit: int = 200) -> list[dict]:
    k = _pkey(q)
    if not k:
        return []
    return _rows(SEL + " where pkey like ? order by pkey limit ?", (f"%{k}%", limit))


def by_title(t: str) -> list[dict]:
    return _rows(SEL + " where title=?", (t.strip().upper(),))


def by_company(no: str) -> list[dict]:
    return _rows(SEL + " where company_no=? limit 500", (no.strip(),))


def portfolio_of(name: str, limit: int = 500) -> list[dict]:
    """Every title held by one proprietor name (exact key), for land assembly and owner research."""
    return _rows(SEL + " where pkey=? limit ?", (_pkey(name), limit))


def lookup_for_site(pc: str, site: dict | None = None) -> list[dict] | None:
    """Titles at the site's postcode. None when no CCOD or OCOD data is loaded, so the caller can say so."""
    if not DB.exists() or not meta()["rows"]:
        return None
    rows = by_postcode(pc)
    addr = re.sub(r"[^a-z0-9 ]", "", ((site or {}).get("address") or "").lower())
    toks = {t for t in addr.split() if len(t) > 2 and not t.isdigit()}

    def score(r):
        a = set(re.sub(r"[^a-z0-9 ]", "", (r["address"] or "").lower()).split())
        return -len(toks & a)
    rows.sort(key=score)
    return [{**r, "proprietor": r["proprietor"], "title": r["title"]} for r in rows]


# ---------------------------------------------------------------- official copy of the register (OC1) importer

def pdf_text(data: bytes) -> str:
    from pypdf import PdfReader
    rd = PdfReader(io.BytesIO(data))
    return "\n".join((p.extract_text() or "") for p in rd.pages)


def _section(text: str, start: str, ends: tuple[str, ...]) -> str:
    m = re.search(start, text, re.I)
    if not m:
        return ""
    rest = text[m.end():]
    cut = len(rest)
    for e in ends:
        mm = re.search(e, rest, re.I)
        if mm:
            cut = min(cut, mm.start())
    return rest[:cut].strip()


def _clean(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


ENTRY = re.compile(r"(?m)^\s*\d+\s+\((?:\d{2}\.\d{2}\.\d{4}|[^)]{0,20})\)\s*")


def _entries(section: str) -> list[str]:
    """Numbered register entries as single-line strings. Falls back to the whole section when no numbering is found."""
    parts = ENTRY.split(section)
    parts = [_clean(p) for p in parts if _clean(p)]
    if len(parts) > 1:
        return parts
    return [_clean(section)] if section.strip() else []


def _party(blob: str) -> tuple[str, str, str]:
    cn = re.search(r"\(Co\.?\s*Regn\.?\s*No\.?\s*([A-Z0-9]+)\)", blob, re.I)
    name = re.split(r"\s*\(Co\.?\s*Regn", blob, flags=re.I)[0].strip(" ,.;")
    if not cn:
        name = re.split(r"\s+of\s+", name, 1)[0].strip(" ,.;")
    addr = blob.split(" of ", 1)[1].strip(" .") if " of " in blob else ""
    return name, (cn.group(1) if cn else ""), addr


def parse_oc1(text: str) -> dict:
    """Read the title number, tenure, proprietors, price paid, charges, restrictions and covenants from an official copy."""
    t = text.replace("\r", "")
    out: dict = {"title": "", "tenure": "", "class": "", "address": "", "proprietors": [], "price": None, "price_date": "", "charges": [], "restrictions": [], "covenants": [], "notices": [], "issue_date": ""}
    m = re.search(r"Title\s+number\s*[:\-]?\s*([A-Z]{0,3}\d{1,9})", t, re.I)
    if m:
        out["title"] = m.group(1).upper()
    m = re.search(r"Issued on\s+(\d{1,2}\s+\w+\s+\d{4})", t, re.I)
    if m:
        out["issue_date"] = m.group(1)
    prop = _section(t, r"A:\s*Property Register", (r"B:\s*Proprietorship Register", r"C:\s*Charges Register"))
    ents = _entries(prop)
    if ents:
        first = next((e for e in ents if re.search(r"\b(freehold|leasehold|lease)\b", e, re.I)), ents[-1] if len(ents) > 1 else ents[0])
        out["address"] = first[:400]
        mt = re.search(r"\b(freehold|leasehold)\b", first, re.I)
        if mt:
            out["tenure"] = mt.group(1).title()
    reg = _section(t, r"B:\s*Proprietorship Register", (r"C:\s*Charges Register", r"End of register"))
    m = re.search(r"Title\s+(absolute|good leasehold|possessory|qualified)", reg, re.I)
    if m:
        out["class"] = m.group(1).capitalize()
    for e in _entries(reg):
        if re.match(r"PROPRIETOR:", e, re.I):
            name, cn, addr = _party(e.split(":", 1)[1].strip())
            if name and name.upper() != "NONE":
                out["proprietors"].append({"name": name[:160], "company_no": cn, "address": addr[:200]})
        mm = re.search(r"price stated to have been paid on\s+(\d{1,2}\s+\w+\s+\d{4})\s+was\s+£\s*([\d,]+)", e, re.I)
        if mm:
            out["price_date"], out["price"] = mm.group(1), float(mm.group(2).replace(",", ""))
        if re.match(r"RESTRICTION:", e, re.I):
            out["restrictions"].append(e.split(":", 1)[1].strip()[:300])
    chg = _section(t, r"C:\s*Charges Register", (r"End of register",))
    pending = None
    for e in _entries(chg):
        mm = re.match(r"REGISTERED CHARGE\s+dated\s+(\d{1,2}\s+\w+\s+\d{4})", e, re.I)
        if mm:
            pending = {"date": mm.group(1), "chargee": "", "company_no": ""}
            out["charges"].append(pending)
            rest = e[mm.end():]
            pm = re.search(r"Proprietor:\s*(.+)", rest, re.I)
            if pm:
                pending["chargee"], pending["company_no"], _ = _party(pm.group(1))
            continue
        pm = re.match(r"Proprietor:\s*(.+)", e, re.I)
        if pm and pending is not None and not pending["chargee"]:
            pending["chargee"], pending["company_no"], _ = _party(pm.group(1))
            continue
        if re.search(r"covenant", e, re.I):
            out["covenants"].append(e[:500])
        elif re.search(r"UNILATERAL NOTICE|AGREED NOTICE|NOTICE OF|EASEMENT|PRE-?EMPTION|OPTION", e, re.I):
            out["notices"].append(e[:300])
    return out


def oc1_to_site(site: dict, parsed: dict) -> dict:
    """Write the register facts onto the site: vendor, price history, parcel record and diligence notes. Returns what changed."""
    site["title_register"] = {**parsed, "imported": date.today().isoformat()}
    changed = []
    if parsed["proprietors"] and not site.get("vendor"):
        site["vendor"] = parsed["proprietors"][0]["name"]
        changed.append("vendor")
    if parsed["proprietors"]:
        parcels = site.setdefault("parcels", [])
        ref = parsed["title"]
        if not any(p.get("ref") == ref for p in parcels):
            import uuid
            parcels.append({"id": "p-" + uuid.uuid4().hex[:6], "ref": ref, "address": (parsed["address"] or "")[:120], "owner": parsed["proprietors"][0]["name"], "owner_type": "Company" if parsed["proprietors"][0]["company_no"] else "Individual",
                            "area_ha": None, "status": "Identified", "ask": None, "offer": None, "notes": f"From the official copy of the register ({parsed['tenure'] or 'tenure not stated'})."})
            changed.append("parcel")
    return {"changed": changed}


# ---------------------------------------------------------------- Companies House and a custom paid provider

def _ch_headers(key: str) -> dict:
    return {"Authorization": "Basic " + base64.b64encode(f"{key}:".encode()).decode()}


def company(no: str, key: str) -> dict:
    no = re.sub(r"\s+", "", no).upper().zfill(8) if no.isdigit() else re.sub(r"\s+", "", no).upper()
    js = ds._http(f"https://api.company-information.service.gov.uk/company/{no}", headers=_ch_headers(key))
    out = {"number": no, "name": js.get("company_name"), "status": js.get("company_status"), "type": js.get("type"), "created": js.get("date_of_creation"), "sic": js.get("sic_codes") or [],
           "office": ", ".join(str(v) for v in (js.get("registered_office_address") or {}).values() if v), "has_charges": js.get("has_charges"), "accounts_overdue": (js.get("accounts") or {}).get("overdue"),
           "url": f"https://find-and-update.company-information.service.gov.uk/company/{no}"}
    if js.get("has_charges"):
        try:
            ch = ds._http(f"https://api.company-information.service.gov.uk/company/{no}/charges", headers=_ch_headers(key))
            out["charges"] = [{"status": c.get("status"), "created": c.get("created_on"), "delivered": c.get("delivered_on"), "classification": (c.get("classification") or {}).get("description"),
                               "entitled": ", ".join(p.get("name", "") for p in c.get("persons_entitled", []))} for c in ch.get("items", [])[:20]]
        except Exception as e:
            out["charges_error"] = str(e)[:100]
    return out


def _dig(obj, path: str):
    for part in [p for p in (path or "").split(".") if p]:
        if isinstance(obj, list):
            try:
                obj = obj[int(part)]
            except (ValueError, IndexError):
                return None
        elif isinstance(obj, dict):
            obj = obj.get(part)
        else:
            return None
    return obj


def custom_title_lookup(cfg: dict, title: str = "", postcode: str = "", address: str = "") -> dict:
    """Call the user's configured provider. The URL may contain {title}, {postcode} and {address}."""
    c = cfg.get("title_api") or {}
    if not c.get("url"):
        raise RuntimeError("No provider is configured")
    from urllib.parse import quote
    url = c["url"].replace("{title}", quote(title)).replace("{postcode}", quote(postcode)).replace("{address}", quote(address))
    hdr = {c.get("header") or "Authorization": c.get("key", "")} if c.get("key") else {}
    js = ds._http(url, headers=hdr, timeout=30)
    owner = _dig(js, c.get("owner_path", "")) if c.get("owner_path") else None
    return {"owner": owner, "raw": json.dumps(js)[:3000]}
