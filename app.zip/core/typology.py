"""Unit typologies: a default schedule of accommodation for any scheme, editable down to room dimensions.

A typology is a list of unit types (each with a count and a list of rooms) plus block, parking and
policy settings. It drives the unit mix and floor area used in the appraisal, the floorplans, the policy
checks and the facts quoted in planning replies.
"""
from __future__ import annotations

import math
import re
import uuid

from . import floorplan as fp

SQM_TO_SQFT = 10.7639
WALL_FACTOR = 1.06          # partitions and wall thickness inside the gross internal area
S1_FLAT = 4.8               # depth of the habitable strip in flats, metres

# Nationally Described Space Standard, Table 1 (MHCLG 2015): minimum GIA in m2 for 1, 2 and 3 storey dwellings
NDSS = {(1, 2): (50, 58, None), (2, 3): (61, 70, None), (2, 4): (70, 79, None), (3, 4): (74, 84, 90), (3, 5): (86, 93, 99), (3, 6): (95, 102, 108),
        (4, 5): (90, 97, 103), (4, 6): (99, 106, 112), (4, 7): (108, 115, 121), (4, 8): (117, 124, 130), (5, 6): (103, 110, 116), (5, 7): (112, 119, 125),
        (5, 8): (121, 128, 134), (6, 7): (116, 123, 129), (6, 8): (125, 132, 138)}
STORAGE = {0: 1.0, 1: 1.5, 2: 2.0, 3: 2.5, 4: 3.0, 5: 3.5, 6: 4.0}


def ndss_min(beds: int, persons: int, storeys: int = 1, shower_only: bool = False) -> float | None:
    if beds == 0:
        return 37.0 if shower_only else 39.0
    row = NDSS.get((beds, persons))
    if not row:
        # nearest published row for the same bedroom count
        rows = [(p, v) for (b, p), v in NDSS.items() if b == beds]
        if not rows:
            return None
        row = min(rows, key=lambda x: abs(x[0] - persons))[1]
    v = row[min(max(storeys, 1), 3) - 1]
    return float(v) if v else float(row[min(max(storeys, 1), 3) - 2] or row[0])


def storage_min(beds: int) -> float:
    return STORAGE.get(beds, 4.0 + 0.5 * max(0, beds - 6))


def _id() -> str:
    return uuid.uuid4().hex[:6]


def room(name, kind, w, d, floor=0, band=None) -> dict:
    r = {"id": _id(), "name": name, "kind": kind, "w": round(w, 2), "d": round(d, 2), "floor": floor}
    if band:
        r["band"] = band
    return r


def _rw(name, kind, area, across, mode, floor=0):
    """Room from an area and the across-dimension of its strip."""
    along = area / across
    return room(name, kind, along if mode == "wide" else across, across if mode == "wide" else along, floor)


def _bedrooms(beds: int, persons: int, s1: float, mode="wide", min_w=True):
    doubles = max(0, min(beds, persons - beds))
    singles = beds - doubles
    out = []
    for i in range(doubles):
        nominal, wmin = (12.6, 2.9) if i == 0 else (11.9, 2.7)
        out.append(("Main bedroom" if i == 0 else f"Bedroom {i + 1}", nominal, wmin))
    for j in range(singles):
        out.append((f"Bedroom {doubles + j + 1}", 7.9, 2.2))
    res = []
    for nm, nominal, wmin in out:
        area = max(nominal, wmin * s1)
        res.append((nm, area))
    return res


def _persons_default(beds: int, family: str) -> int:
    if beds == 0:
        return 1
    if family == "house":
        return {1: 2, 2: 4, 3: 5, 4: 6, 5: 7}.get(beds, beds + 2)
    return {1: 2, 2: 3, 3: 5, 4: 6}.get(beds, beds + 2)


# ------------------------------------------------------------------ generators

def make_flat(beds: int, persons: int | None = None, target_gia: float | None = None, m43: bool = False, name: str | None = None, code: str | None = None) -> dict:
    persons = persons or _persons_default(beds, "flat")
    ndss = ndss_min(beds, persons, 1) or 50.0
    tgt = target_gia or ndss * (1.18 if m43 else 1.04)
    s1 = S1_FLAT + (0.4 if m43 else 0.0)
    beds_a = _bedrooms(beds, persons, s1)
    if m43 and beds_a:
        beds_a[0] = (beds_a[0][0], max(beds_a[0][1], 3.6 * s1))
    bath = 6.0 if m43 else 4.2
    hall = (5.0 if beds == 0 else 5.5 + 1.2 * beds) + (3.0 if m43 else 0)
    store = storage_min(beds)
    extra_wc = 1.9 if beds >= 3 else 0.0
    ens = 3.6 if (beds >= 3 or m43 and beds >= 2) else 0.0
    B = bath + hall + store + extra_wc + ens
    rooms_area = tgt / WALL_FACTOR
    bed_sum = sum(a for _n, a in beds_a)
    living = rooms_area - B - bed_sum
    min_living = 24.0 if beds == 0 else 19.0 + 2.0 * beds
    if beds == 0:
        living = rooms_area - B
    scaled = False
    if living < min_living:
        if target_gia:
            scaled = True
            living = max(living, min_living * 0.6)
        else:
            living = min_living
    A = living + bed_sum
    U = A / s1
    s2 = B / U
    if s2 < 1.35:                                  # keep the service strip deep enough to hold a bathroom
        hall += (1.35 - s2) * U
        B = bath + hall + store + extra_wc + ens
        s2 = B / U
    m = "wide"
    rooms = [_rw("Living, kitchen and dining" if beds else "Living, sleeping and kitchen", "kdl", living, s1, m)]
    for nm, a in beds_a:
        rooms.append(_rw(nm, "bedroom", a, s1, m))
    rooms.append(_rw("Bathroom", "bathroom", bath, s2, m))
    if ens:
        rooms.append(_rw("En-suite", "ensuite", ens, s2, m))
    if extra_wc:
        rooms.append(_rw("WC", "wc", extra_wc, s2, m))
    rooms.append(_rw("Hall", "hall", hall, s2, m))
    rooms.append(_rw("Storage", "store", store, s2, m))
    outdoor = 5.0 + max(0, persons - 2)
    rooms.append(room("Balcony", "balcony", outdoor / 1.6, 1.6))
    label = "studio" if beds == 0 else f"{beds} bed {persons} person"
    u = {"id": _id(), "code": code or ("STU" if beds == 0 else f"{beds}B{persons}P"), "name": name or (f"Studio flat" if beds == 0 else f"{label} flat"), "family": "flat", "beds": beds, "persons": persons,
         "storeys": 1, "count": 1, "aff": 0, "m4": "M4(3)" if m43 else "M4(2)", "aspect": "dual" if beds >= 3 else "single", "attach": "block", "ceiling_m": 2.5, "rooms": rooms}
    if m43:
        u["name"] = f"{label} wheelchair flat"
        u["code"] = (code or f"{beds}B{persons}P") + "W"
    return u


def make_house(beds: int, persons: int | None = None, storeys: int = 2, attach: str = "terrace", target_gia: float | None = None, name: str | None = None, code: str | None = None) -> dict:
    persons = persons or _persons_default(beds, "house")
    ndss = ndss_min(beds, persons, storeys) or 84.0
    tgt = target_gia or ndss * 1.04
    S = {1: 6.0, 2: 5.6, 3: 6.2, 4: 6.9, 5: 7.6}.get(beds, 7.6)
    if storeys == 1:
        S = {1: 6.6, 2: 7.4, 3: 8.4, 4: 9.2}.get(beds, 9.2)
    s2 = 1.9
    s1 = S - s2
    bed_areas = _bedrooms(beds, persons, s1, "deep")
    baths = [("Bathroom", "bathroom", 4.4)]
    if beds >= 3 and persons >= 5:
        baths.append(("En-suite", "ensuite", 3.4))
    if beds >= 5:
        baths.append(("En-suite 2", "ensuite", 3.4))
    store = storage_min(beds)
    T = tgt / WALL_FACTOR
    foot = T / storeys
    U = foot / S
    stair = 3.4
    hall = 4.2
    wc = 1.8
    m = "deep"
    rooms = []

    def strip_room(name_, kind, area, floor, front):
        across = s1 if front else s2
        rooms.append(_rw(name_, kind, area, across, m, floor))
    if storeys == 1:
        # single storey: bedrooms and living share the habitable strip
        need_front = sum(a for _n, a in bed_areas) + 22.0 + 6.0
        U = max(U, need_front / s1)
        foot = U * S
        front_free = s1 * U - sum(a for _n, a in bed_areas)
        rooms_f = [("Living room", "living", front_free * 0.42), ("Kitchen and dining", "kitchen", front_free * 0.58)]
        for nm, k, a in rooms_f:
            strip_room(nm, k, a, 0, True)
        for nm, a in bed_areas:
            strip_room(nm, "bedroom", a, 0, True)
        rear = s2 * U
        rest = rear - sum(a for _n, _k, a in baths) - store - wc
        strip_room("Hall", "hall", max(3.0, rest), 0, False)
        for nm, k, a in baths:
            strip_room(nm, k, a, 0, False)
        strip_room("Storage", "store", store, 0, False)
        strip_room("WC", "wc", wc, 0, False)
    else:
        # bedrooms on the upper floors
        upper = storeys - 1
        per_floor = [[] for _ in range(upper)]
        for i, b in enumerate(bed_areas):
            per_floor[(0 if i == 0 else 1) if storeys == 3 else 0].append(b)
        need = max(sum(a for _n, a in pf) for pf in per_floor if pf) if any(per_floor) else 10
        U = max(U, need / s1)
        foot = U * S
        for fl, pf in enumerate(per_floor, start=1):
            for nm, a in pf:
                strip_room(nm, "bedroom", a, fl, True)
        rear = s2 * U
        # ground floor
        front0 = s1 * U
        kit_liv = front0
        if storeys == 3:
            strip_room("Kitchen and dining", "kitchen", front0 * 0.62, 0, True)
            strip_room("Study", "study", front0 * 0.38, 0, True)
        else:
            strip_room("Living room", "living", kit_liv * 0.45, 0, True)
            strip_room("Kitchen and dining", "kitchen", kit_liv * 0.55, 0, True)
        rest0 = rear - stair - wc - store
        strip_room("Hall", "hall", max(3.0, rest0), 0, False)
        strip_room("Stair", "stair", stair, 0, False)
        strip_room("WC", "wc", wc, 0, False)
        strip_room("Storage", "store", store, 0, False)
        # upper floors, service strip
        baths_left = list(baths)
        for fl in range(1, upper + 1):
            front_used = sum(a for _n, a in per_floor[fl - 1])
            if storeys == 3 and fl == 1:
                strip_room("Living room", "living", max(8.0, s1 * U - front_used), fl, True)
                front_used = s1 * U
            elif front_used < s1 * U - 0.2:
                strip_room("Study", "study", s1 * U - front_used, fl, True) if s1 * U - front_used > 4.5 else None
            here = []
            if baths_left:
                here.append(baths_left.pop(0))
            if fl == 1 and baths_left and storeys == 2:
                here += [baths_left.pop(0)] if baths_left else []
            here_sum = sum(a for _n, _k, a in here)
            land = rear - here_sum - stair
            strip_room("Landing", "landing", max(2.5, land), fl, False)
            strip_room("Stair", "stair", stair, fl, False)
            for nm, k, a in here:
                strip_room(nm, k, a, fl, False)
    garden_area = {1: 40, 2: 50, 3: 70, 4: 95, 5: 110}.get(beds, 110)
    gw = max(S, garden_area / 10.0)
    rooms.append(room("Garden", "garden", gw, 10.0))
    kind_name = {"terrace": "terraced", "semi": "semi-detached", "detached": "detached"}[attach]
    if storeys == 1:
        nm = f"{beds} bed {persons} person {'detached ' if attach == 'detached' else ''}bungalow"
    elif storeys == 3:
        nm = f"{beds} bed {persons} person town house"
    else:
        nm = f"{beds} bed {persons} person {kind_name} house"
    u = {"id": _id(), "code": code or f"{'BG' if storeys == 1 else 'TH' if storeys == 3 else 'H'}{beds}{persons}", "name": name or nm, "family": "house", "beds": beds, "persons": persons, "storeys": storeys, "count": 1, "aff": 0,
         "m4": "M4(1)", "aspect": "dual", "attach": attach, "ceiling_m": 2.5, "rooms": rooms}
    return u


def make_room_unit(kind: str = "coliving") -> dict:
    """Single-occupancy rooms: co-living studio, care bedroom, student cluster."""
    m = "wide"
    if kind == "care":
        s1 = 4.0
        rooms = [_rw("Bedroom and sitting area", "bedroom", 15.6, s1, m), _rw("En-suite wet room", "ensuite", 4.6, 1.6, m), _rw("Entrance", "hall", 1.6, 1.6, m)]
        u = {"code": "CARE", "name": "Care bedroom with en-suite", "family": "room", "beds": 1, "persons": 1, "shared_sqm": 14.0}
    elif kind == "cluster":
        s1 = 4.2
        rooms = [_rw("Kitchen and living", "kdl", 24.0, s1, m)]
        for i in range(4):
            rooms.append(_rw(f"Bedroom {i + 1}", "bedroom", 2.5 * s1, s1, m))
        for i in range(4):
            rooms.append(_rw(f"En-suite {i + 1}", "ensuite", 4.0, 2.2, m))
        rooms.append(_rw("Hall", "hall", 8.0, 2.2, m))
        u = {"code": "CL4", "name": "Student cluster, 4 bedrooms", "family": "cluster", "beds": 4, "persons": 4, "shared_sqm": 6.0}
    else:
        s1 = 4.0
        rooms = [_rw("Room and living space", "bedroom", 12.4, s1, m), _rw("En-suite", "ensuite", 3.6, 1.8, m), _rw("Kitchenette", "utility", 2.4, 1.8, m), _rw("Entrance", "hall", 1.6, 1.8, m)]
        u = {"code": "CL", "name": "Co-living studio", "family": "room", "beds": 1, "persons": 1, "shared_sqm": 5.0}
    u.update({"id": _id(), "storeys": 1, "count": 1, "aff": 0, "m4": "M4(2)", "aspect": "single", "attach": "block", "ceiling_m": 2.5, "rooms": rooms})
    return u


TYPE_LIBRARY = {
    "flat_studio": ("Studio flat", lambda: make_flat(0)),
    "flat_1b2p": ("1 bed 2 person flat", lambda: make_flat(1, 2)),
    "flat_2b3p": ("2 bed 3 person flat", lambda: make_flat(2, 3)),
    "flat_2b4p": ("2 bed 4 person flat", lambda: make_flat(2, 4)),
    "flat_3b5p": ("3 bed 5 person flat", lambda: make_flat(3, 5)),
    "flat_2b3p_w": ("2 bed 3 person wheelchair flat (M4(3))", lambda: make_flat(2, 3, m43=True)),
    "house_2b4p": ("2 bed 4 person terraced house", lambda: make_house(2, 4, 2, "terrace")),
    "house_3b5p": ("3 bed 5 person semi-detached house", lambda: make_house(3, 5, 2, "semi")),
    "house_3b6p": ("3 bed 6 person semi-detached house", lambda: make_house(3, 6, 2, "semi")),
    "house_4b6p": ("4 bed 6 person detached house", lambda: make_house(4, 6, 2, "detached")),
    "house_4b7p": ("4 bed 7 person detached house", lambda: make_house(4, 7, 2, "detached")),
    "town_3b5p": ("3 bed 5 person town house", lambda: make_house(3, 5, 3, "terrace")),
    "bungalow_2b3p": ("2 bed 3 person bungalow", lambda: make_house(2, 3, 1, "detached")),
    "room_coliving": ("Co-living studio", lambda: make_room_unit("coliving")),
    "room_care": ("Care bedroom with en-suite", lambda: make_room_unit("care")),
    "cluster_student": ("Student cluster, 4 bedrooms", lambda: make_room_unit("cluster")),
}

# scheme presets: (label, description, [(type key, share of units)], extra settings)
PRESETS = {
    "suburban_houses": ("Suburban houses", "Terraced, semi-detached and detached houses with gardens.", [("house_2b4p", .22), ("house_3b5p", .38), ("house_4b6p", .28), ("bungalow_2b3p", .04), ("town_3b5p", .08)], {"block": None}),
    "mixed_houses_flats": ("Mixed houses and flats", "Houses with a small block of flats.", [("flat_1b2p", .12), ("flat_2b3p", .12), ("house_2b4p", .20), ("house_3b5p", .34), ("house_4b6p", .22)], {"block": {"floors": 3, "per_floor": 6}}),
    "urban_flats": ("Urban flats", "Flats for sale in one or more blocks, with wheelchair units.", [("flat_studio", .06), ("flat_1b2p", .32), ("flat_2b3p", .18), ("flat_2b4p", .28), ("flat_3b5p", .08), ("flat_2b3p_w", .08)], {"block": {"floors": 6, "per_floor": 8}}),
    "btr": ("Build to rent", "Rental flats with shared amenity space.", [("flat_studio", .12), ("flat_1b2p", .38), ("flat_2b3p", .18), ("flat_2b4p", .22), ("flat_2b3p_w", .10)], {"block": {"floors": 10, "per_floor": 10}, "shared_sqm": 4.5}),
    "coliving": ("Co-living", "Private rooms with shared kitchens and lounges.", [("room_coliving", 1.0)], {"block": {"floors": 8, "per_floor": 16}, "shared_sqm": 5.0}),
    "care": ("Care home", "Care bedrooms with en-suites and shared space.", [("room_care", 1.0)], {"block": {"floors": 3, "per_floor": 24}, "shared_sqm": 14.0}),
    "retirement": ("Retirement and extra care", "One and two bedroom flats with communal facilities.", [("flat_1b2p", .55), ("flat_2b3p", .45)], {"block": {"floors": 4, "per_floor": 10}, "shared_sqm": 8.0, "retirement": True}),
    "student": ("Student clusters", "Cluster flats of four bedrooms.", [("cluster_student", 1.0)], {"block": {"floors": 6, "per_floor": 8}, "shared_sqm": 3.0}),
}


def library() -> list[dict]:
    return [{"key": k, "name": v[0]} for k, v in TYPE_LIBRARY.items()]


def new_unit(key: str, count: int = 1) -> dict:
    if key not in TYPE_LIBRARY:
        raise ValueError("Unknown unit type")
    u = TYPE_LIBRARY[key][1]()
    u["count"] = max(1, int(count))
    return u


def _spread(shares: list[tuple[str, float]], n: int) -> list[tuple[str, int]]:
    raw = [(k, s * n) for k, s in shares]
    counts = [(k, int(math.floor(v))) for k, v in raw]
    left = n - sum(c for _k, c in counts)
    order = sorted(range(len(raw)), key=lambda i: -(raw[i][1] - counts[i][1]))
    counts = [[k, c] for k, c in counts]
    for i in order[:left]:
        counts[i][1] += 1
    return [(k, c) for k, c in counts if c > 0]


PRESET_BY_STRATEGY = {"btr": "btr"}


def choose_preset(site: dict) -> str:
    text = " ".join(str(site.get(k) or "") for k in ("name", "description", "type", "asset_type", "address")).lower()
    if re.search(r"care home|nursing|residential care", text):
        return "care"
    if re.search(r"retirement|extra care|later living|sheltered", text):
        return "retirement"
    if re.search(r"co-?living|shared living", text):
        return "coliving"
    if re.search(r"student|pbsa", text):
        return "student"
    if site.get("strategy") == "btr" or re.search(r"build[- ]to[- ]rent|\bbtr\b|multifamily", text):
        return "btr"
    units = int(site.get("units") or 0)
    ha = float(site.get("site_ha") or 0)
    dph = units / ha if ha and units else 0
    if dph >= 90 or re.search(r"apartment|flats?\b|tower|block", text) and not re.search(r"houses|homes", text):
        return "urban_flats"
    if dph >= 55:
        return "mixed_houses_flats"
    return "suburban_houses"


def default_typology(site: dict, preset: str | None = None, units: int | None = None) -> dict:
    preset = preset or choose_preset(site)
    label, _d, shares, extra = PRESETS[preset]
    n = int(units or site.get("units") or 0)
    if n <= 0:
        ha = float(site.get("site_ha") or 0)
        n = max(4, round(ha * (35 if preset in ("suburban_houses",) else 120))) if ha else 20
    us = []
    for key, c in _spread(shares, n):
        u = new_unit(key, c)
        us.append(u)
    typ = {"v": 1, "preset": preset, "units": us, "block": extra.get("block") or {"floors": 4, "per_floor": 8, "ground_loss": 0},
           "shared_sqm": extra.get("shared_sqm"), "site": {"parking": None, "cycle": None, "amenity_sqm": None}, "sync": True, "source": "default"}
    if extra.get("block") is not None and "ground_loss" not in typ["block"]:
        typ["block"]["ground_loss"] = 0
    typ["policy"] = {"pack": detect_pack(site), "overrides": {}}
    assign_access(typ)
    return typ


def assign_access(typ: dict) -> None:
    """Give enough home types M4(2) to reach the pack target, starting with flats and bungalows."""
    from . import policy
    pk = policy.PACKS[typ["policy"]["pack"]]
    n = sum(u["count"] for u in typ["units"])
    if not n:
        return
    have = sum(u["count"] for u in typ["units"] if u["m4"] in ("M4(2)", "M4(3)"))
    order = sorted([u for u in typ["units"] if u["m4"] not in ("M4(2)", "M4(3)")], key=lambda u: (u["family"] == "house", u["storeys"] > 1, u["beds"]))
    for u in order:
        if have / n >= pk["m42_share"] - 1e-9:
            break
        u["m4"] = "M4(2)"
        have += u["count"]


LONDON_AREAS = {"E", "EC", "N", "NW", "SE", "SW", "W", "WC", "BR", "CR", "DA", "EN", "HA", "IG", "KT", "RM", "SM", "TW", "UB"}


def detect_pack(site: dict) -> str:
    pc = str(site.get("postcode") or "").strip().upper()
    m = re.match(r"([A-Z]{1,2})\d", pc)
    la = str(site.get("la") or "").lower()
    if m and m.group(1) in LONDON_AREAS:
        return "london"
    if "london borough" in la or la.startswith("city of london"):
        return "london"
    return "england"


def _guess(text: str):
    t = (text or "").lower()
    m = re.search(r"(\d)\s*-?\s*bed", t)
    beds = int(m.group(1)) if m else (0 if "studio" in t else 2)
    if "studio" in t:
        beds = 0
    fam = "house" if re.search(r"house|bungalow|villa|cottage|town ?house|detached|semi|terrace", t) else "flat"
    storeys = 1 if "bungalow" in t else 3 if re.search(r"town ?house", t) else 2
    attach = "detached" if "detached" in t and "semi" not in t else "semi" if "semi" in t else "terrace"
    return beds, fam, storeys, attach


def from_unit_mix(site: dict) -> dict | None:
    mix = [m for m in (site.get("unit_mix") or []) if m.get("count")]
    if not mix:
        return None
    units = []
    for m in mix:
        beds, fam, storeys, attach = _guess(m.get("type", ""))
        gia = float(m["nsa_sqft"]) / SQM_TO_SQFT if m.get("nsa_sqft") else None
        pers = max(1, beds + 1) if beds else 1
        if re.search(r"care", str(m.get("type", "")), re.I) and beds <= 1:
            u = make_room_unit("care")
        elif fam == "house":
            u = make_house(beds or 2, pers, storeys, attach, target_gia=gia)
        else:
            u = make_flat(beds, pers, target_gia=gia)
        if gia:
            scale_unit(u, gia)
        u["name"] = str(m.get("type") or u["name"])
        u["count"] = int(m["count"])
        u["m4"] = ""
        for k in ("sale_value", "rent_pcm"):
            if m.get(k):
                u[k] = float(m[k])
        units.append(u)
    hints = " ".join(str(m.get("type", "")) for m in mix).lower()
    fams = {u["family"] for u in units}
    preset = "suburban_houses" if fams == {"house"} else "mixed_houses_flats" if "house" in fams else choose_preset(site)
    typ = default_typology({**site, "units": None}, preset, 4)
    typ["units"] = units
    typ["source"] = "unit mix"
    if preset == "suburban_houses":
        typ["block"] = {"floors": 3, "per_floor": 6, "ground_loss": 0}
    return typ


FLEX = {"kdl", "living", "kitchen", "dining", "study", "hall", "landing", "communal"}


def scale_unit(u: dict, gia_m2: float) -> dict:
    """Resize the unit to a target GIA. Living, kitchen and circulation space flex first so bedrooms, bathrooms and storage keep their sizes."""
    base = [(r, r["w"], r["d"]) for r in u["rooms"] if not fp.is_external(r)]

    def apply(t: float):
        f = math.sqrt(max(0.05, 1 + t))
        for r, w, d in base:
            if r["kind"] in FLEX:
                r["w"], r["d"] = round(max(0.9, w * f), 2), round(max(0.9, d * f), 2)
            else:
                r["w"], r["d"] = w, d

    def gia_at(t: float) -> float:
        apply(t)
        return fp.fit_unit(u)["gia"] * WALL_FACTOR
    lo, hi = -0.65, 2.0
    if gia_at(lo) > gia_m2:                # even the smallest flexible rooms are too big: fall back to scaling everything
        apply(lo)
    else:
        for _ in range(28):
            mid = (lo + hi) / 2
            if gia_at(mid) < gia_m2:
                lo = mid
            else:
                hi = mid
        apply((lo + hi) / 2)
    cur = fp.fit_unit(u)["gia"] * WALL_FACTOR
    if cur and abs(cur - gia_m2) / gia_m2 > 0.01:
        k = math.sqrt(gia_m2 / cur)
        for r in u["rooms"]:
            if not fp.is_external(r):
                r["w"], r["d"] = round(r["w"] * k, 2), round(r["d"] * k, 2)
    return u


# ------------------------------------------------------------------ normalise and analyse

def _f(x, default=None):
    try:
        if x in (None, ""):
            return default
        return float(x)
    except (TypeError, ValueError):
        return default


def normalise(typ: dict, site: dict | None = None) -> dict:
    typ = dict(typ or {})
    units = []
    for u in typ.get("units") or []:
        u = dict(u)
        u["id"] = u.get("id") or _id()
        u["family"] = u.get("family") if u.get("family") in ("house", "flat", "room", "cluster") else "flat"
        u["beds"] = max(0, int(_f(u.get("beds"), 1)))
        u["persons"] = max(1, int(_f(u.get("persons"), max(1, u["beds"] * 2 if u["beds"] else 1))))
        u["storeys"] = min(4, max(1, int(_f(u.get("storeys"), 1))))
        u["count"] = max(0, int(_f(u.get("count"), 1)))
        u["aff"] = min(u["count"], max(0, int(_f(u.get("aff"), 0))))
        u["m4"] = u.get("m4") if u.get("m4") in ("", "M4(1)", "M4(2)", "M4(3)") else ""
        u["aspect"] = "dual" if u.get("aspect") == "dual" else "single"
        u["attach"] = u.get("attach") or ("terrace" if u["family"] == "house" else "block")
        u["ceiling_m"] = _f(u.get("ceiling_m"), 2.5)
        u["name"] = str(u.get("name") or "Unit type")[:60]
        u["code"] = str(u.get("code") or u["name"][:6])[:8]
        for k in ("sale_value", "rent_pcm", "shared_sqm", "build_psf"):
            u[k] = _f(u.get(k))
            if u[k] is None:
                u.pop(k, None)
        rooms = []
        for r in u.get("rooms") or []:
            r = dict(r)
            r["id"] = r.get("id") or _id()
            r["kind"] = r.get("kind") if r.get("kind") in fp.KIND_LABEL else "bedroom"
            r["name"] = str(r.get("name") or fp.KIND_LABEL[r["kind"]])[:40]
            r["w"] = round(min(60.0, max(0.6, _f(r.get("w"), 2.0))), 2)
            r["d"] = round(min(60.0, max(0.6, _f(r.get("d"), 2.0))), 2)
            r["floor"] = min(3, max(0, int(_f(r.get("floor"), 0))))
            if r.get("band") not in ("front", "rear"):
                r.pop("band", None)
            rooms.append(r)
        u["rooms"] = rooms
        for k in ("auto_price", "auto_build"):
            u[k] = bool(u.get(k))
        units.append(u)
    typ["units"] = units
    b = dict(typ.get("block") or {})
    b["floors"] = min(60, max(1, int(_f(b.get("floors"), 4))))
    b["per_floor"] = min(60, max(1, int(_f(b.get("per_floor"), 8))))
    b["ground_loss"] = min(b["per_floor"] - 1, max(0, int(_f(b.get("ground_loss"), 0))))
    typ["block"] = b
    s = dict(typ.get("site") or {})
    for k in ("parking", "cycle", "amenity_sqm"):
        s[k] = _f(s.get(k))
    typ["site"] = s
    typ["shared_sqm"] = _f(typ.get("shared_sqm"))
    typ["efficiency"] = _f(typ.get("efficiency"))
    pol = dict(typ.get("policy") or {})
    pol["pack"] = pol.get("pack") if pol.get("pack") in ("england", "london") else detect_pack(site or {})
    pol["overrides"] = {k: v for k, v in (pol.get("overrides") or {}).items() if v not in (None, "")}
    typ["policy"] = pol
    typ["v"] = 1
    typ["sync"] = bool(typ.get("sync", True))
    return typ


def apartment(u: dict) -> bool:
    return u["family"] in ("flat", "room", "cluster")


def allocate(typ: dict) -> dict:
    """Spread apartment types over blocks and floors. Returns blocks with per-floor counts by unit id."""
    units = [u for u in typ["units"] if apartment(u) and u["count"] > 0]
    total = sum(u["count"] for u in units)
    b = typ["block"]
    F, upf, loss = b["floors"], b["per_floor"], b["ground_loss"]
    if not total:
        return {"blocks": [], "n_blocks": 0, "floors": F, "per_floor": upf}
    cap = max(1, F * upf - loss)
    nb = max(1, math.ceil(total / cap))
    grid = [[{} for _ in range(F)] for _ in range(nb)]
    room_left = [[(upf - (loss if f == 0 else 0)) for f in range(F)] for _ in range(nb)]
    cells = [(bi, f) for f in range(F - 1, -1, -1) for bi in range(nb)]
    pos = 0
    for u in sorted(units, key=lambda u: -u["count"]):
        for _ in range(u["count"]):
            for step in range(len(cells)):
                bi, f = cells[(pos + step) % len(cells)]
                if room_left[bi][f] > 0:
                    grid[bi][f][u["id"]] = grid[bi][f].get(u["id"], 0) + 1
                    room_left[bi][f] -= 1
                    pos = (pos + step + 1) % len(cells)
                    break
    return {"blocks": grid, "n_blocks": nb, "floors": F, "per_floor": upf}


def analyse(typ: dict, site: dict | None = None) -> dict:
    """Geometry and totals for a normalised typology."""
    site = site or {}
    geoms = {u["id"]: fp.fit_unit(u) for u in typ["units"]}
    per = {}
    for u in typ["units"]:
        g = geoms[u["id"]]
        gia = g["gia"] * WALL_FACTOR
        beds_ok = [r for r in u["rooms"] if r["kind"] == "bedroom"]
        per[u["id"]] = {"gia": round(gia, 1), "gia_sqft": round(gia * SQM_TO_SQFT), "W": g["W"], "D": g["D"], "stretch": g["stretch"], "floors": len(g["floors"]),
                        "outdoor": round(sum(e["area"] for e in g["ext"] if e["kind"] == "balcony"), 1), "garden": round(sum(e["area"] for e in g["ext"] if e["kind"] == "garden"), 1)}
    units = typ["units"]
    n = sum(u["count"] for u in units)
    net = sum(per[u["id"]]["gia"] * u["count"] for u in units)
    alloc = allocate(typ)
    plate, eff = None, None
    apts = [u for u in units if apartment(u) and u["count"]]
    if apts and alloc["blocks"]:
        # typical floor: the fullest middle floor of the first block
        f_mid = 1 if alloc["floors"] > 1 else 0
        comp = alloc["blocks"][0][f_mid]
        plate = fp.floor_plate(apts, geoms, comp)
        if plate["n"]:
            eff = plate["eff"]
    houses_net = sum(per[u["id"]]["gia"] * u["count"] for u in units if not apartment(u))
    apt_net = sum(per[u["id"]]["gia"] * u["count"] for u in apts)
    shared = 0.0
    for u in apts:
        s = u.get("shared_sqm")
        if s is None:
            s = typ.get("shared_sqm") or 0
        shared += (s or 0) * u["count"]
    eff_used = max(0.6, min(0.95, typ.get("efficiency") or eff or 0.8)) if apts else None
    gross = houses_net + (apt_net / eff_used if apt_net else 0) + shared
    ha = float(site.get("site_ha") or 0)
    return {"geoms": geoms, "per": per, "units": n, "net_sqm": round(net, 1), "gross_sqm": round(gross, 1), "gross_sqft": round(gross * SQM_TO_SQFT), "net_sqft": round(net * SQM_TO_SQFT),
            "efficiency": round(eff_used, 3) if eff_used else None, "plate": plate, "alloc": alloc, "shared_sqm": round(shared, 1), "density": round(n / ha, 1) if ha and n else None,
            "houses": sum(u["count"] for u in units if u["family"] == "house"), "flats": sum(u["count"] for u in apts)}


def to_unit_mix(typ: dict, calc: dict) -> list[dict]:
    out = []
    for u in typ["units"]:
        if not u["count"]:
            continue
        m = {"type": u["name"], "count": u["count"], "nsa_sqft": calc["per"][u["id"]]["gia_sqft"], "code": u["code"]}
        if u.get("sale_value"):
            m["sale_value"] = u["sale_value"]
        if u.get("rent_pcm"):
            m["rent_pcm"] = u["rent_pcm"]
        if u.get("build_psf"):
            m["build_psf"] = u["build_psf"]
        out.append(m)
    return out


def apply_to_site(site: dict, typ: dict) -> dict:
    """Store the typology and write the unit mix, unit count and gross area the appraisal reads."""
    typ = normalise(typ, site)
    calc = analyse(typ, site)
    site["typology"] = typ
    if typ.get("sync", True) and calc["units"]:
        site["unit_mix"] = to_unit_mix(typ, calc)
        site["units"] = calc["units"]
        site["gia_sqft"] = calc["gross_sqft"]
    return calc


def summary_line(typ: dict, calc: dict) -> str:
    parts = []
    for u in typ["units"]:
        if u["count"]:
            parts.append(f"{u['count']} x {u['name'].lower()}")
    return ", ".join(parts)


def mix_by_beds(typ: dict) -> dict:
    out: dict[str, int] = {}
    for u in typ["units"]:
        k = "studio" if u["beds"] == 0 else f"{min(u['beds'], 4)}{'+' if u['beds'] >= 4 else ''} bed"
        out[k] = out.get(k, 0) + u["count"]
    return out
