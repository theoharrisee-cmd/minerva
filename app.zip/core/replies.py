"""Draft replies to planning correspondence.

Four kinds are covered: case officer queries, consultee responses, neighbour and public comments, and
pre-application or S106 negotiation. The drafts follow the national guidance on material planning
considerations, consultation, planning obligations and viability (see GUIDANCE below). A draft is a
starting point for the person who sends it: facts that only they hold are left as [square brackets]
and listed as things to complete."""
from __future__ import annotations

import json
import re
from datetime import date

KINDS = {
    "officer": "Case officer query",
    "consultee": "Consultee response",
    "neighbour": "Neighbour or public comment",
    "s106": "Pre-application, S106 or viability",
}

GUIDANCE = [
    {"topic": "Material planning considerations", "url": "https://www.gov.uk/guidance/determining-a-planning-application",
     "points": ["Decisions follow the development plan unless material considerations indicate otherwise.",
                "Land use, design, highways, drainage, ecology, heritage and policy compliance are material. Property values, private rights to light and the identity of the applicant are not.",
                "Public support or opposition counts only where it rests on planning grounds. Tie each point to a policy or a material consideration."]},
    {"topic": "Consultation and response times", "url": "https://www.gov.uk/guidance/consultation-and-pre-decision-matters",
     "points": ["Statutory consultees must give a substantive, reasoned response within 21 days of receiving the consultation (18 days for some public service infrastructure).",
                "Consultees may recommend refusal or conditions. The authority decides whether amended plans need re-consultation.",
                "Pre-commencement conditions need the applicant's written agreement, so respond to draft conditions promptly."]},
    {"topic": "Planning obligations", "url": "https://www.gov.uk/guidance/planning-obligations",
     "points": ["An obligation must be necessary to make the development acceptable, directly related to it, and fair and reasonable in scale and kind (Regulation 122).",
                "Ask for payment triggers, spend deadlines, repayment of unspent sums and a proportionate monitoring fee in the heads of terms.",
                "Applicants may seek flexibility through a viability case, and can appeal if the terms are not agreed."]},
    {"topic": "Viability", "url": "https://www.gov.uk/guidance/viability",
     "points": ["Schemes that comply with an up-to-date plan are treated as viable. A viability case has to show what has changed since the plan was made.",
                "Benchmark land value is existing use value plus a premium for the landowner. The price paid for the land does not justify a departure from policy.",
                "Use standardised inputs, evidence each assumption, expect the summary to be published, and note that developer return is usually 15 to 20% of GDV."]},
]

# Each topic: label, detection pattern, response paragraph, evidence to attach, checks before sending.
TOPICS = {
    "highways": ("Highways and access", r"highway|access|visibility|splay|junction|trip|traffic|parking|swept path|road safety|s278|travel plan|trics",
                 "{tc}On highways and access, the scheme provides {parking} and {access}. The transport assessment uses trip rates from [source and status], and we will provide the junction modelling and swept path drawings you have asked for. We are willing to enter into a section 278 agreement for any works to the public highway, and to accept a travel plan and construction traffic management plan by condition.",
                 ["Transport assessment addendum", "Junction capacity model outputs", "Swept path drawings", "Draft travel plan"],
                 ["Confirm the trip rate source and survey dates.", "Confirm the visibility splays achieved against the speed survey.", "Check the parking ratio against the adopted standard."]),
    "drainage": ("Drainage and flood risk", r"drain|suds|llfa|runoff|attenuat|flood|fra\b|sewer|surface water|foul|thames water|anglian water|united utilities|severn trent",
                 "On drainage and flood risk, the strategy will manage surface water in line with the sustainable drainage hierarchy and limits discharge to the greenfield rate for the relevant storm events, with an allowance for climate change. {flood}We will submit the revised strategy and calculations, and we accept a condition requiring detailed design before commencement. For foul drainage we are in contact with the sewerage undertaker about capacity and will share its written response.",
                 ["Flood risk assessment and drainage strategy", "Drainage calculations and plan", "Sewerage undertaker capacity response"],
                 ["Confirm the greenfield runoff rates and the climate change allowance used.", "Confirm who will adopt and maintain the drainage features.", "Check the sequential test wording if the site is in flood zone 2 or 3."]),
    "ecology": ("Ecology, biodiversity net gain and habitats", r"ecolog|biodiversity|bng|net gain|habitat|bat|badger|great crested|protected species|sang|samm|spa\b|sac\b|nutrient|hra\b|natural england|lighting",
                "{ecology}On ecology, the scheme will deliver at least the statutory 10% biodiversity net gain, measured using the statutory metric, with a habitat management plan for the maintenance period. We will provide the updated ecological appraisal and any survey work that falls outside the season, and we agree to conditions covering a construction environmental management plan and a lighting strategy.",
                ["Ecological appraisal and species surveys", "Biodiversity metric and net gain plan", "Habitat management plan", "Habitats regulations assessment information, if required"],
                ["Confirm the metric version and the baseline habitat survey date.", "Confirm whether off-site units are needed and where they will be secured.", "Check nutrient neutrality or recreational mitigation requirements for this catchment."]),
    "heritage": ("Heritage and conservation", r"heritage|conservation|listed|significance|setting|historic england|conservation officer|character|archaeolog",
                 "{heritage}On heritage, we will support the proposals with a heritage statement. Where the authority sees harm, the public benefits of the scheme are set out in the planning statement, including housing delivery, the re-use of a redundant building and any contribution to local character. We will provide further views and visualisations, and we would welcome a meeting with the conservation officer.",
                 ["Heritage statement and impact assessment", "Verified views", "Public benefits schedule"],
                 ["Confirm the level of harm you are asserting (none, less than substantial, substantial).", "Check the wording against the statutory duties for listed buildings and conservation areas."]),
    "contamination": ("Contamination and ground conditions", r"contaminat|phase 1|phase 2|remediat|ground investigation|gas|made ground|environmental health|asbestos|ground condition",
                      "On ground conditions, the desk study [status] and a ground investigation is {gi}. We propose that the remediation strategy and validation report are secured by the standard conditions, and we will provide the results to environmental health when available.",
                      ["Phase 1 desk study", "Phase 2 investigation report", "Remediation and verification strategy"],
                      ["Confirm the status of the ground investigation and the dates.", "Check the remediation cost sits within the appraisal."]),
    "design": ("Design, density and layout", r"design|density|height|massing|layout|materials|overlook|privacy|daylight|sunlight|bre\b|amenity space|character|scale|storey|design code|nationally described space",
               "On design and layout, the scheme is {units_phrase}. We will provide daylight, sunlight and privacy testing against the accepted standards and show how the layout responds to the design policies in the adopted plan. We are happy to provide the additional street scenes and sections requested and to discuss revisions to the elevations and materials where they resolve your concern without losing homes.",
               ["Design and access statement update", "Sections and street scenes", "Daylight and sunlight report"],
               ["Confirm separation distances and the standard they are tested against.", "Confirm the space standard compliance schedule."]),
    "affordable": ("Affordable housing", r"affordable|registered provider|social rent|shared ownership|first homes|tenure|nomination",
                   "On affordable housing, the scheme offers {aff} of homes as affordable housing, with the tenure split set by the adopted policy, subject to the outcome of discussions with registered providers. We will confirm the provider and the unit mix on the affordable homes once terms are agreed.",
                   ["Affordable housing statement", "Registered provider letter of interest"],
                   ["Confirm the tenure split against the policy.", "Confirm the offer is consistent with the appraisal."]),
    "viability": ("Viability", r"viab|benchmark land value|gdv|profit|residual|review mechanism|late stage|independent assessment|bnpp|district valuer|red book",
                  "On viability, our assessment follows the national guidance. It uses standardised inputs, evidences each assumption, and identifies what has changed since the plan was made. Benchmark land value is taken as existing use value plus a landowner premium. We accept that the summary will be published and we are willing to fund an independent review. Developer return is {profit}. We will show the appraisal with and without the requested obligations.",
                  ["Viability assessment and appraisal", "Evidence of sales values and build costs", "Benchmark land value evidence"],
                  ["Confirm each input has a source you can cite.", "Confirm the profit assumption against the plan-stage viability evidence.", "Decide the position on review mechanisms before the meeting."]),
    "s106": ("Planning obligations", r"s106|section 106|obligation|heads of terms|contribution|education|health|open space|monitoring fee|cil\b|trigger|indexation|repayment|unilateral undertaking",
             "{s106}On planning obligations, we will accept contributions that meet the three tests in Regulation 122: necessary to make the development acceptable, directly related to it, and fair and reasonable in scale and kind. For each requested contribution we ask for the policy basis, the calculation and the project it will fund. We propose payment on defined triggers linked to occupation, indexation from the date of the agreement, a spend deadline with repayment of unspent sums, and a proportionate monitoring fee.",
             ["Draft heads of terms with our comments", "Calculation queries by contribution"],
             ["Ask for the policy and the calculation behind each item.", "Check the total against the S106 allowance in the appraisal.", "Confirm whether CIL applies and whether any items overlap with it."]),
    "amenity": ("Amenity, noise and construction", r"noise|dust|construction|hours of work|disturb|air quality|light pollution|smell|vibration|amenity|neighbour|construction traffic",
                "We recognise that construction affects neighbours. We will submit a construction environmental management plan covering working hours, dust and noise control, wheel washing and delivery routing, and we will appoint a named community liaison contact. We accept a condition securing the plan before work begins.",
                ["Construction environmental management plan", "Noise assessment, if requested"],
                ["Confirm the working hours you can commit to.", "Name the community liaison contact."]),
    "homes": ("Housing mix, space standards and layouts", r"space standard|ndss|nationally described|unit mix|housing mix|dwelling mix|unit sizes|floor area|\bgia\b|bedroom size|storage|schedule of accommodation|typolog|floor ?plans?|layouts?|internal (space|area)",
              "On housing mix and space standards, the scheme provides {units_phrase}: {mix}. {space} We will provide the schedule of accommodation with the gross internal area, bedspaces and built-in storage for each home type, together with the floorplan for each type, so that compliance can be checked line by line.",
              ["Schedule of accommodation", "Floorplans for each home type", "Space standards compliance table"],
              ["Check the schedule against the drawings for each type.", "Confirm bedspaces and storey counts for each type."]),
    "accessibility": ("Accessible and adaptable homes", r"m4\(2\)|m4\(3\)|wheelchair|accessib|adaptable|step[- ]free|part m\b|disabled|lift",
                      "On accessibility, {access_note} We will provide the M4(2) and M4(3) compliance drawings for each type and show the location of the wheelchair user homes in the blocks and their parking.",
                      ["Accessibility statement", "M4(2) and M4(3) compliance drawings", "Wheelchair home locations and parking"],
                      ["Confirm the policy target and how it is applied to affordable and market homes.", "Confirm lift provision and travel distances."]),
    "outdoor": ("Private and communal amenity space", r"private amenity|balcon|garden|outdoor space|communal (amenity|garden|space)|play ?space|amenity space|terrace",
                "On private and communal amenity space, {outdoor} We will dimension each balcony and garden on the floorplans and show the communal amenity and play space in the landscape scheme.",
                ["Amenity space schedule", "Landscape masterplan with play space"],
                ["Check the standard applied to balcony depth and garden length.", "Check play space against the child yield for the scheme."]),
    "trees": ("Trees and landscape", r"tree|hedgerow|landscape|arboricult|tpo|planting|woodland",
              "On trees and landscape, the arboricultural impact assessment identifies the trees to be kept and protected, and the landscape scheme replaces any loss with new planting. We accept conditions for tree protection during construction and for a detailed landscape scheme with a maintenance period.",
              ["Arboricultural impact assessment", "Tree protection plan", "Landscape masterplan"],
              ["Confirm the number and category of trees to be lost and the replacement ratio."]),
    "fire": ("Fire safety and building safety", r"fire|gateway|hse\b|building safety|evacuation|sprinkler|second staircase|high rise|higher-risk",
             "On fire safety, the scheme is being designed to meet the building regulations, and for any higher-risk building we will submit the fire statement with the application and engage with the Building Safety Regulator at the gateway stages. The fire strategy will be developed by a named fire engineer and we will share it as it is completed.",
             ["Planning fire safety statement", "Fire strategy summary"],
             ["Confirm whether the building is higher-risk under the Building Safety Act.", "Confirm the fire engineer and their instruction date."]),
    "timing": ("Timing and determination", r"extension of time|deadline|determination|target date|planning performance agreement|ppa\b|withdraw|committee date|8 weeks|13 weeks|16 weeks",
               "On timing, we would like to agree the programme to determination. We are willing to agree an extension of time or a planning performance agreement if it gives certainty on the committee date, and we will return any further information within [number] working days of your request.",
               ["Proposed programme to determination"],
               ["Check the statutory determination date on the file.", "Decide whether to offer an extension of time or ask for a decision."]),
    "principle": ("Principle of development and policy", r"principle|allocation|local plan|nppf|green belt|grey belt|five year|housing land supply|tilted balance|policy|weight|emerging",
                  "On the principle of development, we rely on {principle}. We ask that the officer report addresses the weight given to the emerging policies and the position on housing land supply, which is a material consideration in the balance. {precedent}",
                  ["Planning statement policy appraisal"],
                  ["Cite the exact policy numbers.", "Check the current housing land supply figure for the authority."]),
}

NON_MATERIAL = re.compile(r"property value|house price|devalue|right to light|view from|loss of view|competition|builder|developer profit|another site|moral|i just don'?t like|business", re.I)

REF_RX = re.compile(r"\b(\d{2,4}/\d{2,6}/[A-Z]{2,6}|[A-Z]{1,3}/\d{2,4}/\d{2,6}|\d{2}[A-Z]{2}\d{4,6}|P/?\d{2,4}/\d{3,6}|DC/\d{2}/\d{3,6}|\d{5}/[A-Z]+/\d{2})\b")
DATE_RX = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(20\d\d)\b|\b(\d{1,2})/(\d{1,2})/(20\d\d)\b", re.I)
ITEM_RX = re.compile(r"(?m)^\s*(?:\(?\d{1,2}[.)]|\(?[a-h]\)|[-*•])\s+(.{12,400})$")


def parse(text: str) -> dict:
    """Pull out the reference, any dates, the sender's name and the numbered requests."""
    text = text or ""
    ref = REF_RX.search(text)
    dates = []
    for m in DATE_RX.finditer(text):
        dates.append(m.group(0))
    greeting = re.search(r"(?im)^\s*(?:dear|hi|hello)\s+([A-Z][A-Za-z'\- ]{1,40}?)[,:]?\s*$", text)
    who = re.search(r"(?im)^(?:regards|kind regards|yours sincerely|yours faithfully|many thanks|thanks|best wishes|best regards),?\s*\n+\s*([A-Z][A-Za-z'\-. ]{2,40})\s*$", text)
    items = [re.sub(r"\s+", " ", m.group(1)).strip() for m in ITEM_RX.finditer(text)]
    return {"ref": ref.group(1) if ref else "", "dates": dates[:4], "sender": who.group(1).strip() if who else "", "addressed_to": greeting.group(1).strip() if greeting else "", "items": items[:12]}


def topics_in(text: str) -> list[str]:
    found = []
    for key, (label, rx, *_r) in TOPICS.items():
        if re.search(rx, text or "", re.I):
            found.append(key)
    return found


def _precedent(site: dict) -> str:
    from . import track
    return track.facts(site.get("track")).get("precedent_sentence", "")


def _ctx(site: dict, inv: dict, scheme: dict | None = None) -> dict:
    units = site.get("units")
    aff = (site.get("ovr") or {}).get("affordable_pct")
    fz = str(site.get("flood_zone") or "1")
    cons = site.get("consultees") or []

    def note(pattern):
        for c in cons:
            if re.search(pattern, c.get("body", ""), re.I) and c.get("summary"):
                return "The position on file is: " + c["summary"].rstrip(".") + ". "
        return ""
    sc = scheme or {}
    units = sc.get("units") or units
    return {
        "site": site.get("name") or "the site", "address": site.get("address") or site.get("name") or "the site", "units": units,
        "units_phrase": sc.get("units_phrase") or (f"{units} homes" if units else "[number] homes"), "aff": f"{aff * 100:.0f}%" if aff else "[percentage]",
        "flood": (f"The site lies in flood zone {fz}, so the sequential test and exception test material is being updated. " if fz in ("2", "3") else "The site lies in flood zone 1. "),
        "parking": sc.get("parking_sentence") or "[parking ratio]", "access": "[access arrangement]",
        "mix": sc.get("mix") or "[unit mix]", "space": sc.get("space_sentence") or "[state whether each home type meets the Nationally Described Space Standard]",
        "access_note": sc.get("access_sentence") or "[state the M4(2) and M4(3) provision]", "outdoor": sc.get("outdoor_sentence") or "[describe the balcony and garden provision]", "density": sc.get("density_sentence") or "[density]", "tc": note(r"highway"),
        "ecology": note(r"natural england|ecolog"), "heritage": note(r"historic|conservation|heritage"),
        "gi": "[under way or complete]", "profit": "[percentage] of GDV, within the range in the national guidance",
        "s106": note(r"education|health|s106|section 106"), "principle": f"the {site.get('planning_status', 'planning')} position and [policy references]",
        "precedent": _precedent(site), "who": inv.get("name") or "[your name]", "firm": inv.get("firm") or "[your firm]",
    }


def _fill(tpl: str, c: dict) -> str:
    return re.sub(r"\{(\w+)\}", lambda m: str(c.get(m.group(1), "")), tpl).replace("  ", " ").strip()


def _opening(kind: str, meta: dict, c: dict) -> str:
    ref = f" ({meta['ref']})" if meta.get("ref") else ""
    addr = c["address"]
    if kind == "officer":
        return f"Thank you for your email about the application{ref} at {addr}. We respond to each point below and list the documents we will submit."
    if kind == "consultee":
        return f"Thank you for your response to the application{ref} at {addr}. We have read it carefully and set out our response and proposed way forward below."
    if kind == "neighbour":
        return f"Thank you for taking the time to comment on the proposals for {addr}. We have read what you wrote and respond to the points that relate to planning below."
    return f"Thank you for your letter about {addr}{ref}. We set out our position on each point below and suggest a way to close the open items."


def _closing(kind: str, meta: dict, c: dict, deadline: str) -> str:
    dl = f" We will reply by {deadline}." if deadline else ""
    if kind == "neighbour":
        return f"If you would like to discuss any of this, please contact {c['who']} at {c['firm']} on [telephone] or [email].{dl}"
    return f"Please tell us if you need anything further, and whether a short meeting would help resolve the remaining points.{dl}"


def _template(kind: str, incoming: str, site: dict, inv: dict, tone: str, extra_topics: list[str], scheme: dict | None = None) -> dict:
    meta = parse(incoming)
    c = _ctx(site, inv, scheme)
    topics = topics_in(incoming)
    for t in extra_topics:
        if t in TOPICS and t not in topics:
            topics.append(t)
    if kind == "s106":
        topics = [t for t in topics if t not in ("s106", "viability")]
        topics = ["s106", "viability"] + topics
    if kind == "neighbour":
        topics = [t for t in topics if t in ("highways", "amenity", "design", "trees", "ecology", "drainage", "heritage")] or ["amenity"]
    if not topics:
        topics = ["principle"]
    blocks, evidence, checks = [], [], []
    for t in topics[:6]:
        label, _rx, tpl, ev, chk = TOPICS[t]
        blocks.append((label, _fill(tpl, c)))
        evidence += [e for e in ev if e not in evidence]
        checks += [x for x in chk if x not in checks]
    anticipate = []
    if scheme:
        area_topic = {"Space": ("homes", "design"), "Accessibility": ("accessibility",), "Outdoor space": ("outdoor", "design"), "Parking and cycling": ("highways",), "Mix and tenure": ("affordable", "homes"),
                      "Safety": ("fire",), "Density": ("design",), "Design": ("design",)}
        shown = set(topics[:6])
        for ck in scheme.get("checks", []):
            tps = area_topic.get(ck["area"], ())
            line = f"Scheme check, {ck['title'].lower()}: {ck['detail']}"
            if any(t in shown for t in tps):
                if line not in checks:
                    checks.append(line)
            elif line not in anticipate:
                anticipate.append(line)
    lines = [f"{'Dear ' + (meta['sender'] or meta['addressed_to']) + ',' if (meta['sender'] or meta['addressed_to']) else ('Dear Sir or Madam,' if kind == 'neighbour' else 'Dear [name],')}", "", _opening(kind, meta, c), ""]
    n = 1
    for label, body in blocks:
        lines += [f"{n}. {label}", body, ""]
        n += 1
    if meta["items"] and kind != "neighbour":
        lines += ["Points raised in your message", *[f"- {i}" for i in meta["items"][:8]], "We have treated each of these under the headings above. If any point needs a separate answer, tell us and we will reply in writing.", ""]
    if kind == "neighbour":
        nm = NON_MATERIAL.findall(incoming or "")
        if nm:
            lines += ["Matters that fall outside planning", "Some of the concerns raised, such as " + ", ".join(sorted({x.lower() for x in nm})[:4]) + ", are private matters and the council cannot take them into account when it decides the application. We understand they matter to you, and we are happy to talk about them directly.", ""]
            checks.append("Check that nothing in the reply dismisses a concern that is a material planning consideration.")
        lines += ["The council will consider all comments received before it decides the application, and you can follow progress on its planning register.", ""]
    lines += [_closing(kind, meta, c, (meta["dates"] or [""])[0] if kind != "neighbour" else ""), "", "Yours sincerely," if meta["sender"] or meta["addressed_to"] else "Yours faithfully,", c["who"], c["firm"]]
    body = "\n".join(lines)
    ref = meta["ref"] or "[reference]"
    subj = {"officer": f"Application {ref}, {site.get('name', 'site')}: response to your query", "consultee": f"Application {ref}, {site.get('name', 'site')}: response to consultee comments",
            "neighbour": f"Proposals at {site.get('name', 'the site')}: response to your comments", "s106": f"{site.get('name', 'Site')}: heads of terms and viability, our comments"}[kind]
    if tone == "firm":
        body = body.replace("we are willing to", "we are prepared to").replace("We would welcome", "We ask for")
    return {"subject": subj, "body": body, "topics": [TOPICS[t][0] for t in topics[:6]], "topic_keys": topics[:6], "evidence": evidence, "checks": checks, "anticipate": anticipate[:6], "meta": meta}


SYSTEM = """You draft replies to UK planning correspondence for a housing developer. Write in British English, in plain professional prose, with no em dashes.
Follow the national guidance summarised below. Only argue material planning considerations, and refer to policy and evidence. Where a fact is not in the site data or the message, leave it as [square brackets] for the sender to complete. Do not invent references, figures, policies or dates.
For neighbour comments: be courteous, address the planning points, and say plainly which matters the council cannot take into account. For S106: apply the Regulation 122 tests, ask for the calculation behind each item, and propose triggers, indexation, spend deadlines and monitoring fees. For viability: use standardised inputs, benchmark land value as existing use value plus a premium, and accept publication.
Return JSON only: {"subject": "...", "body": "...", "topics": ["..."], "evidence": ["documents to attach"], "checks": ["things the sender must confirm before sending"]}"""


def _guidance_text() -> str:
    return "\n\n".join(f"{g['topic']} ({g['url']})\n" + "\n".join("- " + p for p in g["points"]) for g in GUIDANCE)


def _site_facts(site: dict) -> str:
    keep = {k: site.get(k) for k in ("name", "address", "la", "units", "site_ha", "planning_status", "strategy", "flood_zone", "asking_price", "description") if site.get(k) not in (None, "")}
    keep["consultees"] = [{k: c.get(k) for k in ("body", "stance", "summary", "date")} for c in (site.get("consultees") or [])][:8]
    keep["applications"] = [{k: a.get(k) for k in ("ref", "status", "description", "key_points")} for a in (site.get("planning_history") or [])][:4]
    return json.dumps(keep, default=str)


def draft(kind: str, incoming: str, site: dict, inv: dict, tone: str = "measured", topics: list[str] | None = None,
          api_key: str | None = None, model: str | None = None, claude=None, scheme: dict | None = None) -> dict:
    if kind not in KINDS:
        kind = "officer"
    base = _template(kind, incoming, site, inv, tone, topics or [], scheme)
    base["kind"] = kind
    base["mode"] = "template"
    base["guidance"] = [{"topic": g["topic"], "url": g["url"]} for g in GUIDANCE]
    if api_key:
        try:
            from . import planning
            call = claude or planning._claude
            msg = (f"Kind of reply: {KINDS[kind]}. Tone: {tone}.\n\nGuidance:\n{_guidance_text()}\n\nSite data:\n{_site_facts(site)}\n\nComparable consents nearby (use only if relevant, do not add others):\n{_precedent(site) or 'none on file'}\n\nScheme facts from the homes schedule (quote these, do not invent others):\n{json.dumps({k: v for k, v in (scheme or {}).items() if k not in ('checks', 'mix_by_beds')}, default=str)}\n\nOpen policy findings on the scheme:\n{json.dumps((scheme or {}).get('checks', []), default=str)}\n\n"
                   f"Sender: {inv.get('name') or '[your name]'}, {inv.get('firm') or '[your firm]'}.\n\nMessage received:\n{incoming[:8000]}\n\n"
                   f"Draft a reply. Suggested topics: {', '.join(base['topics'])}.")
            raw = call(api_key, model or "claude-sonnet-4-5", SYSTEM, [{"role": "user", "content": msg}], 2500)
            d = planning._parse_json(raw)
            if d.get("body"):
                base.update(subject=d.get("subject") or base["subject"], body=d["body"].replace(chr(0x2014), ", "), mode="claude",
                            evidence=d.get("evidence") or base["evidence"], checks=d.get("checks") or base["checks"], topics=d.get("topics") or base["topics"])
        except Exception as e:
            base["note"] = f"The Claude draft failed ({str(e)[:80]}), so the template draft is shown."
    base["placeholders"] = sorted(set(re.findall(r"\[[^\]\n]{2,40}\]", base["body"])))
    return base


def deadline_flag(incoming: str, today: date | None = None) -> str:
    """Mention of a date in the message that falls within 21 days, for a nudge in the interface."""
    today = today or date.today()
    months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]
    for m in DATE_RX.finditer(incoming or ""):
        try:
            d = date(int(m.group(3)), months.index(m.group(2).lower()) + 1, int(m.group(1))) if m.group(1) else date(int(m.group(6)), int(m.group(5)), int(m.group(4)))
        except (ValueError, TypeError):
            continue
        days = (d - today).days
        if 0 <= days <= 21:
            return f"{d:%d %B %Y} is in {days} day{'s' if days != 1 else ''}"
    return ""
