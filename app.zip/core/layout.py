"""Layout test for the houses on a site boundary.

Rows of houses face streets, with back gardens meeting back gardens, in the pattern most housing estates use.
The test tries many orientations and offsets and keeps the one that fits the most houses, then measures what that
layout gives: homes by type, garden lengths and areas, back to back distances, parking and the land left over.
It is a capacity and standards test, not a scheme design: junctions, drainage, open space and access are not drawn.
Flats are not placed. Everything is in metres on a flat local grid.
"""
from __future__ import annotations

import math

from . import floorplan as fp, geo

DEFAULTS = {"street": 9.5, "front": 5.0, "margin": 3.0, "side_gap": {"terrace": 0.0, "semi": 1.0, "detached": 3.0, "block": 0.0}, "parking_bay": 2.5, "bay_depth": 5.0, "street_bay": 6.0, "street_bay_share": 0.45,
            "back_to_back": 21.0, "front_to_front": 20.0}


def _rot(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c + p[1] * s, -p[0] * s + p[1] * c)


def _unrot(p, a):
    return _rot(p, -a)


def _inside(pt, ring) -> bool:
    x, y = pt
    ins = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            ins = not ins
        j = i
    return ins


def _edge_dist(pt, ring) -> float:
    return min(geo.seg_dist(pt[0], pt[1], *ring[i], *ring[(i + 1) % len(ring)]) for i in range(len(ring)))


def _ok(rect, ring, margin) -> bool:
    x0, y0, x1, y1 = rect
    for p in ((x0, y0), (x1, y0), (x1, y1), (x0, y1), ((x0 + x1) / 2, y0), ((x0 + x1) / 2, y1), (x0, (y0 + y1) / 2), (x1, (y0 + y1) / 2)):
        if not _inside(p, ring) or _edge_dist(p, ring) < margin:
            return False
    return True


def boundary_ring(site: dict):
    """(ring in metres about the site point, source note). A drawn boundary, or a 2:1 rectangle of the stated site area."""
    lat0, lon0 = site["lat"], site["lon"]
    b = site.get("boundary")
    if b and b.get("ring"):
        xy = geo.ring_to_xy([tuple(p) for p in b["ring"]], lat0, lon0)
        return xy, "drawn boundary"
    ha = float(site.get("site_ha") or 0)
    if ha > 0:
        a = ha * 1e4
        w = math.sqrt(2 * a)
        h = a / w
        return [(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)], "assumed rectangle of the stated site area, because no boundary is drawn"
    return None, "no boundary or site area"


def _house_types(typ: dict, calc: dict, pk: dict) -> list[dict]:
    out = []
    for u in typ["units"]:
        if u["family"] != "house" or not u["count"]:
            continue
        p = calc["per"][u["id"]]
        att = u.get("attach") or "terrace"
        att = "semi" if att.startswith("semi") else "detached" if att == "detached" else "terrace"
        out.append({"id": u["id"], "name": u["name"], "code": u.get("code", ""), "beds": u["beds"], "count": u["count"], "W": p["W"], "D": p["D"], "attach": att, "storeys": u["storeys"],
                    "garden_need": pk["garden_area"].get(min(u["beds"], 5), 100)})
    return out


def _try(ring, theta, dy, types, prm, garden_len):
    """One layout at one orientation and offset. Returns (plots, streets)."""
    R = [_rot(p, theta) for p in ring]
    xs, ys = [p[0] for p in R], [p[1] for p in R]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    dmax = max(t["D"] for t in types)
    pd = prm["front"] + dmax + garden_len
    M = prm["street"] + 2 * pd
    s = prm["street"]
    total_w = sum(t["count"] for t in types)
    share = {t["id"]: t["count"] / total_w for t in types}
    placed = {t["id"]: 0 for t in types}
    n_placed = 0
    plots, streets = [], []
    k = -1
    while True:
        ys_c = y0 + dy + k * M + M / 2
        k += 1
        if ys_c - M / 2 > y1:
            break
        row_plots = {"N": [], "S": []}
        for side in ("N", "S"):
            ya, yb = (ys_c + s / 2, ys_c + s / 2 + pd) if side == "N" else (ys_c - s / 2 - pd, ys_c - s / 2)
            x = x0
            while x < x1:
                deficits = sorted(types, key=lambda t: -(share[t["id"]] * (n_placed + 1) - placed[t["id"]]))
                done = False
                for t in deficits:
                    w = t["W"] + prm["side_gap"][t["attach"]]
                    if _ok((x, ya, x + w, yb), R, prm["margin"]):
                        G = pd - prm["front"] - t["D"]
                        plots.append({"t": t["id"], "x": x, "w": w, "ya": ya, "yb": yb, "side": side, "street": k, "D": t["D"], "G": G, "W": t["W"], "beds": t["beds"], "need": t["garden_need"], "attach": t["attach"]})
                        row_plots[side].append(plots[-1])
                        placed[t["id"]] += 1
                        n_placed += 1
                        x += w
                        done = True
                        break
                if not done:
                    x += 1.0
        allp = row_plots["N"] + row_plots["S"]
        if allp:
            streets.append({"k": k, "y": ys_c, "x0": min(p["x"] for p in allp), "x1": max(p["x"] + p["w"] for p in allp)})
    return plots, streets


def run(site: dict, typ: dict, calc: dict, pk: dict, params: dict | None = None) -> dict:
    prm = {**DEFAULTS, **(params or {})}
    ring, note = boundary_ring(site)
    types = _house_types(typ, calc, pk)
    if ring is None:
        return {"ok": False, "error": "Draw the site boundary or enter the site area first."}
    if not types:
        return {"ok": False, "error": "The schedule has no houses to lay out. Flats are not placed by this test."}
    garden_len = max(pk["garden_depth"], 10.5)
    area_m2 = geo.area_m2(ring)
    # candidate orientations: the longest edges and a spread of angles
    edges = sorted(((math.hypot(ring[(i + 1) % len(ring)][0] - ring[i][0], ring[(i + 1) % len(ring)][1] - ring[i][1]), math.atan2(ring[(i + 1) % len(ring)][1] - ring[i][1], ring[(i + 1) % len(ring)][0] - ring[i][0])) for i in range(len(ring))), reverse=True)
    angles = {round(a, 3) for _, a in edges[:3]} | {math.radians(d) for d in range(0, 180, 30)}
    dmax = max(t["D"] for t in types)
    M = prm["street"] + 2 * (prm["front"] + dmax + garden_len)
    best = None
    for th in angles:
        for f in (0.0, 0.33, 0.66):
            pl, st = _try(ring, th, f * M, types, prm, garden_len)
            score = (len(pl), -len(st))
            if best is None or score > best[0]:
                best = (score, th, pl, st)
    if not best or not best[2]:
        return {"ok": False, "error": "No houses fit inside this boundary with the standard street and garden dimensions. The site may be too small or too narrow."}
    _, th, plots, streets = best
    by = {}
    for p in plots:
        by[p["t"]] = by.get(p["t"], 0) + 1
    tmap = {t["id"]: t for t in types}
    # rear to rear distances between plots of opposite rows on neighbouring streets
    b2b = []
    for a in plots:
        if a["side"] != "N":
            continue
        for b in plots:
            if b["side"] == "S" and b["street"] == a["street"] + 1 and min(a["x"] + a["w"], b["x"] + b["w"]) - max(a["x"], b["x"]) > 1.0:
                b2b.append(a["G"] + b["G"])
    gmin = min(p["G"] for p in plots)
    short_len = [p for p in plots if p["G"] < pk["garden_depth"] - 0.05]
    short_area = [p for p in plots if p["w"] * p["G"] < p["need"] - 0.05]
    # parking
    frontage = 0
    for p in plots:
        spaces = int((p["w"] - 1.0) // prm["parking_bay"]) if p["W"] + 0 > 0 else 0
        frontage += max(0, min(spaces, 3))
    street_len = sum(s["x1"] - s["x0"] for s in streets)
    on_street = int(street_len * 2 / prm["street_bay"] * prm["street_bay_share"])
    need = 0.0
    per_bed = pk["parking"]["per_bed"]
    for p in plots:
        need += per_bed.get(min(p["beds"], 5), per_bed.get(3, 2.0))
    road_area = street_len * prm["street"]
    plot_area = sum((p["yb"] - p["ya"]) * p["w"] for p in plots)
    left = max(0.0, area_m2 - plot_area - road_area)
    homes = len(plots)
    # plan in original orientation
    def poly(x0, y0, x1, y1):
        return [_unrot(q, th) for q in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))]
    shapes = {"boundary": [[round(x, 2), round(y, 2)] for x, y in ring],
              "streets": [[[round(x, 2), round(y, 2)] for x, y in poly(s["x0"], s["y"] - prm["street"] / 2, s["x1"], s["y"] + prm["street"] / 2)] for s in streets], "plots": []}
    for p in plots:
        n = p["side"] == "N"
        fy0, fy1 = (p["ya"], p["ya"] + prm["front"]) if n else (p["yb"] - prm["front"], p["yb"])
        hy0, hy1 = (fy1, fy1 + p["D"]) if n else (fy0 - p["D"], fy0)
        shapes["plots"].append({"t": p["t"], "plot": [[round(x, 2), round(y, 2)] for x, y in poly(p["x"], p["ya"], p["x"] + p["w"], p["yb"])],
                                "house": [[round(x, 2), round(y, 2)] for x, y in poly(p["x"] + (p["w"] - p["W"]) / 2, hy0, p["x"] + (p["w"] + p["W"]) / 2, hy1)]})
    checks = []

    def chk(cid, title, status, detail):
        checks.append({"id": cid, "area": "Layout", "title": title, "status": status, "detail": detail, "source": "Layout test"})
    if b2b:
        lo = min(b2b)
        chk("l_b2b", "Back to back distance", "pass" if lo >= prm["back_to_back"] - 0.05 else "fail", f"Closest rear elevations are {lo:.1f} m apart against the {prm['back_to_back']:.0f} m most councils expect.")
    chk("l_garden_len", "Rear garden length", "pass" if not short_len else "warn", f"Shortest garden is {gmin:.1f} m against {pk['garden_depth']:.0f} m." + (f" {len(short_len)} plots are shorter." if short_len else ""))
    chk("l_garden_area", "Garden area by house size", "pass" if not short_area else "warn", "Every garden meets the area standard for its size." if not short_area else f"{len(short_area)} of {homes} gardens are smaller than the standard for their number of bedrooms.")
    st = "info" if need == 0 else "pass" if frontage + on_street >= need - 0.5 and pk["parking"]["basis"] == "minimum" else "pass" if pk["parking"]["basis"] == "maximum" and frontage + on_street <= need + 0.5 else "warn"
    chk("l_parking", "Parking that the layout provides", st, f"About {frontage} spaces on plot and {on_street} on street ({frontage + on_street} in all, {(frontage + on_street) / homes:.2f} per home) against roughly {need:.0f} at the standard for these homes. On street spaces are an estimate.")
    lp = left / area_m2
    chk("l_open", "Land left for open space and drainage", "pass" if lp >= 0.10 or area_m2 < 10000 else "warn", f"{lp:.0%} of the site ({left / 1e4:.2f} ha) is outside plots and streets, before junctions, access and drainage are drawn.")
    return {"ok": True, "note": note, "angle_deg": round(math.degrees(th) % 180, 1), "homes": homes, "by_type": {tid: {"name": tmap[tid]["name"], "laid": n, "wanted": tmap[tid]["count"]} for tid, n in by.items()} | {tid: {"name": t["name"], "laid": 0, "wanted": t["count"]} for tid, t in tmap.items() if tid not in by},
            "wanted": sum(t["count"] for t in types), "site_ha": round(area_m2 / 1e4, 3), "density_dph": round(homes / (area_m2 / 1e4), 1), "streets": len(streets), "street_m": round(street_len), "min_garden_m": round(gmin, 1),
            "min_back_to_back_m": round(min(b2b), 1) if b2b else None, "parking_plot": frontage, "parking_street": on_street, "parking_need": round(need), "left_pct": round(lp, 3), "checks": checks, "shapes": shapes,
            "params": {k: prm[k] for k in ("street", "front", "margin", "back_to_back")}}


def to_svg(res: dict, colours: dict, width: int = 760) -> str:
    sh = res["shapes"]
    pts = [p for p in sh["boundary"]]
    x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
    y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
    pad = 8
    sc = (width - 2 * pad) / max(x1 - x0, 1)
    h = int((y1 - y0) * sc + 2 * pad + 22)
    X = lambda x: round((x - x0) * sc + pad, 1)  # noqa: E731
    Y = lambda y: round((y1 - y) * sc + pad, 1)  # noqa: E731
    path = lambda r: "M" + "L".join(f"{X(p[0])} {Y(p[1])}" for p in r) + "Z"  # noqa: E731
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {h}" width="{width}" height="{h}" font-family="Aptos, Calibri, Arial, sans-serif">', f'<rect width="{width}" height="{h}" fill="#FFFFFF"/>',
         f'<path d="{path(sh["boundary"])}" fill="#F3F6F0" stroke="#000" stroke-width="2" stroke-dasharray="7 3"/>']
    for s in sh["streets"]:
        o.append(f'<path d="{path(s)}" fill="#D9D9D9" stroke="none"/>')
    for p in sh["plots"]:
        o.append(f'<path d="{path(p["plot"])}" fill="#E6F0DA" stroke="#9AAE86" stroke-width="0.6"/>')
    for p in sh["plots"]:
        o.append(f'<path d="{path(p["house"])}" fill="{colours.get(p["t"], "#FF6600")}" stroke="#333" stroke-width="0.6"/>')
    bar = 50 if (x1 - x0) > 150 else 20
    o.append(f'<path d="M{pad} {h - 12}H{pad + bar * sc}" stroke="#000" stroke-width="2"/><text x="{pad + bar * sc + 6}" y="{h - 8}" font-size="11" fill="#000">{bar} m</text>')
    o.append("</svg>")
    return "".join(o)


def signature(site: dict, typ: dict) -> str:
    import hashlib
    import json
    return hashlib.md5(json.dumps([(site.get("boundary") or {}).get("ring"), site.get("site_ha") if not site.get("boundary") else None, sorted((u["name"], u["count"]) for u in typ["units"] if u["family"] == "house")], sort_keys=True, default=str).encode()).hexdigest()[:12]


def colours_for(res: dict) -> dict:
    return {tid: fp.TYPE_COLOURS[i % len(fp.TYPE_COLOURS)] for i, tid in enumerate(res["by_type"])}


def to_png(res: dict, colours: dict | None = None, width: int = 1400) -> bytes:
    from PIL import Image, ImageDraw
    import io
    colours = colours or colours_for(res)
    sh = res["shapes"]
    pts = sh["boundary"]
    x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
    y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
    pad = 14
    sc = (width - 2 * pad) / max(x1 - x0, 1)
    h = int((y1 - y0) * sc + 2 * pad)
    img = Image.new("RGB", (width, h), "white")
    d = ImageDraw.Draw(img)
    P = lambda r: [((x - x0) * sc + pad, (y1 - y) * sc + pad) for x, y in r]  # noqa: E731
    d.polygon(P(pts), fill="#F3F6F0")
    for s in sh["streets"]:
        d.polygon(P(s), fill="#D9D9D9")
    for p in sh["plots"]:
        d.polygon(P(p["plot"]), fill="#E6F0DA", outline="#9AAE86")
    for p in sh["plots"]:
        d.polygon(P(p["house"]), fill=colours.get(p["t"], "#f4c9a3"), outline="#333333")
    bp = P(pts)
    d.line(bp + [bp[0]], fill="black", width=3)
    out = io.BytesIO()
    img.save(out, "PNG", optimize=True)
    return out.getvalue()
