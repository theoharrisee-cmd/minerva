"""Planning track record: how major applications near a site have fared over the previous five years.

Source: PlanIt, which collects applications from council registers. The area is a circle around the site
(default 8 km), so it approximates the council rather than matching its boundary. The API returns the
proposal, status and dates but not the reasons for refusal, so refused schemes are listed with links to
the register for the officer's report. Standard library only.
"""
from __future__ import annotations

import re
import statistics
from datetime import date, datetime, timedelta

from . import datasources as ds

RESI = re.compile(r"dwelling|house|flat|apartment|residential|homes?\b|bedroom|maisonette|bungalow|care home|extra care|student|co-living|build to rent", re.I)
PAGES = 4


def _d(s):
    try:
        return date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def _collect(lat, lon, radius, cfg, state, size, since, planit):
    out = []
    for pg in range(1, PAGES + 1):
        rows = planit(lat, lon, radius, cfg, app_state=state, app_size=size, start_date=since, pg_sz=100, pg=pg, sort="-start_date")
        out += rows
        if len(rows) < 100:
            break
    return out


def fetch(site: dict, cfg: dict | None = None, years: int = 5, radius_km: float = 8.0, planit=None, today: date | None = None) -> dict:
    planit = planit or ds.planit
    today = today or date.today()
    lat, lon = site["lat"], site["lon"]
    since = (today - timedelta(days=365 * years)).isoformat()
    got: dict[str, list[dict]] = {}
    errors = []
    for state in ("Permitted", "Rejected", "Withdrawn"):
        rows = []
        for size in ("Large", "Medium"):
            try:
                rows += [dict(r, size=size) for r in _collect(lat, lon, radius_km, cfg or {}, state, size, since, planit)]
            except Exception as e:
                errors.append(f"{state} {size}: {str(e)[:80]}")
        got[state] = rows
    if not any(got.values()):
        return {"ok": False, "error": errors[0] if errors else "No applications returned", "errors": errors, "fetched": today.isoformat()}
    for lst in got.values():
        for r in lst:
            r["units"] = ds.units_of(r["description"])
            r["resi"] = bool(RESI.search(r["description"] or ""))
    major = {k: [r for r in v if r["size"] == "Large" and r["resi"]] for k, v in got.items()}
    per, days, byyear = {}, [], {}
    for state in ("Permitted", "Rejected"):
        for r in major[state]:
            s, d = _d(r["submitted"]), _d(r["decided"])
            y = (d or s or today).year
            b = byyear.setdefault(y, {"year": y, "approved": 0, "refused": 0, "days": []})
            b["approved" if state == "Permitted" else "refused"] += 1
            if s and d and 0 < (d - s).days < 900:
                days.append((d - s).days)
                b["days"].append((d - s).days)
    ap, rj = len(major["Permitted"]), len(major["Rejected"])
    yrs = []
    for y in sorted(byyear):
        b = byyear[y]
        yrs.append({"year": y, "approved": b["approved"], "refused": b["refused"], "median_days": round(statistics.median(b["days"])) if b["days"] else None})
    recent = [r for r in major["Permitted"] + major["Rejected"] if (_d(r["decided"]) or date.min) >= today - timedelta(days=730)]
    rec_ap = sum(1 for r in recent if r in major["Permitted"])
    prec = sorted([r for r in got["Permitted"] if r["resi"] and (r["units"] or 0) >= 10 and r.get("distance_km") is not None and r["distance_km"] <= 3.0], key=lambda r: (r["distance_km"], -(r["units"] or 0)))
    ref = sorted([r for r in got["Rejected"] if r["resi"] and r["size"] == "Large" and r.get("distance_km") is not None and r["distance_km"] <= 3.0], key=lambda r: r["distance_km"])
    slim = lambda r: {k: r.get(k) for k in ("ref", "address", "description", "units", "submitted", "decided", "distance_km", "url", "lpa")}
    res = {"ok": True, "fetched": today.isoformat(), "years": years, "radius_km": radius_km, "majors": ap + rj, "approved": ap, "refused": rj, "withdrawn": len(major["Withdrawn"]),
           "approval_rate": ap / (ap + rj) if ap + rj else None, "recent_rate": rec_ap / len(recent) if len(recent) >= 5 else None, "recent_n": len(recent),
           "median_days": statistics.median(days) if days else None, "months_to_decide": statistics.median(days) / 30.4 if days else None, "n_days": len(days),
           "by_year": yrs, "precedents": [slim(r) for r in prec[:12]], "refused_nearby": [slim(r) for r in ref[:10]], "errors": errors,
           "note": "PlanIt does not carry reasons for refusal. Open each refused application on the council register to read the officer's report.",
           "lpas": sorted({r.get("lpa") for lst in got.values() for r in lst if r.get("lpa")})[:4]}
    if res["majors"] < 8:
        res["thin"] = True
    return res


def add_points(read_out: dict, track: dict | None) -> dict:
    """Append what the local record says to a planning read-out (mutates and returns it)."""
    if not track or not track.get("ok") or not track.get("majors"):
        return read_out
    r = track["approval_rate"]
    txt = f"Over the last {track['years']} years, {track['approved']} of {track['approved'] + track['refused']} decided residential major applications within {track['radius_km']:g} km were approved ({r:.0%})" + (
        f", with a median {track['median_days']:.0f} days to a decision." if track.get("median_days") else ".")
    if track.get("thin"):
        txt += " The sample is small."
    level = "Low" if r >= 0.8 else "Medium" if r >= 0.6 else "High"
    read_out.setdefault("points", []).append({"level": level, "text": txt, "doc": None})
    return read_out


def facts(track: dict | None) -> dict:
    """Short strings for reply drafting: comparable consents nearby."""
    if not track or not track.get("ok") or not track.get("precedents"):
        return {}
    ps = track["precedents"][:3]
    line = "; ".join(f"{p['ref']} ({p['units']} homes, {p['address'][:60]}, decided {p['decided'][:7] or 'n/a'})" for p in ps)
    return {"precedents": ps, "precedent_sentence": f"Comparable schemes approved nearby include {line}."}
