"""Sold prices from a Price Paid Data bulk file, as a fallback for when the linked-data SPARQL endpoint cannot be used.

Overnight testing (round 8) found that landregistry.data.gov.uk's SPARQL endpoint answers vocabulary queries (the ontology
itself) but returns HTTP 400 on every triple pattern tested against the real transaction data, whether an unbound scan, a
FILTER, or a VALUES-pinned exact postcode: querying lrppi:pricePaid or lrcommon:postcode directly failed every time, on a
plain GET with no other change. That looks like the live service no longer serves the bulk of the dataset over SPARQL, not a
quirk of one query shape, though it was not possible to read an error body to confirm why.

HM Land Registry also publishes the same data as plain CSV files with no key needed: a single 5GB+ file, or one file per
year (a recent year is a few hundred MB). This module reads a yearly file (or several, loaded one after another) into a
local index by postcode, in the same "load a bulk file in Settings" pattern already used for EPC certificates and for HMLR
company ownership data. The official column layout has been stable for years and carries no header row:

Transaction id, Price, Date of transfer, Postcode, Property type (D/S/T/F/O), New build (Y/N), Duration (F/L),
PAON, SAON, Street, Locality, Town/City, District, County, PPD category type, Record status.
"""
from __future__ import annotations

import csv
import gzip
import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from . import store

PATH = store.DATA / "ppd_sales.json.gz"
_cache: dict | None = None
TYPES = {"D": "Detached", "S": "Semi-detached", "T": "Terraced", "F": "Flat / maisonette", "O": "Other"}


def _pc(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().upper())


def sector(postcode: str) -> str | None:
    m = re.match(r"\s*([A-Za-z]{1,2}\d[A-Za-z\d]?)\s*(\d)[A-Za-z]{2}\s*$", postcode or "")
    return f"{m.group(1).upper()} {m.group(2)}" if m else None


def _read_csv(text: str, by_sector: dict) -> int:
    n = 0
    for row in csv.reader(io.StringIO(text)):
        if len(row) < 11:
            continue
        try:
            price = float(row[1])
        except ValueError:
            continue
        postcode = _pc(row[3])
        sec = sector(postcode)
        if not sec or price <= 0:
            continue
        sale = {"paon": row[7], "saon": row[8], "street": (row[9] or "").title(), "town": (row[11] or "").title(), "postcode": postcode,
                "price": price, "date": (row[2] or "")[:10], "type": TYPES.get((row[4] or "").upper(), row[4] or ""),
                "new_build": (row[5] or "").upper() == "Y", "tenure": "Freehold" if (row[6] or "").upper() == "F" else "Leasehold" if (row[6] or "").upper() == "L" else row[6]}
        by_sector.setdefault(sec, []).append(sale)
        n += 1
    return n


def load() -> dict:
    global _cache
    if _cache is None:
        try:
            with gzip.open(PATH, "rt") as f:
                _cache = json.load(f)
        except Exception:
            _cache = {"rows": 0, "loaded": "", "files": [], "by_sector": {}}
    return _cache


def _save(d: dict) -> None:
    global _cache
    with gzip.open(PATH, "wt") as f:
        json.dump(d, f)
    _cache = d


def load_bytes(data: bytes, name: str) -> dict:
    """Read a yearly (or complete) Price Paid Data CSV, with no header row, and merge it into the stored index."""
    d = load()
    by_sector = d["by_sector"]
    n = _read_csv(data.decode("utf-8-sig", "ignore"), by_sector)
    if not n:
        raise ValueError("No sales were found in that file. Use one of the CSV files from the Price Paid Data downloads (a single year is usually enough), not the linked-data or report-builder export.")
    for sec, rows in by_sector.items():
        rows.sort(key=lambda s: s["date"], reverse=True)
    d["rows"] = sum(len(v) for v in by_sector.values())
    d["sectors"] = len(by_sector)
    d["loaded"] = datetime.now(timezone.utc).isoformat(timespec="minutes")
    d["files"] = (d.get("files") or []) + [{"name": name[:80], "sales": n, "when": d["loaded"]}]
    d["files"] = d["files"][-12:]
    _save(d)
    return status()


def load_path(path: str) -> dict:
    p = Path(path).expanduser()
    if not p.exists():
        raise ValueError("That file was not found")
    return load_bytes(p.read_bytes(), p.name)


def clear() -> None:
    global _cache
    _cache = {"rows": 0, "loaded": "", "files": [], "by_sector": {}}
    try:
        PATH.unlink()
    except FileNotFoundError:
        pass


def status() -> dict:
    d = load()
    return {"rows": d["rows"], "sectors": d.get("sectors", len(d["by_sector"])), "loaded": d["loaded"], "files": d["files"]}


def for_sector(sec: str) -> list[dict]:
    return list(load()["by_sector"].get(sec, []))
