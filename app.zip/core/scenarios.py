"""Named scenarios and break-even points for a site appraisal.

A scenario is a set of changes to the base case: sales values, rents, build cost, exit yield, programme
delay and the land price. Break-even finds the single change that takes the scheme to zero profit or back
to the target margin, holding everything else as it is."""
from __future__ import annotations

import copy
import uuid

FIELDS = [
    ("sales", "Sales values", "%", "Change to sales value per sq ft"),
    ("rent", "Rents", "%", "Change to rent per sq ft"),
    ("build", "Build cost", "%", "Change to build cost"),
    ("yield_bps", "Exit yield", "bps", "Added to the exit yield in basis points"),
    ("delay", "Programme delay", "months", "Months added to the time to secure planning"),
    ("land", "Land price", "%", "Change to the price paid for the land"),
]
KEYS = [f[0] for f in FIELDS]

DEFAULTS = [
    {"id": "base", "name": "Base case", "sales": 0, "rent": 0, "build": 0, "yield_bps": 0, "delay": 0, "land": 0},
    {"id": "down", "name": "Downside", "sales": -7.5, "rent": -5, "build": 8, "yield_bps": 25, "delay": 6, "land": 0},
    {"id": "sev", "name": "Severe", "sales": -15, "rent": -10, "build": 12, "yield_bps": 50, "delay": 12, "land": 0},
    {"id": "up", "name": "Upside", "sales": 5, "rent": 4, "build": -3, "yield_bps": -15, "delay": 0, "land": 0},
]


def clean(lst) -> list[dict]:
    out = []
    for i, x in enumerate(lst or []):
        sid = str(x.get("id") or "sc-" + uuid.uuid4().hex[:6])
        fallback = "Base case" if sid == "base" else f"Scenario {i + 1}"
        d = {"id": sid, "name": str(x.get("name") or fallback).strip()[:40] or fallback}
        for k in KEYS:
            try:
                d[k] = float(x.get(k) or 0)
            except (TypeError, ValueError):
                d[k] = 0.0
        out.append(d)
    if not out or out[0]["id"] != "base":
        out.insert(0, dict(DEFAULTS[0]))
    else:
        out[0].update({k: 0.0 for k in KEYS}, name=out[0]["name"] or "Base case")
    return out[:6]


def apply(site: dict, A: dict, sc: dict) -> tuple[dict, dict]:
    """Return (site, assumptions) with the scenario changes applied to copies."""
    s, a = copy.deepcopy(site), dict(A)
    sales, rent, build = 1 + sc.get("sales", 0) / 100, 1 + sc.get("rent", 0) / 100, 1 + sc.get("build", 0) / 100
    s["sales_psf"] = float(site.get("sales_psf") or A["sales_psf"]) * sales
    s["rent_psf"] = float(site.get("rent_psf") or A["rent_psf"]) * rent
    for m in s.get("unit_mix") or []:
        if m.get("sale_value"):
            m["sale_value"] = float(m["sale_value"]) * sales
        if m.get("rent_pcm"):
            m["rent_pcm"] = float(m["rent_pcm"]) * rent
    if s.get("build_cost_total"):
        s["build_cost_total"] = float(s["build_cost_total"]) * build
    a["build_psf"] = A["build_psf"] * build
    a["refurb_psf"] = A["refurb_psf"] * build
    a["exit_yield"] = max(0.005, A["exit_yield"] + sc.get("yield_bps", 0) / 10000)
    a["planning_months"] = max(0.0, A["planning_months"] + sc.get("delay", 0))
    return s, a


def _row(ap: dict, base: dict | None = None) -> dict:
    basis = "profit_on_gdv" if ap["strategy"] == "develop_sell" else "profit_on_cost"
    r = {"gdv": ap["gdv"], "total_cost": ap["total_cost"], "profit": ap["profit"], "margin": ap[basis], "basis": "on GDV" if basis == "profit_on_gdv" else "on cost",
         "target": ap["target_profit"], "irr": ap.get("irr_levered"), "em": ap.get("equity_multiple"), "peak_equity": ap.get("peak_equity"), "land": ap["tested_land_price"],
         "viable": bool(ap["viable"]), "months": ap["months_land"], "rlv": ap.get("rlv"), "irr_unlevered": ap.get("irr_unlevered"), "yoc": ap.get("yield_on_cost"),
         "equity_profit": ap.get("equity_profit")}
    if base:
        r["d_profit"] = r["profit"] - base["profit"]
        r["d_margin"] = r["margin"] - base["margin"]
    return r


def run(site: dict, A: dict, strategy: str, scenarios: list[dict], appraise) -> list[dict]:
    """appraise(site, assumptions, strategy, land_price) is the engine call."""
    b_ap = appraise(site, A, strategy, None)
    base_land = b_ap["tested_land_price"]
    out, base = [], None
    for sc in scenarios:
        s2, a2 = apply(site, A, sc)
        ap = appraise(s2, a2, strategy, base_land * (1 + sc.get("land", 0) / 100))
        row = _row(ap, base)
        row.update(id=sc["id"], name=sc["name"], changes={k: sc.get(k, 0) for k in KEYS})
        if base is None:
            base = row
        out.append(row)
    return out


def _solve(f, lo: float, hi: float, iters: int = 32):
    """f is monotonic between lo and hi (either direction). Returns x where f(x) = 0, or None if there is no sign change."""
    flo, fhi = f(lo), f(hi)
    if flo == 0:
        return lo
    if flo * fhi > 0:
        return None
    for _ in range(iters):
        mid = (lo + hi) / 2
        fm = f(mid)
        if fm * flo > 0:
            lo, flo = mid, fm
        else:
            hi = mid
    return (lo + hi) / 2


def breakeven(site: dict, A: dict, strategy: str, appraise) -> dict:
    """Single-variable break-even points against the base case."""
    base = appraise(site, A, strategy, None)
    if base.get("incomplete"):
        return {"incomplete": True, "missing": base.get("missing")}
    basis = "profit_on_gdv" if strategy == "develop_sell" else "profit_on_cost"
    tgt = base["target_profit"]
    land0 = base["tested_land_price"]

    def margin(sc, land=None):
        s2, a2 = apply(site, A, {**{k: 0 for k in KEYS}, **sc})
        ap = appraise(s2, a2, strategy, land if land is not None else land0)
        return ap[basis], ap["profit"]

    out = {"base": {"profit": base["profit"], "margin": base[basis], "target": tgt, "land": land0}, "rows": []}
    specs = []
    if strategy == "btr":
        specs.append(("Exit yield", "yield_bps", 0, 600, "bps", "Change in exit yield", -300, 600))
    else:
        specs.append(("Sales values", "sales", 0, -60, "%", "Change in sales values", -60, 60))
    if strategy != "develop_sell":
        specs.append(("Rents", "rent", 0, -60, "%", "Change in rents", -60, 60))
    specs.append(("Build cost", "build", 0, 120, "%", "Change in build cost", -40, 120))
    specs.append(("Programme delay", "delay", 0, 60, "months", "Extra months before consent", 0, 60))
    for label, key, lo, hi, unit, phrase, tlo, thi in specs:
        row = {"label": label, "key": key, "unit": unit, "phrase": phrase}
        for tag, want in (("zero", None), ("target", tgt)):
            if want is None:
                x = _solve(lambda v: margin({key: v})[1], lo, hi)
            else:
                x = _solve(lambda v: margin({key: v})[0] - want, tlo, thi)
            row[tag] = x
        out["rows"].append(row)
    # land price ceiling: price at which profit is zero and at which the target margin is met
    top = max(land0 * 6, 1_000_000)
    zero = _solve(lambda p: margin({}, p)[1], 0, top)
    target = _solve(lambda p: margin({}, p)[0] - tgt, 0, top)
    out["land"] = {"zero": zero, "target": target, "tested": land0, "asking": base.get("asking") or None}
    return out
