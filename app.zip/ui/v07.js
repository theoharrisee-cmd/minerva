/* easyDevelopment v0.6: area and demographic search, data sources, per-site data tab, land ownership. */
Object.assign(I, {
  search: '<svg viewBox="0 0 24 24"><circle cx="10" cy="10" r="6"/><path d="M15 15l6 6"/></svg>',
  data: '<svg viewBox="0 0 24 24"><path d="M4 6c0-1.5 3.6-3 8-3s8 1.5 8 3-3.6 3-8 3-8-1.5-8-3z"/><path d="M4 6v6c0 1.5 3.6 3 8 3s8-1.5 8-3V6M4 12v6c0 1.5 3.6 3 8 3s8-1.5 8-3v-6"/></svg>',
});
NAV.splice(2, 0, ["search", "Search"]);
NAV.splice(NAV.findIndex(x => x[0] === "sourcing") + 1, 0, ["data", "Data sources"]);
Object.assign(TITLES, { search: ["Search", "Find sites and places from open data, by area, planning and demographics"], data: ["Data sources", "Every source, its status, and your credentials and land ownership data"] });

const ssel = (id, opts, v) => `<select id="${id}">${opts.map(([k, l]) => `<option value="${k}" ${String(v) === String(k) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
const pop = n => n >= 1e6 ? (n / 1e6).toFixed(1) + "m" : n >= 1e3 ? Math.round(n / 1e3) + "k" : String(n);
const lsGet = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { } };
const toNum = id => { const e = $("#" + id); return !e || e.value === "" ? null : +e.value; };
const csvOut = (name, rows) => { const b = new Blob(["﻿" + rows.map(r => r.map(c => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n")], { type: "text/csv" }); const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = name; document.body.append(a); a.click(); a.remove(); };

/* ================= search ================= */
const SR = { mode: lsGet("ed_srmode", "area"), c: lsGet("ed_srcrit", { radius_km: 5, sources: ["brownfield", "planit"], exclude: ["green_belt", "sssi", "ancient_woodland", "national_park"], consented: "any", near_mode: "drive", limit: 40 }),
  p: lsGet("ed_prcrit", { city_min_pop: 200000, city_max_min: 13, mode: "drive", kind: "any" }), res: null, pl: null, run: null, sel: new Set(), sort: "score", saved: [], info: null, pinsMap: null, msg: "", scr: null, scrRun: null, mand: null };

async function vSearch() {
  if (!SR.info) { try { SR.info = await api("/api/places/info"); SR.saved = (await api("/api/searches")).items; } catch { SR.info = { count: 0, source: "" }; } }
  $("#view").innerHTML = `<div class="tabs" style="margin-bottom:14px"><button class="pill ${SR.mode === "area" ? "on" : ""}" data-act="srmode" data-v="area">Sites in an area</button><button class="pill ${SR.mode === "places" ? "on" : ""}" data-act="srmode" data-v="places">Places by demographics</button><button class="pill ${SR.mode === "map" ? "on" : ""}" data-act="srmode" data-v="map">Map</button></div>
   ${SR.mode === "map" ? '<div id="mapws"></div>' : `<div class="srgrid"><div class="card pad srform" id="srform">${SR.mode === "area" ? areaForm() : placesForm()}</div><div id="srout">${SR.mode === "area" ? areaOut() : placesOut()}</div></div>`}`;
  if (SR.mode === "map") { vSearchMap(); return; }
  bindSearch();
  if (SR.mode === "area" && SR.res) paintSrMap();
}
const srChecks = (name, opts, sel) => `<div class="chk">${opts.map(([k, l]) => `<label><input type="checkbox" data-sr="${name}" value="${k}" ${sel.includes(k) ? "checked" : ""}>${esc(l)}</label>`).join("")}</div>`;
function savedList(kind) {
  const xs = SR.saved.filter(s => s.kind === kind);
  return xs.length ? `<div class="sec" style="margin:14px 0 6px"><h3 style="font-size:13px">Saved searches</h3></div>${xs.map(s => `<div class="row" style="padding:6px 0"><span class="grow" data-act="srload" data-id="${esc(s.id)}" style="cursor:pointer">${esc(s.name)}</span><button class="ghost" data-act="srdel" data-id="${esc(s.id)}" title="Delete">${I.x}</button></div>`).join("")}` : "";
}
function areaForm() {
  const c = SR.c, place = c.place_name || "";
  return `<h3 style="margin-bottom:4px">Search for sites</h3><div class="tsub" style="margin-bottom:12px">Ranks brownfield register sites and planning applications in the area, screened against constraint layers. Scores are for triage, with the reasons shown.</div>
  <div class="three"><label class="field" style="grid-column:span 2"><span>Centre: postcode or town</span><input type="text" id="sr_place" value="${esc(c.place || "")}" placeholder="e.g. RG40 3QT or Leicester"></label><label class="field"><span>Radius (km)</span><input type="number" id="sr_rad" min="0.5" max="25" step="0.5" value="${c.radius_km ?? 5}"></label></div>
  <div class="three" style="margin-top:8px"><label class="field"><span>Site area, min ha</span><input type="number" id="sr_minha" step="0.1" value="${c.min_ha ?? ""}"></label><label class="field"><span>Site area, max ha</span><input type="number" id="sr_maxha" step="0.1" value="${c.max_ha ?? ""}"></label><label class="field"><span>Homes, min</span><input type="number" id="sr_minu" value="${c.min_units ?? ""}"></label></div>
  <div class="three" style="margin-top:8px"><label class="field"><span>Homes, max</span><input type="number" id="sr_maxu" value="${c.max_units ?? ""}"></label><label class="field"><span>Permission</span>${ssel("sr_cons", [["any", "Any"], ["yes", "Has permission"], ["no", "No permission yet"]], c.consented || "any")}</label><label class="field"><span>Applications from the last</span>${ssel("sr_years", [[1, "1 year"], [2, "2 years"], [3, "3 years"], [5, "5 years"]], c.years || 3)}</label></div>
  <div class="lbl">Sources</div>${srChecks("sources", [["brownfield", "Brownfield land registers"], ["planit", "Planning applications (PlanIt)"]], c.sources || [])}
  <label class="chk one"><input type="checkbox" id="sr_bf" ${c.brownfield_only ? "checked" : ""}>Brownfield only</label>
  <div class="lbl">Leave out sites inside</div>${srChecks("exclude", (D.data_filters || []).map(f => [f.key, f.label]), c.exclude || [])}
  <div class="lbl">Demographics and access</div><div class="tsub" style="margin-bottom:6px">Only sites within reach of a place with at least this many residents. Times are estimates from straight-line distance.</div>
  <div class="three"><label class="field"><span>Place has at least</span><input type="number" id="sr_np" step="10000" value="${c.near_pop ?? ""}" placeholder="200000"></label><label class="field"><span>Within (minutes)</span><input type="number" id="sr_nm" value="${c.near_min ?? ""}" placeholder="13"></label><label class="field"><span>By</span>${ssel("sr_nmode", [["drive", "Car"], ["cycle", "Cycle"], ["walk", "Walking"]], c.near_mode || "drive")}</label></div>
  <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap"><button class="btn primary" data-act="srrun" ${SR.run?.running ? "disabled" : ""}>Search</button><button class="btn" data-act="srsave" data-k="area">Save search</button><button class="btn" data-act="srpreset">Within 13 minutes of a city of 200,000</button><button class="btn" data-act="srmandate" title="Uses the sizes, exclusions and planning tolerance in your investor profile">Start from my mandate</button></div>${SR.mand?.regions?.length ? `<div class="tsub" style="margin-top:8px">Your mandate regions: ${SR.mand.regions.map(r => `<a href="#" data-act="srregion" data-i="${SR.mand.regions.indexOf(r)}">${esc(r.region)} (${esc(r.town)})</a>`).join(", ")}</div>` : ""}${savedList("area")}`;
}
function readArea() {
  const c = { ...SR.c };
  c.place = $("#sr_place").value.trim(); c.radius_km = toNum("sr_rad") || 5; c.min_ha = toNum("sr_minha"); c.max_ha = toNum("sr_maxha"); c.min_units = toNum("sr_minu"); c.max_units = toNum("sr_maxu");
  c.consented = $("#sr_cons").value; c.years = +$("#sr_years").value; c.brownfield_only = $("#sr_bf").checked; c.near_pop = toNum("sr_np"); c.near_min = toNum("sr_nm"); c.near_mode = $("#sr_nmode").value;
  c.sources = $$('[data-sr="sources"]:checked').map(x => x.value); c.exclude = $$('[data-sr="exclude"]:checked').map(x => x.value);
  SR.c = c; lsSet("ed_srcrit", c); return c;
}
function scrCell(x) {
  if (!x) return '<span class="tsub">not screened</span>';
  if (!x.ok) return `<span class="tsub" title="${esc(x.error || "")}">n/a</span>`;
  const big = x.rlv_per_ha != null ? `£${(x.rlv_per_ha / 1e6).toFixed(2)}m per ha` : `£${Math.round(x.rlv_per_home / 1e3)}k per home`;
  return `<b class="${x.viable ? "" : "neg"}">${x.viable ? big : "Does not stack up"}</b><div class="tsub">${x.viable ? money(x.rlv) + " in total" : "even at nil land cost"}</div>${x.allowances.length ? `<div class="tsub">Allowances: ${x.allowances.map(esc).join(", ")}</div>` : ""}${x.fit ? `<div><span class="chip ${x.fit.hard_fail ? "hi" : x.fit.score >= 85 ? "ok" : "med"}">${esc(x.fit.label)}</span>${x.fit.fails.length ? `<span class="tsub"> ${esc(x.fit.fails.join(", "))}</span>` : ""}</div>` : ""}${x.concentration?.text ? `<div class="tsub">${esc(x.concentration.text)}</div>` : ""}`;
}
function areaOut() {
  const r = SR.res, j = SR.run;
  if (j?.running) return `<div class="card pad"><b>${esc(j.step || "Working")}</b><div class="bar" style="margin-top:10px"><i style="width:${j.total ? Math.min(100, j.done / j.total * 100) : 5}%"></i></div><div class="tsub" style="margin-top:8px">Constraint layers are read once for the whole area, then every candidate is tested against them.</div></div>`;
  if (SR.msg) return `<div class="card pad"><div class="notice">${esc(SR.msg)}</div></div>`;
  if (!r) return `<div class="card pad empty">Set a centre and criteria, then press Search.<div class="tsub" style="margin-top:8px">Data comes from planning.data.gov.uk and PlanIt when the app is online.</div></div>`;
  const S = SR.scr || {}, hasS = Object.keys(S).length > 0, rlvOf = c => S[c.id]?.ok ? (S[c.id].rlv_per_ha ?? S[c.id].rlv_per_home ?? 0) : -1;
  const rows = [...r.candidates].sort((a, b) => SR.sort === "score" ? b.score - a.score : SR.sort === "rlv" ? rlvOf(b) - rlvOf(a) : SR.sort === "dist" ? a.distance_km - b.distance_km : SR.sort === "ha" ? (b.ha || 0) - (a.ha || 0) : (b.units || 0) - (a.units || 0));
  const sr = SR.scrRun;
  return `<div class="card"><div class="h"><h3>${r.count} candidate${r.count === 1 ? "" : "s"}</h3><span class="m">from ${r.considered} found · sort ${ssel("sr_sort", [["score", "score"], ...(hasS ? [["rlv", "residual value"]] : []), ["dist", "distance"], ["ha", "area"], ["units", "homes"]], SR.sort)}</span></div>
   ${r.notes.length ? `<div class="notice" style="margin:0 16px 10px">${r.notes.map(esc).join("<br>")}</div>` : ""}
   <div class="map" id="srmap" style="height:260px;margin:0 16px 12px"></div>
   <div class="tablewrap" style="max-height:60vh"><table><thead><tr><th><input type="checkbox" id="sr_all"></th><th class="num">Score</th><th>Site</th><th class="num">Ha</th><th class="num">Homes</th><th class="num">km</th>${hasS ? '<th class="num" style="min-width:210px">Residual land value</th>' : ""}<th>Source</th><th>Screening</th></tr></thead><tbody>
   ${rows.map(c => `<tr data-c="${esc(c.id)}"><td><input type="checkbox" data-srsel="${esc(c.id)}" ${SR.sel.has(c.id) ? "checked" : ""}></td><td class="num"><span class="chip ${c.score >= 70 ? "ok" : c.score >= 50 ? "med" : "hi"}">${c.score}</span></td>
     <td><b>${esc(c.name)}</b><div class="tsub">${esc(c.address || "")}${c.status ? " · " + esc(c.status) : ""}</div><details><summary class="tsub" style="cursor:pointer">Why this score</summary><ul class="why">${c.why.map(w => `<li>${esc(w)}</li>`).join("")}</ul>${c.notes ? `<div class="tsub">${esc(c.notes)}</div>` : ""}</details></td>
     <td class="num">${c.ha ? c.ha.toFixed(2) : "n/a"}</td><td class="num">${c.units ?? "n/a"}</td><td class="num">${c.distance_km.toFixed(1)}</td>${hasS ? `<td class="num">${scrCell(S[c.id])}</td>` : ""}<td>${(c.sources || []).map(esc).join(", ")}${c.url ? ` <a href="${esc(c.url)}" target="_blank" rel="noopener" class="tsub">source</a>` : ""}</td>
     <td>${c.constraint_labels.map(l => `<span class="chip hi">${esc(l)}</span>`).join(" ") || '<span class="chip ok">No constraints found</span>'}${c.place ? ` <span class="chip acc">${c.place.minutes} min to ${esc(c.place.name)}</span>` : ""}</td></tr>`).join("")}</tbody></table></div>
   ${sr?.running ? `<div style="padding:0 16px 10px"><b>Screening ${sr.done} of ${sr.total}</b><div class="bar" style="margin-top:6px"><i style="width:${sr.total ? sr.done / sr.total * 100 : 5}%"></i></div></div>` : ""}
   ${hasS ? `<div class="tsub" style="padding:0 16px 8px">Residual value is what a developer could pay for the land and still make the target profit, after allowances for the constraints found. It uses council-wide average prices and a default mix, so use it to rank sites, then open one for a proper appraisal. ${esc(Object.values(S).find(x => x.ok)?.basis || "")}</div>` : ""}
   <div style="padding:12px 16px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button class="btn ${hasS ? "" : "primary"}" data-act="srscreen" ${sr?.running ? "disabled" : ""}>${hasS ? "Screen again" : "Screen the top 25 for viability"}</button>${hasS ? `<button class="btn" data-act="sraddviable">Add all viable</button>` : ""}<button class="btn primary" data-act="sradd">Add ${SR.sel.size || "selected"} to sites</button><button class="btn" data-act="sraddtop">Add all scoring 70 or more</button><button class="btn" data-act="srcsv">Export CSV</button><span class="tsub">Added sites start at Sourced with the constraint flags set. Open one and run its Data tab for the full check.</span></div></div>`;
}
function paintSrMap() {
  const el = $("#srmap"); if (!el || !SR.res) return; if (mapInst) { mapInst.destroy(); mapInst = null; }
  const pins = SR.res.candidates.map(c => ({ id: c.id, lat: c.lat, lon: c.lon, g: c.score >= 70 ? "A" : c.score >= 50 ? "B" : "C", label: c.score, name: c.name, score: c.score, src: (c.sources || []).join(", ") }));
  mapInst = makeMap(el, pins, id => { const row = $(`tr[data-c="${id}"]`); row?.scrollIntoView({ block: "center" }); row?.classList.add("sel"); });
  mapInst.setTheme(document.documentElement.dataset.theme === "dark");
}
function placesForm() {
  const p = SR.p;
  return `<h3 style="margin-bottom:4px">Search places by demographics</h3><div class="tsub" style="margin-bottom:12px">Find the towns, and the zones around cities, that meet a population and travel-time test. ${SR.info ? `List: ${esc(SR.info.source)}, ${SR.info.count} places.` : ""}</div>
  <div class="lbl">Access to a city</div><div class="three"><label class="field"><span>City has at least</span><input type="number" id="pr_cp" step="10000" value="${p.city_min_pop ?? ""}"></label><label class="field"><span>Within (minutes)</span><input type="number" id="pr_cm" value="${p.city_max_min ?? ""}"></label><label class="field"><span>No closer than (minutes)</span><input type="number" id="pr_cmin" value="${p.city_min_min ?? ""}" placeholder="0"></label></div>
  <div class="three" style="margin-top:8px"><label class="field"><span>By</span>${ssel("pr_mode", [["drive", "Car"], ["cycle", "Cycle"], ["walk", "Walking"]], p.mode || "drive")}</label></div>
  <div class="lbl">The place itself</div><div class="three"><label class="field"><span>Population, min</span><input type="number" id="pr_min" step="5000" value="${p.min_pop ?? ""}"></label><label class="field"><span>Population, max</span><input type="number" id="pr_max" step="5000" value="${p.max_pop ?? ""}"></label><label class="field"><span>Type</span>${ssel("pr_kind", [["any", "Any"], ["city", "Cities"], ["town", "Towns"]], p.kind || "any")}</label></div>
  <div class="lbl">Limit to an area (optional)</div><div class="three"><label class="field" style="grid-column:span 2"><span>Centre: postcode or town</span><input type="text" id="pr_place" value="${esc(p.place || "")}"></label><label class="field"><span>Radius (km)</span><input type="number" id="pr_rad" value="${p.radius_km ?? ""}"></label></div>
  <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap"><button class="btn primary" data-act="prrun">Search places</button><button class="btn" data-act="srsave" data-k="places">Save search</button></div>${savedList("places")}
  <details style="margin-top:14px"><summary class="tsub" style="cursor:pointer">Place list and population data</summary><div class="tsub" style="margin:8px 0">Populations are rounded, order of magnitude Census 2021. To use your own figures, paste a CSV with the columns name, lat, lon, population, kind.</div><textarea id="pr_csv" style="min-height:80px" placeholder="name,lat,lon,population,kind"></textarea><div style="display:flex;gap:8px;margin-top:6px"><button class="btn sm" data-act="prcsv">Use this list</button><button class="btn sm" data-act="prreset">Back to built-in list</button></div></details>`;
}
function readPlaces() {
  const p = { city_min_pop: toNum("pr_cp"), city_max_min: toNum("pr_cm"), city_min_min: toNum("pr_cmin"), mode: $("#pr_mode").value, min_pop: toNum("pr_min"), max_pop: toNum("pr_max"), kind: $("#pr_kind").value, place: $("#pr_place").value.trim(), radius_km: toNum("pr_rad") };
  SR.p = p; lsSet("ed_prcrit", p); return p;
}
const MODEW = { drive: "by car", cycle: "by bike", walk: "on foot" };
function placesOut() {
  const r = SR.pl; if (!r) return `<div class="card pad empty">For example: towns within 13 minutes by car of a city of 200,000 or more.<div class="tsub" style="margin-top:8px">A city zone shows how far that time reaches, and lets you search for sites inside it.</div></div>`;
  const p = SR.p;
  return `${r.zones.length ? `<div class="card" style="margin-bottom:14px"><div class="h"><h3>City zones</h3><span class="m">${r.zones.length} cities of ${pop(p.city_min_pop || 0)}+ · ${p.city_max_min} min ${MODEW[p.mode]} is about ${r.zones[0].radius_km} km</span></div><div class="tablewrap" style="max-height:34vh"><table><thead><tr><th>City</th><th class="num">Residents</th><th class="num">Reach (km)</th><th></th></tr></thead><tbody>
    ${r.zones.map((z, i) => `<tr><td><b>${esc(z.name)}</b></td><td class="num">${pop(z.population)}</td><td class="num">${z.min_radius_km ? z.min_radius_km + " to " : ""}${z.radius_km}</td><td style="text-align:right"><button class="btn sm" data-act="przone" data-i="${i}">Search sites in this zone</button></td></tr>`).join("")}</tbody></table></div></div>` : ""}
   <div class="card"><div class="h"><h3>${r.count} matching place${r.count === 1 ? "" : "s"}</h3><span class="m">${esc(r.note)}</span></div>${r.count ? `<div class="tablewrap" style="max-height:44vh"><table><thead><tr><th>Place</th><th>Type</th><th class="num">Residents</th><th>Nearest qualifying city</th><th class="num">Est. minutes</th><th></th></tr></thead><tbody>
    ${r.places.map((x, i) => `<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.kind)}</td><td class="num">${pop(x.population)}</td><td>${x.anchor ? `${esc(x.anchor.name)} (${pop(x.anchor.population)})` : ""}</td><td class="num">${x.anchor ? x.anchor.minutes : ""}</td><td style="text-align:right"><button class="btn sm" data-act="prsites" data-i="${i}">Search sites here</button></td></tr>`).join("")}</tbody></table></div>` : `<div class="empty">No places match. Loosen the times or populations, or widen the area.</div>`}</div>`;
}
function bindSearch() {
  $("#sr_sort")?.addEventListener("change", e => { SR.sort = e.target.value; $("#srout").innerHTML = areaOut(); bindSearch(); paintSrMap(); });
  $("#sr_all")?.addEventListener("change", e => { $$("[data-srsel]").forEach(c => { c.checked = e.target.checked; e.target.checked ? SR.sel.add(c.dataset.srsel) : SR.sel.delete(c.dataset.srsel); }); const b = $('[data-act="sradd"]'); if (b) b.textContent = `Add ${SR.sel.size || "selected"} to sites`; });
  $$("[data-srsel]").forEach(c => c.onchange = () => { c.checked ? SR.sel.add(c.dataset.srsel) : SR.sel.delete(c.dataset.srsel); const b = $('[data-act="sradd"]'); if (b) b.textContent = `Add ${SR.sel.size || "selected"} to sites`; });
}
async function pollScreen() {
  try { const s = await api("/api/search/screen/status"); SR.scrRun = s.running ? s : null; if (s.error) toast(s.error); SR.scr = Object.keys(s.results).length ? s.results : SR.scr; if (!s.running && SR.scr) SR.sort = "rlv"; } catch (e) { SR.scrRun = null; toast(e.message); }
  if (view !== "search" || SR.mode !== "area") return;
  const out = $("#srout"); if (out) { out.innerHTML = areaOut(); bindSearch(); }
  if (SR.scrRun) setTimeout(pollScreen, 1200); else paintSrMap();
}
async function pollSearch() {
  try { const s = await api("/api/search/status"); SR.run = s; if (s.error) { SR.msg = s.error; SR.run = null; } else if (!s.running) { SR.res = s.result; SR.run = null; SR.sel = new Set(); if (SR.res && !SR.res.count) SR.msg = "No candidates matched. Loosen the criteria or widen the radius."; else SR.msg = ""; } } catch (e) { SR.msg = e.message; SR.run = null; }
  if (view !== "search" || SR.mode !== "area") return;
  const out = $("#srout"); if (out) { out.innerHTML = areaOut(); bindSearch(); }
  if (SR.run) setTimeout(pollSearch, 1500); else { paintSrMap(); const b = $('[data-act="srrun"]'); if (b) b.disabled = false; }
}
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t) return; const act = t.dataset.act;
  try {
    if (act === "srmode") { SR.mode = t.dataset.v; lsSet("ed_srmode", SR.mode); vSearch(); }
    else if (act === "srpreset") { SR.c = { ...readArea(), near_pop: 200000, near_min: 13, near_mode: "drive" }; lsSet("ed_srcrit", SR.c); vSearch(); }
    else if (act === "srrun") {
      const c = readArea(); if (!c.place && c.lat == null) { toast("Enter a postcode or town, or set the centre on the map"); return; } if (!c.place) delete c.place;
      const body = { ...c };
      SR.msg = ""; SR.res = null; SR.scr = null; SR.run = { running: true, step: "Starting" };
      const r = await api("/api/search/start", body); if (!r.started) { toast("A search is already running"); return; }
      SR.c.lat = r.lat; SR.c.lon = r.lon; $("#srout").innerHTML = areaOut(); pollSearch();
    }
    else if (act === "srscreen") {
      const r = await api("/api/search/screen", { strategy: SR.mand?.strategy || "develop_sell", limit: 25 }); if (!r.started) { toast("A screen is already running"); return; }
      SR.scr = null; SR.scrRun = { running: true, done: 0, total: 25 }; $("#srout").innerHTML = areaOut(); bindSearch(); pollScreen();
    }
    else if (act === "sraddviable") { const ids = SR.res.candidates.filter(c => SR.scr?.[c.id]?.viable).map(c => c.id); if (!ids.length) { toast("No screened site is viable"); return; } const r = await api("/api/search/add", { ids }); toast(`${r.added.length} viable site${r.added.length === 1 ? "" : "s"} added`); await load(false); vSearch(); }
    else if (act === "srmandate") { const m = await api("/api/search/mandate", {}); SR.mand = m; SR.c = { ...readArea(), ...m.criteria }; lsSet("ed_srcrit", SR.c); vSearch(); toast("Criteria set from your investor profile"); }
    else if (act === "srregion") { e.preventDefault(); const r = SR.mand.regions[+t.dataset.i]; SR.c = { ...readArea(), place: r.town, lat: r.lat, lon: r.lon }; lsSet("ed_srcrit", SR.c); vSearch(); }
    else if (act === "sradd" || act === "sraddtop") {
      const ids = act === "sraddtop" ? SR.res.candidates.filter(c => c.score >= 70).map(c => c.id) : [...SR.sel]; if (!ids.length) { toast(act === "sradd" ? "Tick the sites to add" : "No candidate scores 70 or more"); return; }
      const r = await api("/api/search/add", { ids }); toast(`${r.added.length} site${r.added.length === 1 ? "" : "s"} added${r.added.length < ids.length ? ` (${ids.length - r.added.length} already on file)` : ""}`); await load(false); vSearch();
    }
    else if (act === "srcsv") csvOut("easyDevelopment_search.csv", [["Score", "Name", "Address", "Hectares", "Homes", "Distance km", "Sources", "Status", "Constraints", "Latitude", "Longitude", "Why"], ...SR.res.candidates.map(c => [c.score, c.name, c.address, c.ha ?? "", c.units ?? "", c.distance_km, (c.sources || []).join("; "), c.status, c.constraint_labels.join("; "), c.lat, c.lon, c.why.join("; ")])]);
    else if (act === "srsave") { const crit = t.dataset.k === "area" ? readArea() : readPlaces(); const name = prompt("Name this search", t.dataset.k === "area" ? "Sites near " + (crit.place || "centre") : "Places search"); if (!name) return; SR.saved = (await api("/api/searches/save", { name, kind: t.dataset.k, criteria: crit })).items; vSearch(); }
    else if (act === "srload") { const s = SR.saved.find(x => x.id === t.dataset.id); if (!s) return; if (s.kind === "area") { SR.c = s.criteria; SR.mode = "area"; } else { SR.p = s.criteria; SR.mode = "places"; } vSearch(); }
    else if (act === "srdel") { SR.saved = (await api("/api/searches/delete", { id: t.dataset.id })).items; vSearch(); }
    else if (act === "prrun") { const p = readPlaces(); if (p.place) { const g = await api("/api/search/geocode", { place: p.place }); p.lat = g.lat; p.lon = g.lon; } SR.pl = await api("/api/places/search", p); $("#srout").innerHTML = placesOut(); }
    else if (act === "prcsv") { const r = await api("/api/places/import", { text: $("#pr_csv").value }); toast(`${r.count} places loaded`); SR.info = null; vSearch(); }
    else if (act === "prreset") { await api("/api/places/reset", {}); SR.info = null; toast("Built-in list restored"); vSearch(); }
    else if (act === "przone" || act === "prsites") {
      const p = SR.p, it = act === "przone" ? SR.pl.zones[+t.dataset.i] : SR.pl.places[+t.dataset.i];
      SR.c = { ...SR.c, place: it.name, place_name: it.name, lat: it.lat, lon: it.lon, radius_km: act === "przone" ? it.radius_km : 3, near_pop: p.city_min_pop || null, near_min: p.city_max_min || null, near_min_min: p.city_min_min || null, near_mode: p.mode };
      SR.mode = "area"; lsSet("ed_srmode", "area"); lsSet("ed_srcrit", SR.c); SR.res = null; vSearch();
    }
  } catch (err) { toast(err.message); }
});

/* ================= data sources ================= */
const DS = { d: null, hq: "", hres: null, hby: "postcode", msg: "", layers: {}, busy: {} };
const KIND = { live: ["ok", "Live"], key: ["acc", "Needs key or file"], upload: ["acc", "Import"], discover: ["med", "Choose layers"], link: ["lo", "Link"] };
async function loadData() { DS.d = await api("/api/data/state"); }
async function vData() {
  if (!DS.d) { $("#view").innerHTML = '<div class="empty">Loading</div>'; try { await loadData(); } catch (e) { $("#view").innerHTML = `<div class="empty">${esc(e.message)}</div>`; return; } }
  const d = DS.d, on = d.sources.filter(s => s.on).length, tested = d.sources.filter(s => s.tested?.ok).length, h = d.hmlr, cfg = d.settings;
  $("#view").innerHTML = `<div class="stat4">${kpi("Sources switched on", on, `of ${d.sources.length}`)}${kpi("Datasets on planning.data.gov.uk", d.platform.ok ? d.platform.count : "not read", d.platform.ok ? "checked " + (d.platform.when || "").slice(0, 10) : esc(d.platform.error || "press Refresh list"))}${kpi("Passed a live test", tested, "in this app")}${kpi("Titles loaded (CCOD and OCOD)", h.rows ? h.rows.toLocaleString("en-GB") : "none", h.datasets.map(x => x.dataset.toUpperCase() + " " + (x.loaded || "").slice(0, 10)).join(", ") || "load a file or use your key")}</div>
  ${d.groups.map(g => dataGroup(g)).join("")}
  <div class="two" style="margin-top:16px;align-items:start">${pdgCard()}<div>${layersCard()}${credsCard()}</div></div>
  ${ownerCard()}`;
  bindData();
}
function dataGroup(g) {
  const xs = DS.d.sources.filter(s => s.group === g); if (!xs.length) return "";
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>${esc(g)}</h3><span class="m">${xs.length} sources</span></div><div class="tablewrap" style="max-height:none"><table><thead><tr><th>Source</th><th>Access</th><th>Status</th><th>Licence</th><th style="width:1%">On</th><th></th></tr></thead><tbody>
  ${xs.map(s => { const k = KIND[s.kind] || KIND.link, t = s.tested; return `<tr style="cursor:default"><td><b>${esc(s.name)}</b><div class="tsub">${esc(s.publisher)}. ${esc(s.note)}</div>${s.has_wms ? wmsPicker(s) : ""}</td><td><span class="chip ${k[0]}">${k[1]}</span></td>
   <td>${t ? `<span class="chip ${t.ok === true ? "ok" : t.ok === false ? "hi" : "lo"}">${t.ok === true ? "Passed" : t.ok === false ? "Failed" : "Not set"}</span><div class="tsub">${esc(t.detail || "")}${t.when ? " · " + when(t.when) : ""}</div>` : s.testable ? '<span class="chip lo">Untested</span>' : '<span class="tsub">Reference</span>'}</td>
   <td class="tsub">${esc(s.licence)}</td><td><button class="switch ${s.on ? "on" : ""}" data-act="dsw" data-id="${s.id}" title="Include in site checks"></button></td>
   <td style="white-space:nowrap">${s.testable ? `<button class="btn sm" data-act="dtest" data-id="${s.testable && s.test ? s.test : s.id}" ${DS.busy[s.id] ? "disabled" : ""}>${DS.busy[s.id] ? "Testing" : "Test"}</button> ` : ""}${s.url ? `<button class="btn sm" data-act="dopen" data-u="${esc(s.url)}">Open</button>` : ""}</td></tr>`; }).join("")}</tbody></table></div></div>`;
}
function wmsPicker(s) {
  const L = DS.layers[s.id], c = s.wms_cfg || {};
  return `<div style="margin-top:6px;display:flex;gap:6px;align-items:center;flex-wrap:wrap">${c.layer ? `<span class="chip acc">Layer: ${esc(c.layer)}</span>` : ""}<button class="btn sm" data-act="wmslist" data-id="${s.id}">List layers</button>${L ? `<select id="wms_${s.id}" style="max-width:340px">${L.map(l => `<option value="${esc(l.name)}" ${c.layer === l.name ? "selected" : ""}>${esc(l.title)}</option>`).join("")}</select><button class="btn sm" data-act="wmsuse" data-id="${s.id}">Use this layer</button>` : ""}</div>`;
}
function pdgCard() {
  const d = DS.d, pl = d.platform;
  return `<div class="card"><div class="h"><h3>planning.data.gov.uk datasets</h3><button class="btn sm" data-act="dpdgrefresh">Refresh list</button></div><div class="tsub" style="padding:0 16px 8px">Use the connection-test icon in the top bar to check every live connection at once (this list included). Each dataset here is checked at every site. ${pl.ok ? `The platform currently publishes ${pl.count} datasets; those in this list that it does not publish are skipped.` : `The platform list could not be read (${esc(pl.error || "not yet fetched")}), so every dataset here is attempted.`}</div>
   <div class="tablewrap" style="max-height:46vh"><table><thead><tr><th>Dataset</th><th>Group</th><th>Platform</th><th style="width:1%">On</th></tr></thead><tbody>${d.pdg.map(x => `<tr style="cursor:default"><td>${esc(x.label)}<div class="tsub">${esc(x.id)}</div></td><td class="tsub">${esc(x.group)}</td><td>${x.published === null ? '<span class="chip lo">Unknown</span>' : x.published ? '<span class="chip ok">Published</span>' : '<span class="chip hi">Not found</span>'}</td><td><button class="switch ${x.on ? "on" : ""}" data-act="dpdg" data-id="${x.id}"></button></td></tr>`).join("")}</tbody></table></div>
   <div style="padding:12px 16px"><div class="lbl" style="margin-top:0">Add any other dataset from the platform</div><div style="display:flex;gap:8px"><input type="text" id="d_extra" list="d_extra_l" placeholder="e.g. local-nature-reserve" style="flex:1"><datalist id="d_extra_l">${pl.other.map(o => `<option value="${esc(o.id)}">${esc(o.name)}</option>`).join("")}</datalist><button class="btn" data-act="dextra">Add</button></div>
   ${d.extra_pdg.length ? `<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">${d.extra_pdg.map(x => `<span class="chip acc">${esc(x)} <a data-act="dextrarm" data-id="${esc(x)}" style="cursor:pointer;margin-left:4px">${I.x.replace("<svg", '<svg style="width:12px;height:12px"')}</a></span>`).join("")}</div>` : ""}</div></div>`;
}
function layersCard() {
  const L = DS.d.layers;
  return `<div class="card" style="margin-bottom:16px"><div class="h"><h3>Your own map layers</h3></div><div class="tsub" style="padding:0 16px 8px">Any ArcGIS FeatureServer layer, WMS or WFS service can be checked at every site. Find URLs on a publisher's open data page, for example Natural England, the Environment Agency or a council.</div>
  ${L.length ? `<div class="list">${L.map((l, i) => `<div class="row" style="cursor:default"><div class="grow"><div class="t">${esc(l.name)}</div><div class="m">${esc(l.type.toUpperCase())} · ${esc(l.group || "")} · ${esc(l.url)}${l.layer ? " · " + esc(l.layer) : ""}</div></div><button class="switch ${l.on !== false ? "on" : ""}" data-act="dlayeron" data-i="${i}"></button><button class="ghost" data-act="dlayerrm" data-i="${i}">${I.x}</button></div>`).join("")}</div>` : ""}
  <div style="padding:12px 16px"><div class="three"><label class="field"><span>Name</span><input type="text" id="ly_name"></label><label class="field"><span>Type</span>${ssel("ly_type", [["arcgis", "ArcGIS layer"], ["wms", "WMS"], ["wfs", "WFS"]], "arcgis")}</label><label class="field"><span>Group</span>${ssel("ly_group", DS.d.groups.map(g => [g, g]), DS.d.groups[1])}</label></div>
   <label class="field" style="margin-top:8px"><span>Service URL</span><input type="text" id="ly_url" placeholder="https://.../FeatureServer/0"></label><div class="three" style="margin-top:8px"><label class="field"><span>Layer name (WMS or WFS)</span><input type="text" id="ly_layer"></label><label class="field"><span>Field to show (optional)</span><input type="text" id="ly_field"></label><label class="field"><span>Effect on search score</span>${ssel("ly_w", [[0, "None"], [-1, "Minor constraint"], [-3, "Major constraint"]], 0)}</label></div>
   <div style="display:flex;gap:8px;margin-top:10px"><button class="btn" data-act="dlayertest">Test at central London</button><button class="btn primary" data-act="dlayeradd">Add layer</button></div></div></div>`;
}
function credsCard() {
  const s = DS.d.settings, ta = s.title_api;
  return `<div class="card"><div class="h"><h3>Credentials and providers</h3></div><div style="padding:0 16px 16px"><div class="tsub" style="margin-bottom:10px">Keys are stored in your profile on this installation and are never shown again.</div>
   <div class="two"><label class="field"><span>HM Land Registry API key ${s.has_hmlr_key ? '<span class="chip ok">saved</span>' : ""}</span><input type="password" id="k_hmlr" placeholder="${s.has_hmlr_key ? "unchanged" : "from Use land and property data"}"></label><label class="field"><span>Companies House API key ${s.has_ch_key ? '<span class="chip ok">saved</span>' : ""}</span><input type="password" id="k_ch" placeholder="${s.has_ch_key ? "unchanged" : "free from Companies House"}"></label></div>
   <label class="field" style="margin-top:8px"><span>Contact email for PlanIt (sent in the request header, as its terms ask)</span><input type="text" id="k_planit" value="${esc(s.planit_contact)}"></label>
   <details style="margin-top:12px"><summary class="tsub" style="cursor:pointer">Paid title data provider (your own account)</summary><div class="tsub" style="margin:8px 0">Enter the request URL your provider documents, using {title}, {postcode} or {address} where they belong, the header that carries your key, and the dotted path to the owner name in the JSON reply, for example data.0.owner. Nothing is assumed about any vendor.</div>
   <label class="field"><span>Request URL</span><input type="text" id="t_url" value="${esc(ta.url || "")}"></label><div class="three" style="margin-top:8px"><label class="field"><span>Header name</span><input type="text" id="t_hdr" value="${esc(ta.header || "Authorization")}"></label><label class="field"><span>Key ${ta.has_key ? '<span class="chip ok">saved</span>' : ""}</span><input type="password" id="t_key"></label><label class="field"><span>Owner field path</span><input type="text" id="t_own" value="${esc(ta.owner_path || "")}"></label></div></details>
   <div style="margin-top:12px"><button class="btn primary" data-act="dcreds">Save</button></div></div></div>`;
}
function ownerCard() {
  const h = DS.d.hmlr, st = h.status || {};
  return `<div class="card" style="margin-top:16px"><div class="h"><h3>Land ownership</h3><span class="m">${h.rows ? h.rows.toLocaleString("en-GB") + " company-owned titles indexed" : "no data loaded"}</span></div><div style="padding:0 16px 16px">
   <div class="tsub" style="margin-bottom:10px">HM Land Registry publishes every title held by a UK company (CCOD) or an overseas company (OCOD) free each month. Load it once and every site check, and this search, uses it. Owner names for individuals are only in the paid official copy of the register, imported from a site's Data tab.</div>
   ${h.diff ? `<div class="tsub" style="margin-bottom:10px">Last reload (${esc(h.diff.dataset.toUpperCase())}, ${esc(h.diff.loaded.slice(0, 10))}) compared with the file it replaced: ${h.diff.added.toLocaleString("en-GB")} titles added or changed hands, ${h.diff.removed.toLocaleString("en-GB")} removed, ${h.diff.watched} changes at your shortlisted sites. Reload each month and shortlisted sites are told about changes at their postcodes.</div>` : ""}
   ${st.running ? `<div class="notice">Loading ${esc((st.dataset || "").toUpperCase())}: ${(st.rows || 0).toLocaleString("en-GB")} rows. ${esc(st.message || "")}</div>` : st.error ? `<div class="notice" style="background:color-mix(in srgb,var(--hi) 12%,transparent)">${esc(st.error)}</div>` : ""}
   <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><button class="btn primary" data-act="hapi" ${DS.d.settings.has_hmlr_key ? "" : "disabled"} title="${DS.d.settings.has_hmlr_key ? "" : "Add your API key above"}">Download CCOD and OCOD with my key</button><label class="btn">Upload a file<input type="file" id="h_file" accept=".csv,.zip" hidden></label><input type="text" id="h_path" placeholder="or a file path on this computer" style="width:260px"><button class="btn" data-act="hpath">Load</button></div>
   <div class="lbl">Search owners</div><div style="display:flex;gap:8px;flex-wrap:wrap"><input type="text" id="h_q" value="${esc(DS.hq)}" placeholder="Company name, postcode, title number or company number" style="flex:1;min-width:260px">${ssel("h_by", [["proprietor", "Owner name"], ["postcode", "Postcode"], ["outward", "Postcode district"], ["title", "Title number"], ["company", "Company number"]], DS.hby)}<button class="btn primary" data-act="hsearch">Search</button></div>
   ${DS.msg ? `<div class="notice" style="margin-top:10px">${esc(DS.msg)}</div>` : ""}${DS.hres ? ownerRows(DS.hres) : ""}</div></div>`;
}
function ownerRows(rows) {
  if (!rows.length) return '<div class="empty">No titles found.</div>';
  return `<div class="tablewrap" style="max-height:46vh;margin-top:10px"><table><thead><tr><th>Title</th><th>Owner</th><th>Address</th><th>Tenure</th><th class="num">Price paid</th><th>Registered</th><th></th></tr></thead><tbody>${rows.slice(0, 200).map(r => `<tr style="cursor:default"><td>${esc(r.title)}</td><td><b>${esc(r.proprietor)}</b><div class="tsub">${esc(r.category || "")}${r.company_no ? " · " + esc(r.company_no) : ""}${r.country ? " · " + esc(r.country) : ""}</div></td><td>${esc(r.address)}<div class="tsub">${esc(r.postcode)}</div></td><td>${esc(r.tenure)}</td><td class="num">${r.price ? money(r.price) : ""}</td><td class="tsub">${esc(r.added || "")}</td>
   <td style="white-space:nowrap"><button class="btn sm" data-act="hport" data-n="${esc(r.proprietor)}">All their titles</button>${r.company_no ? ` <button class="btn sm" data-act="hch" data-n="${esc(r.company_no)}">Companies House</button>` : ""}</td></tr>`).join("")}</tbody></table></div>${rows.length > 200 ? `<div class="tsub" style="margin-top:6px">Showing 200 of ${rows.length}. Narrow the search.</div>` : ""}`;
}
function bindData() {
  $("#h_file")?.addEventListener("change", async e => { const f = e.target.files[0]; if (!f) return; DS.msg = `Reading ${f.name}. Large files take a minute.`; vData(); try { const r = await api("/api/hmlr/load", { kind: "upload", files: [await fileB64(f)] }); DS.msg = `${r.dataset.toUpperCase()} loaded: ${r.rows.toLocaleString("en-GB")} rows.`; await loadData(); } catch (err) { DS.msg = err.message; } vData(); });
}
async function dsave(patch, then) { DS.d = await api("/api/data/settings", patch); if (then) then(); vData(); }
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t) return; const act = t.dataset.act;
  if (!["dsw", "dtest", "dopen", "wmslist", "wmsuse", "dpdgrefresh", "dpdg", "dextra", "dextrarm", "dlayeron", "dlayerrm", "dlayertest", "dlayeradd", "dcreds", "hapi", "hpath", "hsearch", "hport", "hch"].includes(act)) return;
  const d = DS.d; const off = new Set(d?.sources.filter(s => !s.on).map(s => s.id));
  try {
    if (act === "dopen") openUrl(t.dataset.u);
    else if (act === "dsw" && d.sources.find(x => x.id === t.dataset.id).has_wms) { const s = d.sources.find(x => x.id === t.dataset.id), cur = s.wms_cfg || {}; if (!cur.layer) { toast("List the layers and choose one first"); return; } await dsave({ wms: wmsAll(s.id, { ...cur, on: !cur.on }) }); }
    else if (act === "dsw") { const s = d.sources.find(x => x.id === t.dataset.id); const offL = d.sources.filter(x => !x.on && x.id !== s.id).map(x => x.id); if (s.on) offL.push(s.id); await dsave({ off: offL }); }
    else if (act === "dtest") { const id = t.dataset.id; const src = d.sources.find(s => (s.test || s.id) === id); DS.busy[src.id] = 1; vData(); try { await api("/api/data/test", { id }); } finally { delete DS.busy[src.id]; } await loadData(); vData(); }
    else if (act === "wmslist") { t.disabled = true; try { DS.layers[t.dataset.id] = (await api("/api/data/wms_layers", { id: t.dataset.id })).layers; } finally { } vData(); }
    else if (act === "wmsuse") { const id = t.dataset.id, l = $("#wms_" + id).value, cur = d.sources.find(s => s.id === id).wms_cfg || {}; await dsave({ wms: wmsAll(id, { ...cur, layer: l, on: true, weight: -1 }) }); toast("Layer saved and switched on for site checks."); }
    else if (act === "dtestall") { t.disabled = true; t.textContent = "Testing..."; try { const r = await api("/api/data/testall", {}); const bad = Object.entries(r.results).filter(([, v]) => v.ok === false); toast(bad.length ? `${bad.length} connection${bad.length > 1 ? "s" : ""} failed: ${bad.map(x => x[0]).join(", ")}` : "Every live connection answered"); } finally { await loadData(); vData(); } }
    else if (act === "dpdgrefresh") { t.disabled = true; DS.d = await api("/api/data/discover", {}); vData(); }
    else if (act === "dpdg") { const o = d.pdg.filter(x => !x.on).map(x => x.id); const id = t.dataset.id; const i = o.indexOf(id); i >= 0 ? o.splice(i, 1) : o.push(id); await dsave({ off: [...off].filter(x => !d.pdg.some(p => p.id === x)).concat(o) }); }
    else if (act === "dextra") { const v = $("#d_extra").value.trim(); if (!v) return; await dsave({ extra_pdg: [...new Set([...d.extra_pdg, v])] }); }
    else if (act === "dextrarm") await dsave({ extra_pdg: d.extra_pdg.filter(x => x !== t.dataset.id) });
    else if (act === "dlayeron") { const L = d.layers.map((l, i) => i === +t.dataset.i ? { ...l, on: l.on === false } : l); await dsave({ layers: L }); }
    else if (act === "dlayerrm") await dsave({ layers: d.layers.filter((_, i) => i !== +t.dataset.i) });
    else if (act === "dlayeradd" || act === "dlayertest") {
      const l = { name: $("#ly_name").value.trim(), type: $("#ly_type").value, group: $("#ly_group").value, url: $("#ly_url").value.trim(), layer: $("#ly_layer").value.trim(), field: $("#ly_field").value.trim(), weight: +$("#ly_w").value, on: true };
      if (!l.name || !l.url) { toast("Give the layer a name and a URL"); return; }
      if (act === "dlayertest") { const r = await api("/api/data/layer_test", { layer: l }); toast(r.status === "error" ? "Failed: " + r.detail : `Reachable. ${r.value}`); }
      else await dsave({ layers: [...d.layers, l] });
    }
    else if (act === "dcreds") {
      const p = { planit_contact: $("#k_planit").value.trim(), hmlr_key: $("#k_hmlr").value, ch_key: $("#k_ch").value, title_api: { url: $("#t_url").value.trim(), header: $("#t_hdr").value.trim() || "Authorization", owner_path: $("#t_own").value.trim(), key: $("#t_key").value } };
      await dsave(p, () => toast("Saved"));
    }
    else if (act === "hapi") { const r = await api("/api/hmlr/load", { kind: "api" }); DS.msg = r.started ? "Download started. Files are large, so this takes a few minutes." : "A load is already running."; pollHmlr(); vData(); }
    else if (act === "hpath") { const p = $("#h_path").value.trim(); if (!p) return; DS.msg = "Reading the file"; vData(); try { const r = await api("/api/hmlr/load", { kind: "path", path: p }); DS.msg = `${r.dataset.toUpperCase()} loaded: ${r.rows.toLocaleString("en-GB")} rows.`; await loadData(); } catch (err) { DS.msg = err.message; } vData(); }
    else if (act === "hsearch") { DS.hq = $("#h_q").value.trim(); DS.hby = $("#h_by").value; const r = await api("/api/hmlr/search", { q: DS.hq, by: DS.hby }); DS.msg = r.empty ? "No ownership data is loaded yet. Load CCOD or OCOD above." : ""; DS.hres = r.rows; vData(); }
    else if (act === "hport") { DS.hres = (await api("/api/hmlr/portfolio", { name: t.dataset.n })).rows; DS.msg = `All titles held by ${t.dataset.n}`; vData(); }
    else if (act === "hch") { const r = await api("/api/hmlr/company", { no: t.dataset.n }); modal(chModal(r)); }
  } catch (err) { toast(err.message); }
});
const wmsAll = (id, v) => { const w = {}; DS.d.sources.forEach(s => { if (s.wms_cfg) w[s.id] = s.wms_cfg; }); w[id] = v; return w; };
function chModal(c) {
  return `<h3>${esc(c.name || c.number)}</h3><div class="tsub" style="margin-bottom:10px">Company ${esc(c.number)} · ${esc(c.status || "")} · ${esc(c.type || "")}${c.created ? " · incorporated " + esc(c.created) : ""}</div>
   <div>${esc(c.office || "")}</div><div class="tsub" style="margin-top:6px">SIC: ${(c.sic || []).join(", ") || "not stated"}${c.accounts_overdue ? " · accounts overdue" : ""}</div>
   ${(c.charges || []).length ? `<table style="margin-top:12px"><thead><tr><th>Charge</th><th>Status</th><th>Created</th><th>Held by</th></tr></thead><tbody>${c.charges.map(x => `<tr style="cursor:default"><td>${esc(x.classification || "")}</td><td>${esc(x.status || "")}</td><td>${esc(x.created || "")}</td><td>${esc(x.entitled || "")}</td></tr>`).join("")}</tbody></table>` : `<div class="tsub" style="margin-top:12px">${c.has_charges ? "Charges could not be read." : "No registered charges."}</div>`}
   <div style="margin-top:14px;display:flex;gap:8px"><button class="btn" data-act="dopen" data-u="${esc(c.url)}">Open on Companies House</button><button class="btn" onclick="closeModal()">Close</button></div>`;
}
let hpT = null;
async function pollHmlr() { clearTimeout(hpT); try { const s = await api("/api/hmlr/status"); if (DS.d) DS.d.hmlr = s; if (s.status.running) { hpT = setTimeout(pollHmlr, 3000); } else { await loadData(); } } catch { } if (view === "data") vData(); }

/* ================= site data tab ================= */
const SD = { open: {} };
Object.assign(TITLES, {});
function tData() {
  const s = drawer.site, p = s.data_pack;
  if (s.lat == null) return `<div class="card pad empty">Add a postcode to this site so it can be located.<div class="tsub" style="margin-top:8px">Data checks need coordinates.</div></div>`;
  const stale = p && (Date.now() - new Date(p.checked)) > 14 * 864e5;
  const head = `<div class="card pad" style="margin-bottom:14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="grow"><b>${p ? `Checked ${when(p.checked)}` : "Not checked yet"}</b><div class="tsub">${p ? `${p.counts.datasets} planning datasets, live and market sources. ${p.counts.hit} constraints or findings, ${p.counts.error} sources unavailable.${stale ? " This check is over two weeks old." : ""}` : "Runs every data source you have switched on for this location."}</div></div><button class="btn primary" data-act="denrich">${p ? "Check again" : "Run data checks"}</button>${p?.title_area_ha ? `<button class="btn" data-act="dapplyha" title="Use the registered title area">Use ${p.title_area_ha} ha as site area</button>` : ""}</div>`;
  if (!p) return head + ownershipPanel(s);
  const groups = D.data_groups ||= ["Planning and policy", "Environment and risk", "Market and demographics", "Infrastructure and access", "Land and ownership"];
  const body = groups.map(g => { const xs = p.items.filter(x => x.group === g); if (!xs.length) return ""; return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>${esc(g)}</h3><span class="m">${xs.filter(x => x.status === "hit").length} findings</span></div><div class="tablewrap" style="max-height:none"><table><tbody>
    ${xs.map(x => `<tr style="cursor:default"><td style="width:26%"><b>${esc(x.label)}</b><div class="tsub">${esc(x.source)}</div></td><td style="width:12%"><span class="chip ${x.status === "hit" ? "hi" : x.status === "clear" ? "ok" : x.status === "error" ? "lo" : "acc"}">${x.status === "hit" ? "Found" : x.status === "clear" ? "Clear" : x.status === "error" ? "Unavailable" : "Info"}</span></td><td>${esc(x.value)}${x.detail ? `<div class="tsub">${esc(x.detail)}</div>` : ""}</td><td style="width:1%">${x.url ? `<button class="ghost" data-act="dopen" data-u="${esc(x.url)}">${I.link}</button>` : ""}</td></tr>`).join("")}</tbody></table></div></div>`; }).join("");
  const apps = (p.planit || []).length ? `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Nearby applications</h3><span class="m">PlanIt, within 800 m</span></div><div class="tablewrap" style="max-height:340px"><table><thead><tr><th>Reference</th><th>Address and proposal</th><th>Status</th><th>Submitted</th><th class="num">km</th></tr></thead><tbody>${p.planit.map(a => `<tr style="cursor:default"><td>${a.url ? `<a href="${esc(a.url)}" target="_blank" rel="noopener">${esc(a.ref)}</a>` : esc(a.ref)}</td><td><b>${esc(a.address)}</b><div class="tsub">${esc((a.description || "").slice(0, 160))}</div></td><td>${esc(a.state)}</td><td class="tsub">${esc(a.submitted)}</td><td class="num">${a.distance_km ?? ""}</td></tr>`).join("")}</tbody></table></div></div>` : "";
  const lk = `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Further checks</h3><span class="m">opened for this location</span></div><div class="list">${p.links.map(l => `<div class="row" data-act="dopen" data-u="${esc(l.url)}"><div class="grow"><div class="t">${esc(l.name)}</div><div class="m">${esc(l.note || "")}</div></div>${I.link}</div>`).join("")}</div></div>`;
  return head + (p.errors.length ? `<div class="notice" style="margin-bottom:14px">${p.errors.length} source${p.errors.length > 1 ? "s were" : " was"} unavailable: ${esc(p.errors.slice(0, 4).join("; "))}</div>` : "") + body + apps + ownershipPanel(s) + lk;
}
function ownershipPanel(s) {
  const r = s.title_register, ccod = (s.data_pack?.items || []).find(x => x.id === "ccod");
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Ownership and title</h3><span class="m">${r ? "official copy imported " + esc(r.imported) : "no register imported"}</span></div><div style="padding:0 16px 16px">
   ${r ? `<div class="two"><div><div class="lbl" style="margin-top:0">Title ${esc(r.title)}</div><div>${esc(r.tenure || "")}${r.class ? " · title " + esc(r.class.toLowerCase()) : ""}${r.price ? ` · ${money(r.price)} paid ${esc(r.price_date)}` : ""}</div><div class="tsub" style="margin-top:4px">${esc(r.address || "")}</div>
      <div class="lbl">Proprietors</div>${r.proprietors.map(p => `<div><b>${esc(p.name)}</b>${p.company_no ? ` <button class="btn sm" data-act="hch" data-n="${esc(p.company_no)}">Companies House</button>` : ""}<div class="tsub">${esc(p.address || "")}</div></div>`).join("") || '<div class="tsub">None read</div>'}</div>
     <div><div class="lbl" style="margin-top:0">Charges</div>${r.charges.map(c => `<div>${esc(c.chargee || "Chargee not read")} <span class="tsub">${esc(c.date)}</span></div>`).join("") || '<div class="tsub">No registered charges read</div>'}<div class="lbl">Restrictions and notices</div>${[...r.restrictions, ...r.notices].map(x => `<div class="tsub" style="margin-bottom:4px">${esc(x)}</div>`).join("") || '<div class="tsub">None read</div>'}<div class="lbl">Covenants</div>${r.covenants.map(x => `<div class="tsub" style="margin-bottom:4px">${esc(x)}</div>`).join("") || '<div class="tsub">None read</div>'}</div></div>` : ""}
   ${ccod?.titles?.length ? `<div class="lbl">Company-owned titles at this postcode (CCOD and OCOD)</div>${ccod.titles.slice(0, 8).map(t => `<div class="row" style="cursor:default;padding:4px 0"><span class="grow"><b>${esc(t.proprietor)}</b> <span class="tsub">${esc(t.title)} · ${esc(t.address)}</span></span></div>`).join("")}` : ccod ? `<div class="tsub" style="margin-top:6px">${esc(ccod.value)}.</div>` : ""}
   <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center"><label class="btn">Import official copy (PDF)<input type="file" id="oc1_file" accept=".pdf,.txt" hidden></label><button class="btn" data-act="doc1paste">Paste register text</button><button class="btn" data-act="dopen" data-u="https://www.gov.uk/get-information-about-property-and-land">Buy an official copy</button></div>
   <div class="tsub" style="margin-top:8px">The official copy costs £7 from HM Land Registry and is the only source of individual owners, charges and covenants. Importing it fills the vendor and adds the title as a parcel on the Landowners tab.</div></div></div>`;
}
window.EXTRA_TABS.data = tData;
const _bind7 = window.bindV04Tab;
window.bindV04Tab = function () {
  _bind7?.();
  $("#oc1_file")?.addEventListener("change", async e => { const f = e.target.files[0]; if (!f) return; try { const r = await api("/api/hmlr/oc1", { id: drawer.id, files: [await fileB64(f)] }); toast(`Register read: title ${r.parsed.title || "not found"}, ${r.parsed.proprietors.length} proprietor${r.parsed.proprietors.length === 1 ? "" : "s"}`); await load(false); await refreshDrawer(true); } catch (err) { toast(err.message); } });
};
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t || !drawer) return; const act = t.dataset.act;
  try {
    if (act === "denrich") { t.disabled = true; t.textContent = "Checking, this takes up to a minute"; await api("/api/data/enrich", { id: drawer.id }); await load(false); await refreshDrawer(true); }
    else if (act === "dapplyha") { await api("/api/site", { site: { id: drawer.id, site_ha: drawer.site.data_pack.title_area_ha } }); await load(false); await refreshDrawer(true); toast("Site area updated"); }
    else if (act === "doc1paste") { const txt = prompt("Paste the text of the official copy"); if (!txt) return; const r = await api("/api/hmlr/oc1", { id: drawer.id, text: txt }); toast(`Register read: title ${r.parsed.title || "not found"}`); await load(false); await refreshDrawer(true); }
  } catch (err) { toast(err.message); if (t.disabled) { t.disabled = false; t.textContent = "Check again"; } }
});
window.EXTRA_VIEWS = Object.assign(window.EXTRA_VIEWS || {}, { search: vSearch, data: vData });

/* ================= quality of life ================= */
document.addEventListener("keydown", e => {
  if (e.key === "/" && !e.metaKey && !e.ctrlKey && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || "")) { e.preventDefault(); $("#q")?.focus(); }
});
const _pd7 = paintDrawer;
paintDrawer = function (...a) { const r = _pd7.apply(this, a); requestAnimationFrame(() => $(".tab.on")?.scrollIntoView({ inline: "center", block: "nearest" })); return r; };
function exportSites() {
  const rows = sites().filter(s => s.stage !== "Rejected");
  csvOut("easyDevelopment_sites.csv", [["Name", "Address", "Postcode", "Stage", "Strategy", "Source", "Asking price", "Hectares", "Homes", "Planning status", "Score", "Grade"], ...rows.map(s => [s.name, s.address, s.postcode, s.stage, D.strategies[s.strategy] || s.strategy, s.source, s.asking_price ?? "", s.site_ha ?? "", s.units ?? "", s.planning_status || "", ev(s).score.score, ev(s).score.grade])]);
  toast(`${rows.length} sites exported`);
}
const _ci7 = cmdItems;
cmdItems = function (q) {
  const extra = [{ t: "Action", n: "Export sites to CSV", run: exportSites }, { t: "Action", n: "Search for sites in an area", run: () => { view = "search"; SR.mode = "area"; render(); } },
    ...(drawer ? [{ t: "Action", n: "Run data checks on this site", run: () => { drawer.tab = "data"; paintDrawer(); } }] : [])];
  const base = _ci7(q), toks = q.toLowerCase().split(/\s+/).filter(Boolean);
  const hit = extra.filter(x => toks.every(t => `${x.n} ${x.t}`.toLowerCase().includes(t)));
  return (q ? [...hit, ...base] : [...base.slice(0, 6), ...extra, ...base.slice(6)]).slice(0, 12);
};
