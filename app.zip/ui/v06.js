/* easyDevelopment v0.6: homes schedule, room-level editor, floorplans, policy checks. */
const H_ST = { pass: ["ok", "Meets"], warn: ["med", "Check"], fail: ["hi", "Fails"], info: ["lo", "Note"] };
const H_ACCESS = ["", "M4(1)", "M4(2)", "M4(3)"];
function hs() { return drawer.homes || (drawer.homes = { data: null, typ: null, sel: null, dirty: false, plans: {}, busy: false, showNT: false }); }
const hnum = (v, d = 1) => v == null || isNaN(v) ? "" : (+v).toFixed(d);
const hid = () => Math.random().toString(16).slice(2, 8);

async function loadHomes(typ, keepSel = true) {
  const H = hs(), id = drawer.id;
  H.busy = true;
  try {
    const r = await api("/api/typology/get", { id, ...(typ ? { typology: typ } : {}) });
    if (drawer?.id !== id) return;
    H.data = r; H.typ = r.typology;
    if (H.typ) {
      if (!keepSel || !H.typ.units.some(u => u.id === H.sel)) H.sel = H.typ.units[0]?.id || null;
      await loadPlans();
    }
  } catch (e) { toast(e.message); }
  H.busy = false;
  if (drawer?.tab === "homes") paintDrawer(true);
}
async function loadPlans() {
  const H = hs(), id = drawer.id, t = H.typ;
  const one = async (kind, unit) => { try { return (await api("/api/typology/plan", { id, typology: t, kind, unit })).svg || ""; } catch { return ""; } };
  const [unit, block, plots] = await Promise.all([H.sel ? one("unit", H.sel) : "", one("block"), one("plots")]);
  H.plans = { unit, block, plots };
}
const hdirty = () => { hs().dirty = true; };

function tHomes() {
  const H = hs();
  if (!H.data) { if (!H.busy) loadHomes(); return '<div class="empty">Preparing the homes schedule</div>'; }
  if (!H.typ) return homesStart();
  const d = H.data, t = H.typ, tot = d.totals, per = d.per, pol = d.policy, c = pol.counts;
  const u = t.units.find(x => x.id === H.sel) || t.units[0];
  const src = t.source === "unit mix" ? "built from the unit mix on file" : `the default for a ${(d.presets.find(p => p.key === t.preset)?.name || "").toLowerCase()} scheme`;
  const banner = d.saved && !H.dirty ? `<div class="notice ok" style="margin-bottom:12px">This schedule drives the unit mix, floor area and appraisal for this site.</div>`
    : `<div class="notice" style="margin-bottom:12px">${H.dirty ? "You have unsaved changes." : `Showing a schedule ${src}.`} The appraisal does not change until you press <b>Save to appraisal</b>.</div>`;
  return `<div id="homesBody">${banner}
   <div class="card pad" style="margin-bottom:14px"><div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between">
     <div style="display:flex;gap:18px;flex-wrap:wrap">${[["Homes", tot.units], ["Net area", `${Math.round(tot.net_sqm).toLocaleString()} m²`], ["Gross area", `${Math.round(tot.gross_sqm).toLocaleString()} m² (${tot.gross_sqft.toLocaleString()} sq ft)`], ["Net to gross", tot.efficiency ? Math.round(tot.efficiency * 100) + "%" : "n/a"], ["Density", tot.density ? tot.density + " dph" : "add site area"]].map(([k, v]) => `<div><div class="kl">${k}</div><b style="font-size:16px">${v}</b></div>`).join("")}</div>
     <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">${c.fail ? `<span class="chip hi">${c.fail} fail</span>` : ""}${c.warn ? `<span class="chip med">${c.warn} to check</span>` : ""}<span class="chip ok">${c.pass} meet</span>
       <select id="h_preset" style="max-width:190px"><option value="">Start again from</option>${d.presets.map(p => `<option value="${p.key}">${esc(p.name)}</option>`).join("")}</select>
       ${d.saved ? `<button class="btn sm" data-act="hreset">Discard saved</button>` : ""}<button class="btn sm primary" data-act="hsave" ${H.busy ? "disabled" : ""}>Save to appraisal</button></div></div></div>
   <div class="card" style="margin-bottom:14px"><div class="h"><h3>Home types</h3><span class="m">${esc(pol.pack)}</span></div><div class="tablewrap" style="max-height:none"><table><thead><tr><th>Code</th><th>Type</th><th class="num">Homes</th><th class="num">Beds</th><th class="num">People</th><th class="num">Storeys</th><th>Access</th><th>Aspect</th><th class="num">GIA m²</th><th class="num">Standard</th><th class="num">Value £</th><th class="num">Rent pcm</th><th></th></tr></thead><tbody>
    ${t.units.map(x => { const p = per[x.id], ok = p.ndss == null ? null : p.gia + 0.05 >= p.ndss; return `<tr data-u="${x.id}" class="${x.id === u.id ? "sel" : ""}" style="cursor:pointer">
      <td><input type="text" data-hu="${x.id}:code" value="${esc(x.code)}" style="width:62px"></td><td><input type="text" data-hu="${x.id}:name" value="${esc(x.name)}" style="min-width:130px"></td>
      <td class="num"><input type="number" min="0" data-hu="${x.id}:count" value="${x.count}" style="width:64px"></td><td class="num"><input type="number" min="0" max="8" data-hu="${x.id}:beds" value="${x.beds}" style="width:54px"></td>
      <td class="num"><input type="number" min="1" max="12" data-hu="${x.id}:persons" value="${x.persons}" style="width:54px"></td><td class="num"><input type="number" min="1" max="4" data-hu="${x.id}:storeys" value="${x.storeys}" style="width:54px"></td>
      <td><select data-hu="${x.id}:m4">${H_ACCESS.map(a => `<option value="${a}" ${x.m4 === a ? "selected" : ""}>${a || "not set"}</option>`).join("")}</select></td>
      <td><select data-hu="${x.id}:aspect"><option value="single" ${x.aspect === "single" ? "selected" : ""}>Single</option><option value="dual" ${x.aspect === "dual" ? "selected" : ""}>Dual</option></select></td>
      <td class="num"><b>${hnum(p.gia)}</b></td><td class="num">${p.ndss ? `<span class="${ok ? "" : "neg"}">${p.ndss}</span>` : '<span class="tsub">n/a</span>'}</td>
      <td class="num"><input type="number" data-hu="${x.id}:sale_value" value="${x.sale_value ?? ""}" placeholder="from £/sq ft" style="width:80px"></td><td class="num"><input type="number" data-hu="${x.id}:rent_pcm" value="${x.rent_pcm ?? ""}" style="width:66px"></td>
      <td style="white-space:nowrap"><button class="ghost" data-act="hdup" data-id="${x.id}" title="Duplicate">${I.copy || "+"}</button><button class="ghost" data-act="hdel" data-id="${x.id}" title="Remove">${I.x}</button></td></tr>`; }).join("")}</tbody></table></div>
    <div style="display:flex;gap:8px;padding:12px 16px;align-items:center"><select id="h_add" style="max-width:280px">${d.library.map(l => `<option value="${l.key}">${esc(l.name)}</option>`).join("")}</select><button class="btn sm" data-act="hadd">Add home type</button><span class="tsub">Click a row to see its plan.</span></div></div>
   ${u ? unitPanel(u, per[u.id], d) : ""}
   ${blockPanel(t, d)}
   ${sitePanel(t, d)}
   ${policyPanel(d)}</div>`;
}

function homesStart() {
  const d = hs().data;
  return `<div class="card pad"><h3 style="margin-bottom:6px">Set up the homes schedule</h3><div class="tsub" style="margin-bottom:12px">Choose the kind of scheme and the number of homes. easyDevelopment builds a default schedule of accommodation with room sizes that meet the Nationally Described Space Standard, and you can change any of it.</div>
   <label class="field" style="max-width:200px;margin-bottom:12px"><span>Number of homes</span><input type="number" id="h_units" value="${drawer.site.units || 20}" min="1"></label>
   <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px">${d.presets.map(p => `<button class="card pad" style="text-align:left;cursor:pointer" data-act="hpreset" data-k="${p.key}"><b>${esc(p.name)}</b><div class="tsub" style="margin-top:4px">${esc(p.text)}</div></button>`).join("")}</div></div>`;
}

function unitPanel(u, p, d) {
  const H = hs(), multi = u.storeys > 1, kinds = Object.entries(d.kinds);
  const rooms = u.rooms.map(r => { const a = r.w * r.d; return `<tr style="cursor:default"><td><input type="text" data-hr="${u.id}:${r.id}:name" value="${esc(r.name)}" style="min-width:140px"></td>
    <td><select data-hr="${u.id}:${r.id}:kind">${kinds.map(([k, l]) => `<option value="${k}" ${r.kind === k ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></td>
    ${multi ? `<td><select data-hr="${u.id}:${r.id}:floor">${[0, 1, 2, 3].slice(0, u.storeys).map(f => `<option value="${f}" ${r.floor === f ? "selected" : ""}>${["Ground", "First", "Second", "Third"][f]}</option>`).join("")}</select></td>` : ""}
    <td class="num"><input type="number" step="0.05" min="0.6" data-hr="${u.id}:${r.id}:w" value="${r.w}" style="width:68px"></td><td class="num"><input type="number" step="0.05" min="0.6" data-hr="${u.id}:${r.id}:d" value="${r.d}" style="width:68px"></td>
    <td class="num">${a.toFixed(1)}</td><td><button class="ghost" data-act="hroomdel" data-u="${u.id}" data-r="${r.id}">${I.x}</button></td></tr>`; }).join("");
  const inside = u.rooms.filter(r => !["balcony", "garden"].includes(r.kind)).reduce((n, r) => n + r.w * r.d, 0);
  return `<div style="display:grid;gap:14px;margin-bottom:14px">
   <div class="card"><div class="h"><h3>${esc(u.name)}</h3><span class="m">${hnum(p.gia)} m² GIA · ${p.floors} floor${p.floors > 1 ? "s" : ""}</span></div><div class="plan">${H.plans.unit || '<div class="empty">Drawing</div>'}</div>
    ${p.stretch > 0.08 ? `<div class="notice" style="margin:0 16px 14px">The floors do not add up to the same area, so some rooms are drawn larger than entered. Adjust the room sizes to balance them.</div>` : ""}</div>
   <div class="card"><div class="h"><h3>Rooms</h3><span class="m">metres, width across the front</span></div><div class="tablewrap" style="max-height:520px"><table><thead><tr><th>Room</th><th>Type</th>${multi ? "<th>Floor</th>" : ""}<th class="num">Width</th><th class="num">Depth</th><th class="num">m²</th><th></th></tr></thead><tbody>${rooms}</tbody></table></div>
    <div style="display:flex;gap:8px;padding:12px 16px;flex-wrap:wrap;align-items:center"><button class="btn sm" data-act="hroomadd" data-u="${u.id}">Add room</button>${u.family === "house" ? `<label class="field" style="margin:0"><select data-hu="${u.id}:attach"><option value="terrace" ${u.attach === "terrace" ? "selected" : ""}>Terraced</option><option value="semi" ${u.attach === "semi" ? "selected" : ""}>Semi-detached</option><option value="detached" ${u.attach === "detached" ? "selected" : ""}>Detached</option></select></label>` : ""}
      <label class="field" style="margin:0;flex-direction:row;align-items:center;gap:6px"><span>Ceiling m</span><input type="number" step="0.05" data-hu="${u.id}:ceiling_m" value="${u.ceiling_m}" style="width:70px"></label></div>
    <div class="tsub" style="padding:0 16px 14px">Rooms total ${inside.toFixed(1)} m² before walls. Room areas hold when you change a width or depth, and the plan closes around them.</div></div></div>`;
}

function blockPanel(t, d) {
  const tot = d.totals, b = t.block, H = hs();
  if (!tot.flats && !H.plans.plots) return "";
  const stack = tot.stack[0];
  const names = Object.fromEntries(t.units.map(u => [u.id, u.code]));
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>${tot.flats ? "Blocks and floors" : "Plots"}</h3><span class="m">${tot.flats ? `${tot.blocks} block${tot.blocks > 1 ? "s" : ""}` : ""}</span></div><div class="pad">
   ${tot.flats ? `<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:12px">
     <label class="field"><span>Storeys</span><input type="number" min="1" max="60" data-hb="floors" value="${b.floors}" style="width:80px"></label>
     <label class="field"><span>Homes per floor</span><input type="number" min="1" max="60" data-hb="per_floor" value="${b.per_floor}" style="width:80px"></label>
     <label class="field"><span>Ground floor homes lost to lobby</span><input type="number" min="0" data-hb="ground_loss" value="${b.ground_loss}" style="width:80px"></label>
     <label class="field"><span>Net to gross override %</span><input type="number" min="60" max="95" data-hs="efficiency" value="${t.efficiency ? Math.round(t.efficiency * 100) : ""}" placeholder="${tot.plate ? Math.round(tot.plate.eff * 100) : ""}" style="width:110px"></label></div>
     <div class="plan">${H.plans.block || ""}</div>
     ${stack ? `<div class="tablewrap" style="max-height:none;margin-top:12px"><table><thead><tr><th>Floor</th><th class="num">Homes</th><th>Mix, block 1</th></tr></thead><tbody>${stack.floors.slice().reverse().map(f => `<tr style="cursor:default"><td>${f.floor === 0 ? "Ground" : "Level " + f.floor}</td><td class="num">${f.units}</td><td>${Object.entries(f.mix).map(([id, n]) => `${n} x ${esc(names[id] || "")}`).join(", ")}</td></tr>`).join("")}</tbody></table></div>` : ""}` : ""}
   ${H.plans.plots ? `<div class="plan" style="margin-top:${tot.flats ? 14 : 0}px">${H.plans.plots}</div><div class="tsub" style="margin-top:6px">Each outline is a plot with its house and garden, up to six shown per type.</div>` : ""}</div></div>`;
}

function sitePanel(t, d) {
  const s = t.site, pk = t.policy, ov = pk.overrides || {};
  const F = (k, l, v, ph = "") => `<label class="field"><span>${l}</span><input type="number" step="any" data-hs="${k}" value="${v ?? ""}" placeholder="${ph}" style="width:130px"></label>`;
  const P = (k, l, ph) => `<label class="field"><span>${l}</span><input type="number" step="any" data-hp="${k}" value="${ov[k] ?? ""}" placeholder="${ph}" style="width:110px"></label>`;
  const req = d.policy.requirements || {};
  return `<div class="card pad" style="margin-bottom:14px"><h3 style="margin-bottom:10px">Site provision and policy</h3><div style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end">
    ${F("parking", "Car parking spaces", s.parking, req.parking ? "about " + Math.round(req.parking) : "")}${F("cycle", "Cycle spaces", s.cycle, req.cycle || "")}${F("shared_sqm", "Shared space per home (m²)", t.shared_sqm, "0")}${F("amenity_sqm", "Communal amenity space (m²)", s.amenity_sqm, "")}
    <label class="field"><span>Policy pack</span><select data-hpk="pack">${Object.entries(d.packs).map(([k, l]) => `<option value="${k}" ${pk.pack === k ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label></div>
    <details style="margin-top:12px"><summary class="tsub" style="cursor:pointer">Change the policy targets for this site</summary><div style="display:flex;gap:14px;flex-wrap:wrap;margin-top:10px">${P("m42_share", "M4(2) share %", "pack default")}${P("m43_share", "M4(3) share %", "pack default")}${P("affordable_pct", "Affordable housing %", "pack default")}${P("outdoor_flat_base", "Flat outdoor space m²", "pack default")}${P("garden_depth", "Garden depth m", "pack default")}${P("parking_per_unit", "Parking per home", "pack default")}</div><div class="tsub" style="margin-top:8px">Blank fields use the pack values. Set them to your council's adopted standards.</div></details></div>`;
}

function policyPanel(d) {
  const pol = d.policy, groups = {};
  pol.checks.forEach(c => (groups[c.area] = groups[c.area] || []).push(c));
  const H = hs();
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Policy checks</h3><span class="m">${esc(pol.pack)}</span></div>
   ${Object.entries(groups).map(([a, cs]) => `<div style="padding:8px 16px 4px"><div class="kl" style="margin-bottom:4px">${esc(a)}</div>${cs.map(c => { const [cls, lab] = H_ST[c.status]; return `<div style="display:flex;gap:10px;padding:7px 0;border-top:1px solid var(--line);align-items:flex-start"><span class="chip ${cls}" style="min-width:52px;justify-content:center">${lab}</span><div style="min-width:0"><b>${esc(c.title)}</b><div class="tsub" style="white-space:normal;margin-top:2px">${esc(c.detail)}</div>${c.source ? `<div class="tsub" style="opacity:.7">${esc(c.source)}</div>` : ""}</div></div>`; }).join("")}</div>`).join("")}
   <div style="padding:10px 16px 16px"><button class="btn sm" data-act="hnt">${H.showNT ? "Hide" : "Show"} what these checks cannot test</button>${H.showNT ? `<ul style="margin:10px 0 0 18px;color:var(--muted);font-size:13px">${pol.not_tested.map(x => `<li>${esc(x)}</li>`).join("")}</ul><div class="tsub" style="margin-top:6px">These need a site layout or specialist reports.</div>` : ""}</div></div>`;
}

/* ---------------- editing ---------------- */
function hsetUnit(id, f, v) {
  const u = hs().typ.units.find(x => x.id === id); if (!u) return;
  const numf = ["count", "beds", "persons", "storeys", "ceiling_m"], optf = ["sale_value", "rent_pcm"];
  if (numf.includes(f)) u[f] = +v || 0; else if (optf.includes(f)) { if (v === "") delete u[f]; else u[f] = +v; } else u[f] = v;
  if (f === "storeys") u.rooms.forEach(r => { if (r.floor >= u.storeys) r.floor = u.storeys - 1; });
}
function hsetRoom(uid, rid, f, v) {
  const r = hs().typ.units.find(x => x.id === uid)?.rooms.find(x => x.id === rid); if (!r) return;
  r[f] = ["w", "d", "floor"].includes(f) ? +v : v;
  if (f === "kind") delete r.band;
}
const hrefresh = debounce(async () => { hdirty(); await loadHomes(hs().typ); }, 250);

document.addEventListener("change", e => {
  const t = e.target; if (!drawer || drawer.tab !== "homes" || !hs().typ) return;
  const H = hs();
  if (t.dataset.hu) { const [id, f] = t.dataset.hu.split(":"); hsetUnit(id, f, t.value); hrefresh(); }
  else if (t.dataset.hr) { const [uid, rid, f] = t.dataset.hr.split(":"); hsetRoom(uid, rid, f, t.value); hrefresh(); }
  else if (t.dataset.hb) { H.typ.block[t.dataset.hb] = +t.value || 0; hrefresh(); }
  else if (t.dataset.hs) { const k = t.dataset.hs; if (k === "shared_sqm") H.typ.shared_sqm = t.value === "" ? null : +t.value; else if (k === "efficiency") H.typ.efficiency = t.value === "" ? null : +t.value / 100; else H.typ.site[k] = t.value === "" ? null : +t.value; hrefresh(); }
  else if (t.dataset.hp) { const ov = H.typ.policy.overrides = H.typ.policy.overrides || {}; if (t.value === "") delete ov[t.dataset.hp]; else ov[t.dataset.hp] = +t.value; hrefresh(); }
  else if (t.dataset.hpk) { H.typ.policy.pack = t.value; H.typ.policy.overrides = {}; hrefresh(); }
  else if (t.id === "h_preset" && t.value) { const k = t.value; t.value = ""; if (confirm("Replace the current schedule with the default for this scheme type?")) hpreset(k); }
});
async function hpreset(k, units) {
  const H = hs();
  try { const r = await api("/api/typology/preset", { id: drawer.id, preset: k, units: units || drawer.site.units || undefined }); H.data = r; H.typ = r.typology; H.sel = H.typ.units[0]?.id; H.dirty = true; await loadPlans(); paintDrawer(true); }
  catch (e) { toast(e.message); }
}
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"), row = e.target.closest("tr[data-u]");
  if (row && !t && !e.target.closest("input,select") && drawer?.tab === "homes") { const H = hs(); if (H.sel !== row.dataset.u) { H.sel = row.dataset.u; await loadPlans(); paintDrawer(true); } return; }
  if (!t || !drawer) return;
  const act = t.dataset.act, H = drawer.homes;
  try {
    if (act === "hpreset") await hpreset(t.dataset.k, +($("#h_units")?.value) || undefined);
    else if (act === "hsave") { t.disabled = true; const r = await api("/api/typology/save", { id: drawer.id, typology: H.typ }); H.data = r; H.typ = r.typology; H.dirty = false; await load(false); await refreshDrawer(true); drawer.tab = "homes"; await loadPlans(); paintDrawer(true); toast("Saved. The appraisal now uses this schedule."); }
    else if (act === "hreset") { if (!confirm("Discard the saved schedule? The unit mix and floor area already in the appraisal stay as they are.")) return; const r = await api("/api/typology/reset", { id: drawer.id }); H.data = r; H.typ = r.typology; H.dirty = false; H.sel = H.typ?.units[0]?.id; await loadPlans(); paintDrawer(true); }
    else if (act === "hadd") { const r = await api("/api/typology/unit", { id: drawer.id, key: $("#h_add").value, count: 1 }); H.typ.units.push(r.unit); H.sel = r.unit.id; hdirty(); await loadHomes(H.typ); }
    else if (act === "hdel") { e.stopPropagation(); H.typ.units = H.typ.units.filter(u => u.id !== t.dataset.id); hdirty(); await loadHomes(H.typ, false); }
    else if (act === "hdup") { e.stopPropagation(); const u = H.typ.units.find(x => x.id === t.dataset.id), c = JSON.parse(JSON.stringify(u)); c.id = hid(); c.name += " (copy)"; c.code += "2"; c.rooms.forEach(r => r.id = hid()); H.typ.units.push(c); H.sel = c.id; hdirty(); await loadHomes(H.typ); }
    else if (act === "hroomadd") { const u = H.typ.units.find(x => x.id === t.dataset.u); u.rooms.push({ id: hid(), name: "New room", kind: "bedroom", w: 3, d: 3, floor: 0 }); hdirty(); await loadHomes(H.typ); }
    else if (act === "hroomdel") { const u = H.typ.units.find(x => x.id === t.dataset.u); u.rooms = u.rooms.filter(r => r.id !== t.dataset.r); hdirty(); await loadHomes(H.typ); }
    else if (act === "hnt") { H.showNT = !H.showNT; paintDrawer(true); }
    else if (act === "hopen") { drawer.tab = "homes"; paintDrawer(); }
  } catch (err) { toast(err.message); if (t.disabled) t.disabled = false; }
});

/* ---------------- plans on the appraisal tab ---------------- */
const _tAp6 = tAppraisal;
tAppraisal = function () { return `<div id="hm_strip"></div>` + _tAp6(); };
async function loadStrip() {
  const id = drawer.id, box = $("#hm_strip"); if (!box) return;
  try {
    if (!drawer.strip) {
      const d = await api("/api/typology/get", { id });
      if (!d.typology) { drawer.strip = { none: true }; }
      else { const th = (await api("/api/typology/plan", { id, kind: "thumbs", typology: d.typology })).thumbs || {}; drawer.strip = { d, th }; }
    }
  } catch { return; }
  if (drawer?.id !== id || drawer.tab !== "appraisal") return;
  const S = drawer.strip, b = $("#hm_strip"); if (!b || S.none) return;
  const d = S.d, t = d.typology, per = d.per, c = d.policy.counts;
  b.innerHTML = `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Homes and plans</h3><span class="m">${d.totals.units} homes · ${d.totals.gross_sqft.toLocaleString()} sq ft gross · ${d.saved ? "saved schedule" : "default schedule"}</span></div>
    <div class="gallery">${t.units.filter(u => u.count).map(u => { const p = per[u.id], ok = p.ndss == null ? null : p.gia + 0.05 >= p.ndss; return `<div class="gcard" data-act="hopen"><div class="plan sm">${S.th[u.id] || ""}</div><div style="padding:8px 4px 2px"><b>${u.count} x ${esc(u.code)}</b> <span class="tsub">${hnum(p.gia)} m²</span> ${ok === null ? "" : `<span class="chip ${ok ? "ok" : "hi"}">${ok ? "meets standard" : "below standard"}</span>`}</div></div>`; }).join("")}</div>
    <div style="padding:6px 16px 14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button class="btn sm" data-act="hopen">Open homes schedule</button>${c.fail ? `<span class="chip hi">${c.fail} policy fail</span>` : ""}${c.warn ? `<span class="chip med">${c.warn} to check</span>` : ""}${!d.saved ? '<span class="tsub">Save the schedule on the Homes tab to make the appraisal use it.</span>' : ""}</div></div>`;
}
const _bind6 = window.bindV04Tab;
window.bindV04Tab = function () { _bind6?.(); if (drawer.tab === "appraisal") loadStrip(); };
const _rd6 = refreshDrawer;
refreshDrawer = async function (soft) { if (drawer && !drawer._keepHomes) { drawer.strip = null; } return _rd6(soft); };

window.EXTRA_TABS.homes = tHomes;
