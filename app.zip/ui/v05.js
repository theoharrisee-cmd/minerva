/* easyDevelopment v0.5: home planning news, notifications, command bar, saved views, scenarios, replies, site report, constraints. */
Object.assign(I, {
  refresh: '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg>',
  bell: '<svg viewBox="0 0 24 24"><path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7M10 20a2 2 0 0 0 4 0"/></svg>',
  deck: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/></svg>',
});
const fdt = s => { try { const d = new Date(String(s).slice(0, 10)); return isNaN(d) ? "" : d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }); } catch { return ""; } };
const num1 = (x, d = 1) => x == null || isNaN(x) ? "n/a" : (+x).toFixed(d);

/* ---------------- planning news (home) ---------------- */
let NEWS = null, newsTries = 0;
const newsClass = k => /grant|approv|consent|allowed|no objection|support/i.test(k) ? "ok" : /refus|object|dismiss|withdrawn/i.test(k) ? "hi" : /condition|mixed/i.test(k) ? "med" : "lo";
async function loadNews(force) {
  try { if (force) { newsTries = 0; await api("/api/news/refresh", {}); } NEWS = await api("/api/news"); } catch (e) { return; }
  paintNews();
  if (NEWS.refreshing && newsTries++ < 6 && view === "overview") setTimeout(() => view === "overview" && loadNews(), 4000);
}
function paintNews() {
  const el = $("#newsBody"); if (!el || !NEWS) return;
  const items = NEWS.items.slice(0, 9);
  $("#newsMeta").textContent = NEWS.refreshing ? "checking" : NEWS.last ? `checked ${when(NEWS.last)}` : "";
  el.innerHTML = items.map(n => `<div class="row" data-act="open" data-id="${esc(n.site_id)}" style="align-items:flex-start"><span class="chip ${newsClass(n.kind)}" style="margin-top:2px;white-space:nowrap">${esc(n.kind)}</span>
    <div class="grow"><div class="t" style="white-space:normal">${esc(n.site_name)}${n.ref ? ` <span class="tsub">${esc(n.ref)}</span>` : ""}</div><div class="m" style="white-space:normal">${esc((n.text || "").slice(0, 110))}</div>
    <div class="m">${fdt(n.date)} · ${n.own ? "on your file" : `${n.distance_km.toFixed(1)} km away`}</div></div></div>`).join("")
    || `<div class="empty">No planning activity yet.<br><span class="tsub">Applications you record on a site appear here. For sites with a postcode, easyDevelopment also checks applications published to planning.data.gov.uk within 1 km.</span></div>`;
}

/* ---------------- notifications ---------------- */
let FEED = { items: [], unseen: 0 };
async function loadFeed() { try { FEED = await api("/api/feed"); } catch { return; } paintBell(); if ($("#notif").classList.contains("on")) paintNotif(); }
function paintBell() { $("#bellIcon").innerHTML = I.bell; const b = $("#bellN"); b.hidden = !FEED.unseen; b.textContent = FEED.unseen > 9 ? "9+" : FEED.unseen; }
const kindTab = k => ({ diligence: "diligence", land: "land", planning_new: "planning", planning_change: "planning", price_change: "overview", date: "overview" }[k] || "overview");
function paintNotif() {
  const el = $("#notif");
  el.innerHTML = `<div class="nh"><b>Notifications</b><span style="flex:1"></span>${FEED.unseen ? '<button class="btn sm" data-act="feedall">Mark all read</button>' : ""}</div>
   <div class="nb">${FEED.items.map(n => `<div class="ni ${n.seen ? "" : "new"}" data-act="feedopen" data-id="${esc(n.id)}" data-site="${esc(n.site_id)}" data-kind="${esc(n.kind)}"><span class="dot ${n.level === "important" ? "hi" : ""}"></span><div><div class="t">${esc(n.title)}</div><div class="m">${n.site_name ? esc(n.site_name) + " · " : ""}${esc(n.detail || "").slice(0, 120)}</div></div></div>`).join("") || '<div class="empty">Nothing needs your attention.</div>'}</div>`;
}
$("#bellBtn").onclick = e => { e.stopPropagation(); const el = $("#notif"); el.classList.toggle("on"); if (el.classList.contains("on")) { paintNotif(); loadFeed(); } };
document.addEventListener("click", e => { const el = $("#notif"); if (el.classList.contains("on") && !e.target.closest("#notif,#bellBtn")) el.classList.remove("on"); });
const _load5 = load;
load = async function (k) { const r = await _load5(k); loadFeed(); return r; };
setInterval(loadFeed, 60000);

/* ---------------- command bar ---------------- */
let CK = { i: 0, items: [] };
function cmdItems(q) {
  const views = NAV.map(([k, l]) => ({ t: "View", n: l, run: () => { view = k; render(); } }));
  const acts = [{ t: "Action", n: "Add a deal", run: () => addDeal() }, { t: "Action", n: "Refresh listings", run: () => startScrape() }, { t: "Action", n: "Toggle light and dark", run: () => $("#themeBtn").click() },
    { t: "Action", n: "Open notifications", run: () => $("#bellBtn").click() }, { t: "Action", n: "Save current filters as a view", run: () => { view = "sites"; render(); viewModal(); } }];
  const ss = sites().map(s => ({ t: "Site", n: s.name, sub: s.address || s.postcode || "", run: () => openSite(s.id) }));
  const all = [...views, ...acts, ...ss], toks = q.toLowerCase().split(/\s+/).filter(Boolean);
  const hit = all.filter(x => toks.every(t => `${x.n} ${x.sub || ""} ${x.t}`.toLowerCase().includes(t)));
  return (q ? hit : [...views, ...acts, ...ss.slice(0, 6)]).slice(0, 12);
}
function cmdOpen() {
  const w = $("#cmdk"); w.classList.add("on"); w.innerHTML = '<div class="cmdk"><input id="ck_in" placeholder="Go to a site or view, or run an action" autocomplete="off"><div id="ck_list"></div><div class="tsub" style="padding:8px 14px;border-top:1px solid var(--line)">Enter to select, Esc to close</div></div>';
  const paint = () => { CK.items = cmdItems($("#ck_in").value); CK.i = Math.min(CK.i, CK.items.length - 1); $("#ck_list").innerHTML = CK.items.map((x, i) => `<div class="ck ${i === CK.i ? "on" : ""}" data-i="${i}"><span class="chip lo">${x.t}</span><span>${esc(x.n)}</span><span class="tsub">${esc(x.sub || "")}</span></div>`).join("") || '<div class="empty">No matches</div>'; };
  CK.i = 0; paint(); const inp = $("#ck_in"); inp.focus();
  inp.oninput = () => { CK.i = 0; paint(); };
  inp.onkeydown = e => {
    if (e.key === "ArrowDown") { CK.i = Math.min(CK.items.length - 1, CK.i + 1); paint(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { CK.i = Math.max(0, CK.i - 1); paint(); e.preventDefault(); }
    else if (e.key === "Enter") { const x = CK.items[CK.i]; cmdClose(); x?.run(); }
    else if (e.key === "Escape") cmdClose();
  };
  $("#ck_list").onclick = e => { const r = e.target.closest(".ck"); if (r) { const x = CK.items[+r.dataset.i]; cmdClose(); x?.run(); } };
  w.onclick = e => { if (e.target === w) cmdClose(); };
}
function cmdClose() { $("#cmdk").classList.remove("on"); $("#cmdk").innerHTML = ""; }
document.addEventListener("keydown", e => {
  const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || "");
  if (((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") || (e.key === "/" && !typing)) { e.preventDefault(); $("#cmdk").classList.contains("on") ? cmdClose() : cmdOpen(); }
}, true);

/* ---------------- saved views ---------------- */
const VKEYS = ["q", "stage", "src", "viable", "strat", "fit", "region", "minunits"];
const curFilters = () => ({ ...Object.fromEntries(VKEYS.map(k => [k, F[k]])), sortKey, sortDir });
const sameView = v => JSON.stringify(Object.fromEntries(VKEYS.map(k => [k, v.filters[k] ?? ({ q: "", stage: "active", src: "all", viable: false, strat: "all", fit: false, region: "all", minunits: 0 })[k]]))) === JSON.stringify(Object.fromEntries(VKEYS.map(k => [k, F[k]])));
const _vSites5 = vSites;
vSites = function () {
  _vSites5();
  const regs = D.regions || [];
  $("#view").insertAdjacentHTML("afterbegin", `<div class="toolbar" id="viewsbar"><span class="tsub">Views</span>
   ${(D.views || []).map(v => `<span class="pill ${sameView(v) ? "on" : ""}" data-act="viewapply" data-id="${esc(v.id)}" style="display:inline-flex;gap:6px;align-items:center">${esc(v.name)}<button class="ghost" style="padding:0" data-act="viewdel" data-id="${esc(v.id)}" title="Delete view">${I.x}</button></span>`).join("") || '<span class="tsub">None saved</span>'}
   <span style="flex:1"></span>
   <select id="freg" style="width:auto"><option value="all">All regions</option>${regs.map(r => `<option ${F.region === r ? "selected" : ""}>${esc(r)}</option>`).join("")}</select>
   <input type="number" id="fmin" placeholder="Min units" value="${F.minunits || ""}" style="width:110px" min="0">
   <button class="btn sm" data-act="viewsave">Save view</button></div>`);
  $("#freg").onchange = e => { F.region = e.target.value; render(); };
  $("#fmin").onchange = e => { F.minunits = +e.target.value || 0; render(); };
};
function viewModal() {
  modal(`<h3>Save this view</h3><p class="tsub" style="margin-top:-6px">Saves the stage, source, strategy, region, unit count and other filters currently applied on Sites.</p><label class="field"><span>Name</span><input type="text" id="vw_name" placeholder="e.g. BTR in the North West over 50 units"></label>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="viewgo">Save</button></div>`, () => $("#vw_name").focus());
}

/* ---------------- constraints ---------------- */
function constraintsCard() {
  const s = drawer.site, r = s.constraints_result;
  const hits = r ? Object.values(r.hits || {}) : [];
  const links = [["Flood risk for this postcode", s.postcode ? `https://check-long-term-flood-risk.service.gov.uk/postcode?postcode=${encodeURIComponent(s.postcode)}` : ""], ["Planning data map", s.lat != null ? `https://www.planning.data.gov.uk/map/?lat=${s.lat}&lng=${s.lon}&zoom=16` : ""]].filter(x => x[1]);
  return `<div class="card pad" style="margin-top:14px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3>Site constraints</h3><button class="btn sm" data-act="cnrun" ${s.lat == null ? "disabled" : ""}>${r ? "Check again" : "Check open data"}</button></div>
   ${s.lat == null ? tsub("Add a postcode under Details so the site can be placed on the map and checked.") : drawer.cnBusy ? tsub("Checking planning.data.gov.uk") : r ? `${hits.length ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">${hits.map(h => `<span class="chip med" title="${esc(h.entities.map(e => e.name).filter(Boolean).join(", "))}">${esc(h.label)}</span>`).join("")}</div>` : tsub("None of the checked designations cover this point.", "margin-bottom:6px")}
     ${tsub(`${r.checked_datasets || 0} datasets checked ${when(r.checked)}.${r.errors?.length ? ` ${r.errors.length} could not be reached.` : ""} Coverage varies by council, so treat a clear result as a first pass.`)}` : tsub(s.demo ? "Illustrative site: the live check is available but the coordinates are fictional." : "Not checked yet.")}
   <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px">${links.map(([l, u]) => `<button class="btn sm" ${ext(u)}>${I.link}${l}</button>`).join("")}</div></div>`;
}
const _tOE5 = tOverviewExtra;
tOverviewExtra = function () { return _tOE5() + constraintsCard(); };
async function runConstraints(auto) {
  if (!drawer || drawer.cnBusy) return; const id = drawer.id; drawer.cnBusy = true; if (drawer.tab === "overview") paintDrawer(true);
  try { await api("/api/constraints", { id }); } catch (e) { if (!auto) toast(e.message); }
  if (drawer?.id === id) { drawer.cnBusy = false; await load(); }
}

/* ---------------- scenarios ---------------- */
const SCN_LABELS = { sales: "Sales %", rent: "Rents %", build: "Build %", yield_bps: "Yield bps", delay: "Delay months", land: "Land %" };
function tScenarios() {
  const s = drawer.site;
  if (!drawer.scn) { loadScenarios(); return '<div class="empty">Working out the scenarios</div>'; }
  const r = drawer.scn, lst = r.list;
  return `<div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><h3>Scenarios</h3><div style="display:flex;gap:6px"><button class="btn sm" data-act="scnadd" ${lst.length >= 6 ? "disabled" : ""}>Add scenario</button><button class="btn sm" data-act="scnreset">Reset</button><button class="btn sm primary" data-act="scnsave">Save to site</button></div></div>
   <div class="tsub" style="margin-bottom:10px">Each column changes the base case. Sales, rents, build cost and land price are percentage changes. Delay adds months before consent.</div>
   <div class="tablewrap" style="max-height:none"><table id="scn_t"><thead><tr><th>Name</th>${Object.values(SCN_LABELS).map(l => `<th class="num">${l}</th>`).join("")}<th></th></tr></thead><tbody>
   ${lst.map((x, i) => `<tr style="cursor:default" data-sc="${i}"><td><input type="text" data-k="name" value="${esc(x.name)}" ${i === 0 ? "disabled" : ""} style="min-width:120px"></td>${Object.keys(SCN_LABELS).map(k => `<td class="num"><input type="number" step="any" data-k="${k}" value="${+x[k]}" ${i === 0 ? "disabled" : ""} style="width:80px"></td>`).join("")}<td>${i ? `<button class="ghost" data-act="scndel" data-i="${i}">${I.x}</button>` : ""}</td></tr>`).join("")}</tbody></table></div></div>
   <div id="scnRes">${scnResults(r)}</div>`;
}
function scnResults(r) {
  if (r.incomplete) return `<div class="notice" style="margin-top:14px">Missing ${esc((r.missing || []).join(", "))}. Add it under Details to run scenarios.</div>`;
  const rows = r.rows, mx = Math.max(1, ...rows.map(x => Math.abs(x.profit)));
  const f = (x, u) => x == null ? '<span class="tsub">not reached</span>' : `${x > 0 ? "+" : ""}${num1(x)}${u === "%" ? "%" : u === "bps" ? " bps" : " months"}`;
  const be = r.breakeven;
  return `<div class="card" style="margin-top:14px"><div class="h"><h3>Results</h3><span class="m">${rows[0].basis}</span></div><div class="tablewrap" style="max-height:none"><table><thead><tr><th>Scenario</th><th class="num">GDV</th><th class="num">Total cost</th><th class="num">Profit</th><th class="num">Margin</th><th class="num">Levered IRR</th><th class="num">Peak equity</th><th>Result</th></tr></thead><tbody>
   ${rows.map(x => `<tr style="cursor:default"><td><b>${esc(x.name)}</b></td><td class="num">${money(x.gdv)}</td><td class="num">${money(x.total_cost)}</td><td class="num ${x.profit < 0 ? "neg" : ""}">${money(x.profit)}${x.d_profit != null ? `<div class="tsub">${x.d_profit >= 0 ? "+" : ""}${money(x.d_profit)}</div>` : ""}</td><td class="num">${pct(x.margin)}</td><td class="num">${pct(x.irr)}</td><td class="num">${money(x.peak_equity)}</td><td><span class="chip ${x.viable ? "ok" : x.profit < 0 ? "hi" : "med"}">${x.viable ? "Meets target" : x.profit < 0 ? "Loss" : "Below target"}</span></td></tr>`).join("")}</tbody></table></div>
   <div style="padding:6px 16px 16px">${rows.map(x => `<div style="display:flex;align-items:center;gap:10px;margin-top:6px"><span style="width:110px;font-size:12.5px;color:var(--muted)">${esc(x.name)}</span><div style="flex:1;height:12px;background:var(--surface2);border-radius:6px;overflow:hidden"><i style="display:block;height:100%;width:${Math.abs(x.profit) / mx * 100}%;background:${x.profit < 0 ? "var(--hi)" : "var(--accent)"}"></i></div><b style="width:80px;text-align:right;font-size:12.5px">${money(x.profit)}</b></div>`).join("")}</div></div>
   <div class="card" style="margin-top:14px"><div class="h"><h3>Break-even</h3><span class="m">one change at a time</span></div><div class="tablewrap" style="max-height:none"><table><thead><tr><th>Change</th><th class="num">Profit reaches zero</th><th class="num">Meets target margin (${pct(be.base.target, 0)})</th></tr></thead><tbody>
   ${be.rows.map(x => `<tr style="cursor:default"><td>${esc(x.phrase)}</td><td class="num">${f(x.zero, x.unit)}</td><td class="num">${f(x.target, x.unit)}</td></tr>`).join("")}
   <tr style="cursor:default"><td>Land price (tested at ${money(be.land.tested)})</td><td class="num">${be.land.zero ? money(be.land.zero) : '<span class="tsub">not reached</span>'}</td><td class="num">${be.land.target ? money(be.land.target) : '<span class="tsub">not reached</span>'}</td></tr></tbody></table></div>
   <div class="tsub" style="padding:8px 16px 14px">Target margin is reached at a land price of ${be.land.target ? money(be.land.target) : "n/a"}, which is the maximum bid. Above ${be.land.zero ? money(be.land.zero) : "n/a"} the scheme loses money.</div></div>`;
}
async function loadScenarios(list, save) {
  const id = drawer.id;
  try { const r = await api("/api/scenarios", { id, strategy: drawer.ev.strategy, ...(list ? { scenarios: list, save: !!save } : {}) }); if (drawer?.id !== id) return; drawer.scn = r; if (list && drawer.tab === "scenarios") $("#scnRes").innerHTML = scnResults(r); else if (drawer.tab === "scenarios") paintDrawer(true); }
  catch (e) { toast(e.message); }
}
const readScn = () => $$("#scn_t tbody tr").map((tr, i) => { const o = { id: drawer.scn.list[i]?.id }; $$("[data-k]", tr).forEach(inp => o[inp.dataset.k] = inp.dataset.k === "name" ? inp.value : +inp.value || 0); return o; });
const runScn = debounce(() => loadScenarios(readScn()), 400);

/* ---------------- replies ---------------- */
const REP_HINT = { officer: "Paste the case officer's email or the list of queries.", consultee: "Paste the consultee's response, such as highways, drainage or ecology.", neighbour: "Paste the neighbour or public comment.", s106: "Paste the draft heads of terms or the council's viability comments. You can leave this blank to start from the standard position." };
function repState() { return drawer.rep || (drawer.rep = { kind: "officer", tone: "measured", text: "", draft: null, hist: null }); }
function tReplies() {
  const R = repState(), d = R.draft;
  if (!R.hist) loadReplies();
  return `<div class="two" style="grid-template-columns:minmax(0,1fr) minmax(0,1.25fr);align-items:start">
   <div class="card pad"><h3 style="margin-bottom:6px">Message received</h3><div class="tsub" style="margin-bottom:10px">Drafts follow GOV.UK guidance on material considerations, consultation, planning obligations and viability. You review and send them yourself.</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">${Object.entries(D.reply_kinds).map(([k, l]) => `<button class="pill ${R.kind === k ? "on" : ""}" data-act="repkind" data-k="${k}">${esc(l)}</button>`).join("")}</div>
    <textarea id="rep_in" style="min-height:250px;font-family:var(--font)" placeholder="${esc(REP_HINT[R.kind])}">${esc(R.text)}</textarea>
    <div style="display:flex;gap:8px;align-items:center;margin-top:10px"><label class="field" style="margin:0"><select id="rep_tone"><option value="measured" ${R.tone === "measured" ? "selected" : ""}>Measured</option><option value="firm" ${R.tone === "firm" ? "selected" : ""}>Firm</option></select></label><span style="flex:1"></span><button class="btn primary" data-act="repdraft">Draft reply</button></div>
    <div class="tsub" style="margin-top:8px">${D.has_key ? "Drafted with Claude, using the site record and the guidance." : "Drafted from templates and the site record. Add a Claude key in Settings for a tailored draft."}</div>
    ${R.hist?.length ? `<div class="kl" style="margin:16px 0 6px">Saved on this site</div>${R.hist.map(h => `<div class="usage" style="display:flex;justify-content:space-between;gap:8px;align-items:center"><span style="min-width:0"><b style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(h.subject || "Reply")}</b><span class="tsub">${esc(D.reply_kinds[h.kind] || "")} · ${when(h.saved)}</span></span><span style="white-space:nowrap"><button class="btn sm" data-act="repload" data-id="${esc(h.id)}">Open</button><button class="ghost" data-act="repdel" data-id="${esc(h.id)}">${I.x}</button></span></div>`).join("")}` : ""}</div>
   <div>${d ? `<div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3>Draft reply</h3><span class="chip ${d.mode === "claude" ? "acc" : "lo"}">${d.mode === "claude" ? "Claude draft" : "Template draft"}</span></div>
     ${d.deadline ? `<div class="notice" style="margin-bottom:10px">Deadline in the message: ${esc(d.deadline)}.</div>` : ""}${d.note ? `<div class="notice" style="margin-bottom:10px">${esc(d.note)}</div>` : ""}
     <label class="field"><span>Subject</span><input type="text" id="rep_subj" value="${esc(d.subject)}"></label>
     <label class="field" style="margin-top:10px"><span>Body</span><textarea id="rep_body" style="min-height:420px;font-family:var(--font);line-height:1.5">${esc(d.body)}</textarea></label>
     <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px"><button class="btn sm primary" data-act="repcopy">Copy</button><button class="btn sm" data-act="repmail">Open in email</button><button class="btn sm" data-act="repsave">Save to site</button></div></div>
     ${d.placeholders?.length ? `<div class="card pad" style="margin-top:14px"><h3 style="margin-bottom:6px">Complete before sending</h3><div style="display:flex;gap:6px;flex-wrap:wrap">${d.placeholders.map(p => `<span class="chip med">${esc(p)}</span>`).join("")}</div></div>` : ""}
     ${d.checks?.length ? `<div class="card pad" style="margin-top:14px"><h3 style="margin-bottom:6px">Check the facts</h3>${d.checks.map(c => `<div class="flag" style="padding:5px 0">${esc(c)}</div>`).join("")}</div>` : ""}
     ${d.evidence?.length ? `<div class="card pad" style="margin-top:14px"><h3 style="margin-bottom:6px">Documents to attach</h3>${d.evidence.map(c => `<div class="flag" style="padding:4px 0">${esc(c)}</div>`).join("")}</div>` : ""}
     <div class="card pad" style="margin-top:14px"><h3 style="margin-bottom:6px">Guidance applied</h3>${d.guidance.map(g => `<div style="padding:3px 0"><a href="#" ${ext(g.url)}>${esc(g.topic)}</a></div>`).join("")}</div>`
      : `<div class="card pad"><div class="empty">Paste a message and press Draft reply.<div class="tsub" style="margin-top:8px">Topics covered: highways, drainage, ecology and net gain, heritage, contamination, design, affordable housing, viability, planning obligations, amenity, trees, fire safety, timing and policy.</div></div></div>`}</div></div>`;
}
async function loadReplies() { const id = drawer.id; try { const r = await api("/api/replies", { id, op: "list" }); if (drawer?.id === id) { repState().hist = r.items; if (drawer.tab === "replies") paintDrawer(true); } } catch { } }
const keepRep = () => { const R = repState(); if ($("#rep_in")) R.text = $("#rep_in").value; if ($("#rep_tone")) R.tone = $("#rep_tone").value; if ($("#rep_subj") && R.draft) { R.draft.subject = $("#rep_subj").value; R.draft.body = $("#rep_body").value; } };

/* ---------------- report ---------------- */
function tReport() {
  const s = drawer.site, st = drawer.ev.strategy, u = `/report/${encodeURIComponent(s.id)}?strategy=${st}`;
  return `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"><button class="btn sm primary" data-act="repprint">Print or save as PDF</button><button class="btn sm" data-act="repwin" data-u="${esc(u)}">Open in a window</button><button class="btn sm" data-act="deck" data-id="${esc(s.id)}">${I.deck}Investor deck</button><button class="btn sm" data-act="cpaper" data-id="${esc(s.id)}">${I.doc}Committee paper</button></div>
   <iframe id="rep_frame" src="${u}" style="width:100%;height:1500px;border:1px solid var(--line);border-radius:12px;background:#fff"></iframe>`;
}

/* ---------------- registries and hooks ---------------- */
Object.assign(window.EXTRA_TABS, { scenarios: tScenarios, replies: tReplies, report: tReport });
const _bind5 = window.bindV04Tab;
window.bindV04Tab = function () {
  _bind5?.();
  if (drawer.tab === "scenarios" && drawer.scn && $("#scn_t")) $$("#scn_t input").forEach(i => i.oninput = runScn);
  if (drawer.tab === "replies") { $("#rep_in")?.addEventListener("input", keepRep); $("#rep_tone")?.addEventListener("change", keepRep); }
  const s = drawer.site;
  if (drawer.tab === "overview" && !s.constraints_result && s.lat != null && !s.demo && !drawer._cAuto) { drawer._cAuto = true; runConstraints(true); }
};
const _rd5 = refreshDrawer;
refreshDrawer = async function (soft) { if (drawer && !drawer.keepScn) drawer.scn = null; return _rd5(soft); };
const _dActions = drawerActions;
drawerActions = function (s) { return _dActions(s) + `<button class="btn sm" data-act="deck" data-id="${esc(s.id)}" title="Investor deck">${I.deck}Deck</button>`; };

document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t) return;
  const act = t.dataset.act;
  try {
    if (act === "newsrefresh") { loadNews(true); toast("Checking for planning activity"); }
    else if (act === "feedall") { await api("/api/feed/seen", { all: true }); await load(); await loadFeed(); }
    else if (act === "feedopen") {
      $("#notif").classList.remove("on"); await api("/api/feed/seen", { ids: [t.dataset.id] }); loadFeed();
      if (t.dataset.site) { await load(); openSite(t.dataset.site, kindTab(t.dataset.kind)); } else if (t.dataset.kind === "debt") { view = "portfolio"; render(); }
    }
    else if (act === "viewapply") { const v = D.views.find(x => x.id === t.dataset.id); if (v) { Object.assign(F, { q: "", stage: "active", src: "all", viable: false, strat: "all", fit: false, region: "all", minunits: 0 }, Object.fromEntries(VKEYS.filter(k => k in v.filters).map(k => [k, v.filters[k]]))); if (v.filters.sortKey) { sortKey = v.filters.sortKey; sortDir = v.filters.sortDir || -1; } $("#q").value = F.q; render(); } }
    else if (act === "viewdel") { e.stopPropagation(); const r = await api("/api/views", { op: "delete", vid: t.dataset.id }); D.views = r.views; render(); }
    else if (act === "viewsave") viewModal();
    else if (act === "viewgo") { const name = $("#vw_name").value.trim(); if (!name) return toast("Give the view a name"); const r = await api("/api/views", { view: { name, filters: curFilters() } }); D.views = r.views; closeModal(); render(); toast("View saved"); }
    else if (act === "cnrun") runConstraints(false);
    else if (act === "scnadd") { const l = readScn(); l.push({ name: `Scenario ${l.length}`, sales: 0, rent: 0, build: 0, yield_bps: 0, delay: 0, land: 0 }); await loadScenarios(l); paintDrawer(true); }
    else if (act === "scndel") { const l = readScn().filter((_, k) => k !== +t.dataset.i); await loadScenarios(l); paintDrawer(true); }
    else if (act === "scnreset") { const r = await api("/api/scenarios", { id: drawer.id, strategy: drawer.ev.strategy, scenarios: [{ id: "base", name: "Base case" }, { id: "down", name: "Downside", sales: -7.5, rent: -5, build: 8, yield_bps: 25, delay: 6 }, { id: "sev", name: "Severe", sales: -15, rent: -10, build: 12, yield_bps: 50, delay: 12 }, { id: "up", name: "Upside", sales: 5, rent: 4, build: -3, yield_bps: -15 }], save: true }); drawer.scn = r; paintDrawer(true); await load(false); }
    else if (act === "scnsave") { await loadScenarios(readScn(), true); toast("Scenarios saved to the site"); }
    else if (act === "repkind") { keepRep(); repState().kind = t.dataset.k; repState().draft = null; paintDrawer(true); }
    else if (act === "repdraft") {
      keepRep(); const R = repState(); if (!R.text.trim() && R.kind !== "s106") return toast("Paste the message you are replying to");
      t.disabled = true; t.textContent = "Drafting"; try { R.draft = await api("/api/replies", { id: drawer.id, kind: R.kind, text: R.text, tone: R.tone }); } finally { paintDrawer(true); }
    }
    else if (act === "repcopy") { keepRep(); const d = repState().draft; try { await navigator.clipboard.writeText(`Subject: ${d.subject}\n\n${d.body}`); toast("Copied"); } catch { $("#rep_body").select(); document.execCommand("copy"); toast("Copied"); } }
    else if (act === "repmail") { keepRep(); const d = repState().draft, to = drawer.ev.contact?.best_email || ""; openUrl(`mailto:${to}?subject=${encodeURIComponent(d.subject)}&body=${encodeURIComponent(d.body)}`); }
    else if (act === "repsave") { keepRep(); const R = repState(), d = R.draft; await api("/api/replies", { id: drawer.id, op: "save", reply: { kind: R.kind, subject: d.subject, body: d.body, incoming: R.text, topics: d.topics, ref: d.meta?.ref } }); R.hist = null; toast("Saved to this site"); paintDrawer(true); }
    else if (act === "repload") { const h = repState().hist.find(x => x.id === t.dataset.id); if (h) { const R = repState(); R.kind = h.kind; R.text = h.incoming || ""; R.draft = { subject: h.subject, body: h.body, topics: h.topics || [], placeholders: [...new Set((h.body.match(/\[[^\]\n]{2,40}\]/g) || []))], evidence: [], checks: [], guidance: [], mode: "saved" }; paintDrawer(true); } }
    else if (act === "repdel") { await api("/api/replies", { id: drawer.id, op: "delete", rid: t.dataset.id }); repState().hist = null; paintDrawer(true); }
    else if (act === "repprint") { const f = $("#rep_frame"); if (D.hosted) f.contentWindow.print(); else { openUrl(location.origin + f.getAttribute("src")); } }
    else if (act === "repwin") openUrl(D.hosted ? t.dataset.u : location.origin + t.dataset.u);
    else if (act === "deck") { e.stopPropagation(); const id = t.dataset.id, s = sites().find(x => x.id === id); if (D.hosted) { download(`/download/deck/${encodeURIComponent(id)}.pptx?strategy=${ev(s).strategy}`); toast("Building the investor deck"); } else { const r = await api("/api/deck/save", { id, strategy: ev(s).strategy }); toast(`Saved to Downloads: ${r.name}`); } }
  } catch (err) { toast(err.message); if (t.disabled) t.disabled = false; }
});
loadFeed();
