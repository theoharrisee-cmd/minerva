/* easyDevelopment v0.4: shortlist and alerts, compare, portfolio, structure, diligence, land, comparable schemes, cost benchmarks. */
Object.assign(I, {
  shortlist: '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>',
  compare: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="7" height="16" rx="1.5"/><rect x="14" y="4" width="7" height="16" rx="1.5"/><path d="M6.5 9h0M17.5 9h0M6.5 13h0M17.5 13h0"/></svg>',
  portfolio: '<svg viewBox="0 0 24 24"><path d="M3 20h18M6 20V10M11 20V4M16 20v-7M21 20V8"/></svg>',
  land: '<svg viewBox="0 0 24 24"><path d="M3 7l6-3 6 3 6-3v13l-6 3-6-3-6 3z"/><path d="M9 4v13M15 7v13"/></svg>',
  bell: '<svg viewBox="0 0 24 24"><path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7M10 20a2 2 0 0 0 4 0"/></svg>',
  doc: '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>',
});
NAV.splice(3, 0, ["shortlist", "Shortlist"], ["compare", "Compare"], ["portfolio", "Portfolio"], ["land", "Landowners"]);
Object.assign(TITLES, {
  shortlist: ["Shortlist", "Sites you are following, with alerts on price, planning and key dates"],
  compare: ["Compare", "Up to four sites side by side"],
  portfolio: ["Portfolio", "Existing schemes, capital deployed and what is left to invest"],
  land: ["Landowners", "Parcels, owners and approaches across every site"],
});
const FOOT = () => D?.cost_footnote || "";
const gbp = x => x == null || isNaN(x) ? "" : Math.round(x).toLocaleString("en-GB");
const nv = id => { const e = $("#" + id); return !e || e.value === "" ? null : +e.value; };
const debounce = (fn, ms = 350) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const tsub = (t, st = "") => `<div class="tsub" style="${st}">${t}</div>`;
const flash = (el, msg) => { if (el) el.textContent = msg; };

/* ---------------- shortlist star, compare tick, drawer actions ---------------- */
let CMP = [];
function rowTools(s) {
  return `<button class="ghost star ${s._watch ? "on" : ""}" data-act="star" data-id="${esc(s.id)}" title="${s._watch ? "Remove from shortlist" : "Add to shortlist"}">${I.shortlist}</button><input type="checkbox" data-act="cmp" data-id="${esc(s.id)}" title="Add to compare" ${CMP.includes(s.id) ? "checked" : ""}>`;
}
function drawerActions(s) {
  return `<button class="btn sm ${s._watch ? "primary" : ""}" data-act="star" data-id="${esc(s.id)}">${I.shortlist}${s._watch ? "Shortlisted" : "Shortlist"}</button><button class="btn sm" data-act="cpaper" data-id="${esc(s.id)}">${I.doc}Committee paper</button>`;
}

/* ---------------- compare ---------------- */
function vCompare() {
  const rows = CMP.map(id => sites().find(s => s.id === id)).filter(Boolean);
  const free = sites().filter(s => !CMP.includes(s.id) && s.stage !== "Rejected").sort((a, b) => a.name.localeCompare(b.name));
  const a = s => ev(s).appraisal, ok = s => a(s) && !a(s).incomplete;
  const M = [
    ["Score", s => ev(s).score.score, x => x, "hi"],
    ["Mandate fit", s => ev(s).fit?.active && !ev(s).fit.hard_fail ? ev(s).fit.score : null, x => x, "hi"],
    ["Strategy", null, s => D.strategies[ev(s).strategy]],
    ["Stage", null, s => s.stage],
    ["Planning", null, s => s.planning_status || "Unknown"],
    ["Region", null, s => s._region || ""],
    ["Asking price", s => s.asking_price, money, "lo"],
    ["Units", s => ok(s) ? a(s).units : null, x => x],
    ["Exit value (GDV)", s => ok(s) ? a(s).gdv : null, money],
    ["Total cost", s => ok(s) ? a(s).total_cost : null, money],
    ["Maximum bid", s => ok(s) ? a(s).max_bid : null, money, "hi"],
    ["Headroom to asking", s => ok(s) ? a(s).headroom_vs_asking : null, x => pct(x, 0), "hi"],
    ["Profit on GDV or cost", s => ok(s) ? (a(s).profit_basis === "gdv" ? a(s).profit_on_gdv : a(s).profit_on_cost) : null, (x, s) => `${pct(x)} on ${a(s).profit_basis === "gdv" ? "GDV" : "cost"}`, "hi"],
    ["Levered IRR", s => ok(s) ? a(s).irr_levered : null, x => pct(x, 1), "hi"],
    ["Equity multiple", s => ok(s) ? a(s).equity_multiple : null, x => x.toFixed(2) + "x", "hi"],
    ["Peak equity", s => ok(s) ? a(s).peak_equity : null, money, "lo"],
    ["Yield on cost", s => ok(s) && ev(s).strategy !== "develop_sell" ? a(s).yield_on_cost : null, x => pct(x, 2), "hi"],
    ["Months from purchase to exit", s => ok(s) ? a(s).months_land : null, x => Math.round(x), "lo"],
    ["High severity flags", s => ev(s).flags.filter(f => f.severity === "High").length, x => x, "lo"],
    ["Diligence complete", s => s._dd ? s._dd.pct : null, x => x + "%", "hi"],
    ["Documents on file", s => s._ndocs, x => x],
  ];
  const best = M.map(([, f, , dir]) => {
    if (!dir || !f) return -1; const v = rows.map(f); const ok2 = v.filter(x => x != null); if (ok2.length < 2) return -1;
    const t = dir === "hi" ? Math.max(...ok2) : Math.min(...ok2); if (ok2.every(x => x === t)) return -1; return v.indexOf(t);
  });
  $("#view").innerHTML = `<div class="toolbar">
    ${rows.map(s => `<span class="chip acc" style="padding:5px 6px 5px 11px">${esc(s.name.slice(0, 32))}<button class="ghost" style="padding:2px" data-act="cmprm" data-id="${esc(s.id)}">${I.x}</button></span>`).join("")}
    ${rows.length < 4 ? `<select id="cmpadd" style="width:auto;max-width:300px"><option value="">Add a site</option>${free.map(s => `<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("")}</select>` : ""}
    <span style="flex:1"></span>${rows.length ? '<button class="btn sm" data-act="cmpclear">Clear</button>' : ""}</div>
   ${rows.length < 2 ? `<div class="card empty">Pick at least two sites. You can also tick the box next to any site in the Sites table.</div>` : ""}
   ${rows.length ? `<div class="card tablewrap"><table class="cmp"><thead><tr><th></th>${rows.map(s => `<th><div style="display:flex;gap:8px;align-items:center;margin-bottom:6px">${grade(ev(s).score.grade)}<div><div style="font-weight:640">${esc(s.name)}</div><div class="tsub" style="font-weight:400">${esc(s.address || "")}</div></div></div><div style="display:flex;gap:6px"><button class="btn sm" data-act="open" data-id="${esc(s.id)}">Open</button><button class="btn sm" data-act="cpaper" data-id="${esc(s.id)}">Paper</button></div></th>`).join("")}</tr></thead><tbody>
    ${M.map(([l, f, fmt], i) => `<tr><td>${l}</td>${rows.map((s, j) => { if (!f) return `<td>${esc(fmt(s))}</td>`; const v = f(s); return `<td class="${best[i] === j ? "best" : ""}">${v == null ? '<span class="tsub">n/a</span>' : esc(fmt(v, s))}</td>`; }).join("")}</tr>`).join("")}
    </tbody></table></div><div class="fn">The shaded cell marks the strongest figure in each row where higher or lower is clearly better.</div>` : ""}`;
  $("#cmpadd")?.addEventListener("change", e => { if (e.target.value) { CMP.push(e.target.value); vCompare(); } });
}

/* ---------------- shortlist and alerts ---------------- */
const EVI = { price_change: "£", listing_status: "!", listing_gone: "!", listing_check: "?", planning_new: "P", planning_change: "P", date: "D", activity: "A", shortlist: "S", check_error: "?" };
function vShortlist() {
  const w = sites().filter(s => s._watch), al = D.alerts;
  const feed = sites().flatMap(s => (s._events || []).map(e => ({ ...e, site: s }))).sort((a, b) => b.ts.localeCompare(a.ts)).slice(0, 60);
  const unseen = feed.filter(e => !e.seen).length;
  $("#view").innerHTML = `<div class="grid" style="grid-template-columns:minmax(0,1.6fr) minmax(320px,1fr);align-items:start">
   <div class="grid">
    <div class="card"><div class="h"><h3>Shortlisted sites</h3><span class="m">${w.length}</span></div><div class="list">
     ${w.map(s => `<div class="row" data-act="open" data-id="${esc(s.id)}">${grade(ev(s).score.grade)}<div class="grow"><div class="t">${s._unseen ? '<i class="dot-un"></i>' : ""}${esc(s.name)}</div><div class="m">${esc(s.stage)} · ${money(s.asking_price)} · ${s.watch?.last_check ? "checked " + when(s.watch.last_check) : "not checked yet"}</div></div><button class="ghost star on" data-act="star" data-id="${esc(s.id)}" title="Remove">${I.shortlist}</button></div>`).join("") || '<div class="empty">No sites yet. Press the star beside any site, or use the Shortlist button in its workbench.</div>'}
    </div></div>
    <div class="card"><div class="h"><h3>Activity</h3><span style="display:flex;gap:8px;align-items:center"><span class="m">${unseen ? unseen + " new" : "up to date"}</span>${unseen ? '<button class="btn sm" data-act="seenall">Mark all read</button>' : ""}</span></div>
     ${feed.map(e => `<div class="ev ${e.level === "important" ? "imp" : ""}" data-act="open" data-id="${esc(e.site.id)}"><div class="ic">${EVI[e.kind] || "-"}</div><div style="flex:1;min-width:0"><div style="font-weight:600">${e.seen ? "" : '<i class="dot-un"></i>'}${esc(e.title)}</div>${e.detail ? `<div class="tsub" style="color:var(--ink2)">${esc(e.detail)}</div>` : ""}<div class="tsub">${esc(e.site.name)} · ${when(e.ts)}${e.sent ? " · emailed" : ""}</div></div></div>`).join("") || '<div class="empty">Nothing has happened yet.</div>'}</div>
   </div>
   <div class="grid" style="position:sticky;top:0">
    <div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center"><h3>Email alerts</h3><button class="switch ${al.enabled ? "on" : ""}" id="al_enabled" type="button"></button></div>
     ${tsub("A digest goes out when something changes on a shortlisted site. Checks cover the agent's listing page, planning applications published to planning.data.gov.uk, and your key dates.", "margin:6px 0 12px")}
     <label class="field"><span>Send to</span><input type="text" id="al_to" value="${esc(al.to)}" placeholder="you@example.com"></label>
     <div class="two" style="margin-top:10px"><label class="field"><span>Check every</span><select id="al_int">${[1, 3, 6, 12, 24].map(h => `<option value="${h}" ${+al.interval_hours === h ? "selected" : ""}>${h} hour${h > 1 ? "s" : ""}</option>`).join("")}</select></label>
      <label class="field"><span>Email me about</span><select id="al_level"><option value="info" ${al.digest_min_level === "info" ? "selected" : ""}>Everything</option><option value="important" ${al.digest_min_level === "important" ? "selected" : ""}>Important changes only</option></select></label></div>
     <div class="kl" style="margin:16px 0 6px">Outgoing mail server (SMTP)</div>
     <div class="two"><label class="field"><span>Server</span><input type="text" id="al_host" value="${esc(al.smtp_host)}" placeholder="smtp.gmail.com"></label><label class="field"><span>Port</span><input type="number" id="al_port" value="${al.smtp_port}"></label></div>
     <div class="two" style="margin-top:10px"><label class="field"><span>Username</span><input type="text" id="al_user" value="${esc(al.smtp_user)}"></label><label class="field"><span>Password ${al.has_password ? '<span class="chip ok">saved</span>' : ""}</span><input type="password" id="al_pass" placeholder="${al.has_password ? "Saved. Paste to replace" : ""}"></label></div>
     <label class="field" style="margin-top:10px"><span>From address (optional)</span><input type="text" id="al_from" value="${esc(al.from)}"></label>
     <label class="tog" style="margin-top:10px"><span>Use STARTTLS</span><button class="switch ${al.smtp_tls ? "on" : ""}" id="al_tls" type="button"></button></label>
     ${tsub("Gmail and Outlook need an app password rather than your normal one.", "margin-top:8px")}
     <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap"><button class="btn primary" data-act="alsave">Save</button><button class="btn" data-act="altest">Send test email</button><button class="btn" data-act="alrun" ${al.running ? "disabled" : ""}>${al.running ? "Checking" : "Check now"}</button></div>
     <div id="al_msg" class="tsub" style="margin-top:10px">${al.last_run ? "Last check " + when(al.last_run) + (al.last_sent ? ", last email " + when(al.last_sent) : "") : "No checks have run yet."}${al.last_error ? `<div class="neg">${esc(al.last_error)}</div>` : ""}</div></div>
    ${D.hosted ? `<div class="notice">On Render's free plan the service sleeps when idle, so scheduled checks only run while it is awake. A paid instance or an uptime monitor pinging /healthz keeps it running.</div>` : ""}
   </div></div>`;
  $$(".switch[id^=al_]").forEach(b => b.onclick = () => b.classList.toggle("on"));
}
async function saveAlerts() {
  await api("/api/alerts/settings", { enabled: $("#al_enabled").classList.contains("on"), to: $("#al_to").value.trim(), from: $("#al_from").value.trim(), interval_hours: $("#al_int").value, digest_min_level: $("#al_level").value,
    smtp_host: $("#al_host").value.trim(), smtp_port: $("#al_port").value, smtp_user: $("#al_user").value.trim(), smtp_password: $("#al_pass").value, smtp_tls: $("#al_tls").classList.contains("on") });
}
async function pollChecks() {
  const t = setInterval(async () => {
    const r = await api("/api/alerts/status");
    if (!r.running) { clearInterval(t); await load(); toast(`Check finished: ${r.last?.new_events || 0} new update${r.last?.new_events === 1 ? "" : "s"}${r.last?.emailed ? `, ${r.last.emailed} emailed` : ""}${r.error ? `. Email problem: ${r.error}` : ""}`); }
  }, 1500);
}

/* ---------------- build cost card (appraisal tab) and settings benchmark ---------------- */
function costCard() {
  const c = drawer.ev.costs; if (!c) return "";
  const cur = +effective(drawer.site, "build_psf");
  return `<div class="card pad" style="margin-top:14px"><h3 style="margin-bottom:4px">Build cost check</h3>${tsub(`${esc(c.label)}, ${esc(c.region)}. £ per sq ft of gross internal area before externals and fees.`, "margin-bottom:10px")}
   <div class="stat4" style="grid-template-columns:repeat(3,1fr);margin:0 0 10px"><div><div class="kl">Low</div><b>£${c.low}*</b></div><div><div class="kl">Mid</div><b>£${c.mid}*</b></div><div><div class="kl">High</div><b>£${c.high}*</b></div></div>
   ${cur ? `<div class="tsub">You are using £${Math.round(cur)}. ${cur < c.low ? "That sits below the low end." : cur > c.high ? "That sits above the high end." : "That sits inside the range."}</div>` : ""}
   <button class="btn sm" style="margin-top:10px" data-act="usecost" data-v="${c.mid}" ${c.strategy === "value_add" ? 'data-k="refurb_psf"' : 'data-k="build_psf"'}>Use £${c.mid}* in the appraisal</button>
   <div class="fn">${esc(FOOT())}</div></div>`;
}
function costSettingsCard() {
  const rg = COSTREG || "";
  return `<div class="card pad"><h3 style="margin-bottom:4px">Build cost benchmarks*</h3>${tsub("£ per sq ft GIA by scheme type. Choose a region to see it adjusted.", "margin-bottom:10px")}
   <select id="cost_reg" style="margin-bottom:10px"><option value="">England, outside London</option>${D.regions.map(r => `<option ${rg === r ? "selected" : ""}>${esc(r)}</option>`).join("")}</select>
   <table><thead><tr><th>Type</th><th class="num">Low</th><th class="num">Mid</th><th class="num">High</th></tr></thead><tbody id="cost_rows"><tr><td colspan="4" class="tsub">Loading</td></tr></tbody></table><div class="fn">${esc(FOOT())}</div></div>`;
}
let COSTREG = "";
async function loadCostTable() {
  const r = await api("/api/costs", { region: COSTREG || null }); const b = $("#cost_rows"); if (!b) return;
  b.innerHTML = r.table.map(x => `<tr style="cursor:default"><td>${esc(x.label)}</td><td class="num">£${x.low}*</td><td class="num">£${x.mid}*</td><td class="num">£${x.high}*</td></tr>`).join("");
}

/* ---------------- structure tab: waterfall and lender ---------------- */
const STX = {};
function tStructure() {
  const s = drawer.site, st = drawer.struct;
  if (!st) { loadStructure(); return '<div class="empty">Working out the structure</div>'; }
  if (st.incomplete) return `<div class="notice">Add a price and site size before the funding structure can be tested.</div>`;
  const t = st.terms, cv = st.covenants;
  return `<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start">
   <div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><h3>Equity waterfall</h3><span class="chip acc">peak equity ${money(st.peak_equity)}</span></div>
    ${tsub("Splits the equity cash flows between the investor and the sponsor. Capital goes in pro rata. Distributions clear each hurdle in turn, and above each hurdle the sponsor takes the promote shown.", "margin-bottom:12px")}
    <label class="field" style="max-width:220px"><span>Sponsor co-investment (% of equity)</span><input type="number" step="any" id="wf_co" value="${t.sponsor_coinvest}"></label>
    <div class="kl" style="margin:14px 0 6px">Hurdles</div>
    <table id="wf_tiers"><thead><tr><th>Above IRR (% pa)</th><th>Sponsor promote (%)</th><th></th></tr></thead><tbody>${t.tiers.map((x, i) => `<tr style="cursor:default"><td><input type="number" step="any" data-wt="hurdle" value="${x.hurdle}"></td><td><input type="number" step="any" data-wt="promote" value="${x.promote}"></td><td><button class="ghost" data-act="wfdel" data-i="${i}">${I.x}</button></td></tr>`).join("")}</tbody></table>
    <div style="display:flex;gap:8px;margin-top:10px"><button class="btn sm" data-act="wfadd">Add hurdle</button><button class="btn sm primary" data-act="wfsave">Save to site</button></div>
    <div id="wf_res" style="margin-top:14px">${wfResult(st.waterfall)}</div></div>
   <div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><h3>Lender view</h3><span class="chip ${st.lender.pass_all ? "ok" : "hi"}">${st.lender.pass_all ? "All tests pass" : "Breach"}</span></div>
    ${tsub("Debt sized from the appraisal cash flow, tested against covenants you can change.", "margin-bottom:12px")}
    <div class="stat4" style="grid-template-columns:repeat(2,1fr)">${kpi("Senior debt at peak", money(st.lender.metrics.senior), `${st.lender.metrics.senior_ltc.toFixed(0)}% of cost`)}${kpi("Mezzanine at peak", money(st.lender.metrics.mezz), st.lender.metrics.mezz ? `${st.lender.metrics.total_ltc.toFixed(0)}% total of cost` : "none in the appraisal")}</div>
    <table id="lv_tbl"><thead><tr><th>Test</th><th class="num">Position</th><th class="num">Limit</th><th></th></tr></thead><tbody>${lenderRows(st.lender)}</tbody></table>
    ${st.lender.metrics.sales_cover != null ? `<div class="tsub" style="margin-top:8px">Net sales proceeds cover peak debt ${st.lender.metrics.sales_cover.toFixed(2)} times.</div>` : ""}
    <div class="tsub" style="margin-top:6px">Interest over the life of the loan: ${money(st.lender.metrics.interest)}.</div>
    <button class="btn sm primary" style="margin-top:10px" data-act="cvsave">Save limits to site</button></div></div>`;
}
const CVKEYS = { "Senior loan to cost": "max_senior_ltc", "Total loan to cost": "max_total_ltc", "Senior loan to GDV": "max_senior_ltgdv", "Total loan to GDV": "max_total_ltgdv", "Profit on cost": "min_profit_on_cost", "Interest cover on stabilised income": "min_icr", "Debt yield": "min_debt_yield" };
const lenderRows = l => l.tests.map(t => `<tr style="cursor:default"><td>${esc(t.name)}</td><td class="num">${t.value.toFixed(1)}${t.unit}</td><td class="num"><span class="tsub">${t.kind}</span> <input type="number" step="any" style="width:76px;padding:4px 6px" data-cv="${CVKEYS[t.name]}" value="${t.limit}"></td><td><span class="chip ${t.ok ? "ok" : "hi"}">${t.ok ? "Pass" : "Breach"}</span></td></tr>`).join("");
function wfResult(w) {
  const r = (n, x) => `<tr style="cursor:default"><td><b>${n}</b></td><td class="num">${money(x.invested)}</td><td class="num">${money(x.profit)}</td><td class="num">${pct(x.irr)}</td><td class="num">${x.multiple ? x.multiple.toFixed(2) + "x" : "n/a"}</td></tr>`;
  const tot = w.total.profit, inv = w.investor.profit, sp = w.sponsor.profit;
  return `<table><thead><tr><th></th><th class="num">Invested</th><th class="num">Profit</th><th class="num">IRR</th><th class="num">Multiple</th></tr></thead><tbody>${r("All equity", w.total)}${r("Investor", w.investor)}${r("Sponsor", w.sponsor)}</tbody></table>
   ${tot > 0 ? `<div class="stack" style="margin-top:12px"><i style="width:${inv / tot * 100}%;background:var(--ink)" title="Investor"></i><i style="width:${(sp - w.promote) / tot * 100}%;background:#FFA366" title="Sponsor capital"></i><i style="width:${w.promote / tot * 100}%;background:var(--accent)" title="Promote"></i></div><div class="legend2"><span><i style="background:var(--ink)"></i>Investor ${money(inv)}</span><span><i style="background:#FFA366"></i>Sponsor return on capital ${money(sp - w.promote)}</span><span><i style="background:var(--accent)"></i>Promote ${money(w.promote)} (${(w.promote_share_of_profit * 100).toFixed(0)}% of profit)</span></div>` : tsub("No profit to share at these assumptions.", "margin-top:10px")}`;
}
async function loadStructure(body) {
  try { const r = await api("/api/structure", { id: drawer.id, strategy: drawer.ev.strategy, ...(body || {}) }); drawer.struct = r; if (drawer.tab === "structure" && !body) paintDrawer(true); return r; }
  catch (e) { toast(e.message); }
}
function readTerms() { return { sponsor_coinvest: nv("wf_co") ?? 10, tiers: $$("#wf_tiers tbody tr").map(tr => ({ hurdle: +$('[data-wt="hurdle"]', tr).value, promote: +$('[data-wt="promote"]', tr).value })) }; }
function readCov() { const o = {}; $$("[data-cv]").forEach(i => { if (i.value !== "") o[i.dataset.cv] = +i.value; }); return o; }
const recalcStructure = debounce(async () => {
  const r = await loadStructure({ terms: readTerms(), covenants: readCov() }); if (!r) return;
  drawer.struct = { ...drawer.struct, ...r }; $("#wf_res").innerHTML = wfResult(r.waterfall); $("#lv_tbl tbody").innerHTML = lenderRows(r.lender);
  bindStructureInputs();
});
function bindStructureInputs() { $$("#wf_co,[data-wt],[data-cv]").forEach(i => i.oninput = recalcStructure); }

/* ---------------- diligence tab ---------------- */
function tDiligence() {
  const d = drawer.dd;
  if (!d) { loadDD(); return '<div class="empty">Loading the checklist</div>'; }
  const cats = [...new Set(d.items.map(i => i.category))], sm = d.summary;
  return `<div class="card pad" style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap"><div><h3>Due diligence</h3>${tsub("The checklist was set up from what the file already shows. Change any status, owner or date.", "max-width:520px")}</div>
    <div style="min-width:240px"><div style="display:flex;justify-content:space-between;margin-bottom:6px"><b id="dd_pct">${sm.pct}% complete</b><span class="tsub" id="dd_sub">${sm.done} of ${sm.total}${sm.issues ? ` · ${sm.issues} issue${sm.issues > 1 ? "s" : ""}` : ""}${sm.overdue ? ` · ${sm.overdue} overdue` : ""}</span></div><div class="bar"><i id="dd_bar" style="width:${sm.pct}%"></i></div></div></div></div>
   ${cats.map(c => `<div class="sec"><h3>${esc(c)}</h3><span class="m">${d.items.filter(i => i.category === c && i.status === "Done").length} of ${d.items.filter(i => i.category === c && i.status !== "Not applicable").length}</span></div>
    <div class="card tablewrap" style="max-height:none"><table><tbody>${d.items.filter(i => i.category === c).map(i => `<tr style="cursor:default" data-di="${i.id}"><td style="min-width:260px">${esc(i.item)}${i.note ? `<div class="tsub">${esc(i.note)}</div>` : ""}</td>
      <td style="width:160px"><select data-df="status" style="min-width:148px">${D.dd_statuses.map(x => `<option ${x === i.status ? "selected" : ""}>${x}</option>`).join("")}</select></td>
      <td style="width:130px"><input type="text" data-df="owner" placeholder="Owner" value="${esc(i.owner)}"></td><td style="width:140px"><input type="text" data-df="due" placeholder="YYYY-MM-DD" value="${esc(i.due)}"></td><td style="width:34px"><button class="ghost" data-act="ddnote" data-id="${i.id}" title="Note">&#9998;</button></td>${i.custom ? `<td style="width:34px"><button class="ghost" data-act="dddel" data-id="${i.id}">${I.x}</button></td>` : ""}</tr>`).join("")}</tbody></table></div>`).join("")}
   <div style="margin-top:14px"><button class="btn" data-act="ddadd">Add an item</button></div>`;
}
async function loadDD() { try { drawer.dd = await api("/api/dd/get", { id: drawer.id }); if (drawer.tab === "diligence") paintDrawer(true); } catch (e) { toast(e.message); } }
const saveDD = debounce(async () => { const r = await api("/api/dd/save", { id: drawer.id, items: drawer.dd.items }); drawer.dd.summary = r.summary; const s = sites().find(x => x.id === drawer.id); if (s) s._dd = r.summary; const sm = r.summary; flash($("#dd_pct"), sm.pct + "% complete"); flash($("#dd_sub"), `${sm.done} of ${sm.total}${sm.issues ? ` · ${sm.issues} issue${sm.issues > 1 ? "s" : ""}` : ""}${sm.overdue ? ` · ${sm.overdue} overdue` : ""}`); const b = $("#dd_bar"); if (b) b.style.width = sm.pct + "%"; }, 500);

/* ---------------- land tab and landowners view ---------------- */
function tLand() {
  const L = drawer.land;
  if (!L) { loadLand(); return '<div class="empty">Loading parcels</div>'; }
  const sm = L.summary, ps = L.parcels, today = new Date().toISOString().slice(0, 10);
  return `<div class="stat4">${kpi("Land secured", `${sm.secured_pct.toFixed(0)}%`, `${sm.secured_ha.toFixed(2)} of ${sm.target_ha ? sm.target_ha.toFixed(2) : "?"} ha`)}${kpi("Agreed or secured", `${sm.committed_pct.toFixed(0)}%`, "heads agreed, options and contracts")}${kpi("Blended land price", sm.blended_per_ha ? money(sm.blended_per_ha) + "/ha" : "n/a", `${money(sm.price_total)} across live parcels`)}${kpi("Open ransom risk", sm.ransom, sm.unapproached ? `${sm.unapproached} not yet approached` : "all approached")}</div>
   <div class="card pad" style="margin-bottom:14px"><div class="bar"><i style="width:${Math.min(100, sm.secured_pct)}%"></i></div>${tsub("Assembly is only as strong as the last parcel. Ransom strips and hold-outs are marked below.", "margin-top:8px")}</div>
   <div class="sec"><h3>Parcels</h3><button class="btn sm primary" data-act="parcel" data-i="-1">Add parcel</button></div>
   <div class="card tablewrap" style="max-height:none"><table><thead><tr><th>Parcel</th><th>Owner</th><th>Status</th><th class="num">Area (ha)</th><th class="num">Ask</th><th class="num">Offer</th><th>Next action</th><th></th></tr></thead><tbody>
   ${ps.map((p, i) => `<tr style="cursor:default"><td><b>${esc(p.ref || "Parcel")}</b>${p.ransom ? ' <span class="chip hi">ransom</span>' : ""}<div class="tsub">${esc(p.address)}</div></td><td>${esc(p.owner)}<div class="tsub">${esc(p.owner_type)}${p.contact_name ? " · " + esc(p.contact_name) : ""}</div></td><td><span class="chip ${["Option signed", "Contracted"].includes(p.status) ? "ok" : p.status === "Declined" ? "hi" : ["In talks", "Heads agreed", "Approached"].includes(p.status) ? "med" : ""}">${esc(p.status)}</span></td>
     <td class="num">${p.area_ha ?? ""}</td><td class="num">${p.ask ? money(p.ask) : ""}</td><td class="num">${p.offer ? money(p.offer) : ""}</td><td>${esc(p.next_action)}${p.next_date ? `<div class="tsub ${p.next_date < today && !["Option signed", "Contracted", "Declined"].includes(p.status) ? "od" : ""}">${fdate(p.next_date)}</div>` : ""}</td>
     <td style="white-space:nowrap"><button class="ghost" data-act="parcelletter" data-pid="${p.id}" title="Draft approach letter">${I.doc}</button><button class="ghost" data-act="parcel" data-i="${i}" title="Edit">&#9998;</button><button class="ghost" data-act="parceldel" data-i="${i}">${I.x}</button></td></tr>`).join("") || `<tr style="cursor:default"><td colspan="8"><div class="empty">No parcels yet. Add each ownership so you can see how much of the site you control.</div></td></tr>`}</tbody></table></div>`;
}
async function loadLand() { try { drawer.land = await api("/api/land/get", { id: drawer.id }); if (drawer.tab === "land") paintDrawer(true); } catch (e) { toast(e.message); } }
async function saveParcels(list) { drawer.land = await api("/api/land/save", { id: drawer.id, parcels: list }); await load(); }
let PEDIT = null;
function parcelModal(i) {
  const p = i >= 0 ? drawer.land.parcels[i] : { status: "Not approached", owner_type: "Unknown", log: [] };
  PEDIT = { i, log: [...(p.log || [])] };
  const f = (id, l, v, t = "text", ph = "") => `<label class="field"><span>${l}</span><input type="${t}" id="pc_${id}" value="${esc(v ?? "")}" placeholder="${ph}"></label>`;
  modal(`<h3>${i >= 0 ? "Edit" : "Add"} parcel</h3><div class="three">${f("ref", "Reference", p.ref, "text", "Parcel A")}${f("address", "Address or description", p.address)}${f("title_no", "Title number", p.title_no)}
   ${f("owner", "Owner", p.owner)}<label class="field"><span>Owner type</span><select id="pc_owner_type">${D.owner_types.map(o => `<option ${o === p.owner_type ? "selected" : ""}>${o}</option>`).join("")}</select></label>${f("area_ha", "Area (ha)", p.area_ha, "number")}
   <label class="field"><span>Status</span><select id="pc_status">${D.parcel_status.map(o => `<option ${o === p.status ? "selected" : ""}>${o}</option>`).join("")}</select></label>${f("ask", "Owner's ask (£)", p.ask, "number")}${f("offer", "Our offer (£)", p.offer, "number")}
   ${f("deal_type", "Structure", p.deal_type, "text", "Option, conditional contract, outright")}${f("contact_name", "Contact name", p.contact_name)}${f("contact_email", "Contact email", p.contact_email)}
   ${f("contact_phone", "Contact phone", p.contact_phone)}${f("next_action", "Next action", p.next_action)}${f("next_date", "Next action date", p.next_date, "text", "YYYY-MM-DD")}</div>
   <label class="tog" style="margin-top:10px"><span>This parcel controls access (ransom risk)</span><input type="checkbox" id="pc_ransom" ${p.ransom ? "checked" : ""}></label>
   <div class="kl" style="margin:14px 0 6px">Contact log</div><div id="pc_log"></div>
   <div style="display:flex;gap:8px;margin-top:6px"><select id="pc_lt" style="width:110px"><option>Note</option><option>Call</option><option>Meeting</option><option>Letter</option><option>Email</option><option>Signed</option></select><input type="text" id="pc_ln" placeholder="What happened"><button class="btn sm" data-act="pclogadd">Add</button></div>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="parcelsave">Save parcel</button></div>`, paintPLog);
}
function paintPLog() { const el = $("#pc_log"); if (el) el.innerHTML = PEDIT.log.map((e, k) => `<div class="usage" style="display:flex;justify-content:space-between;gap:8px"><span><b>${esc(e.type)}</b> · ${fdate(e.date)} · ${esc(e.note)}</span><button class="ghost" data-act="pclogdel" data-k="${k}">${I.x}</button></div>`).join("") || tsub("No entries yet."); }
function readParcel(existing) {
  const g = id => $("#pc_" + id).value, n = id => g(id) === "" ? null : +g(id);
  return { ...(existing || {}), ref: g("ref"), address: g("address"), title_no: g("title_no"), owner: g("owner"), owner_type: g("owner_type"), area_ha: n("area_ha"), status: g("status"), ask: n("ask"), offer: n("offer"), deal_type: g("deal_type"),
    contact_name: g("contact_name"), contact_email: g("contact_email"), contact_phone: g("contact_phone"), next_action: g("next_action"), next_date: g("next_date"), ransom: $("#pc_ransom").checked, log: PEDIT.log };
}
async function parcelLetter(siteId, pid) {
  const d = await api("/api/land/letter", { id: siteId, parcel_id: pid });
  modal(`<h3>Approach letter</h3><label class="field"><span>To</span><input type="text" id="q_to" value="${esc(d.to)}" placeholder="No email on file"></label><label class="field" style="margin-top:10px"><span>Subject</span><input type="text" id="q_sub" value="${esc(d.subject)}"></label>
   <label class="field" style="margin-top:10px"><span>Letter</span><textarea id="q_body" style="font-family:var(--font);min-height:300px">${esc(d.body)}</textarea></label>
   <div class="mf"><button class="btn" data-act="closem">Close</button><button class="btn" data-act="qcopy">Copy</button><button class="btn primary" data-act="qmail">Open in email app</button></div>`);
}

let LANDALL = null;
async function vLand(noload) {
  if (!noload || !LANDALL) { $("#view").innerHTML = '<div class="empty">Loading</div>'; LANDALL = (await api("/api/land/all")).parcels; if (view !== "land") return; }
  const ps = LANDALL, today = new Date().toISOString().slice(0, 10), open = p => !["Option signed", "Contracted", "Declined"].includes(p.status);
  const K = { n: ps.length, live: ps.filter(p => ["Approached", "In talks", "Heads agreed"].includes(p.status)).length, od: ps.filter(p => p.next_date && p.next_date < today && open(p)).length, un: ps.filter(p => p.status === "Not approached").length };
  $("#view").innerHTML = `<div class="grid kpis" style="grid-template-columns:repeat(4,1fr)">${kpi("Parcels tracked", K.n, `${new Set(ps.map(p => p.site_id)).size} sites`)}${kpi("In conversation", K.live, "approached, in talks or heads agreed")}${kpi("Actions overdue", K.od, "past their date")}${kpi("Not yet approached", K.un, "")}</div>
   <div class="toolbar" style="margin-top:16px"><button class="btn primary" data-act="offmarket">Add off-market site</button><span class="tsub">Off-market leads are ordinary sites with the source set to Off-market. Add parcels in the site's Land tab.</span></div>
   <div class="card tablewrap"><table><thead><tr><th>Site</th><th>Parcel</th><th>Owner</th><th>Status</th><th class="num">Ha</th><th class="num">Ask</th><th class="num">Offer</th><th>Next action</th></tr></thead><tbody>
   ${ps.sort((a, b) => (a.next_date || "9").localeCompare(b.next_date || "9")).map(p => `<tr data-act="openland" data-id="${esc(p.site_id)}"><td>${esc(p.site_name)}</td><td>${esc(p.ref || p.address)}${p.ransom ? ' <span class="chip hi">ransom</span>' : ""}</td><td>${esc(p.owner)}<div class="tsub">${esc(p.owner_type)}</div></td><td><span class="chip ${["Option signed", "Contracted"].includes(p.status) ? "ok" : p.status === "Declined" ? "hi" : ["In talks", "Heads agreed", "Approached"].includes(p.status) ? "med" : ""}">${esc(p.status)}</span></td><td class="num">${p.area_ha ?? ""}</td><td class="num">${p.ask ? money(p.ask) : ""}</td><td class="num">${p.offer ? money(p.offer) : ""}</td><td>${esc(p.next_action)}${p.next_date ? `<div class="tsub ${p.next_date < today && open(p) ? "od" : ""}">${fdate(p.next_date)}</div>` : ""}</td></tr>`).join("") || `<tr><td colspan="8"><div class="empty">No parcels recorded. Open a site and use its Land tab.</div></td></tr>`}</tbody></table></div>`;
}
function offMarketModal() {
  modal(`<h3>Add an off-market site</h3>${tsub("For land you hear about through a contact, a drive-by or the title register. It goes into your sites with the source set to Off-market, and the owner becomes its first parcel.", "margin:-6px 0 12px")}
   <div class="three"><label class="field"><span>Name</span><input type="text" id="om_name" placeholder="Land east of Church Lane"></label><label class="field"><span>Postcode</span><input type="text" id="om_pc"></label><label class="field"><span>Site area (ha)</span><input type="number" step="0.05" id="om_ha"></label>
   <label class="field"><span>Owner</span><input type="text" id="om_owner"></label><label class="field"><span>Owner type</span><select id="om_ot">${D.owner_types.map(o => `<option>${o}</option>`).join("")}</select></label><label class="field"><span>Contact phone or email</span><input type="text" id="om_ct"></label></div>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="omsave">Add site</button></div>`);
}

/* ---------------- portfolio ---------------- */
let PF = null;
async function vPortfolio(noload) {
  if (!noload || !PF) { $("#view").innerHTML = '<div class="empty">Loading</div>'; PF = await api("/api/portfolio"); if (view !== "portfolio") return; }
  const sm = PF.summary, org = PF.org || {}, bs = org.balance_sheet || {}, cf = org.cashflow || [];
  const fund = sm.fund_size, seg = fund ? [["Invested", sm.equity_invested, "var(--ink)"], ["Still to fund", sm.equity_to_come, "#B34700"], ["Offers and acquisitions in pipeline", sm.pipeline_equity, "var(--accent)"]] : [];
  const used = seg.reduce((n, x) => n + x[1], 0), avail = sm.equity_available;
  const bars = (obj, fmt = money) => { const m = Math.max(1, ...Object.values(obj)); return Object.entries(obj).map(([k, v]) => `<div style="display:flex;align-items:center;gap:10px;margin-bottom:7px"><span style="width:130px;font-size:12.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(D.strategies[k] || k)}</span><div class="bar" style="flex:1"><i style="width:${v / m * 100}%"></i></div><b style="width:70px;text-align:right;font-size:12.5px">${fmt(v)}</b></div>`).join("") || tsub("Nothing to show yet."); };
  $("#view").innerHTML = `<div class="toolbar"><button class="btn primary" data-act="schemeedit" data-id="">Add existing scheme</button><button class="btn" data-act="pfimport"><span class="spark">&#10022;</span> Import from Excel</button></div>
   <div class="grid kpis">${kpi("Live schemes", sm.n_live, `${sm.units || 0} units`)}${kpi("Total GDV", money(sm.gdv), `cost ${money(sm.cost)}`)}${kpi("Equity in", money(sm.equity_invested), `${money(sm.equity_to_come)} still to fund`)}${kpi("Debt drawn", money(sm.debt_drawn), `${money(sm.debt_undrawn)} undrawn${sm.debt_rate ? " · " + pct(sm.debt_rate, 2) + " avg" : ""}`)}${kpi("Equity headroom", sm.headroom != null ? money(sm.headroom) : "n/a", sm.headroom != null ? "after commitments and pipeline" : "set equity available in My mandate")}</div>
   <div class="grid" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);margin-top:16px;align-items:start">
    <div class="grid" style="min-width:0;grid-template-columns:minmax(0,1fr)">
     <div class="card pad"><h3 style="margin-bottom:10px">Capital view</h3>${fund ? `<div class="stack">${seg.map(x => `<i style="width:${x[1] / fund * 100}%;background:${x[2]}" title="${x[0]}"></i>`).join("")}</div><div class="legend2">${seg.map(x => `<span><i style="background:${x[2]}"></i>${x[0]} ${money(x[1])}</span>`).join("")}<span><i style="background:var(--surface2);border:1px solid var(--line)"></i>Fund size ${money(fund)}</span></div>
       <div class="kv" style="margin-top:14px;grid-template-columns:200px 1fr"><div>Deployed and committed</div><div>${pct((sm.equity_invested + sm.equity_to_come) / fund, 0)} of fund</div><div>With pipeline</div><div>${pct(used / fund, 0)} of fund</div>${avail ? `<div>Equity available now</div><div>${money(avail)}</div><div>Left after commitments</div><div class="${avail - sm.equity_to_come - sm.pipeline_equity >= 0 ? "pos" : "neg"}">${money(avail - sm.equity_to_come - sm.pipeline_equity)}</div>` : ""}${sm.largest?.share != null ? `<div>Largest scheme</div><div>${esc(sm.largest.name)}, ${pct(sm.largest.share, 0)} of fund</div>` : ""}${sm.cash != null ? `<div>Cash at bank</div><div>${money(sm.cash)}</div>` : ""}</div>` : tsub("Set your fund size and equity available under My mandate to see how much is deployed.")}
      ${PF.pipeline.length ? `<div class="kl" style="margin:14px 0 6px">Pipeline counted (stage Offer or Acquired)</div>${PF.pipeline.map(p => `<div class="usage" style="display:flex;justify-content:space-between"><span>${esc(p.name)} <span class="chip">${esc(p.stage)}</span></span><b>${money(p.peak_equity)}</b></div>`).join("")}` : ""}</div>
     <div class="card"><div class="h"><h3>Schemes</h3><span class="m">${PF.schemes.length}</span></div><div class="tablewrap" style="max-height:none;overflow-x:auto"><table><thead><tr><th>Scheme</th><th>Status</th><th class="num">Units</th><th class="num">GDV</th><th class="num">Equity in / total</th><th class="num">Debt drawn</th><th>Maturity</th><th></th></tr></thead><tbody>
      ${PF.schemes.map(s => `<tr style="cursor:default"><td style="min-width:210px"><b>${esc(s.name)}</b><div class="tsub">${esc(s.location)}${s.region ? " · " + esc(s.region) : ""} · ${esc(D.strategies[s.strategy])}</div></td><td><span class="chip ${s.status === "Sold" ? "" : s.status === "On site" ? "acc" : s.status === "Stabilised" ? "ok" : "lo"}">${esc(s.status)}</span></td><td class="num">${s.units ?? ""}</td><td class="num">${s.gdv ? money(s.gdv) : ""}</td><td class="num">${s.equity_invested != null || s.equity_committed != null ? `${money(s.equity_invested || 0)} / ${money(s.equity_committed || 0)}` : ""}</td><td class="num">${s.debt_drawn ? money(s.debt_drawn) : ""}${s.debt_rate ? `<div class="tsub">${pct(s.debt_rate, 2)}</div>` : ""}</td><td style="white-space:nowrap">${fdate(s.debt_maturity)}</td>
       <td style="white-space:nowrap"><button class="ghost" data-act="schemeedit" data-id="${esc(s.id)}">&#9998;</button><button class="ghost" data-act="schemedel" data-id="${esc(s.id)}">${I.x}</button></td></tr>`).join("") || `<tr style="cursor:default"><td colspan="8"><div class="empty">No schemes yet. Add one by hand, or import your portfolio spreadsheet.</div></td></tr>`}</tbody></table></div></div>
    </div>
    <div class="grid" style="min-width:0;grid-template-columns:minmax(0,1fr)">
     <div class="card pad"><h3 style="margin-bottom:10px">GDV by status</h3>${bars(sm.by_status)}</div>
     <div class="card pad"><h3 style="margin-bottom:10px">GDV by region</h3>${bars(sm.by_region)}</div>
     <div class="card pad"><h3 style="margin-bottom:10px">GDV by strategy</h3>${bars(sm.by_strategy)}</div>
     <div class="card pad"><h3 style="margin-bottom:10px">Debt maturities</h3>${bars(sm.maturities)}</div>
     <div class="card pad"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3>Company accounts</h3>${org.imported ? '<button class="btn sm" data-act="orgclear">Clear</button>' : ""}</div>
      ${Object.keys(bs).length ? `<div class="kv" style="grid-template-columns:150px 1fr">${Object.entries(bs).filter(([k]) => k !== "as_at").map(([k, v]) => `<div>${esc(k.replace(/_/g, " "))}</div><div>${money(v)}</div>`).join("")}</div>${bs.as_at ? tsub("As at " + esc(bs.as_at), "margin-top:6px") : ""}` : tsub("No balance sheet yet. Import your accounts workbook.")}
      ${cf.length ? `<div class="kl" style="margin:14px 0 6px">Cash flow (${cf.length} periods)</div>${orgCF(cf)}` : ""}${org.imported ? tsub(`From ${esc(org.file || "a workbook")}, ${when(org.imported)}`, "margin-top:8px") : ""}</div>
    </div></div>`;
}
function orgCF(cf) {
  const v = cf.map(c => c.closing ?? c.net ?? 0), W = 320, H = 90, p = 6, mn = Math.min(0, ...v), mx = Math.max(1, ...v), y = x => H - p - (x - mn) / (mx - mn || 1) * (H - 2 * p), bw = (W - 2 * p) / v.length;
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;stroke-width:1"><line x1="${p}" x2="${W - p}" y1="${y(0)}" y2="${y(0)}" stroke="var(--line)"/>${v.map((x, i) => `<rect x="${p + i * bw + 1}" y="${Math.min(y(x), y(0))}" width="${Math.max(1, bw - 2)}" height="${Math.abs(y(x) - y(0))}" fill="${x >= 0 ? "var(--accent)" : "var(--hi)"}" opacity=".8" rx="1"/>`).join("")}</svg><div class="tsub">${esc(cf[0].period)} to ${esc(cf[cf.length - 1].period)}, ${cf[0].closing != null ? "closing cash" : "net cash flow"}</div>`;
}
const SF = [["name", "Scheme name", "text"], ["location", "Location or postcode", "text"], ["units", "Units", "number"], ["gdv", "GDV (£)", "number"], ["total_cost", "Total cost (£)", "number"], ["equity_committed", "Total equity (£)", "number"], ["equity_invested", "Equity invested (£)", "number"],
  ["debt_facility", "Debt facility (£)", "number"], ["debt_drawn", "Debt drawn (£)", "number"], ["debt_rate", "Interest rate (%)", "number"], ["debt_maturity", "Debt maturity", "text"], ["start_date", "Start on site", "text"], ["pc_date", "Practical completion", "text"], ["sales_to_date", "Sales to date (£)", "number"], ["income_pa", "Rent or income pa (£)", "number"]];
function schemeModal(id) {
  const s = PF.schemes.find(x => x.id === id) || { status: "On site", strategy: "develop_sell" };
  modal(`<h3>${id ? "Edit" : "Add"} existing scheme</h3><div class="three">${SF.map(([k, l, t]) => `<label class="field"><span>${l}</span><input type="${t}" step="any" id="sc_${k}" value="${esc(k === "debt_rate" && s[k] != null ? +(s[k] * 100).toFixed(3) : s[k] ?? "")}" ${k.includes("date") || k === "debt_maturity" ? 'placeholder="YYYY-MM-DD"' : ""}></label>`).join("")}
   <label class="field"><span>Strategy</span><select id="sc_strategy">${Object.entries(D.strategies).map(([k, v]) => `<option value="${k}" ${s.strategy === k ? "selected" : ""}>${v}</option>`).join("")}</select></label>
   <label class="field"><span>Status</span><select id="sc_status">${D.port_statuses.map(o => `<option ${o === s.status ? "selected" : ""}>${o}</option>`).join("")}</select></label></div>
   <label class="field" style="margin-top:12px"><span>Notes</span><textarea id="sc_notes" style="font-family:var(--font);min-height:70px">${esc(s.notes || "")}</textarea></label>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="schemesave" data-id="${esc(s.id || "")}">Save scheme</button></div>`);
}
async function saveScheme(id) {
  const o = { id: id || null, strategy: $("#sc_strategy").value, status: $("#sc_status").value, notes: $("#sc_notes").value };
  SF.forEach(([k, , t]) => { const v = $("#sc_" + k).value; o[k] = t === "number" ? (v === "" ? null : (k === "debt_rate" ? +v / 100 : +v)) : v; });
  if (!o.name) return toast("Give the scheme a name");
  await api("/api/portfolio/save", { scheme: o }); closeModal(); PF = null; toast("Scheme saved"); vPortfolio();
}

/* ---- Excel import ---- */
let IMP = null;
function importModal() {
  IMP = null;
  modal(`<h3><span class="spark">&#10022;</span> Import from Excel</h3>${tsub("Drop the workbook you already keep for your portfolio, cash flow or balance sheet. The sheets are read and matched to schemes, company accounts and cash flow. You review everything before it is added.", "margin:-6px 0 12px")}
   <div class="drop" id="imp_drop"><input type="file" id="imp_in" accept=".xlsx,.xlsm" hidden><b>Drop an .xlsx file here</b><div class="tsub">or click to choose. Nothing leaves this app unless you have added a Claude key in Settings.</div></div>
   <div class="tsub" style="margin-top:10px">${D.has_key ? "A Claude key is set, so the sheets are sent to Claude for interpretation." : "No Claude key is set, so sheets are read by matching column and row names. Add a key in Settings for fuller interpretation of unusual layouts."}</div>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button></div>`, () => {
    const d = $("#imp_drop"), i = $("#imp_in");
    d.onclick = () => i.click(); i.onchange = () => runImport(i.files[0]);
    d.ondragover = e => { e.preventDefault(); d.classList.add("over"); }; d.ondragleave = () => d.classList.remove("over"); d.ondrop = e => { e.preventDefault(); runImport(e.dataTransfer.files[0]); };
  });
}
async function runImport(f) {
  if (!f) return;
  const steps = ["Opening the workbook", "Finding the sheets", "Matching columns to scheme fields", "Checking the figures"];
  const m = $("#modal .modal"); m.innerHTML = `<h3><span class="spark">&#10022;</span> Reading ${esc(f.name)}</h3><div class="steps-anim" id="anim">${steps.map((s, i) => `<div id="an${i}">${i === 0 ? "&#9679;" : "&#9675;"} ${s}</div>`).join("")}</div>`;
  let k = 0; const t = setInterval(() => { if (k < steps.length - 1) { $("#an" + k).className = "done"; $("#an" + k).innerHTML = "&#10003; " + steps[k]; k++; $("#an" + k).className = "on"; $("#an" + k).innerHTML = "&#9679; " + steps[k]; } }, 700);
  $("#an0").className = "on";
  try { const enc = await fileB64(f); const r = await api("/api/portfolio/import", { data: enc.data, name: f.name }); clearInterval(t); IMP = r; importReview(); }
  catch (e) { clearInterval(t); m.innerHTML = `<h3>Could not read the file</h3><div class="notice">${esc(e.message)}</div><div class="mf"><button class="btn" data-act="closem">Close</button><button class="btn" data-act="pfimport">Try another file</button></div>`; }
}
const BSF = ["cash", "stock_wip", "debtors", "total_assets", "creditors", "borrowings", "total_liabilities", "net_assets"];
function importReview() {
  const r = IMP, m = $("#modal .modal"); m.classList.add("big");
  const cols = [["name", "Scheme", "text"], ["status", "Status", "sel"], ["units", "Units", "number"], ["gdv", "GDV", "number"], ["total_cost", "Total cost", "number"], ["equity_committed", "Equity total", "number"], ["equity_invested", "Equity in", "number"], ["debt_facility", "Facility", "number"], ["debt_drawn", "Drawn", "number"]];
  m.innerHTML = `<h3><span class="spark">&#10022;</span> Review what was found</h3>
   <div class="tsub" style="margin:-6px 0 10px">Read by ${r.engine.startsWith("claude") ? "Claude (" + esc(r.engine.slice(7)) + ")" : "column and row name matching"} · ${r.sheets.map(s => `${esc(s.name)}: ${esc(s.kind)}`).join(", ")}</div>
   ${r.notes.map(n => `<div class="usage">${esc(n)}</div>`).join("")}
   ${r.schemes.length ? `<div class="sec"><h3>Schemes (${r.schemes.length})</h3><span class="m">Highlighted boxes had no figure in the sheet</span></div><div class="imp-table"><table><thead><tr><th></th>${cols.map(c => `<th>${c[1]}</th>`).join("")}</tr></thead><tbody>
    ${r.schemes.map((s, i) => `<tr data-si="${i}" class="${s._review.length ? "need" : ""}"><td><input type="checkbox" data-sinc checked></td>${cols.map(([k, , t]) => t === "sel" ? `<td><select data-sf="status">${D.port_statuses.map(o => `<option ${o === s.status ? "selected" : ""}>${o}</option>`).join("")}</select></td>` : `<td><input type="${t}" step="any" data-sf="${k}" value="${esc(s[k] ?? "")}" ${!s[k] && s._review.includes(k) ? 'style="border-color:var(--gC)"' : ""}></td>`).join("")}</tr>`).join("")}</tbody></table></div>` : ""}
   ${Object.keys(r.balance_sheet || {}).length ? `<div class="sec"><h3>Balance sheet</h3><span class="m">${esc(r.balance_sheet.as_at || "")}</span></div><div class="three">${BSF.filter(k => r.balance_sheet[k] != null).map(k => `<label class="field"><span>${k.replace(/_/g, " ")} (£)</span><input type="number" step="any" data-bs="${k}" value="${r.balance_sheet[k]}"></label>`).join("")}</div>` : ""}
   ${r.cashflow?.length ? `<div class="sec"><h3>Cash flow</h3><span class="m">${r.cashflow.length} periods</span></div>${orgCF(r.cashflow)}` : ""}
   ${!r.schemes.length && !Object.keys(r.balance_sheet || {}).length && !r.cashflow?.length ? '<div class="notice">Nothing recognisable was found. Column headers such as Scheme, Units, GDV, Total cost, Equity and Facility help. You can add schemes by hand instead.</div>' : ""}
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="impcommit">Add to portfolio</button></div>`;
}
async function commitImport() {
  const schemes = $$("tr[data-si]").filter(tr => $("[data-sinc]", tr).checked).map(tr => { const o = { ...IMP.schemes[+tr.dataset.si] }; $$("[data-sf]", tr).forEach(i => o[i.dataset.sf] = i.type === "number" ? (i.value === "" ? null : +i.value) : i.value); delete o._review; return o; });
  const bs = { ...(IMP.balance_sheet || {}) }; $$("[data-bs]").forEach(i => bs[i.dataset.bs] = i.value === "" ? null : +i.value);
  const r = await api("/api/portfolio/commit", { schemes, balance_sheet: bs, cashflow: IMP.cashflow, file: IMP.file });
  closeModal(); PF = null; toast(`${r.added} added, ${r.updated} updated`); vPortfolio();
}

/* ---------------- comparable schemes (market tab) ---------------- */
const SCH = {}; let schMap = null;
const KCOL = { Built: "#333333", "Under construction": "#D99A00", Consented: "#1E8E3E", Submitted: "#8C8C8C", Refused: "#D93025" };
function schemeSection() {
  const s = drawer.site, r = SCH[s.id];
  if (!r) { loadSchemes(false); return `<div class="sec"><h3>Nearby schemes</h3></div><div class="card empty">Loading</div>`; }
  const sm = r.summary;
  return `<div class="sec"><h3>Nearby schemes</h3><div style="display:flex;gap:8px;align-items:center"><select id="sch_r" style="width:auto">${[1, 2, 3, 5].map(x => `<option value="${x}" ${sm.radius_km === x ? "selected" : ""}>${x} km</option>`).join("")}</select><button class="btn sm primary" data-act="schfind" ${s.postcode ? "" : "disabled"}>Find schemes</button><button class="btn sm" data-act="schadd">Add a scheme</button></div></div>
   <div class="card pad" style="margin-bottom:12px">${tsub("Built schemes come from Land Registry new build sales. Consented and submitted schemes come from planning.data.gov.uk where the council publishes there, so coverage varies. Add anything else you know about by hand.", "margin-bottom:10px")}
    <div id="schmap" class="map" style="height:360px"></div>
    <div class="legend2">${Object.entries(KCOL).map(([k, c]) => `<span><i style="background:${c}"></i>${k}</span>`).join("")}<span><i style="background:var(--accent)"></i>This site</span></div>
    ${(r.notes || []).map(n => `<div class="notice" style="margin:10px 0 0">${esc(n)}</div>`).join("")}</div>
   ${sm.n ? `<div class="stat4">${kpi("Schemes found", sm.n, Object.entries(sm.by_kind).map(([k, v]) => `${v} ${k.toLowerCase()}`).join(", "))}${kpi("Units nearby", sm.units, "consented, submitted and built")}${kpi("Median density", sm.median_density ? sm.median_density.toFixed(0) + "/ha" : "n/a", "where site area is known")}${kpi("Median £ psf", sm.median_psf ? "£" + Math.round(sm.median_psf) : "n/a", "where a price is known")}</div>
   <div class="card tablewrap" style="max-height:340px"><table><thead><tr><th>Scheme</th><th>Status</th><th class="num">Units</th><th class="num">Density</th><th class="num">Price</th><th class="num">£ psf</th><th class="num">Distance</th><th>Source</th><th></th></tr></thead><tbody>
   ${r.items.map(x => `<tr style="cursor:default"><td>${esc(x.name)}<div class="tsub">${esc(x.detail || "")}</div></td><td><span class="chip" style="color:${KCOL[x.kind]}">${esc(x.kind)}</span></td><td class="num">${x.units ?? ""}</td><td class="num">${x.density ? x.density.toFixed(0) + "/ha" : ""}</td><td class="num">${x.price ? money(x.price) : ""}</td><td class="num">${x.psf ? "£" + Math.round(x.psf) : ""}</td><td class="num">${x.distance_km.toFixed(1)} km</td><td>${esc(x.source)}</td><td>${x.source === "Added by you" || x.source === "Illustrative" ? `<button class="ghost" data-act="schedit" data-sid="${esc(x.id)}">&#9998;</button><button class="ghost" data-act="schdel" data-sid="${esc(x.id)}">${I.x}</button>` : ""}</td></tr>`).join("")}</tbody></table></div>` : `<div class="card empty">No schemes within ${sm.radius_km} km yet.</div>`}`;
}
async function loadSchemes(fetchNow, radius) {
  const s = drawer.site;
  try { SCH[s.id] = await api("/api/schemes/map", { id: s.id, fetch: !!fetchNow, radius: radius || SCH[s.id]?.summary?.radius_km || 3 }); } catch (e) { toast(e.message); return; }
  if (drawer?.id === s.id && drawer.tab === "market") { paintDrawer(true); }
}
function initSchemeMap() {
  const s = drawer.site, r = SCH[s.id], el = $("#schmap"); if (!el || !r) return;
  schMap?.destroy();
  const pins = r.items.map(x => ({ id: x.id, lat: x.lat, lon: x.lon, color: KCOL[x.kind], label: x.units ? (x.units > 999 ? "1k" : x.units) : "", size: 28, name: x.name, tip: `<b>${esc(x.name)}</b><br>${esc(x.kind)}${x.units ? " · " + x.units + " units" : ""}<br><span style="opacity:.7">${esc(x.source)} · ${x.distance_km.toFixed(1)} km</span>` }));
  if (s.lat != null) pins.push({ id: "subject", lat: s.lat, lon: s.lon, color: "#FF6600", label: "&#9733;", size: 36, name: s.name, tip: `<b>${esc(s.name)}</b><br>This site` });
  schMap = makeMap(el, pins, () => { }); schMap.setTheme(document.documentElement.dataset.theme === "dark");
}
let SEDIT = null;
function schemeCompModal(sid) {
  const x = sid ? (drawer.site.scheme_comps || []).find(m => m.id === sid) || {} : {};
  SEDIT = x.id || null;
  const f = (id, l, v, t = "text", ph = "") => `<label class="field"><span>${l}</span><input type="${t}" step="any" id="sk_${id}" value="${esc(v ?? "")}" placeholder="${ph}"></label>`;
  modal(`<h3>${sid ? "Edit" : "Add"} comparable scheme</h3><div class="three">${f("name", "Name", x.name)}${f("postcode", "Postcode", x.postcode)}<label class="field"><span>Status</span><select id="sk_kind">${D.scheme_kinds.map(k => `<option ${k === (x.kind || "Consented") ? "selected" : ""}>${k}</option>`).join("")}</select></label>
   ${f("units", "Units", x.units, "number")}${f("site_ha", "Site area (ha)", x.site_ha, "number")}${f("psf", "Sales £ per sq ft", x.psf, "number")}${f("price", "Average price (£)", x.price, "number")}${f("date", "Date", x.date, "text", "YYYY-MM")}${f("detail", "Note", x.detail)}</div>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="schsave">Save</button></div>`);
}

/* ---------------- registries and hooks ---------------- */
window.EXTRA_VIEWS = { shortlist: vShortlist, compare: vCompare, portfolio: vPortfolio, land: vLand };
window.EXTRA_TABS = { structure: tStructure, diligence: tDiligence, land: tLand };
window.bindV04Tab = () => {
  if (drawer.tab === "structure" && drawer.struct && !drawer.struct.incomplete) bindStructureInputs();
  if (drawer.tab === "market") { if (SCH[drawer.site.id]) initSchemeMap(); }
  if (drawer.tab === "diligence" && drawer.dd) {
    $$("[data-di]").forEach(tr => $$("[data-df]", tr).forEach(i => i.onchange = () => { const it = drawer.dd.items.find(x => x.id === tr.dataset.di); it[i.dataset.df] = i.value; saveDD(); }));
  }
};
const _tMarket = tMarket;
tMarket = function () { return _tMarket() + schemeSection(); };
const _vSettings = vSettings;
vSettings = function () { _vSettings(); const col = $("#view .grid > .grid:last-child"); if (col) { col.insertAdjacentHTML("afterbegin", costSettingsCard()); loadCostTable(); $("#cost_reg").onchange = e => { COSTREG = e.target.value; loadCostTable(); }; } };
const _refreshDrawer = refreshDrawer;
refreshDrawer = async function (soft) { if (drawer) { drawer.struct = null; drawer.dd = null; drawer.land = null; } return _refreshDrawer(soft); };

/* ---------------- events ---------------- */
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t) return;
  const act = t.dataset.act, i = t.dataset.i != null ? +t.dataset.i : null;
  try {
    if (act === "star") { e.stopPropagation(); const s = sites().find(x => x.id === t.dataset.id); const on = !s._watch; await api("/api/site/watch", { id: s.id, on }); toast(on ? "Added to your shortlist" : "Removed from your shortlist"); await load(); }
    else if (act === "cmp") { e.stopPropagation(); const id = t.dataset.id; if (t.checked) { if (CMP.length >= 4) { t.checked = false; return toast("Compare holds up to four sites"); } CMP.push(id); } else CMP = CMP.filter(x => x !== id); }
    else if (act === "cmprm") { CMP = CMP.filter(x => x !== t.dataset.id); vCompare(); }
    else if (act === "cmpclear") { CMP = []; vCompare(); }
    else if (act === "cpaper") { e.stopPropagation(); const id = t.dataset.id, s = sites().find(x => x.id === id); if (D.hosted) { download(`/download/committee/${encodeURIComponent(id)}.docx?strategy=${ev(s).strategy}`); toast("Building the committee paper"); } else { const r = await api("/api/committee/save", { id, strategy: ev(s).strategy }); toast(`Saved to Downloads: ${r.name}`); } }
    else if (act === "seenall") { await api("/api/watch/seen", {}); await load(); }
    else if (act === "alsave") { await saveAlerts(); toast("Alert settings saved"); await load(); }
    else if (act === "altest") { await saveAlerts(); t.disabled = true; try { await api("/api/alerts/test", {}); toast("Test email sent"); } finally { t.disabled = false; } }
    else if (act === "alrun") { await saveAlerts(); await api("/api/alerts/run", {}); t.disabled = true; t.textContent = "Checking"; pollChecks(); }
    else if (act === "usecost") { const k = t.dataset.k; drawer.ovr[k] = +t.dataset.v; await refreshDrawer(true); drawer.tab = "appraisal"; paintDrawer(); toast(`£${t.dataset.v} per sq ft applied. Press Save to site to keep it.`); }
    // structure
    else if (act === "wfadd") { const tb = $("#wf_tiers tbody"); tb.insertAdjacentHTML("beforeend", `<tr style="cursor:default"><td><input type="number" step="any" data-wt="hurdle" value="20"></td><td><input type="number" step="any" data-wt="promote" value="40"></td><td><button class="ghost" data-act="wfdel">${I.x}</button></td></tr>`); bindStructureInputs(); recalcStructure(); }
    else if (act === "wfdel") { t.closest("tr").remove(); recalcStructure(); }
    else if (act === "wfsave") { await loadStructure({ terms: readTerms(), covenants: readCov(), save: true }); toast("Waterfall terms saved to the site"); }
    else if (act === "cvsave") { await loadStructure({ terms: readTerms(), covenants: readCov(), save: true }); toast("Lender limits saved to the site"); }
    // diligence
    else if (act === "ddadd") { modal(`<h3>Add a diligence item</h3><label class="field"><span>Category</span><input type="text" id="dd_c" value="Commercial"></label><label class="field" style="margin-top:10px"><span>Item</span><input type="text" id="dd_i"></label><div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="ddaddgo">Add</button></div>`); }
    else if (act === "ddaddgo") { const item = $("#dd_i").value.trim(); if (!item) return; drawer.dd.items.push({ id: "", category: $("#dd_c").value || "Other", item, status: "Not started", owner: "", due: "", note: "", custom: true }); closeModal(); const r = await api("/api/dd/save", { id: drawer.id, items: drawer.dd.items }); drawer.dd = r; await load(); }
    else if (act === "dddel") { drawer.dd.items = drawer.dd.items.filter(x => x.id !== t.dataset.id); const r = await api("/api/dd/save", { id: drawer.id, items: drawer.dd.items }); drawer.dd = r; await load(); }
    else if (act === "ddnote") { const it = drawer.dd.items.find(x => x.id === t.dataset.id); modal(`<h3>${esc(it.item)}</h3><label class="field"><span>Note</span><textarea id="dd_n" style="font-family:var(--font)">${esc(it.note)}</textarea></label><div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-act="ddnotego" data-id="${it.id}">Save</button></div>`); }
    else if (act === "ddnotego") { drawer.dd.items.find(x => x.id === t.dataset.id).note = $("#dd_n").value; closeModal(); const r = await api("/api/dd/save", { id: drawer.id, items: drawer.dd.items }); drawer.dd = r; await load(); }
    // land
    else if (act === "parcel") parcelModal(i);
    else if (act === "pclogadd") { const n = $("#pc_ln").value.trim(); if (n) { PEDIT.log.push({ date: new Date().toISOString().slice(0, 10), type: $("#pc_lt").value, note: n }); $("#pc_ln").value = ""; paintPLog(); } }
    else if (act === "pclogdel") { PEDIT.log.splice(+t.dataset.k, 1); paintPLog(); }
    else if (act === "parcelsave") { const list = [...drawer.land.parcels]; const p = readParcel(PEDIT.i >= 0 ? list[PEDIT.i] : null); if (PEDIT.i >= 0) list[PEDIT.i] = p; else list.push(p); closeModal(); await saveParcels(list); toast("Parcel saved"); }
    else if (act === "parceldel") { if (confirm("Remove this parcel?")) { const list = drawer.land.parcels.filter((_, k) => k !== i); await saveParcels(list); } }
    else if (act === "parcelletter") await parcelLetter(drawer.id, t.dataset.pid);
    else if (act === "openland") { await openSite(t.dataset.id, "land"); }
    else if (act === "offmarket") offMarketModal();
    else if (act === "omsave") {
      const name = $("#om_name").value.trim() || "Off-market site", ct = $("#om_ct").value.trim();
      const site = { name, postcode: $("#om_pc").value, address: $("#om_pc").value, site_ha: +$("#om_ha").value || null, strategy: "develop_sell", source: "Off-market", off_market: true, stage: "Sourced",
        parcels: [{ ref: "Parcel A", address: name, owner: $("#om_owner").value, owner_type: $("#om_ot").value, area_ha: +$("#om_ha").value || null, status: "Not approached", contact_email: ct.includes("@") ? ct : "", contact_phone: ct.includes("@") ? "" : ct, log: [] }] };
      const r = await api("/api/site", { site }); closeModal(); LANDALL = null; await load(); openSite(r.id, "land");
    }
    // portfolio
    else if (act === "schemeedit") schemeModal(t.dataset.id);
    else if (act === "schemesave") await saveScheme(t.dataset.id);
    else if (act === "schemedel") { if (confirm("Remove this scheme?")) { await api("/api/portfolio/delete", { id: t.dataset.id }); PF = null; vPortfolio(); } }
    else if (act === "pfimport") importModal();
    else if (act === "impcommit") await commitImport();
    else if (act === "orgclear") { await api("/api/org/clear", {}); PF = null; vPortfolio(); }
    // schemes
    else if (act === "schfind") { t.disabled = true; t.textContent = "Searching"; await loadSchemes(true, +$("#sch_r").value); }
    else if (act === "schadd") schemeCompModal(null);
    else if (act === "schedit") schemeCompModal(t.dataset.sid);
    else if (act === "schdel") { await api("/api/schemes/delete", { id: drawer.id, scheme_id: t.dataset.sid }); await load(); await loadSchemes(false); }
    else if (act === "schsave") {
      const g = k => $("#sk_" + k).value, o = { id: SEDIT, name: g("name"), postcode: g("postcode"), kind: g("kind"), units: g("units"), site_ha: g("site_ha"), psf: g("psf"), price: g("price"), date: g("date"), detail: g("detail"), source: "Added by you" };
      if (!o.name) return toast("Give the scheme a name");
      await api("/api/schemes/save", { id: drawer.id, scheme: o }); closeModal(); await load(); await loadSchemes(false);
    }
  } catch (err) { toast(err.message); if (t.disabled) t.disabled = false; }
});
