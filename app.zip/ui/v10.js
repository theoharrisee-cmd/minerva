/* easyDevelopment v0.9: tax and net returns, council levies, cost plan upload, listing alerts, side by side scenarios, map sketches, first run guide and shortcuts. */
const rate10 = v => v == null || isNaN(v) ? "n/a" : (+v).toLocaleString("en-GB", { maximumFractionDigits: 2 });
const sgn10 = v => v == null ? "" : Math.abs(v) < 0.5 ? "£0" : (v > 0 ? "+" : "-") + money(Math.abs(v));

/* ---------- tax and net returns (Structure tab) ---------- */
const TX = { data: null, id: null };
async function loadTax(body) {
  const id = drawer.id;
  try { const r = await api(body ? "/api/tax/save" : "/api/tax/get", { id, ...(body ? { tax: body } : {}) }); if (drawer?.id !== id) return; TX.data = r; TX.id = id; } catch (e) { toast(e.message); }
  if (drawer?.tab === "structure") paintDrawer(true);
}
function taxCard() {
  if (TX.id !== drawer.id) { TX.data = null; TX.id = drawer.id; loadTax(); }
  const d = TX.data; if (!d) return `<div class="card pad" style="margin-bottom:14px"><div class="tsub">Working out tax</div></div>`;
  if (d.incomplete) return "";
  const st = d.settings, c = d.company, p = d.personal, sd = d.sdlt, head = d.structure;
  const th = (k, l) => `<th class="num">${l}${head === k ? '<div class="tsub" style="font-weight:400">headline</div>' : ""}</th>`;
  const row = (l, a, b) => `<tr style="cursor:default"><td>${l}</td><td class="num">${a}</td><td class="num">${b}</td></tr>`;
  const mult = x => x ? x.toFixed(2) + "x" : "n/a";
  return `<div class="card pad" style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><h3>Tax and net returns</h3><span class="chip">${esc(d.structures[head])}</span></div>
   <div class="tsub" style="margin:4px 0 12px">The appraisal above is before tax. This works out stamp duty, VAT that cannot be recovered, and tax on the profit, for a company and for personal ownership side by side.</div>
   <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px">
    <label class="field"><span>Headline structure</span><select data-tx="structure">${Object.entries(d.structures).map(([k, v]) => `<option value="${k}" ${st.structure === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
    <label class="field"><span>Personal tax rate on trading profit (%)</span><input type="number" step="1" data-tx="personal_rate" value="${+(st.personal_rate * 100).toFixed(1)}"></label>
    <label class="field"><span>Associated companies</span><input type="number" step="1" min="0" data-tx="associated" value="${st.associated}"></label>
    <label class="field"><span>Stamp duty basis</span><select data-tx="sdlt_basis">${Object.entries({nonres: "Non-residential rates (land)", residential: "Residential rates plus 5% surcharge"}).map(([k, v]) => `<option value="${k}" ${(st.sdlt_basis || "nonres") === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
    <label class="field"><span>Months from exit to tax payment</span><input type="number" step="1" min="0" data-tx="tax_delay" value="${st.tax_delay}"></label>
    <label class="field"><span>VAT not recovered (£, blank for the rule below)</span><input type="number" step="any" data-tx="vat_override" value="${st.vat_override ?? ""}" placeholder="${Math.round(d.vat.amount)}"></label></div>
   <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;align-items:center"><button class="btn primary sm" data-act="txsave">Save tax settings</button><span class="tsub">Associated companies share the small profits limits.</span></div>
   <div class="tablewrap" style="max-height:none;margin-top:14px"><table><thead><tr><th></th>${th("company", "Company")}${th("personal", "Personal")}</tr></thead><tbody>
    ${row("Profit before tax", money(d.pre_tax_profit), money(d.pre_tax_profit))}${row("VAT not recovered", money(d.vat.amount), money(d.vat.amount))}${row("Tax on profit", `${money(c.tax)} <span class="tsub">${pct(c.effective, 1)}</span>`, `${money(p.tax)} <span class="tsub">${pct(p.effective, 1)}</span>`)}
    ${row("<b>Profit after tax</b>", `<b>${money(c.net_profit)}</b>`, `<b>${money(p.net_profit)}</b>`)}${row("Net margin", pct(c.net_margin), pct(p.net_margin))}${row("Levered IRR after tax", pct(c.irr), pct(p.irr))}${row("Equity multiple after tax", mult(c.multiple), mult(p.multiple))}
    ${row('<span class="tsub">Before tax: levered IRR ' + pct(d.pre_tax.irr) + ", multiple " + mult(d.pre_tax.multiple) + "</span>", "", "")}</tbody></table></div>
   <div class="notice" style="margin-top:12px">Stamp duty on the land price tested is about ${money(sd.calculated)} at non-residential rates, against an acquisition allowance of ${money(sd.allowance)}. ${esc(sd.note)}</div>
   <div class="tsub" style="margin-top:10px">${esc(d.vat.note)}</div><div class="tsub" style="margin-top:6px">${esc(d.rates_note)}</div><div class="tsub" style="margin-top:6px">${esc(d.caveat)}</div></div>`;
}

/* ---------- council levies (Planning tab) ---------- */
const LV = { data: null, id: null, busy: false, all: {} };
async function loadLevies(path, body) {
  const id = drawer.id; LV.busy = true;
  try { const r = await api(path || "/api/levies/get", { id, ...(body || {}) }); if (drawer?.id !== id) return; LV.data = r; LV.id = id; } catch (e) { toast(e.message); }
  LV.busy = false; if (drawer?.tab === "planning") paintDrawer(true);
}
function levyCard() {
  if (LV.id !== drawer.id) { LV.data = null; LV.id = drawer.id; loadLevies(); }
  const d = LV.data; if (!d) return `<div class="card pad" style="margin-bottom:14px"><div class="tsub">Loading</div></div>`;
  const cur = d.current, f = d.found;
  const stat = (k, fmt) => { const c = cur[k]; return `<div class="card kpi"><div class="l">${esc(c.label)}</div><div class="v">${fmt(c.value)}</div><div class="s">${c.applied ? `from ${esc(c.applied.source || "a document")} <button class="ghost" data-act="lvclear" data-k="${k}" title="Go back to the assumption" style="padding:0 4px">${I.x}</button>` : "assumption"}</div></div>`; };
  const src = (x, si) => {
    const show = LV.all[si] ? 99 : 6, more = (arr) => arr.length > show ? `<button class="btn sm" data-act="lvmore" data-i="${si}" style="margin-top:6px">Show all ${arr.length}</button>` : "";
    const cil = x.cil.slice(0, show), tar = x.tariffs.slice(0, show), aff = x.affordable.slice(0, show);
    return `<div style="border-top:1px solid var(--line);padding-top:12px;margin-top:12px"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b>${esc(x.label)}</b><div class="tsub">${x.kind === "pdf" ? "PDF" : "Web page"}, ${num9(x.chars)} characters read on ${esc((x.read || "").slice(0, 10))} · <a href="${esc(x.url)}" target="_blank" rel="noopener">open the source</a></div></div></div>
     ${cil.length ? `<div class="kl" style="margin:10px 0 4px">CIL rates found</div><div class="tablewrap" style="max-height:none"><table><thead><tr><th>Wording in the document</th><th class="num">£ per sq m</th><th class="num">£ per sq ft</th><th></th></tr></thead><tbody>${cil.map((c, i) => `<tr style="cursor:default"><td>${c.residential ? '<span class="chip ok">Residential</span> ' : ""}${esc(c.label)}<div class="tsub">${esc(c.snippet)}</div></td><td class="num">${rate10(c.rate_sqm)}</td><td class="num">${rate10(c.rate_sqft)}</td><td><button class="btn sm" data-act="lvuse" data-key="cil_psf" data-v="${c.rate_sqft}" data-s="${si}" data-i="${i}" data-t="cil">Use</button></td></tr>`).join("")}</tbody></table></div>${more(x.cil)}
      <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-top:8px"><label class="field" style="width:190px"><span>Allow for indexation since adoption (%)</span><input type="number" id="lv_idx" step="1" value="0"></label><label class="chk one" style="margin:0"><input type="checkbox" id="lv_rel">Reduce by the affordable share (social housing relief)</label></div>` : `<div class="tsub" style="margin-top:8px">No CIL rates in pounds per square metre were found in this document.</div>`}
     ${tar.length ? `<div class="kl" style="margin:12px 0 4px">Contributions per home</div><div class="tablewrap" style="max-height:none"><table><tbody>${tar.map((t2, i) => `<tr style="cursor:default"><td>${esc(t2.label)}<div class="tsub">${esc(t2.snippet)}</div></td><td class="num">${money(t2.amount)} <span class="tsub">per ${esc(t2.per)}</span></td><td><button class="btn sm" data-act="lvuse" data-key="s106_per_unit" data-v="${t2.amount}" data-s="${si}" data-i="${i}" data-t="tar" ${["bedroom"].includes(t2.per) ? "disabled title=\"This is per bedroom. Enter the total per home by hand.\"" : ""}>Use as the S106 per home</button></td></tr>`).join("")}</tbody></table></div><div class="tsub" style="margin-top:4px">Each line is one contribution. If a policy lists several, add them up and enter the total on the Appraisal tab.</div>${more(x.tariffs)}` : ""}
     ${aff.length ? `<div class="kl" style="margin:12px 0 4px">Affordable housing policy</div><div class="tablewrap" style="max-height:none"><table><tbody>${aff.map((a, i) => `<tr style="cursor:default"><td>${esc(a.snippet)}${a.threshold ? `<div class="tsub">Threshold mentioned: ${esc(a.threshold)}</div>` : ""}</td><td class="num"><b>${rate10(a.pct)}%</b></td><td><button class="btn sm" data-act="lvuse" data-key="affordable_pct" data-v="${a.pct}" data-s="${si}" data-i="${i}" data-t="aff">Use as the affordable share</button></td></tr>`).join("")}</tbody></table></div>${more(x.affordable)}` : ""}</div>`;
  };
  return `<div class="card pad" style="margin-bottom:14px"><h3>Council levies and obligations</h3>
   <div class="tsub" style="margin:4px 0 12px">Reads the council's published CIL charging schedule, and any planning obligations or affordable housing policy page you point it at, then lets you choose which figure feeds the appraisal. ${esc(d.note)}</div>
   <div class="stat4">${stat("cil_psf", v => `£${rate10(v)} psf`)}${stat("s106_per_unit", v => money(v))}${stat("affordable_pct", v => pct(v, 0))}</div>
   ${d.mayoral ? `<div class="notice" style="margin:12px 0 0">${esc(d.mayoral.note)} <b>£${rate10(d.mayoral.rate_sqm)} per sq m (£${rate10(d.mayoral.rate_sqft)} per sq ft).</b> <a href="${esc(d.mayoral.source)}" target="_blank" rel="noopener">Source</a><div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-top:8px"><label class="chk one" style="margin:0"><input type="checkbox" id="lv_mcil" checked>Add it to a borough rate when I use one below</label><button class="btn sm" data-act="lvmcil">Use the Mayoral rate alone</button></div></div>` : ""}
   <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;align-items:end"><button class="btn primary sm" data-act="lvfind" ${d.la ? "" : "disabled"} ${LV.busy ? "disabled" : ""}>${LV.busy ? "Reading" : d.la ? `Find ${esc(d.la)}'s CIL charging schedule` : "Add a postcode to find the council"}</button>
    <label class="field grow" style="min-width:260px"><span>Or read a page or PDF from the council (schedule, obligations SPD, local plan policy)</span><input type="text" id="lv_url" placeholder="https://"></label><button class="btn sm" data-act="lvread" ${LV.busy ? "disabled" : ""}>Read this link</button></div>
   ${f ? `<div class="${f.ok && !f.error ? "tsub" : "notice"}" style="margin-top:10px">${f.error ? esc(f.error) : `Found ${f.items.length} schedule${f.items.length > 1 ? "s" : ""} on planning.data.gov.uk${f.items[0]?.adopted ? `, newest adopted ${esc(f.items[0].adopted)}` : ""}.`}${f.items?.length && f.items[0].page_url ? ` <a href="${esc(f.items[0].page_url)}" target="_blank" rel="noopener">Council page</a>` : ""}</div>` : ""}
   ${d.sources.map(src).join("")}
   ${d.links.length ? `<div class="tsub" style="margin-top:14px">Look for the document yourself: ${d.links.map(l => `<a href="${esc(l.url)}" target="_blank" rel="noopener">${esc(l.label)}</a>`).join(" · ")}</div>` : ""}</div>`;
}

/* ---------- cost plan upload (Appraisal tab) ---------- */
const CPL = { data: null, id: null, busy: false };
async function loadCostPlan(path, body) {
  const id = drawer.id; CPL.busy = true;
  try { const r = await api(path || "/api/costplan/get", { id, ...(body || {}) }); if (drawer?.id !== id) return; CPL.data = r; CPL.id = id; } catch (e) { toast(e.message); }
  CPL.busy = false; if (drawer?.tab === "appraisal") paintDrawer(true);
}
const readPlanRows = () => $$("#pl_rows tr[data-pli]").map(tr => ({ i: +tr.dataset.pli, kind: $("[data-pl-kind]", tr).value, on: $("[data-pl-on]", tr).checked }));
function costPlanCard() {
  if (CPL.id !== drawer.id) { CPL.data = null; CPL.id = drawer.id; loadCostPlan(); }
  const d = CPL.data; if (!d) return "";
  const head = `<h3>Quantity surveyor's cost plan</h3>`;
  if (!d.has) return `<div class="card pad" style="margin-top:14px">${head}<div class="tsub" style="margin:4px 0 10px">Upload the cost plan as an Excel or CSV file. Each line is read for its description and amount, given a kind (construction, contingency, fees and so on) that you can change, and the build cost, contingency and fees are set from it once you apply it.</div>
    <div class="drop" id="pl_drop" style="padding:18px"><input type="file" id="pl_in" accept=".xlsx,.xlsm,.csv" hidden><b>Drop the cost plan here</b><div class="tsub">or click to choose an .xlsx, .xlsm or .csv file</div></div></div>`;
  const sm = d.summary, ap = d.applied, bm = d.benchmark;
  return `<div class="card pad" style="margin-top:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">${head}<span class="chip ${ap ? "ok" : ""}">${ap ? "Applied to the appraisal" : "Not applied yet"}</span></div>
   <div class="tsub" style="margin:4px 0 10px">${esc(d.file)}, sheet ${esc(d.sheet)}${d.columns?.amount ? `, amounts from "${esc(d.columns.amount)}"` : ""}. ${d.sheets.length > 1 ? `Other sheets: ${d.sheets.filter(s => s.name !== d.sheet).map(s => `<a href="#" data-act="plsheet" data-n="${esc(s.name)}">${esc(s.name)}</a>`).join(", ")}. ` : ""}Check each line's kind below.</div>
   <div class="stat4">${kpi("Build cost", money(sm.build), sm.psf ? `£${Math.round(sm.psf)} per sq ft GIA` : "add the floor area")}${kpi("Contingency", sm.contingency_pct != null ? pct(sm.contingency_pct) : "none", "of build cost")}${kpi("Professional fees", sm.fees_pct != null ? pct(sm.fees_pct) : "none", "of build cost")}${kpi("Left out", money(sm.excluded), "land, finance, levies and switched off lines")}</div>
   ${bm ? `<div class="tsub" style="margin-top:10px">At £${Math.round(bm.psf)} per sq ft the plan is ${esc(bm.verdict)} for ${esc(bm.label.toLowerCase())} (indicative £${bm.low} to £${bm.high}).</div>` : ""}
   ${sm.reconciliation ? `<div class="tsub" style="margin-top:6px">Check: the plan's "${esc(sm.reconciliation.label)}" is ${money(sm.reconciliation.plan)} and the lines switched on add up to ${money(sm.reconciliation.lines)}${Math.abs(sm.reconciliation.diff) < 1 ? ", which agree." : `, a difference of ${sgn10(sm.reconciliation.diff)}.`}</div>` : ""}
   ${sm.warnings.map(w => `<div class="notice" style="margin-top:8px">${esc(w)}</div>`).join("")}
   ${sm.groups.length ? `<div class="tablewrap" style="max-height:none;margin-top:12px"><table><thead><tr><th>Build cost by element</th><th class="num">Amount</th><th class="num">Share</th></tr></thead><tbody>${sm.groups.map(g => `<tr style="cursor:default"><td>${esc(g.group)}</td><td class="num">${money(g.amount)}</td><td class="num">${pct(g.amount / sm.build, 0)}</td></tr>`).join("")}</tbody></table></div>` : ""}
   <div class="kl" style="margin:14px 0 6px">Lines in the plan</div>
   <div class="tablewrap" style="max-height:340px"><table><thead><tr><th style="width:44px">Use</th><th>Description</th><th class="num">Amount</th><th style="width:210px">Kind</th></tr></thead><tbody id="pl_rows">
   ${d.items.map(x => `<tr data-pli="${x.i}" style="cursor:default"><td><input type="checkbox" data-pl-on ${x.on ? "checked" : ""} ${x.kind === "total" ? "disabled" : ""} aria-label="Use ${esc(x.label)}"></td><td>${esc(x.label)}${x.group ? `<div class="tsub">${esc(x.group)}</div>` : ""}</td><td class="num">${money(x.amount)}</td><td><select data-pl-kind>${Object.entries(d.kinds).map(([k, v]) => `<option value="${k}" ${x.kind === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></td></tr>`).join("")}</tbody></table></div>
   <div style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap;align-items:end"><label class="field" style="width:200px"><span>Gross internal area (sq ft)</span><input type="number" id="pl_area" step="100" value="${sm.area_sqft ? Math.round(sm.area_sqft) : ""}"></label>
    <button class="btn primary sm" data-act="plapply">${ap ? "Update the appraisal" : "Apply to the appraisal"}</button><button class="btn sm" data-act="plsave">Save changes</button><label class="btn sm" style="margin:0">Replace file<input type="file" id="pl_in" accept=".xlsx,.xlsm,.csv" hidden></label>${ap ? '<button class="btn sm" data-act="plclear">Undo and go back to the estimate</button>' : ""}</div>
   <div class="tsub" style="margin-top:8px">Applying sets the build cost total, and the contingency and fee percentages where the plan states them. Externals and abnormals in the plan are then counted once, in the build cost.</div></div>`;
}
async function planUpload(file) {
  if (!file) return; CPL.busy = true;
  try { const f = await fileB64(file); await loadCostPlan("/api/costplan/read", { name: f.name, data: f.data }); toast("Cost plan read. Check the kind of each line, then apply it."); } catch (e) { toast(e.message); CPL.busy = false; }
}

/* ---------- listings: alert emails and pasted links ---------- */
const LM = { tab: "alerts", cards: null, demo: false, busy: false, msg: "", sel: new Set() };
function openListings() { LM.cards = null; LM.msg = ""; LM.sel = new Set(); paintListings(true); }
function paintListings(first) {
  const body = LM.tab === "alerts" ? alertsPane() : pastePane();
  const html = `<h3>Add from listing alerts or a link</h3><p class="tsub" style="margin-top:-6px">Rightmove, Zoopla and OnTheMarket do not allow their pages to be read automatically. Listings arrive through the saved search alerts they email you, or by pasting a link with the listing text.</p>
   <div style="display:flex;gap:6px;margin:10px 0"><button class="btn sm ${LM.tab === "alerts" ? "primary" : ""}" data-act="lmtab" data-v="alerts">From alert emails</button><button class="btn sm ${LM.tab === "paste" ? "primary" : ""}" data-act="lmtab" data-v="paste">Paste a listing</button></div>${body}
   <div class="mf"><button class="btn" data-act="closem">Close</button></div>`;
  if (first) modal(html, m => m.querySelector(".modal").classList.add("big")); else { const m = $("#modal .modal"); if (m) m.innerHTML = html; }
}
function alertsPane() {
  const c = LM.cards;
  const top = `<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button class="btn primary sm" data-act="lmfind" ${LM.busy ? "disabled" : ""}>${LM.busy ? "Reading emails" : c ? "Check again" : D.outlook?.connected ? "Find alert emails in Outlook" : "Try the demo alerts"}</button><span class="tsub">${D.outlook?.connected ? "Reads Rightmove, Zoopla and OnTheMarket alerts from the last 30 days. Nothing else in the mailbox is read." : "Outlook is not connected, so this shows fictional demo alerts. Connect Outlook on the Deal emails page for your own."}</span></div>`;
  if (LM.msg) return top + `<div class="notice" style="margin-top:10px">${esc(LM.msg)}</div>`;
  if (!c) return top;
  if (!c.length) return top + `<div class="empty" style="margin-top:10px">No property cards were found in the alert emails. If the emails are new, the layout may have changed.</div>`;
  return top + `<div class="tablewrap" style="max-height:44vh;margin-top:10px"><table><thead><tr><th style="width:36px"></th><th>Property</th><th class="num">Price</th><th>Signal</th></tr></thead><tbody>${c.map((x, i) => `<tr style="cursor:default"><td><input type="checkbox" data-lmsel="${i}" ${LM.sel.has(i) ? "checked" : ""} ${x.known ? "disabled" : ""} aria-label="Add ${esc(x.address)}"></td>
   <td><b>${esc(x.address || "Listing " + x.id)}</b><div class="tsub">${esc(x.source_name)}${x.beds ? " · " + x.beds + " bed" : ""} · <a href="${esc(x.url)}" target="_blank" rel="noopener">view listing</a>${x.email ? ` · ${esc((x.email.date || "").slice(0, 10))}` : ""}</div><div class="tsub">${esc((x.summary || "").slice(0, 160))}</div></td>
   <td class="num">${x.price ? money(x.price) : "n/a"}</td><td>${x.known ? '<span class="chip">Already added</span>' : x.development_signal ? '<span class="chip ok">Possible development site</span>' : '<span class="chip lo">Not flagged as development</span>'}</td></tr>`).join("")}</tbody></table></div>
   <div style="display:flex;gap:8px;margin-top:10px;align-items:center"><button class="btn primary sm" data-act="lmadd">Add selected (${LM.sel.size})</button><button class="btn sm" data-act="lmdev">Select the development sites</button><span class="tsub">${LM.demo ? "Demo listings are fictional and are marked as demo." : "Each becomes a lead in Sourced. The alert gives only price, address and a few words, so add the rest on the site."}</span></div>`;
}
function pastePane() {
  return `<label class="field" style="margin-top:4px"><span>Listing link</span><input type="text" id="lm_url" placeholder="https://www.rightmove.co.uk/properties/..."></label>
   <label class="field" style="margin-top:8px"><span>Description copied from the listing page (required)</span><textarea id="lm_text" style="min-height:150px;font-family:var(--font)" placeholder="Paste the price, address and description here. Price, size, planning and units are read from it."></textarea></label>
   <div style="display:flex;gap:8px;margin-top:10px;align-items:center"><button class="btn primary sm" data-act="lmpaste">Add this listing</button><span class="tsub">The link is kept on the site. It is not fetched.</span></div>`;
}

/* ---------- scenarios side by side ---------- */
const SBS = { ids: null };
const chg10 = c => [["sales", "Sales", "%"], ["rent", "Rents", "%"], ["build", "Build", "%"], ["yield_bps", "Yield", " bps"], ["delay", "Delay", " months"], ["land", "Land", "%"]].filter(([k]) => c && +c[k]).map(([k, l, u]) => `${l} ${c[k] > 0 ? "+" : ""}${c[k]}${u}`).join(", ") || "no changes";
function sideBySide(r) {
  if (r.incomplete || !r.rows?.length) return "";
  const rows = r.rows;
  if (!SBS.ids || SBS.ids.length !== Math.min(3, rows.length) || SBS.ids.some(id => !rows.find(x => x.id === id))) SBS.ids = rows.slice(0, Math.min(3, rows.length)).map(x => x.id);
  const cols = SBS.ids.map(id => rows.find(x => x.id === id)), a = cols[0];
  const M = [["Gross development value", "gdv", money, 1, 1], ["Total cost", "total_cost", money, 1, -1], ["Profit", "profit", money, 1, 1], [`Margin ${a.basis}`, "margin", v => pct(v), 0, 1], ["Levered IRR", "irr", v => pct(v), 0, 1], ["Unlevered IRR", "irr_unlevered", v => pct(v), 0, 1],
    ["Equity multiple", "em", v => v ? v.toFixed(2) + "x" : "n/a", 0, 1], ["Peak equity", "peak_equity", money, 1, -1], ["Residual land value", "rlv", money, 1, 1], ["Land price tested", "land", money, 1, 0], ["Months from land to exit", "months", v => v == null ? "n/a" : Math.round(v), 0, -1]];
  const dl = (k, v, base, money_, dir) => { if (v == null || base == null || Math.abs(v - base) < (money_ ? 0.5 : 1e-9)) return ""; const d = v - base, good = dir === 0 ? null : (d > 0) === (dir > 0), txt = money_ ? sgn10(d) : (k === "months" ? (d > 0 ? "+" : "") + Math.round(d) : (d > 0 ? "+" : "") + (k === "em" ? d.toFixed(2) + "x" : (d * 100).toFixed(1) + " pts")); return `<div class="tsub ${good == null ? "" : good ? "pos" : "neg"}">${d > 0 ? "▲" : "▼"} ${txt}${good == null ? "" : good ? " better" : " worse"}</div>`; };
  const sel = i => `<select data-sbs="${i}" aria-label="Scenario ${i + 1}">${rows.map(x => `<option value="${esc(x.id)}" ${SBS.ids[i] === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>`;
  return `<div class="card" style="margin-top:14px"><div class="h"><h3>Side by side</h3><span class="m">differences shown against the first column</span></div>
   <div class="tablewrap" style="max-height:none"><table><thead><tr><th></th>${cols.map((c, i) => `<th class="num">${sel(i)}</th>`).join("")}</tr></thead><tbody>
   <tr style="cursor:default"><td class="tsub">What changes</td>${cols.map(c => `<td class="num tsub" style="white-space:normal">${esc(chg10(c.changes))}</td>`).join("")}</tr>
   ${M.map(([l, k, f, mn, dir]) => `<tr style="cursor:default"><td>${l}</td>${cols.map((c, i) => `<td class="num ${k === "profit" && c[k] < 0 ? "neg" : ""}">${c[k] == null ? "n/a" : f(c[k])}${i ? dl(k, c[k], a[k], mn, dir) : ""}</td>`).join("")}</tr>`).join("")}
   <tr style="cursor:default"><td>Result</td>${cols.map(c => `<td class="num"><span class="chip ${c.viable ? "ok" : c.profit < 0 ? "hi" : "med"}">${c.viable ? "Meets target" : c.profit < 0 ? "Loss" : "Below target"}</span></td>`).join("")}</tr></tbody></table></div></div>`;
}

/* ---------- map sketch ---------- */
const SK = { items: [], cats: null, tool: "line", cat: "access", map: null };
const _gmDraw10 = GeoMap.prototype.draw;
GeoMap.prototype.draw = function (force) {
  _gmDraw10.call(this, force);
  if (!this.svg || !this.sketch?.length || !this.el.clientWidth) return;
  const w = this.el.clientWidth, h = this.el.clientHeight, cp = this.px(this.c.lat, this.c.lon), P = p => { const q = this.px(p[1], p[0]); return [q.x - cp.x + w / 2, q.y - cp.y + h / 2]; };
  let s = "";
  for (const it of this.sketch) {
    const c = this.sketchCats[it.cat] || { colour: "#555", dash: false }, pts = it.coords.map(P), dash = c.dash ? ' stroke-dasharray="9 6"' : "";
    if (it.kind === "area") s += `<path d="M${pts.map(p => p.map(v => v.toFixed(1)).join(" ")).join("L")}Z" fill="${c.colour}" fill-opacity=".2" stroke="${c.colour}" stroke-width="2.5"${dash}/>`;
    else if (it.kind === "line") s += `<polyline points="${pts.map(p => p.map(v => v.toFixed(1)).join(",")).join(" ")}" fill="none" stroke="${c.colour}" stroke-width="3.5"${dash}/><path d="M${pts.at(-1)[0]} ${pts.at(-1)[1] - 6}l6 6l-6 6l-6-6z" fill="${c.colour}" stroke="none"/>`;
    else s += `<path d="M${pts[0][0]} ${pts[0][1] - 10}l8 10l-8 10l-8-10z" fill="${c.colour}" stroke="#fff" stroke-width="1.5"/>`;
    if (it.label) { const cx = pts.reduce((a, p) => a + p[0], 0) / pts.length, cy = pts.reduce((a, p) => a + p[1], 0) / pts.length - (it.kind === "point" ? 16 : 0); s += `<text x="${cx}" y="${cy}" text-anchor="middle" font-size="13" font-weight="600" fill="#111" stroke="#fff" stroke-width="4" paint-order="stroke" style="stroke-linejoin:round">${esc(it.label)}</text>`; }
  }
  this.svg.insertAdjacentHTML("beforeend", s);
};
async function openSketch() {
  const s = drawer.site; if (s.lat == null) { toast("Add a postcode first"); return; }
  const r = await api("/api/sketch/get", { id: s.id }); SK.items = r.items.map(({ measure, ...x }) => x); SK.cats = r.cats; SK.tool = "line"; SK.cat = "access";
  modal(`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3 style="margin:0">Sketch on the map</h3><span class="tsub" id="sk_meas"></span></div>
   <div class="tsub" style="margin-bottom:8px">Choose what to draw, give it a label, click the map, then Finish. Sketches are saved with the site and drawn on the map in the report, committee paper, deck and brief.</div>
   <div class="map" id="sk_map" style="height:46vh"></div><div id="sk_ui"></div>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button><button class="btn primary" data-sk="save">Save sketch</button></div>`, m => {
    m.querySelector(".modal").classList.add("big");
    const map = SK.map = new GeoMap($("#sk_map"), { lat: s.lat, lon: s.lon, zoom: 17, onDraft: d => { if (SK.tool === "point" && d.length === 1) skFinish(); else skMeasure(); } });
    map.sketchCats = SK.cats; map.sketch = SK.items; map.draftKind = SK.tool === "line" ? "line" : "area";
    map.pins = [{ id: s.id, lat: s.lat, lon: s.lon, g: "A", label: "★", name: s.name, tip: esc(s.name) }];
    if (s.boundary) map.setBoundary(s.boundary.ring); map.setMode("draw"); map.draw(); skUi();
  });
}
function skMeasure() {
  const d = SK.map.draft; let t = "";
  if (SK.tool === "line" && d.length > 1) { let m = 0; for (let i = 1; i < d.length; i++) m += Math.hypot((d[i][0] - d[i - 1][0]) * 111320 * Math.cos(d[i][1] * Math.PI / 180), (d[i][1] - d[i - 1][1]) * 110574); t = `${Math.round(m)} m`; }
  else if (SK.tool === "area" && d.length > 2) t = `${polyHa(d, drawer.site).toFixed(2)} ha`;
  $("#sk_meas").textContent = t;
}
function skUi() {
  const cats = SK.cats;
  $("#sk_ui").innerHTML = `<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin-top:10px">
   ${[["line", "Route"], ["area", "Area"], ["point", "Marker"]].map(([k, l]) => `<button class="btn sm ${SK.tool === k ? "primary" : ""}" data-sk="tool" data-v="${k}">${l}</button>`).join("")}
   <label class="field"><span>Category</span><select id="sk_cat">${Object.entries(cats).map(([k, v]) => `<option value="${k}" ${SK.cat === k ? "selected" : ""}>${esc(v.label)}</option>`).join("")}</select></label>
   <label class="field grow"><span>Label</span><input type="text" id="sk_label" maxlength="60" placeholder="e.g. Access from Bearwood Road"></label>
   <button class="btn sm" data-sk="undo">Undo point</button><button class="btn sm primary" data-sk="finish">Finish</button></div>
   <div style="margin-top:10px">${SK.items.length ? SK.items.map((x, i) => `<div style="display:flex;gap:8px;align-items:center;padding:5px 0;border-top:1px solid var(--line)"><span style="width:12px;height:12px;background:${cats[x.cat].colour};display:inline-block"></span><span class="grow">${esc(x.label || "(no label)")} <span class="tsub">${esc(cats[x.cat].label)}, ${x.kind === "line" ? "route" : x.kind === "area" ? "area" : "marker"}</span></span><button class="ghost" data-sk="del" data-i="${i}" aria-label="Delete">${I.x}</button></div>`).join("") : '<div class="tsub">Nothing sketched yet.</div>'}</div>`;
}
function skFinish() {
  const m = SK.map, need = { point: 1, line: 2, area: 3 }[SK.tool];
  if (m.draft.length < need) { toast(`A ${SK.tool === "line" ? "route" : SK.tool === "area" ? "area" : "marker"} needs at least ${need} point${need > 1 ? "s" : ""}`); return; }
  SK.items.push({ id: "sk-" + Math.random().toString(36).slice(2, 8), kind: SK.tool, cat: $("#sk_cat").value, label: $("#sk_label").value.trim(), coords: m.draft.map(p => [...p]) });
  m.sketch = SK.items; m.clearDraft(); $("#sk_label").value = ""; $("#sk_meas").textContent = ""; skUi();
}
function sketchCard() {
  const s = drawer.site, n = drawer.sk?.length;
  return `<div class="card pad" style="margin-top:14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="grow"><b>Map sketch</b><div class="tsub">${n ? `${n} item${n > 1 ? "s" : ""} drawn. They appear on the location map in the report, committee paper, deck and brief.` : "Mark access routes, phases, land to acquire and constraints on the map. The sketch is drawn on the map in every output."}</div></div><button class="btn ${n ? "" : "primary"}" data-act="skopen" ${s.lat == null ? "disabled title=\"Add a postcode first\"" : ""}>${n ? "Edit sketch" : "Sketch on map"}</button></div>`;
}

/* ---------- first run guide and shortcuts ---------- */
const OB = { step: 0, d: null };
const OB_STEPS = ["Welcome", "Your mandate", "Cost of capital", "Tax and style"];
function obInit() {
  const i = D.investor || {};
  OB.d = { name: i.name || "", firm: i.firm || "", strategies: i.strategies?.length ? [...i.strategies] : ["develop_sell", "btr", "value_add"], regions: [...(i.regions || [])], min_deal: i.min_deal || 0, max_deal: i.max_deal || 0, planning_tolerance: i.planning_tolerance || "Speculative",
    cost_of_equity: i.cost_of_equity ?? 12, senior_rate: i.senior_rate ?? 8.5, senior_ltc: i.senior_ltc ?? 60, target_profit_gdv: i.target_profit_gdv ?? 20, target_irr: i.target_irr ?? 18, structure: D.tax_default?.structure || "company", personal_rate: (D.tax_default?.personal_rate ?? 0.45) * 100, bname: D.brand?.name || "easyDevelopment", baccent: D.brand?.accent || "#FF6600" };
}
function obOpen(step = 0) { OB.step = step; if (!OB.d) obInit(); obPaint(true); }
function obRead() {
  const d = OB.d, g = id => $("#" + id);
  if (OB.step === 1) { d.name = g("ob_name").value; d.firm = g("ob_firm").value; d.strategies = $$("[data-obs]:checked").map(x => x.dataset.obs); d.regions = $$("[data-obr]:checked").map(x => x.dataset.obr); d.min_deal = +g("ob_min").value || 0; d.max_deal = +g("ob_max").value || 0; d.planning_tolerance = g("ob_tol").value; }
  if (OB.step === 2) for (const k of ["cost_of_equity", "senior_rate", "senior_ltc", "target_profit_gdv", "target_irr"]) d[k] = +g("ob_" + k).value || 0;
  if (OB.step === 3) { d.structure = g("ob_st").value; d.personal_rate = +g("ob_pr").value || 45; d.bname = g("ob_bn").value || "easyDevelopment"; d.baccent = g("ob_bc").value; }
}
function obPaint(first) {
  const d = OB.d, s = OB.step, f = (k, l, step = "any") => `<label class="field"><span>${l}</span><input type="number" step="${step}" id="ob_${k}" value="${d[k]}"></label>`;
  const bar = `<div style="display:flex;gap:6px;margin-bottom:14px">${OB_STEPS.map((n, i) => `<div style="flex:1;border-top:3px solid ${i <= s ? "var(--accent)" : "var(--line)"};padding-top:5px;font-size:12px;color:${i === s ? "var(--ink)" : "var(--muted)"};font-weight:${i === s ? 700 : 400}">${i + 1}. ${n}</div>`).join("")}</div>`;
  const body = [
    `<h3>Welcome to ${esc(D.brand?.name || "easyDevelopment")}</h3><p style="line-height:1.55">This finds sites, reads the planning position, appraises them with the numbers a developer-investor looks at, and monitors them. A minute of setup makes the scoring, the appraisal defaults and the outputs fit how you work.</p><p class="tsub">Four short steps: what you look for, your cost of capital, your tax structure and house style. Everything can be changed later under My mandate and Settings.</p>`,
    `<h3>What do you look for?</h3><div class="grid" style="grid-template-columns:1fr 1fr;gap:12px"><label class="field"><span>Your name</span><input type="text" id="ob_name" value="${esc(d.name)}"></label><label class="field"><span>Firm</span><input type="text" id="ob_firm" value="${esc(d.firm)}"></label></div>
     <div class="kl" style="margin:12px 0 6px">Strategies</div><div class="chk">${Object.entries(D.strategies).map(([k, v]) => `<label class="chk one"><input type="checkbox" data-obs="${k}" ${d.strategies.includes(k) ? "checked" : ""}>${esc(v)}</label>`).join("")}</div>
     <div class="kl" style="margin:12px 0 6px">Regions (none ticked means anywhere in England)</div><div class="chk" style="display:grid;grid-template-columns:1fr 1fr;gap:2px 12px">${D.regions.map(r => `<label class="chk one"><input type="checkbox" data-obr="${esc(r)}" ${d.regions.includes(r) ? "checked" : ""}>${esc(r)}</label>`).join("")}</div>
     <div class="grid" style="grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:12px"><label class="field"><span>Smallest deal, total cost (£m)</span><input type="number" id="ob_min" step="any" value="${d.min_deal}"></label><label class="field"><span>Largest deal (£m)</span><input type="number" id="ob_max" step="any" value="${d.max_deal}"></label>
     <label class="field"><span>Planning risk you accept</span><select id="ob_tol">${D.tolerance.map(t => `<option ${d.planning_tolerance === t ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></label></div>`,
    `<h3>Cost of capital and targets</h3><p class="tsub" style="margin-top:-6px">These set the finance and return assumptions in every appraisal. Change any of them per site later.</p><div class="grid" style="grid-template-columns:1fr 1fr;gap:12px">${f("cost_of_equity", "Cost of equity, your hurdle rate (% a year)")}${f("senior_rate", "Senior debt all-in rate (% a year)")}${f("senior_ltc", "Senior debt, loan to cost (%)")}${f("target_profit_gdv", "Target profit on GDV for sale schemes (%)")}${f("target_irr", "Target levered IRR (%)")}</div>`,
    `<h3>Tax and house style</h3><div class="grid" style="grid-template-columns:1fr 1fr;gap:12px"><label class="field"><span>How you usually hold a site</span><select id="ob_st">${Object.entries(D.tax_structures).map(([k, v]) => `<option value="${k}" ${d.structure === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label><label class="field"><span>Personal tax rate on trading profit (%)</span><input type="number" id="ob_pr" step="1" value="${d.personal_rate}"></label>
     <label class="field"><span>Name on reports and decks</span><input type="text" id="ob_bn" value="${esc(d.bname)}"></label><label class="field"><span>Accent colour</span><input type="color" id="ob_bc" value="${esc(String(d.baccent).toLowerCase())}" style="width:60px;height:38px;padding:2px"></label></div>
     <p class="tsub" style="margin-top:12px">Press <b>?</b> at any time to see the keyboard shortcuts. Cmd+K (Ctrl+K) opens the command bar.</p>`][s];
  const html = `${bar}${body}<div class="mf">${s === 0 ? '<button class="btn" data-ob="skip">Skip for now</button>' : '<button class="btn" data-ob="back">Back</button>'}<span style="flex:1"></span>${s < 3 ? `<button class="btn primary" data-ob="next">${s === 0 ? "Start" : "Next"}</button>` : '<button class="btn primary" data-ob="done">Finish setup</button>'}</div>`;
  if (first) modal(html); else { const m = $("#modal .modal"); if (m) m.innerHTML = html; }
}
async function obFinish() {
  const d = OB.d;
  await api("/api/onboard", { profile: { active: true, name: d.name, firm: d.firm, strategies: d.strategies.length ? d.strategies : Object.keys(D.strategies), regions: d.regions, min_deal: d.min_deal, max_deal: d.max_deal, planning_tolerance: d.planning_tolerance, cost_of_equity: d.cost_of_equity, senior_rate: d.senior_rate, senior_ltc: d.senior_ltc, target_profit_gdv: d.target_profit_gdv, target_irr: d.target_irr },
    tax: { structure: d.structure, personal_rate: d.personal_rate }, brand: { name: d.bname, accent: d.baccent } });
  closeModal(); await load(); toast("Setup saved. Your appraisals now use these assumptions.");
}
const SHORTCUTS = [["Cmd+K or Ctrl+K", "Command bar: jump to a site, page or action"], ["/", "Search sites"], ["?", "This list"], ["g then h", "Overview"], ["g then s", "Sites"], ["g then p", "Pipeline"], ["g then r", "Sourcing"], ["g then e", "Deal emails"], ["g then m", "My mandate"], ["g then t", "Settings"],
  ["n", "Add a deal"], ["l", "Add from listing alerts or a link"], ["[ and ]", "Previous and next tab in an open site"], ["Esc", "Close the site or a window"]];
function showShortcuts() {
  modal(`<h3>Keyboard shortcuts</h3><div class="tablewrap" style="max-height:60vh"><table><tbody>${SHORTCUTS.map(([k, v]) => `<tr style="cursor:default"><td style="width:170px"><kbd style="border:1px solid var(--line);padding:2px 7px;background:var(--surface2);font:12px var(--font)">${esc(k)}</kbd></td><td>${esc(v)}</td></tr>`).join("")}</tbody></table></div><div class="mf"><button class="btn" data-act="obopen">Run the setup guide again</button><span style="flex:1"></span><button class="btn primary" data-act="closem">Close</button></div>`);
}
let gPending = 0;
document.addEventListener("keydown", e => {
  if (e.metaKey || e.ctrlKey || e.altKey || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || "") || document.activeElement?.isContentEditable || $("#modal")?.classList.contains("on") || $("#cmdk")?.classList.contains("on")) return;
  const k = e.key;
  if (k === "?") { e.preventDefault(); showShortcuts(); return; }
  if (gPending && Date.now() - gPending < 1500) {
    gPending = 0; const to = { h: "overview", s: "sites", p: "pipeline", r: "sourcing", e: "inbox", m: "investor", t: "settings" }[k.toLowerCase()];
    if (to) { e.preventDefault(); if (drawer) closeDrawer(); view = to; render(); } return;
  }
  if (k === "g") { gPending = Date.now(); return; }
  if (k === "n") { e.preventDefault(); addDeal(); return; }
  if (k === "l") { e.preventDefault(); openListings(); return; }
  if ((k === "[" || k === "]") && drawer) { const tabs = $$(".tab"), i = tabs.findIndex(t => t.classList.contains("on")), j = i + (k === "]" ? 1 : -1); if (tabs[j]) { e.preventDefault(); tabs[j].click(); } }
});

/* ---------- wiring ---------- */
const _tStr10 = window.EXTRA_TABS.structure;
window.EXTRA_TABS.structure = function () { const h = _tStr10(); return drawer.struct?.incomplete ? h : taxCard() + h; };
const _tPlan10 = tPlanning;
tPlanning = function () { return levyCard() + _tPlan10(); };
const _tApp10 = tAppraisal;
tAppraisal = function () { return _tApp10() + costPlanCard(); };
const _tOv10 = tOverview;
tOverview = function () {
  if (drawer.skId !== drawer.id) { drawer.skId = drawer.id; drawer.sk = drawer.site?.sketch?.items || []; api("/api/sketch/get", { id: drawer.id }).then(r => { if (drawer?.id === r_id(drawer)) { drawer.sk = r.items; if (drawer.tab === "overview") paintDrawer(true); } }).catch(() => { }); }
  return _tOv10() + sketchCard();
};
const r_id = d => d.id;
const _scn10 = scnResults;
scnResults = function (r) { return _scn10(r) + sideBySide(r); };
const _ad10 = addDeal;
addDeal = function () { _ad10(); const mf = $("#modal .mf"); if (mf && !mf.querySelector("[data-act=lmopen]")) mf.insertAdjacentHTML("afterbegin", '<button class="btn" data-act="lmopen">From alerts or a link</button>'); };
const _ci10 = cmdItems;
cmdItems = function (q) {
  const extra = [{ t: "Action", n: "Add from listing alerts or a link", run: openListings }, { t: "Action", n: "Keyboard shortcuts", run: showShortcuts }, { t: "Action", n: "Run the setup guide", run: () => obOpen(0) }];
  const base = _ci10(q), toks = q.toLowerCase().split(/\s+/).filter(Boolean), hit = extra.filter(x => toks.every(t => `${x.n} ${x.t}`.toLowerCase().includes(t)));
  return q ? [...hit, ...base].slice(0, 12) : [...base.slice(0, 8), ...extra, ...base.slice(8)].slice(0, 12);
};
const _load10 = load;
load = async function (...a) { const r = await _load10.apply(this, a); if (D && D.onboarded === false && !OB.shown && !drawer) { OB.shown = true; setTimeout(() => { if (!drawer) obOpen(0); }, 350); } return r; };

document.addEventListener("click", async e => {
  const b = e.target.closest("[data-ob]");
  if (b) {
    const a = b.dataset.ob;
    try {
      if (a === "skip") { await api("/api/onboard", {}); D.onboarded = true; closeModal(); toast("You can run the setup guide again from the command bar"); }
      else if (a === "next") { obRead(); OB.step++; obPaint(); }
      else if (a === "back") { obRead(); OB.step--; obPaint(); }
      else if (a === "done") { obRead(); b.disabled = true; await obFinish(); }
    } catch (err) { toast(err.message); }
    return;
  }
  const sk = e.target.closest("[data-sk]");
  if (sk && SK.map) {
    const a = sk.dataset.sk, m = SK.map;
    try {
      if (a === "tool") { SK.tool = sk.dataset.v; m.clearDraft(); m.draftKind = SK.tool === "line" ? "line" : "area"; SK.cat = $("#sk_cat").value; const lb = $("#sk_label").value; skUi(); $("#sk_label").value = lb; }
      else if (a === "undo") m.undo();
      else if (a === "finish") skFinish();
      else if (a === "del") { SK.items.splice(+sk.dataset.i, 1); m.sketch = SK.items; m.draw(); skUi(); }
      else if (a === "save") { const r = await api("/api/sketch/save", { id: drawer.id, items: SK.items }); drawer.sk = r.items; closeModal(); SK.map = null; toast(r.items.length ? "Sketch saved. It now appears on the map in every output." : "Sketch cleared"); refreshDrawer(true); }
    } catch (err) { toast(err.message); }
    return;
  }
  const t = e.target.closest("[data-act]"); if (!t) return; const act = t.dataset.act;
  try {
    if (act === "txsave" && drawer) {
      const o = {}; $$("[data-tx]").forEach(el => { const k = el.dataset.tx; o[k] = (k === "structure" || k === "sdlt_basis") ? el.value : (el.value === "" ? (k === "vat_override" ? null : 0) : +el.value); });
      t.disabled = true; await loadTax(o); toast("Tax settings saved");
    }
    else if (act === "lvfind" && drawer) { await loadLevies("/api/levies/find"); }
    else if (act === "lvread" && drawer) { const u = $("#lv_url").value.trim(); if (!u) return toast("Paste a link first"); await loadLevies("/api/levies/read", { url: u }); }
    else if (act === "lvmore") { LV.all[t.dataset.i] = true; paintDrawer(true); }
    else if (act === "lvuse" && drawer) {
      const src = LV.data.sources[+t.dataset.s], row = ({ cil: src.cil, tar: src.tariffs, aff: src.affordable })[t.dataset.t][+t.dataset.i];
      await loadLevies("/api/levies/apply", { key: t.dataset.key, value: +t.dataset.v, index_pct: t.dataset.key === "cil_psf" ? (+($("#lv_idx")?.value) || 0) : 0, mayoral: t.dataset.key === "cil_psf" && !!$("#lv_mcil")?.checked, relief: t.dataset.key === "cil_psf" && !!$("#lv_rel")?.checked, source: `${src.label}`, note: row.snippet });
      toast("Written into the appraisal assumptions"); await load(false); await refreshDrawer(true);
    }
    else if (act === "lvmcil" && drawer) { await loadLevies("/api/levies/apply", { key: "cil_psf", value: 0, mayoral: true, relief: !!$("#lv_rel")?.checked, source: "Mayor of London CIL2 " + LV.data.mayoral.year, note: LV.data.mayoral.note }); toast("Written into the appraisal assumptions"); await load(false); await refreshDrawer(true); }
    else if (act === "lvclear" && drawer) { await loadLevies("/api/levies/clear", { key: t.dataset.k }); await load(false); await refreshDrawer(true); }
    else if (act === "plsave" && drawer) { await loadCostPlan("/api/costplan/save", { rows: readPlanRows(), area_sqft: $("#pl_area").value }); toast("Changes saved"); }
    else if (act === "plapply" && drawer) { t.disabled = true; await loadCostPlan("/api/costplan/apply", { rows: readPlanRows(), area_sqft: $("#pl_area").value }); toast("Cost plan applied to the appraisal"); await load(false); await refreshDrawer(true); }
    else if (act === "plclear" && drawer) { await loadCostPlan("/api/costplan/clear"); toast("Back to the estimate"); await load(false); await refreshDrawer(true); }
    else if (act === "plsheet" && drawer) { e.preventDefault(); await loadCostPlan("/api/costplan/read", { sheet: t.dataset.n }); toast("Sheet read. Check the kind of each line, then apply it."); }
    else if (act === "lmopen") { closeModal(); openListings(); }
    else if (act === "lmtab") { LM.tab = t.dataset.v; paintListings(); }
    else if (act === "lmfind") {
      LM.busy = true; LM.msg = ""; paintListings();
      try { const r = await api("/api/listings/alerts", { demo: !D.outlook?.connected }); LM.cards = r.cards; LM.demo = r.demo; LM.sel = new Set(); if (!r.cards.length) LM.msg = r.messages ? "" : "No alert emails from the property portals were found in the last 30 days."; } catch (err) { LM.msg = err.message; }
      LM.busy = false; paintListings();
    }
    else if (act === "lmdev") { LM.sel = new Set(LM.cards.map((c, i) => c.development_signal && !c.known ? i : -1).filter(i => i >= 0)); paintListings(); }
    else if (act === "lmadd") {
      if (!LM.sel.size) return toast("Tick the listings to add");
      const r = await api("/api/listings/add", { demo: LM.demo, items: [...LM.sel].map(i => LM.cards[i]) }); toast(`${r.added.length} added${r.skipped ? `, ${r.skipped} already on your list` : ""}`); closeModal(); view = "sites"; F.stage = "Sourced"; await load();
    }
    else if (act === "lmpaste") {
      const r = await api("/api/listings/paste", { url: $("#lm_url").value, text: $("#lm_text").value }); closeModal(); await load(); await openSite(r.id, "overview"); toast(r.missing?.length ? `Added. Please confirm: ${r.missing.join(", ")}` : "Listing added");
    }
    else if (act === "skopen" && drawer) { await openSketch(); }
    else if (act === "obopen") { closeModal(); obInit(); obOpen(0); }
  } catch (err) { toast(err.message); if (t.disabled) t.disabled = false; }
});
document.addEventListener("change", e => {
  const s = e.target.closest?.("[data-sbs]");
  if (s && drawer?.scn) { const i = +s.dataset.sbs; SBS.ids[i] = s.value; const box = $("#scnRes"); if (box) box.innerHTML = scnResults(drawer.scn); return; }
  const c = e.target.closest?.("[data-lmsel]"); if (c) { const i = +c.dataset.lmsel; c.checked ? LM.sel.add(i) : LM.sel.delete(i); const b = $('[data-act="lmadd"]'); if (b) b.textContent = `Add selected (${LM.sel.size})`; return; }
  if (e.target.id === "pl_in") planUpload(e.target.files[0]);
  if (e.target.id === "epc_file" && e.target.files[0]) { const f = e.target.files[0]; toast(`Reading ${f.name}. Large files take a minute.`); fileB64(f).then(b => api("/api/epcfile/load", { files: [b] })).then(r => { if (r.error) toast(r.error); else { toast(`${r.keys.toLocaleString("en-GB")} addresses loaded`); load(); } }).catch(err => toast(err.message)); }
  if (e.target.id === "ppd_file" && e.target.files[0]) { const f = e.target.files[0]; toast(`Reading ${f.name}. A year's file takes a minute or two.`); fileB64(f).then(b => api("/api/ppdfile/load", { files: [b] })).then(r => { if (r.error) toast(r.error); else { toast(`${r.rows.toLocaleString("en-GB")} sales loaded`); load(); } }).catch(err => toast(err.message)); }
  if (e.target.id === "sk_cat") SK.cat = e.target.value;
});
document.addEventListener("click", e => { const c = e.target.closest('[data-act="epcclear"]'); if (c) { e.preventDefault(); api("/api/epcfile/clear", {}).then(() => { toast("Certificates file removed"); load(); }); return; } });
document.addEventListener("click", e => { const c = e.target.closest('[data-act="ppdclear"]'); if (c) { e.preventDefault(); api("/api/ppdfile/clear", {}).then(() => { toast("Price Paid Data file removed"); load(); }); return; } });
document.addEventListener("click", e => { const d = e.target.closest("#pl_drop"); if (d && e.target.tagName !== "INPUT") $("#pl_in").click(); });
document.addEventListener("dragover", e => { const d = e.target.closest?.("#pl_drop"); if (d) { e.preventDefault(); d.classList.add("over"); } });
document.addEventListener("dragleave", e => { e.target.closest?.("#pl_drop")?.classList.remove("over"); });
document.addEventListener("drop", e => { const d = e.target.closest?.("#pl_drop"); if (d) { e.preventDefault(); d.classList.remove("over"); planUpload(e.dataTransfer.files[0]); } });
