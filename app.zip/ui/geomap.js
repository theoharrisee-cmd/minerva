/* easyDevelopment v0.7: map workspace. A tile map with an SVG overlay for layers, a search circle, the site
   boundary and a drawing tool. Works without any map key. */
class GeoMap extends MiniMap {
  constructor(el, o = {}) {
    super(el, [], o.onOpen || (() => { }));
    el.classList.add("geomap");
    el.querySelector(".map-empty")?.remove();
    this.svg = document.createElementNS("http://www.w3.org/2000/svg", "svg"); this.svg.setAttribute("class", "ov"); el.insertBefore(this.svg, this.marks);
    this.layers = {}; this.circle = null; this.boundary = null; this.parcels = []; this.mode = "pan"; this.draft = []; this.onClick = o.onClick; this.onDraft = o.onDraft;
    if (o.lat != null) { this.c = { lat: o.lat, lon: o.lon }; this.z = o.zoom || 13; }
    let down = null;
    el.addEventListener("pointerdown", e => { down = { x: e.clientX, y: e.clientY }; });
    el.addEventListener("pointerup", e => {
      if (!down || e.target.closest(".pin,.zoom,.mapbar")) { down = null; return; }
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y); down = null; if (moved > 5) return;
      const r = el.getBoundingClientRect(), cp = this.px(this.c.lat, this.c.lon), q = this.ll(cp.x + e.clientX - r.left - el.clientWidth / 2, cp.y + e.clientY - r.top - el.clientHeight / 2);
      if (this.mode === "draw") { this.draft.push([+q.lon.toFixed(6), +q.lat.toFixed(6)]); this.onDraft?.(this.draft); this.draw(); }
      else this.onClick?.(q.lat, q.lon);
    });
    this.draw();
  }
  bounds() { const w = this.el.clientWidth, h = this.el.clientHeight, cp = this.px(this.c.lat, this.c.lon), a = this.ll(cp.x - w / 2, cp.y - h / 2), b = this.ll(cp.x + w / 2, cp.y + h / 2); return [a.lon, b.lat, b.lon, a.lat]; }
  setMode(m) { this.mode = m; this.el.style.cursor = m === "draw" ? "crosshair" : ""; }
  undo() { this.draft.pop(); this.onDraft?.(this.draft); this.draw(); }
  clearDraft() { this.draft = []; this.onDraft?.(this.draft); this.draw(); }
  setLayer(id, data) { if (data) this.layers[id] = data; else delete this.layers[id]; this.draw(); }
  setCircle(lat, lon, km) { this.circle = lat == null ? null : { lat, lon, km }; this.draw(); }
  setBoundary(ring) { this.boundary = ring; this.draw(); }
  draw(force) {
    super.draw(force);
    if (!this.svg) return;
    const w = this.el.clientWidth, h = this.el.clientHeight; if (!w) return;
    const cp = this.px(this.c.lat, this.c.lon), P = (lon, lat) => { const q = this.px(lat, lon); return [q.x - cp.x + w / 2, q.y - cp.y + h / 2]; };
    const path = ring => "M" + ring.map(p => P(p[0], p[1]).map(v => v.toFixed(1)).join(" ")).join("L") + "Z";
    let s = "";
    for (const L of Object.values(this.layers)) for (const f of L.features || []) {
      if (f.t === "poly") s += `<path d="${path(f.ring)}" fill="${L.colour}" fill-opacity=".22" stroke="${L.colour}" stroke-width="1.2"><title>${esc(f.name || L.label || "")}</title></path>`;
      else { const [x, y] = P(f.lon, f.lat); s += `<rect x="${x - 4}" y="${y - 4}" width="8" height="8" fill="${L.colour}" stroke="#fff" stroke-width="1"><title>${esc(f.name || "")}</title></rect>`; }
    }
    if (this.circle) { const [x, y] = P(this.circle.lon, this.circle.lat), e = this.px(this.circle.lat, this.circle.lon + this.circle.km / (111.32 * Math.cos(this.circle.lat * Math.PI / 180))), r = Math.abs(e.x - this.px(this.circle.lat, this.circle.lon).x); s += `<circle cx="${x}" cy="${y}" r="${r}" fill="#FF6600" fill-opacity=".08" stroke="#FF6600" stroke-width="2" stroke-dasharray="6 4"/><rect x="${x - 5}" y="${y - 5}" width="10" height="10" fill="#FF6600"/>`; }
    if (this.parcels.length) for (const r of this.parcels) s += `<path d="${path(r)}" fill="#4A90D9" fill-opacity=".25" stroke="#1E6FD9" stroke-width="1.5"/>`;
    if (this.boundary?.length > 2) s += `<path d="${path(this.boundary)}" fill="#FF6600" fill-opacity=".18" stroke="#000" stroke-width="2.5" stroke-dasharray="7 3"/>`;
    if (this.draft.length) {
      const pts = this.draft.map(p => P(p[0], p[1]));
      s += (this.draft.length > 2 && this.draftKind !== "line" ? `<path d="${path(this.draft)}" fill="#FF6600" fill-opacity=".2" stroke="#FF6600" stroke-width="2.5"/>` : `<polyline points="${pts.map(p => p.join(",")).join(" ")}" fill="none" stroke="#FF6600" stroke-width="2.5"/>`) + pts.map(p => `<rect x="${p[0] - 4}" y="${p[1] - 4}" width="8" height="8" fill="#fff" stroke="#FF6600" stroke-width="2"/>`).join("");
    }
    this.svg.innerHTML = s;
  }
}
const GM = { layers: null };
async function gmLayers() { if (!GM.layers) GM.layers = (await api("/api/map/layers")).layers; return GM.layers; }
async function gmToggle(map, id, on, toast_) {
  if (!on) { map.setLayer(id, null); return; }
  try { const r = await api("/api/map/layer", { dataset: id, bbox: map.bounds() }); if (r.too_wide) { toast(`Zoom in to see this layer (under ${r.max_km} km across)`); return false; } map.setLayer(id, r); return r.features.length; } catch (e) { toast(e.message); return false; }
}

/* ---------- boundary tool in a modal ---------- */
let BM = null;
async function openBoundary() {
  const s = drawer.site; if (s.lat == null) { toast("Add a postcode first"); return; }
  const layers = await gmLayers().catch(() => []), want = ["title-boundary", "brownfield-land", "green-belt", "flood-risk-zone", "conservation-area"].map(id => layers.find(l => l.id === id)).filter(Boolean);
  modal(`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3 style="margin:0">Site boundary</h3><span class="tsub" id="bm_area"></span></div>
   <div class="tsub" style="margin-bottom:8px">Choose Draw, then click each corner of the site. Title polygons help you follow real boundaries. Press Finish to close the shape.</div>
   <div class="map" id="bm_map" style="height:52vh"></div>
   <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px"><button class="btn sm" data-bm="draw">Draw</button><button class="btn sm" data-bm="undo">Undo point</button><button class="btn sm" data-bm="clear">Clear</button><button class="btn sm" data-bm="finish">Finish</button>
    <span class="grow"></span>${want.map(l => `<label class="chk one" style="margin:0"><input type="checkbox" data-bl="${l.id}" ${l.id === "title-boundary" ? "checked" : ""}>${esc(l.label)}</label>`).join("")}<button class="btn sm" data-bm="reload">Reload layers</button></div>
   <div class="mf"><button class="btn" data-act="closem">Cancel</button>${s.boundary ? '<button class="btn" data-bm="remove">Remove boundary</button>' : ""}<button class="btn primary" data-bm="save">Save boundary and use its area</button></div>`, m => {
    m.querySelector(".modal").classList.add("big");
    BM = { map: null, fin: null };
    const map = BM.map = new GeoMap($("#bm_map"), { lat: s.lat, lon: s.lon, zoom: 17, onDraft: d => { const ok = d.length > 2; $("#bm_area").textContent = ok ? `${(polyHa(d, s)).toFixed(2)} ha` : ""; } });
    map.pins = [{ id: s.id, lat: s.lat, lon: s.lon, g: "A", label: "★", name: s.name, tip: esc(s.name) }]; map.draw();
    if (s.boundary) { map.setBoundary(s.boundary.ring); $("#bm_area").textContent = s.boundary.area_ha + " ha"; }
    gmToggle(map, "title-boundary", true);
  });
}
function polyHa(ring, s) { const R = 6371008.8, la0 = s.lat * Math.PI / 180, xy = ring.map(([x, y]) => [(x - s.lon) * Math.PI / 180 * R * Math.cos(la0), (y - s.lat) * Math.PI / 180 * R]); let a = 0; xy.forEach((p, i) => { const q = xy[(i + 1) % xy.length]; a += p[0] * q[1] - q[0] * p[1]; }); return Math.abs(a) / 2 / 1e4; }
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-bm]"); if (!b || !BM) return; const a = b.dataset.bm, m = BM.map, s = drawer.site;
  try {
    if (a === "draw") { m.setMode("draw"); toast("Click the corners of the site"); }
    else if (a === "undo") m.undo();
    else if (a === "clear") { m.clearDraft(); m.setBoundary(null); }
    else if (a === "finish") { if (m.draft.length < 3) { toast("Add at least three points"); return; } m.setBoundary([...m.draft]); m.clearDraft(); m.setMode("pan"); }
    else if (a === "reload") { for (const c of $$("[data-bl]:checked")) await gmToggle(m, c.dataset.bl, true); }
    else if (a === "save") { const ring = m.draft.length > 2 ? m.draft : m.boundary; if (!ring || ring.length < 3) { toast("Draw the boundary first"); return; } const r = await api("/api/site/boundary", { id: s.id, ring, apply_area: true }); closeModal(); BM = null; toast(`Boundary saved: ${r.boundary.area_ha} ha`); await load(false); await refreshDrawer(true); paintDrawer(true); }
    else if (a === "remove") { await api("/api/site/boundary", { id: s.id, ring: null }); closeModal(); BM = null; await load(false); await refreshDrawer(true); paintDrawer(true); }
  } catch (err) { toast(err.message); }
});
document.addEventListener("change", async e => { const c = e.target.closest?.("[data-bl]"); if (c && BM) { const n = await gmToggle(BM.map, c.dataset.bl, c.checked); if (n === false) c.checked = false; } });

/* ---------- search map workspace ---------- */
const WS = { map: null };
async function vSearchMap() {
  const c = SR.c, layers = await gmLayers().catch(() => []), have = c.lat != null;
  const box = $("#mapws"); if (!box) return;
  box.innerHTML = `<div class="srgrid"><div class="card pad srform"><h3 style="margin-bottom:4px">Map</h3><div class="tsub" style="margin-bottom:10px">Click the map to set the centre of a search. Switch layers on to see constraints and title polygons before you search.</div>
   <div class="lbl" style="margin-top:0">Centre</div><div id="ws_c" class="tsub">${have ? `${c.lat.toFixed(4)}, ${c.lon.toFixed(4)}${c.place_name ? " · " + esc(c.place_name) : ""}` : "Not set. Click the map."}</div>
   <label class="field" style="margin-top:8px"><span>Radius (km)</span><input type="number" id="ws_rad" min="0.5" max="25" step="0.5" value="${c.radius_km ?? 5}"></label>
   <div class="lbl">Layers</div><div class="chk">${layers.map(l => `<label><input type="checkbox" data-wl="${l.id}" ${WS.on?.has(l.id) ? "checked" : ""}><span style="display:inline-block;width:10px;height:10px;background:${l.colour};margin-right:6px"></span>${esc(l.label)}</label>`).join("")}</div>
   <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn" data-act="wsreload">Reload layers for this view</button>${SR.res ? `<button class="btn" data-act="wspins">${WS.pins ? "Hide" : "Show"} last search results</button>` : ""}</div>
   <div style="margin-top:14px"><button class="btn primary" data-act="wssearch" ${have ? "" : "disabled"}>Search sites from this point</button></div>
   <div class="tsub" style="margin-top:8px">The search uses the criteria on the Sites in an area tab.</div></div>
   <div><div class="map" id="wsmap" style="height:72vh"></div></div></div>`;
  if (WS.map) { WS.map.destroy?.(); }
  WS.on = WS.on || new Set();
  const m = WS.map = new GeoMap($("#wsmap"), {
    lat: have ? c.lat : 52.8, lon: have ? c.lon : -1.6, zoom: have ? 12 : 6,
    onClick: (lat, lon) => { SR.c = { ...SR.c, lat, lon, place: "", place_name: "Map point" }; lsSet("ed_srcrit", SR.c); m.setCircle(lat, lon, SR.c.radius_km || 5); $("#ws_c").textContent = `${lat.toFixed(4)}, ${lon.toFixed(4)} · Map point`; $('[data-act="wssearch"]').disabled = false; }
  });
  if (have) m.setCircle(c.lat, c.lon, c.radius_km || 5);
  if (WS.pins && SR.res) m.pins = SR.res.candidates.map(x => ({ id: x.id, lat: x.lat, lon: x.lon, g: x.score >= 70 ? "A" : x.score >= 50 ? "B" : "C", label: x.score, name: x.name, score: x.score, src: (x.sources || []).join(", ") })), m.draw();
  m.onOpen = () => { };
}
document.addEventListener("change", async e => {
  const c = e.target.closest?.("[data-wl]"); if (c && WS.map) { if (c.checked) { const n = await gmToggle(WS.map, c.dataset.wl, true); if (n === false) c.checked = false; else WS.on.add(c.dataset.wl); } else { WS.map.setLayer(c.dataset.wl, null); WS.on.delete(c.dataset.wl); } }
  if (e.target.id === "ws_rad" && WS.map) { SR.c.radius_km = +e.target.value || 5; lsSet("ed_srcrit", SR.c); if (SR.c.lat != null) WS.map.setCircle(SR.c.lat, SR.c.lon, SR.c.radius_km); }
});
document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t || view !== "search" || SR.mode !== "map") return; const act = t.dataset.act;
  if (act === "wsreload") { for (const id of [...WS.on]) await gmToggle(WS.map, id, true); }
  else if (act === "wspins") { WS.pins = !WS.pins; vSearchMap(); }
  else if (act === "wssearch") { SR.mode = "area"; lsSet("ed_srmode", "area"); await vSearch(); $('[data-act="srrun"]')?.click(); }
});
