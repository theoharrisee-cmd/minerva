/* easyDevelopment v0.8: programme and cash flow, funding, comparables, planning strategy, history, pack builder, deal room. */
const num9 = (v, d = 0) => v == null || isNaN(v) ? "n/a" : (+v).toLocaleString("en-GB", { maximumFractionDigits: d });
const mm = v => v < 0 ? "-" + money(-v) : money(v);
const sgn = v => v == null ? "" : Math.abs(v) < 0.5 ? "£0" : (v > 0 ? "+" : "-") + money(Math.abs(v));
const fdt9 = t => { try { return new Date(t).toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }); } catch { return t || ""; } };

/* ---------- small svg charts (one axis, thin marks, tooltips on every mark) ---------- */
function ganttSvg(d) {
  const g = d.gantt, end = Math.max(...g.map(x => x.end)) + 1, W = 900, L = 150, R = 14, rowH = 30, H = g.length * rowH + 34;
  const x = m => L + (W - L - R) * m / end;
  const col = { planning: "var(--muted)", precon: "var(--muted)", build: "var(--accent)", sales: "var(--ink)" };
  const ticks = []; for (let m = 0; m <= end; m += end > 48 ? 12 : 6) ticks.push(m);
  return `<div class="chartbox"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Programme by stage" style="font-size:12px;stroke:none">
   ${ticks.map(m => `<line x1="${x(m)}" x2="${x(m)}" y1="0" y2="${H - 24}" stroke="var(--line)"/><text x="${x(m)}" y="${H - 8}" text-anchor="middle" fill="var(--muted)">${esc(d.rows[Math.min(m, d.rows.length - 1)]?.label || "M" + m)}</text>`).join("")}
   ${g.map((r, i) => `<text x="${L - 10}" y="${i * rowH + 20}" text-anchor="end" fill="var(--ink)">${esc(r.label)}</text><rect x="${x(r.start)}" y="${i * rowH + 6}" width="${Math.max(3, x(r.end + 1) - x(r.start) - 2)}" height="18" fill="${col[r.id]}"><title>${esc(r.label)}: months ${r.start} to ${r.end} (${r.end - r.start + 1})</title></rect>
     <text x="${x(r.start) + 6}" y="${i * rowH + 19}" fill="#fff" style="pointer-events:none">${x(r.end + 1) - x(r.start) > 60 ? r.end - r.start + 1 + " months" : ""}</text>`).join("")}</svg></div>`;
}
function cashSvg(d) {
  const rows = d.rows, W = 900, H = 250, L = 64, R = 14, T = 14, B = 30, n = rows.length;
  const net = rows.map(r => r.unlevered), cum = rows.map(r => r.cum_equity);
  const hi = Math.max(0, ...net, ...cum), lo = Math.min(0, ...net, ...cum), span = (hi - lo) || 1;
  const y = v => T + (H - T - B) * (hi - v) / span, bw = Math.max(2, (W - L - R) / n - 2), x = i => L + (W - L - R) * (i + .5) / n;
  const ticks = [...new Set([lo, 0, hi])];
  const line = cum.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join("");
  const pk = rows.findIndex(r => r.month === d.peak_month);
  return `<div class="chartbox"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Monthly cash flow and cumulative equity" style="font-size:12px;stroke:none">
   ${ticks.map(v => `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L - 8}" y="${y(v) + 4}" text-anchor="end" fill="var(--muted)">${mm(v)}</text>`).join("")}
   <line x1="${L}" x2="${W - R}" y1="${y(0)}" y2="${y(0)}" stroke="var(--ink)" stroke-width="1"/>
   ${rows.map((r, i) => { const v = r.unlevered, top = Math.min(y(0), y(v)), h = Math.abs(y(v) - y(0)); return `<rect x="${x(i) - bw / 2}" y="${top}" width="${bw}" height="${Math.max(h, 1)}" fill="${v >= 0 ? "var(--ink)" : "var(--muted)"}" opacity=".55"><title>${esc(r.label)}: net ${money(v)}, cumulative equity ${money(r.cum_equity)}, debt ${money(r.debt)}</title></rect>`; }).join("")}
   <path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2"/>
   ${pk >= 0 ? `<circle cx="${x(pk)}" cy="${y(cum[pk])}" r="5" fill="var(--accent)" stroke="var(--surface)" stroke-width="2"/><text x="${x(pk) - 12}" y="${y(cum[pk]) - 8}" text-anchor="end" fill="var(--ink)">Peak equity ${money(-cum[pk])}, ${esc(rows[pk].label)}</text>` : ""}
   <text x="${L}" y="${H - 8}" fill="var(--muted)">${esc(rows[0].label)}</text><text x="${W - R}" y="${H - 8}" text-anchor="end" fill="var(--muted)">${esc(rows[n - 1].label)}</text></svg>
   <div class="tsub" style="line-height:1.4;padding:4px 0 0">Bars: net cash flow each month before debt (grey out, dark in). Line: cumulative equity after debt.</div></div>`;
}

/* ---------- programme tab ---------- */
const PG = { data: null, id: null, busy: false };
async function loadProgramme() {
  const id = drawer.id; PG.busy = true;
  try { const r = await api("/api/programme/get", { id }); if (drawer?.id !== id) return; PG.data = r; PG.id = id; } catch (e) { toast(e.message); }
  PG.busy = false; if (drawer?.tab === "programme") paintDrawer(true);
}
const PG_NUM = ["planning_months", "precon_months", "build_months", "sales_months"], PG_PCT = ["presale_pct", "fees_pre_pct", "land_deposit_pct"];
function tProgramme() {
  if (PG.id !== drawer.id) { PG.data = null; PG.id = drawer.id; loadProgramme(); }
  const d = PG.data; if (!d) return '<div class="empty">Building the programme</div>';
  const e = d.programme, L = d.labels, tl = d.timeline, src = k => d.programme.source[k];
  const badge = k => src(k) === "set" ? '<span class="chip acc" title="Set on this programme">set</span>' : `<span class="chip" title="${src(k) === "assumption" ? "Follows the appraisal assumptions" : "Default"}">${src(k) === "assumption" ? "assumption" : "default"}</span>`;
  const field = k => `<label class="field"><span>${esc(L[k])} ${badge(k)}</span><input type="number" step="any" data-pg="${k}" value="${PG_PCT.includes(k) ? Math.round(e[k] * 100) : e[k]}"></label>`;
  const dl = d.delay;
  const last = d.rows[d.rows.length - 1];
  return `<div class="stat4">${kpi("Months to practical completion", tl.pc, `${tl.end} months to the last sale`)}${kpi("Planning to grant", e.planning_months + " months", `pre-construction ${e.precon_months}`)}${kpi("Peak equity", money(-d.rows.reduce((m, r) => Math.min(m, r.cum_equity), 0)), d.rows[d.peak_month]?.label || "")}${kpi("Cost of a month's delay", dl?.per_month ? money(dl.per_month) : "n/a", "profit at the price tested")}</div>
   <div class="card pad" style="margin:14px 0"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px"><h3>Build programme</h3><span class="tsub">${d.custom ? "A programme is set for this site. It replaces the standard timing in every figure." : "Standard timing is in use. Set a programme to control when money moves."}</span></div>${ganttSvg(d)}</div>
   <div class="card pad" style="margin-bottom:14px"><h3 style="margin-bottom:8px">Timing and payments</h3>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px">${PG_NUM.map(field).join("")}${["presale_pct", "fees_pre_pct"].map(field).join("")}
     <label class="field"><span>${esc(L.land_mode)} ${badge("land_mode")}</span><select data-pg="land_mode">${Object.entries(d.land_modes).map(([k, v]) => `<option value="${k}" ${e.land_mode === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
     ${e.land_mode === "conditional" ? field("land_deposit_pct") : ""}
     <label class="field"><span>${esc(L.statutory_at)} ${badge("statutory_at")}</span><select data-pg="statutory_at">${Object.entries(d.statutory).map(([k, v]) => `<option value="${k}" ${e.statutory_at === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label>
     <label class="field"><span>${esc(L.start)}</span><input type="month" data-pg="start" value="${esc(d.dated ? d.start : "")}" placeholder="${esc(d.start)}"></label></div>
    <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap"><button class="btn primary sm" data-act="pgsave">${d.custom ? "Save programme" : "Use this programme"}</button>${d.custom ? '<button class="btn sm" data-act="pgclear">Back to standard timing</button>' : ""}
     <span class="tsub" style="align-self:center">Presales bring receipts forward to practical completion. A conditional contract defers the land balance to planning grant and shortens the time the land is financed. The Excel model keeps the standard timing.</span></div></div>
   <div class="card pad" style="margin-bottom:14px"><h3 style="margin-bottom:8px">Monthly cash flow</h3>${cashSvg(d)}</div>
   ${dl?.rows?.length ? `<div class="card" style="margin-bottom:14px"><div class="h"><h3>What planning delay costs</h3><span class="m">land price held at the price tested</span></div><table><thead><tr><th>Delay to consent</th><th class="num">Profit</th><th class="num">Margin on GDV</th><th class="num">Levered IRR</th><th class="num">Peak equity</th><th class="num">Profit lost</th></tr></thead><tbody>${dl.rows.map(r => `<tr style="cursor:default"><td>${r.delay ? "+" + r.delay + " months" : "Base case"}</td><td class="num">${money(r.profit)}</td><td class="num">${pct(r.profit_on_gdv)}</td><td class="num">${pct(r.irr_levered)}</td><td class="num">${money(r.peak_equity)}</td><td class="num"><b>${r.delay ? money(r.cost) : ""}</b></td></tr>`).join("")}</tbody></table></div>` : ""}
   <div class="card"><div class="h"><h3>Month by month</h3><span class="m">${d.rows.length} months</span></div><div class="tablewrap" style="max-height:380px"><table><thead><tr><th>Month</th><th class="num">Land</th><th class="num">Fees</th><th class="num">Build</th><th class="num">S106 and CIL</th><th class="num">Receipts</th><th class="num">Net</th><th class="num">Debt balance</th><th class="num">Cumulative equity</th></tr></thead><tbody>${d.rows.map(r => `<tr style="cursor:default"><td>${esc(r.label)}</td>${["land", "fees", "build", "statutory", "receipts"].map(k => `<td class="num">${r[k] ? money(r[k]) : ""}</td>`).join("")}<td class="num"><b>${money(r.unlevered)}</b></td><td class="num">${money(r.debt)}</td><td class="num">${money(r.cum_equity)}</td></tr>`).join("")}</tbody></table></div></div>`;
}
function pgCollect() {
  const d = PG.data, out = {};
  $$("[data-pg]").forEach(el => {
    const k = el.dataset.pg; let v = el.value; if (v === "") return;
    const shown = PG_PCT.includes(k) ? Math.round(d.programme[k] * 100) : d.programme[k];
    if (d.programme.source[k] === "set" || String(v) !== String(shown) || k === "start") out[k] = PG_NUM.includes(k) || PG_PCT.includes(k) ? +v : v;
  });
  if (!d.custom) { const sv = d.start_values; if (out.precon_months == null) out.precon_months = sv.precon_months; if (out.fees_pre_pct == null) out.fees_pre_pct = sv.fees_pre_pct * 100; }
  return out;
}
async function pgAfter(r) { PG.data = r; PG.id = drawer.id; drawer.struct = null; FD.data = null; FD.id = null; await load(false); await refreshDrawer(true); }

/* ---------- funding card (Structure tab) ---------- */
const FD = { data: null, id: null, busy: false };
async function loadFunding() {
  const id = drawer.id; FD.busy = true;
  try { const r = await api("/api/funding/get", { id }); if (drawer?.id !== id) return; FD.data = r; FD.id = id; } catch (e) { toast(e.message); }
  FD.busy = false; if (drawer?.tab === "structure") paintDrawer(true);
}
function debtSvg(sch) {
  const W = 900, H = 200, L = 64, R = 14, T = 12, B = 26, n = sch.length, mx = Math.max(1, ...sch.map(r => r.debt), ...sch.map(r => -r.equity)), y = v => T + (H - T - B) * (1 - v / mx), x = i => L + (W - L - R) * (i + .5) / n, bw = Math.max(2, (W - L - R) / n - 2);
  const line = sch.map((r, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(r.debt).toFixed(1)}`).join("");
  return `<div class="chartbox"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Debt balance and equity injected each month" style="font-size:12px;stroke:none">
   ${[0, mx / 2, mx].map(v => `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L - 8}" y="${y(v) + 4}" text-anchor="end" fill="var(--muted)">${money(v)}</text>`).join("")}
   ${sch.map((r, i) => r.equity < 0 ? `<rect x="${x(i) - bw / 2}" y="${y(-r.equity)}" width="${bw}" height="${y(0) - y(-r.equity)}" fill="var(--muted)" opacity=".6"><title>${esc(r.label)}: equity in ${money(-r.equity)}</title></rect>` : "").join("")}
   <path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2"/>${sch.map((r, i) => `<circle cx="${x(i)}" cy="${y(r.debt)}" r="6" fill="transparent"><title>${esc(r.label)}: debt ${money(r.debt)}, drawn ${money(r.draw)}</title></circle>`).join("")}
   <text x="${L}" y="${H - 6}" fill="var(--muted)">${esc(sch[0].label)}</text><text x="${W - R}" y="${H - 6}" text-anchor="end" fill="var(--muted)">${esc(sch[n - 1].label)}</text></svg>
   <div class="tsub" style="padding-top:4px">Line: debt balance including rolled interest. Bars: equity paid in each month.</div></div>`;
}
function fundingCard() {
  if (FD.id !== drawer.id) { FD.data = null; FD.id = drawer.id; loadFunding(); }
  const d = FD.data; if (!d) return `<div class="card pad" style="margin-bottom:14px"><div class="tsub">Setting out the debt package</div></div>`;
  const t = d.terms, r = d.returns, rq = d.request, su = d.sources_uses, ln = d.lender;
  const f = (k, l, v, step = "any") => `<label class="field"><span>${l}</span><input type="number" step="${step}" data-fd="${k}" value="${v}"></label>`;
  return `<div class="card pad" style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><h3>Funding package</h3><span class="chip ${ln.pass_all ? "ok" : "hi"}">${ln.pass_all ? "Within covenant limits" : "Outside a covenant limit"}</span></div>
   <div class="tsub" style="margin:4px 0 12px">${d.prog_custom ? "Drawdown follows the programme you set." : "Drawdown follows the standard timing. Set a programme on the Programme tab to phase land, fees and sales."} Terms here feed every figure in the appraisal.</div>
   <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px">${f("ltc", "Senior loan to cost (%)", +(t.ltc * 100).toFixed(1))}${f("mezz_ltc", "Mezzanine loan to cost (%)", +(t.mezz_ltc * 100).toFixed(1))}${f("finance_rate", "Senior all-in rate (% pa)", +(t.finance_rate * 100).toFixed(2))}${f("mezz_rate", "Mezzanine rate (% pa)", +(t.mezz_rate * 100).toFixed(2))}${f("debt_fee_pct", "Arrangement fee (%)", +(t.debt_fee_pct * 100).toFixed(2))}${f("exit_fee_pct", "Exit fee (%)", +(t.exit_fee_pct * 100).toFixed(2))}
    <label class="field"><span>Drawdown</span><select data-fd="draw_mode">${Object.entries(d.draw_modes).map(([k, v]) => `<option value="${k}" ${t.draw_mode === k ? "selected" : ""}>${esc(v)}</option>`).join("")}</select></label></div>
   <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap"><button class="btn primary sm" data-act="fdsave">Save terms</button><button class="btn sm" data-act="fdterm">Create finance request (Word)</button><span class="tsub" style="align-self:center">A one page request for indicative terms, with borrower details left in brackets.</span></div>
   <div class="stat4" style="margin-top:14px">${kpi("Senior facility", money(rq.senior), `${(t.ltc * 100).toFixed(0)}% of ${money(rq.budget)} funded cost`)}${kpi("Peak debt", money(d.peak_debt), `term ${rq.tenor_months} months`)}${kpi("Levered IRR", pct(r.irr_levered), `unlevered ${pct(r.irr_unlevered)}`)}${kpi("Interest and fees", money((r.interest || 0) + (r.fees || 0)), `equity peak ${money(r.peak_equity)}`)}</div>
   <div class="two" style="margin-top:14px;align-items:start"><div><div class="kl" style="margin-bottom:6px">What the debt does</div><table><thead><tr><th>Package</th><th class="num">Levered IRR</th><th class="num">Multiple</th><th class="num">Peak equity</th><th class="num">Profit to equity</th></tr></thead><tbody>${d.compare.filter(c => !(c.name === "Current package" && d.compare.some(o => o !== c && o.ltc === c.ltc && o.mezz_ltc === c.mezz_ltc))).map(c => `<tr style="cursor:default${c.current ? ";background:var(--accent-soft)" : ""}"><td style="white-space:nowrap">${esc(c.name)}</td><td class="num">${pct(c.irr_levered)}</td><td class="num">${c.equity_multiple ? c.equity_multiple.toFixed(2) + "x" : "n/a"}</td><td class="num">${money(c.peak_equity)}</td><td class="num">${money(c.equity_profit)}</td></tr>`).join("")}</tbody></table></div>
    <div><div class="kl" style="margin-bottom:6px">Uses and sources</div><table><tbody>${su.uses.map(u => `<tr style="cursor:default"><td>${esc(u.label)}</td><td class="num">${money(u.value)}</td></tr>`).join("")}<tr class="tot" style="cursor:default"><td><b>Total uses</b></td><td class="num"><b>${money(su.total_uses)}</b></td></tr></tbody></table>
     <table style="margin-top:8px"><tbody>${su.sources.map(u => `<tr style="cursor:default"><td>${esc(u.label)}</td><td class="num">${money(u.value)}</td></tr>`).join("")}</tbody></table></div></div>
   <div class="kl" style="margin:14px 0 6px">Drawdown</div>${debtSvg(d.schedule)}<div class="tsub" style="margin-top:6px">${esc(su.note)}</div></div>`;
}

/* ---------- comparables (Market tab) ---------- */
const CP = { data: null, id: null, busy: false, open: null };
async function loadComps(body) {
  const id = drawer.id; CP.busy = true;
  try { const r = await api(body ? "/api/compset/save" : "/api/compset/get", { id, ...(body || {}) }); if (drawer?.id !== id) return; CP.data = r; CP.id = id; } catch (e) { toast(e.message); }
  CP.busy = false; if (drawer?.tab === "market") paintDrawer(true);
}
function compMap(d) {
  const pts = (d.subjects.flatMap(s => s.rows)).filter(r => r.lat != null && r.dist_km != null), site = d.site;
  if (!pts.length || site.lat == null) return '<div class="tsub">Sale locations need postcode coordinates. Pull sold prices again with a connection to postcodes.io.</div>';
  const W = 560, H = 380, cx = W / 2, cy = H / 2, mx = Math.max(.5, ...pts.map(p => p.dist_km)) * 1.08, sc = (Math.min(W, H) / 2 - 16) / mx;
  const xy = p => [cx + (p.lon - site.lon) * 111.32 * Math.cos(site.lat * Math.PI / 180) * sc, cy - (p.lat - site.lat) * 110.574 * sc];
  const rings = [.5, 1, 2, 3, 5].filter(k => k < mx);
  return `<div class="chartbox"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Sold comparables around the site" style="font-size:15px;stroke:none">
   ${rings.map(k => `<circle cx="${cx}" cy="${cy}" r="${k * sc}" fill="none" stroke="var(--line)"/><text x="${cx + k * sc + 3}" y="${cy - 3}" fill="var(--muted)">${k} km</text>`).join("")}
   ${pts.map(p => { const [x, y] = xy(p), used = p.included; return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="6" fill="${used ? "var(--ink)" : "var(--surface)"}" stroke="${p.new_build ? "var(--accent)" : "var(--muted)"}" stroke-width="2" data-cptoggle="${esc(p.id)}" style="cursor:pointer"><title>${esc([p.saon, p.paon, p.street].filter(Boolean).join(" "))}, ${esc(p.postcode)}: ${money(p.price)} on ${esc(p.date)}${p.adjusted ? ", adjusted " + money(p.adjusted) : ""}. Click to ${used ? "switch off" : "switch on"}.</title></circle>`; }).join("")}
   <rect x="${cx - 6}" y="${cy - 6}" width="12" height="12" fill="var(--accent)" stroke="var(--surface)" stroke-width="2"><title>The site</title></rect></svg>
   <div class="tsub" style="padding-top:4px">Square: the site. Filled: sale in use. Hollow: switched off or out of range. Orange ring: new build. Positions are the postcode, not the property. Click a sale to switch it.</div></div>`;
}
function compCard() {
  const s = drawer.site; if (!s.comp_set?.sales?.length) return "";
  if (CP.id !== drawer.id) { CP.data = null; CP.id = drawer.id; loadComps(); }
  const d = CP.data; if (!d) return `<div class="card pad" style="margin-top:14px"><div class="tsub">Adjusting the comparables</div></div>`;
  if (!d.has) return "";
  const v = d.factors.values, src = d.factors.source, L = d.factors.labels;
  const fin = (k, val, st = "any") => `<label class="field"><span>${esc(L[k])} <span class="chip ${src[k] === "default" ? "" : "acc"}">${esc(src[k])}</span></span><input type="number" step="${st}" data-cp="${k}" value="${val}"></label>`;
  return `<div class="card" style="margin-top:14px"><div class="h"><h3>Comparable evidence and adjustments</h3><span class="m">${d.n} sales from ${esc(d.sector || "")}, pulled ${esc(d.fetched || "")}</span></div>
   <div style="padding:0 16px 16px"><div class="tsub" style="margin-bottom:10px">Each sale is brought to the subject home: at its £ per sq ft where a floor area is known, aged forward for price growth, and lifted for a new build premium if it was second-hand. Switch a sale off to leave it out. ${esc(d.note)}</div>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">${fin("growth_pa", +(v.growth_pa * 100).toFixed(2))}${fin("newbuild_premium", +(v.newbuild_premium * 100).toFixed(1))}${fin("distance_pct_km", +(v.distance_pct_km * 100).toFixed(1))}${fin("max_km", v.max_km)}${fin("max_months", v.max_months)}</div>
    <div style="display:flex;gap:8px;margin:12px 0;flex-wrap:wrap"><button class="btn sm primary" data-act="cpsave">Apply adjustments</button><button class="btn sm" data-act="cpreset">Reset</button><button class="btn sm" data-act="cpuse" title="Write the adjusted values into the homes schedule">Use adjusted values in the appraisal</button></div>
    <div class="two" style="align-items:start"><div>${compMap(d)}</div><div><table><thead><tr><th>Type</th><th class="num">Sales used</th><th class="num">Adjusted value</th><th>Range</th></tr></thead><tbody>${d.subjects.map(sb => `<tr style="cursor:pointer" data-act="cpopen" data-c="${esc(sb.class)}"><td><b>${esc(sb.class)}</b><div class="tsub">${sb.units.length ? esc(sb.units.join(", ")) : "no homes of this type in the schedule"}</div></td><td class="num">${sb.n}</td><td class="num">${sb.value ? `<b>${money(sb.value)}</b><div class="tsub">${Math.round(sb.psf || 0)} psf</div>` : '<span class="tsub">too few sales</span>'}</td><td>${sb.value ? `${money(sb.low)} to ${money(sb.high)} <span class="chip ${sb.confidence === "high" ? "ok" : sb.confidence === "medium" ? "med" : "lo"}">${esc(sb.confidence)}</span>` : ""}</td></tr>`).join("")}</tbody></table>
     <div class="tsub" style="margin-top:6px">Select a type to see each sale and what was done to it.</div></div></div>
    ${CP.open ? (() => { const sb = d.subjects.find(x => x.class === CP.open); if (!sb) return ""; return `<div class="tablewrap" style="max-height:340px;margin-top:12px"><table><thead><tr><th>Sale</th><th>Date</th><th class="num">Price</th><th class="num">Adjusted</th><th>Adjustments</th><th></th></tr></thead><tbody>${sb.rows.slice(0, 80).map(r => `<tr style="cursor:default;${r.included ? "" : "opacity:.55"}"><td>${esc([r.saon, r.paon, r.street].filter(Boolean).join(" "))}, ${esc(r.postcode)}${r.new_build ? ' <span class="chip acc">new build</span>' : ""}</td><td>${esc(r.date)}</td><td class="num">${money(r.price)}</td><td class="num">${r.adjusted ? "<b>" + money(r.adjusted) + "</b>" : ""}</td><td class="tsub">${r.steps ? r.steps.map(x => `${esc(x.label)} (${sgn(x.value)})`).join("; ") : esc(r.status)}</td><td><button class="btn sm" data-cptoggle="${esc(r.id)}">${r.included ? "Switch off" : r.status === "out of range" ? "" : "Switch on"}</button></td></tr>`).join("")}</tbody></table></div>`; })() : ""}</div></div>`;
}

/* ---------- planning strategy (Planning tab) ---------- */
const ST9 = { data: null, id: null, busy: false };
async function loadStrategy() {
  const id = drawer.id; ST9.busy = true;
  try { const r = await api("/api/strategy/get", { id }); if (drawer?.id !== id) return; ST9.data = r; ST9.id = id; } catch (e) { toast(e.message); }
  ST9.busy = false; if (drawer?.tab === "planning") paintDrawer(true);
}
function strategyCard() {
  if (ST9.id !== drawer.id) { ST9.data = null; ST9.id = drawer.id; loadStrategy(); }
  const d = ST9.data; if (!d) return `<div class="card pad" style="margin-bottom:14px"><div class="tsub">Working out the planning route</div></div>`;
  const lv = { Low: "ok", Medium: "med", High: "hi" }[d.level], tl = d.timeline, mx = Math.max(1, ...tl.stages.map(x => x.months));
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Planning strategy</h3><span class="chip ${lv}">Complexity ${esc(d.level.toLowerCase())}, ${d.score} points</span></div>
   <div style="padding:0 16px 16px"><div class="verdict" style="margin-bottom:12px"><div><div class="l" style="font-size:11.5px;letter-spacing:.07em;text-transform:uppercase;color:var(--muted);font-weight:600">Recommended route</div><div class="vt" style="font-size:19px">${esc(d.route.title)}</div><div class="tsub">${esc(d.route.summary)}</div></div>${tl.total_months ? `<div style="text-align:right"><div class="tsub">Route to consent</div><b style="font-size:22px;white-space:nowrap">${tl.total_months} months</b>${tl.differs ? `<div class="tsub">appraisal assumes ${tl.assumed_months}</div>` : ""}</div>` : ""}</div>
    <div class="two" style="align-items:start"><div><div class="kl" style="margin-bottom:6px">Next steps</div>${d.route.steps.map((x, i) => `<div style="padding:4px 0">${i + 1}. ${esc(x)}</div>`).join("")}
     ${d.reports.length ? `<div class="kl" style="margin:14px 0 6px">Reports to commission</div><div class="tsub">${d.reports.map(esc).join(", ")}.</div>` : ""}
     <div class="kl" style="margin:14px 0 6px">How the score is made up</div>${d.factors.length ? d.factors.map(f => `<div style="display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px solid var(--line)"><span>${esc(f.label)}</span><b style="color:${f.points < 0 ? "var(--ok)" : "var(--ink)"}">${f.points > 0 ? "+" : ""}${f.points}</b></div>`).join("") : '<div class="tsub">Nothing on file adds complexity.</div>'}</div>
     <div>${tl.stages.length ? `<div class="kl" style="margin-bottom:6px">Route to consent</div>${tl.stages.map(x => `<div style="display:flex;gap:8px;align-items:center;padding:3px 0"><span style="width:210px;font-size:12.5px">${esc(x.stage)}</span><span style="flex:1;background:var(--surface2);height:10px"><i style="display:block;height:10px;width:${x.months / mx * 100}%;background:var(--accent)"></i></span><b style="width:24px;text-align:right">${x.months}</b></div>`).join("")}` : ""}
     ${d.arguments.length ? `<div class="kl" style="margin:14px 0 6px">The case to make</div>${d.arguments.map(a => `<div style="padding:6px 0;border-bottom:1px solid var(--line)">${esc(a.text)}<div class="tsub">${esc(a.source)} · <span class="chip ${a.strength === "Strong" ? "ok" : "med"}">${esc(a.strength)}</span></div></div>`).join("")}` : ""}</div></div>
    ${d.concerns.length ? `<div class="kl" style="margin:16px 0 6px">Likely concerns and how to meet them</div><table><thead><tr><th>Topic</th><th>Concern</th><th>Response</th></tr></thead><tbody>${d.concerns.map(c => `<tr style="cursor:default"><td style="min-width:130px"><span class="chip ${sevClass(c.level)}">${esc(c.level)}</span> <b>${esc(c.topic)}</b><div class="tsub">${esc(c.source)}</div></td><td>${esc(c.detail)}</td><td>${esc(c.mitigation)}</td></tr>`).join("")}</tbody></table>` : ""}
    <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">${tl.total_months ? `<button class="btn sm primary" data-act="stapply">Set the programme to ${tl.total_months} months to consent</button>` : ""}<button class="btn sm" data-act="stdoc">Planning strategy (Word)</button></div>
    <div class="tsub" style="margin-top:8px">${esc(d.caveat)}</div></div></div>`;
}

/* ---------- history tab ---------- */
const HS = { data: null, id: null, a: null, b: "now", diff: null, busy: false };
async function loadHistory() {
  const id = drawer.id; HS.busy = true;
  try {
    const r = await api("/api/history/get", { id }); if (drawer?.id !== id) return; HS.data = r; HS.id = id;
    if (r.versions.length) { if (HS.a == null || HS.a >= r.versions.length) { HS.a = Math.max(0, r.versions.length - 2); HS.b = r.versions.length > 1 ? r.versions.length - 1 : "now"; } HS.diff = await api("/api/history/diff", { id, a: HS.a, b: HS.b }); } else HS.diff = null;
  } catch (e) { toast(e.message); }
  HS.busy = false; if (drawer?.tab === "history") paintDrawer(true);
}
const metricFmt = (m, v) => v == null ? "n/a" : m.kind === "money" ? money(v) : m.kind === "pct" ? pct(v) : num9(v);
function attributionBars(parts) {
  const ok = parts.filter(p => p.profit_change != null); if (!ok.length) return "";
  const mx = Math.max(1, ...ok.map(p => Math.abs(p.profit_change)));
  return ok.map(p => `<div style="display:flex;gap:10px;align-items:center;padding:4px 0"><span style="width:150px">${esc(p.label)}</span><span style="flex:1;display:flex;align-items:center;height:14px"><span style="width:50%;display:flex;justify-content:flex-end">${p.profit_change < 0 ? `<i style="display:block;height:12px;width:${Math.abs(p.profit_change) / mx * 100}%;background:var(--hi)" title="${esc(p.label)}: ${sgn(p.profit_change)}"></i>` : ""}</span><span style="width:1px;height:16px;background:var(--ink)"></span><span style="width:50%">${p.profit_change > 0 ? `<i style="display:block;height:12px;width:${p.profit_change / mx * 100}%;background:var(--ok)" title="${esc(p.label)}: ${sgn(p.profit_change)}"></i>` : ""}</span></span><b style="width:90px;text-align:right">${sgn(p.profit_change)}</b></div>`).join("");
}
function tHistory() {
  if (HS.id !== drawer.id) { HS.data = null; HS.id = drawer.id; HS.a = null; HS.b = "now"; loadHistory(); }
  const d = HS.data; if (!d) return '<div class="empty">Reading the history</div>';
  if (!d.versions.length) return `<div class="card pad"><h3>Change history</h3><div class="tsub" style="margin-top:6px">Nothing has been changed on this site yet. From the first saved change, each version is kept here, so you can see what moved the numbers.</div></div>` + eventsList(d.timeline.filter(x => x.kind === "event"));
  const df = HS.diff, opt = (sel, allowNow) => d.versions.map(v => `<option value="${v.index}" ${String(sel) === String(v.index) ? "selected" : ""}>${esc(fdt9(v.t))}: ${esc(v.label)}</option>`).join("") + (allowNow ? `<option value="now" ${sel === "now" ? "selected" : ""}>Now (current state)</option>` : "");
  return `<div class="card pad" style="margin-bottom:14px"><h3>Compare two versions</h3>
   <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin:10px 0"><label class="field" style="min-width:260px"><span>From</span><select id="hs_a">${opt(HS.a, false)}</select></label><label class="field" style="min-width:260px"><span>To</span><select id="hs_b">${opt(HS.b, true)}</select></label><button class="btn sm primary" data-act="hsdiff">Compare</button></div>
   ${df ? (df.same ? '<div class="tsub">These two versions have the same inputs.</div>' : `<div class="two" style="align-items:start"><div><div class="kl" style="margin-bottom:6px">What moved the answer</div><table><thead><tr><th></th><th class="num">Before</th><th class="num">After</th><th class="num">Change</th></tr></thead><tbody>${df.metrics.map(m => `<tr style="cursor:default"><td>${esc(m.label)}</td><td class="num">${metricFmt(m, m.a)}</td><td class="num">${metricFmt(m, m.b)}</td><td class="num"><b style="color:${m.delta == null || m.delta === 0 ? "inherit" : (m.key === "total_cost" || m.key === "peak_equity") === m.delta > 0 ? "var(--hi)" : "var(--ok)"}">${m.delta == null ? "" : m.kind === "money" ? sgn(m.delta) : m.kind === "pct" ? (m.delta > 0 ? "+" : "") + (m.delta * 100).toFixed(1) + " pts" : (m.delta > 0 ? "+" : "") + num9(m.delta)}</b></td></tr>`).join("")}</tbody></table>
     ${df.attribution.length ? `<div class="kl" style="margin:14px 0 6px">Change in profit by group of inputs</div>${attributionBars(df.attribution)}<div class="tsub" style="margin-top:4px">Applied in order (scheme, price, assumptions, programme, funding). Where inputs interact the split depends on that order.</div>` : ""}</div>
     <div><div class="kl" style="margin-bottom:6px">Inputs that changed</div><table><thead><tr><th>Input</th><th>Before</th><th>After</th></tr></thead><tbody>${df.changes.map(c => `<tr style="cursor:default"><td>${esc(c.label)}<div class="tsub">${esc(c.group_label)}</div></td><td>${esc(c.old)}</td><td><b>${esc(c.new)}</b></td></tr>`).join("")}</tbody></table></div></div>`) : ""}</div>
   ${eventsList(d.timeline)}`;
}
function eventsList(tl) {
  if (!tl.length) return "";
  return `<div class="card"><div class="h"><h3>Timeline</h3><span class="m">versions and events</span></div><div class="list">${tl.map(x => x.kind === "version"
    ? `<div class="row" style="cursor:default"><span class="chip acc">Version</span><div class="grow"><div class="t">${esc(x.title)}</div><div class="m">${esc(fdt9(x.t))}</div></div><div style="text-align:right"><b>${x.profit != null ? money(x.profit) : "n/a"}</b><div class="tsub" style="color:${x.delta > 0 ? "var(--ok)" : x.delta < 0 ? "var(--hi)" : "inherit"}">${x.delta != null && x.delta !== 0 ? sgn(x.delta) : ""}</div></div></div>`
    : `<div class="row" style="cursor:default"><span class="chip">${esc(x.level === "important" ? "Alert" : "Event")}</span><div class="grow"><div class="t">${esc(x.title)}</div><div class="m">${esc(x.detail || "")}</div></div><div class="tsub">${esc(fdt9(x.t))}</div></div>`).join("")}</div></div>`;
}

/* ---------- pack builder (Report tab) ---------- */
const PK = { kind: "report", data: null, id: null, busy: false, dirty: false, drag: null, opts: null };
const PK_KINDS = [["report", "Site report"], ["committee", "Committee paper"], ["brief", "Site brief"], ["deck", "Investor deck"]];
async function loadPack(opts) {
  const id = drawer.id; PK.busy = true;
  try { const r = await api("/api/pack/get", { id, kind: PK.kind, strategy: drawer.ev?.strategy, ...(opts ? { opts } : {}) }); if (drawer?.id !== id) return; PK.data = r; PK.id = id; PK.opts = r.opts; if (!opts) PK.dirty = false; } catch (e) { toast(e.message); }
  PK.busy = false; if (drawer?.tab === "report") paintDrawer(true);
}
function packOpts() { const secs = PK.data.sections; return { order: secs.map(s => s.id), off: secs.filter(s => !s.on).map(s => s.id) }; }
function packCard() {
  if (PK.id !== drawer.id) { PK.data = null; PK.id = drawer.id; PK.dirty = false; loadPack(); }
  const d = PK.data, b = D.brand || { name: "easyDevelopment", accent: "#FF6600" };
  const head = `<div class="card pad" style="margin-bottom:14px"><div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">${PK_KINDS.map(([k, l]) => `<button class="btn sm ${PK.kind === k ? "primary" : ""}" data-act="pkkind" data-k="${k}">${l}</button>`).join("")}</div>`;
  if (!d) return head + '<div class="tsub">Building the preview</div></div>';
  const secs = d.sections;
  const list = `<div class="kl" style="margin-bottom:6px">Sections (drag to reorder)</div><div id="pk_list">${secs.map((s, i) => `<div class="pkrow" draggable="true" data-pkid="${esc(s.id)}" style="display:flex;gap:8px;align-items:center;padding:7px 8px;border:1px solid var(--line);margin-bottom:-1px;background:var(--surface);cursor:grab;${s.on ? "" : "opacity:.5"}"><span style="color:var(--muted);user-select:none">⋮⋮</span><input type="checkbox" data-pkon="${esc(s.id)}" ${s.on ? "checked" : ""} aria-label="Include ${esc(s.title)}"><span class="grow">${esc(s.title)}</span><button class="btn sm" data-act="pkmove" data-id="${esc(s.id)}" data-d="-1" ${i === 0 ? "disabled" : ""} aria-label="Move up">↑</button><button class="btn sm" data-act="pkmove" data-id="${esc(s.id)}" data-d="1" ${i === secs.length - 1 ? "disabled" : ""} aria-label="Move down">↓</button></div>`).join("")}</div>`;
  const dl = { report: `<button class="btn sm" data-act="repprint">Print or save as PDF</button>`, committee: `<button class="btn sm primary" data-act="cpaper" data-id="${esc(drawer.id)}">Download committee paper</button>`, brief: `<button class="btn sm primary" data-act="briefdl">Download site brief</button>`, deck: `<button class="btn sm primary" data-act="deck" data-id="${esc(drawer.id)}">Download deck</button>` }[PK.kind];
  const brand = `<div class="kl" style="margin:14px 0 6px">House style</div><div style="display:flex;gap:8px;align-items:end;flex-wrap:wrap"><label class="field"><span>Name on outputs</span><input type="text" id="pk_bn" value="${esc(b.name)}" style="width:170px"></label><label class="field"><span>Accent colour</span><input type="color" id="pk_bc" value="${esc(b.accent.toLowerCase())}" style="width:60px;height:38px;padding:2px"></label><button class="btn sm" data-act="pkbrand">Save style</button></div><div class="tsub" style="margin-top:4px">Applies to the report, committee paper, brief and deck.</div>`;
  const preview = PK.kind === "report" ? `<iframe id="rep_frame" srcdoc="${esc(d.html)}" style="width:100%;height:1100px;border:1px solid var(--line);border-radius:0;background:#fff"></iframe>`
    : `<div class="tsub" style="margin-bottom:8px">${PK.kind === "deck" ? "Outline of the slides as they will export, in order. The download is the finished PowerPoint." : "Outline of the sections as they will export, in order. The download is the finished Word document."}</div><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px">${d.outline.map((o, i) => `<div class="card pad" style="min-height:130px"><div class="tsub">${PK.kind === "deck" ? "Slide " + (o.n || i + 1) : "Section " + (i + 1)}${o.extras?.length ? " · " + esc(o.extras.join(", ")) : ""}</div><b>${esc(o.title)}</b>${(o.lines || []).slice(0, 4).map(l => `<div class="tsub" style="margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(l)}</div>`).join("")}</div>`).join("")}</div>`;
  return head + `<div style="display:grid;grid-template-columns:minmax(260px,320px) minmax(0,1fr);gap:18px;align-items:start"><div>${list}
    <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap"><button class="btn sm primary" data-act="pkpreview">Update preview</button><button class="btn sm" data-act="pksave">Save arrangement</button><button class="btn sm" data-act="pkreset">Reset</button>${dl}</div>
    ${PK.dirty ? '<div class="tsub" style="margin-top:6px;color:var(--med)">The preview shows changes you have not saved. Downloads use the saved arrangement.</div>' : ""}${brand}</div><div>${preview}</div></div></div>`;
}
function tReport9() {
  const s = drawer.site, u = `/report/${encodeURIComponent(s.id)}?strategy=${drawer.ev.strategy}`;
  return `${packCard()}<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"><button class="btn sm" data-act="repwin" data-u="${esc(u)}">Open the saved report in a window</button></div>`;
}

/* ---------- live numbers bar and deal room ---------- */
const room = () => lsG8("ed_room", false);
function nbarHtml() {
  if (!drawer?.ev?.appraisal) return "";
  const a = drawer.ev.appraisal, s = drawer.site, base = s?._ev?.appraisal, ok = a && !a.incomplete;
  if (!ok) return `<div class="nbar"><span class="tsub">Add ${esc((a?.missing || ["site details"]).join(" and "))} to see the numbers.</span></div>`;
  const cell = (l, v, b, kind, good) => { const dlt = base && !base.incomplete && b != null && v != null ? v - b : null; const sig = dlt != null && Math.abs(dlt) > (kind === "pct" ? 5e-5 : 0.5); const tone = !sig ? "" : (dlt > 0) === good ? "var(--ok)" : "var(--hi)";
    return `<div class="nb"><div class="l">${l}</div><div class="v">${kind === "pct" ? pct(v) : money(v)}</div><div class="d" style="color:${tone}">${sig ? (kind === "pct" ? (dlt > 0 ? "+" : "") + (dlt * 100).toFixed(1) + " pts" : sgn(dlt)) + " vs saved" : "&nbsp;"}</div></div>`; };
  const m = a.profit_basis === "gdv" ? "profit_on_gdv" : "profit_on_cost";
  const dirty = Object.keys(drawer.ovr || {}).length > 0;
  return `<div class="nbar">${cell("Residual land value", a.rlv, base?.rlv, "money", true)}${cell("Profit at asking", a.profit, base?.profit, "money", true)}${cell(a.profit_basis === "gdv" ? "Margin on GDV" : "Margin on cost", a[m], base?.[m], "pct", true)}${cell("Levered IRR", a.irr_levered, base?.irr_levered, "pct", true)}${cell("Peak equity", a.peak_equity, base?.peak_equity, "money", false)}${cell("GDV", a.gdv, base?.gdv, "money", true)}${dirty ? '<span class="chip acc" style="align-self:center">Unsaved changes</span>' : ""}</div>`;
}
function railHtml() {
  const s = drawer.site, e = drawer.ev, a = e.appraisal, sc = e.score, [v, col, why] = verdict(a, e.flags), ok = a && !a.incomplete;
  const row = (l, x) => `<div style="display:flex;justify-content:space-between;gap:8px;padding:5px 0;border-bottom:1px solid var(--line)"><span class="tsub">${l}</span><b>${x}</b></div>`;
  const flags = (e.flags || []).slice().sort((p, q) => ({ High: 0, Medium: 1, Low: 2 }[p.severity] - { High: 0, Medium: 1, Low: 2 }[q.severity])).slice(0, 4);
  return `<div class="verdict" style="display:block;margin:0 0 12px"><div class="tsub" style="text-transform:uppercase;letter-spacing:.07em;font-weight:600">Recommendation</div><div class="vt" style="color:${col};font-size:20px">${v}</div><div class="tsub">${esc(why)}</div></div>
   ${ok ? row("Opening offer", money(a.opening_offer)) + row("Walk away above", money(a.walk_away)) + row("Asking price", a.asking ? money(a.asking) : "n/a") + row("Headroom to asking", a.headroom_vs_asking != null ? pct(a.headroom_vs_asking, 0) : "n/a") + row("Homes", num9(a.units)) : ""}
   ${row("Score", `${sc.score} (${sc.grade})`)}${row("Planning", esc(s.planning_status || "Unknown"))}${row("Stage", esc(s.stage || ""))}
   <div class="kl" style="margin:14px 0 6px">Main risks</div>${flags.length ? flags.map(f => `<div style="padding:5px 0"><span class="chip ${sevClass(f.severity)}">${f.severity}</span> ${esc(f.flag)}</div>`).join("") : '<div class="tsub">No risks recorded.</div>'}
   ${ST9.data && ST9.id === drawer.id ? `<div class="kl" style="margin:14px 0 6px">Planning route</div><div class="tsub">${esc(ST9.data.route.title)}${ST9.data.timeline.total_months ? `, about ${ST9.data.timeline.total_months} months` : ""}</div>` : ""}`;
}
function applyRoom() {
  const dr = $("#drawer"); if (!dr || !drawer) return;
  const on = room();
  dr.classList.toggle("room", on); $("#scrim")?.classList.toggle("room", on);
  let bar = $("#nbar");
  if (!bar) { bar = document.createElement("div"); bar.id = "nbar"; const db = $("#dbody"); db?.parentNode.insertBefore(bar, db); }
  bar.innerHTML = nbarHtml();
  const r1 = dr.querySelector(".dh .r1 > div:last-child");
  if (r1 && !r1.querySelector("[data-act=roomtoggle]")) r1.insertAdjacentHTML("afterbegin", `<button class="btn sm" data-act="roomtoggle" title="Switch between the side panel and a full page workspace">${on ? "Side panel" : "Deal room"}</button>`);
  else if (r1) r1.querySelector("[data-act=roomtoggle]").textContent = on ? "Side panel" : "Deal room";
  let rail = $("#rail"); const wrap = dr.querySelector(".rm");
  if (on) {
    if (!wrap) { const w = document.createElement("div"); w.className = "rm"; const side = document.createElement("aside"); side.id = "rail"; side.className = "rail"; const main = document.createElement("div"); main.className = "rmain"; dr.appendChild(w); w.append(side, main); main.append(bar, $("#dbody")); }
    $("#rail").innerHTML = railHtml();
  } else if (wrap) { dr.append(bar, $("#dbody")); wrap.remove(); }
}
const _pd9 = paintDrawer;
paintDrawer = function (soft) { const r = _pd9.apply(this, arguments); try { applyRoom(); } catch (e) { console.error(e); } return r; };
const _apr9 = apResults;
apResults = function () { setTimeout(() => { const b = $("#nbar"); if (b && drawer) b.innerHTML = nbarHtml(); }, 0); return _apr9.apply(this, arguments); };

/* ---------- wiring ---------- */
const _tStr9 = window.EXTRA_TABS.structure;
window.EXTRA_TABS.structure = function () { const h = _tStr9(); return drawer.struct?.incomplete ? h : fundingCard() + h; };
const _tPlan9 = tPlanning;
tPlanning = function () { return strategyCard() + _tPlan9(); };
const _tMkt9 = tMarket;
tMarket = function () { return _tMkt9() + compCard(); };
Object.assign(window.EXTRA_TABS, { programme: tProgramme, history: tHistory, report: tReport9 });

document.addEventListener("click", async e => {
  const tg = e.target.closest("[data-cptoggle]");
  if (tg && drawer) { e.stopPropagation(); await loadComps({ toggle: tg.dataset.cptoggle }); return; }
  const t = e.target.closest("[data-act]"); if (!t || !drawer) return; const act = t.dataset.act;
  try {
    if (act === "roomtoggle") { try { localStorage.setItem("ed_room", JSON.stringify(!room())); } catch { } applyRoom(); }
    else if (act === "pgsave") { t.disabled = true; await pgAfter(await api("/api/programme/save", { id: drawer.id, programme: pgCollect() })); toast("Programme saved. Every figure now follows it."); }
    else if (act === "pgclear") { await pgAfter(await api("/api/programme/save", { id: drawer.id, clear: true })); toast("Back to standard timing"); }
    else if (act === "fdsave") {
      const terms = {}; $$("[data-fd]").forEach(el => { const k = el.dataset.fd; terms[k] = k === "draw_mode" ? el.value : (+el.value || 0) / 100; });
      t.disabled = true; FD.data = await api("/api/funding/save", { id: drawer.id, terms }); FD.id = drawer.id; drawer.struct = null; toast("Funding terms saved"); await load(false); await refreshDrawer(true);
    }
    else if (act === "fdterm" || act === "stdoc") {
      const kind = act === "fdterm" ? "termsheet" : "strategy", st = drawer.ev?.strategy || "";
      if (D.hosted) { download(`/download/${kind}/${encodeURIComponent(drawer.id)}.docx?strategy=${st}`); toast("Building the document"); } else { t.disabled = true; const r = await api("/api/docx/save", { id: drawer.id, kind, strategy: st }); t.disabled = false; toast(`Saved to Downloads: ${r.name}`); }
    }
    else if (act === "cpsave") { const adj = {}; $$("[data-cp]").forEach(el => { const k = el.dataset.cp; adj[k] = ["max_km", "max_months"].includes(k) ? +el.value : (+el.value || 0) / 100; }); await loadComps({ adj }); toast("Adjustments applied"); }
    else if (act === "cpreset") { await loadComps({ reset: true }); }
    else if (act === "cpopen") { CP.open = CP.open === t.dataset.c ? null : t.dataset.c; paintDrawer(true); }
    else if (act === "cpuse") { const r = await api("/api/homes/market/apply", { id: drawer.id, premium: 0, what: "price", overwrite: false }); toast(r.changed ? `${r.changed} values updated from the comparables` : "No schedule values were changed. Values you set by hand are kept."); MK.data = null; MK.id = null; drawer.homes = null; await load(false); await refreshDrawer(true); }
    else if (act === "stapply") { const r = await api("/api/strategy/apply", { id: drawer.id }); ST9.data = r; PG.data = null; PG.id = null; toast(`Programme set to ${r.timeline.total_months} months to consent`); await load(false); await refreshDrawer(true); }
    else if (act === "hsdiff") { HS.a = +$("#hs_a").value; HS.b = $("#hs_b").value === "now" ? "now" : +$("#hs_b").value; HS.diff = await api("/api/history/diff", { id: drawer.id, a: HS.a, b: HS.b }); paintDrawer(true); }
    else if (act === "pkkind") { PK.kind = t.dataset.k; PK.data = null; PK.id = null; PK.dirty = false; paintDrawer(true); }
    else if (act === "pkmove") { const secs = PK.data.sections, i = secs.findIndex(s => s.id === t.dataset.id), j = i + +t.dataset.d; if (j >= 0 && j < secs.length) { [secs[i], secs[j]] = [secs[j], secs[i]]; PK.dirty = true; paintDrawer(true); } }
    else if (act === "pkpreview") { t.disabled = true; await loadPack(packOpts()); PK.dirty = true; paintDrawer(true); }
    else if (act === "pksave") { const r = await api("/api/pack/save", { id: drawer.id, kind: PK.kind, strategy: drawer.ev?.strategy, opts: packOpts() }); PK.data = r; PK.dirty = false; toast("Arrangement saved. Downloads now use it."); paintDrawer(true); }
    else if (act === "pkreset") { const r = await api("/api/pack/save", { id: drawer.id, kind: PK.kind, strategy: drawer.ev?.strategy, opts: { order: [], off: [] } }); PK.data = r; PK.dirty = false; paintDrawer(true); }
    else if (act === "pkbrand") { const r = await api("/api/brand/save", { name: $("#pk_bn").value, accent: $("#pk_bc").value }); D.brand = r.brand; PK.data = null; PK.id = null; toast("Style saved"); paintDrawer(true); }
  } catch (err) { toast(err.message); if (t.disabled) t.disabled = false; }
});
document.addEventListener("change", e => {
  const c = e.target.closest?.("[data-pkon]"); if (!c || !PK.data) return;
  const s = PK.data.sections.find(x => x.id === c.dataset.pkon); if (s) { s.on = c.checked; PK.dirty = true; paintDrawer(true); }
});
document.addEventListener("dragstart", e => { const r = e.target.closest?.(".pkrow"); if (r) { PK.drag = r.dataset.pkid; e.dataTransfer.effectAllowed = "move"; try { e.dataTransfer.setData("text/plain", PK.drag); } catch { } } });
document.addEventListener("dragover", e => { if (e.target.closest?.(".pkrow") && PK.drag) e.preventDefault(); });
document.addEventListener("drop", e => {
  const r = e.target.closest?.(".pkrow"); if (!r || !PK.drag || !PK.data) return; e.preventDefault();
  const secs = PK.data.sections, i = secs.findIndex(s => s.id === PK.drag), j = secs.findIndex(s => s.id === r.dataset.pkid);
  if (i >= 0 && j >= 0 && i !== j) { const [m] = secs.splice(i, 1); secs.splice(j, 0, m); PK.dirty = true; paintDrawer(true); }
  PK.drag = null;
});
