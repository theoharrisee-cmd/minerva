/* easyDevelopment overnight round 7: an in-app "Requirements" page answering what needs an API key, what needs no
   key but internet access, and what no API can do at all. Read straight from API_REQUIREMENTS.md on the server, so
   this page and that file can never say different things. */
Object.assign(I, {
  requirements: '<svg viewBox="0 0 24 24"><path d="M9 4h9a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V8z"/><path d="M9 4v4H5"/><path d="M8 13h8M8 16.5h8M8 9.5h3"/></svg>',
});
NAV.splice(NAV.findIndex(x => x[0] === "settings"), 0, ["requirements", "Requirements"]);
Object.assign(TITLES, { requirements: ["Requirements", "Every function, and what it needs to move from a demo to live data"] });

const REQ = { data: null, busy: false, err: "" };

function linkify(s) {
  return esc(s).replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, t, u) => `<a href="${esc(u)}" target="_blank" rel="noopener">${t}</a>`);
}

function reqStatusChip(cell, headers, idx) {
  const h = (headers[idx] || "").toLowerCase();
  if (h !== "without it" && h !== "status") return linkify(cell);
  const c = /verified/i.test(cell) ? "ok" : /not verified|fixtures only|feature off|off\b/i.test(cell) ? "med" : "acc";
  return `<span class="chip ${c}" style="white-space:normal;text-align:left;height:auto;padding:4px 8px;line-height:1.35">${linkify(cell)}</span>`;
}

function reqSection(sec) {
  const body = sec.paragraphs.map(p => `<p class="tsub" style="margin-bottom:8px">${linkify(p)}</p>`).join("");
  const table = sec.table ? `<div class="tablewrap"><table><thead><tr>${sec.table.headers.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${sec.table.rows.map(r => `<tr style="cursor:default">${r.map((c, i) => `<td${i === 0 ? ' style="min-width:200px"' : ""}>${i === 0 ? `<b>${linkify(c)}</b>` : reqStatusChip(c, sec.table.headers, i)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : "";
  return `<div class="card pad" style="margin-bottom:14px">${sec.heading ? `<h3 style="margin-bottom:10px">${esc(sec.heading)}</h3>` : ""}${body}${table}</div>`;
}

async function vRequirements() {
  if (!REQ.data && !REQ.busy) {
    REQ.busy = true;
    $("#view").innerHTML = `<div class="empty">Loading&hellip;</div>`;
    try { REQ.data = await api("/api/requirements"); } catch (err) { REQ.err = err.message; } finally { REQ.busy = false; }
  }
  if (REQ.err) { $("#view").innerHTML = `<div class="empty">${esc(REQ.err)}</div>`; return; }
  if (!REQ.data) return;
  const need = REQ.data.sections.find(s => /needs a key/i.test(s.heading));
  const missing = need ? need.table.rows.filter(r => !/^(saved|verified)/i.test(r[1] || "")).length : 0;
  $("#view").innerHTML = `
    <div class="card pad" style="margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
      <div><b>${esc(REQ.data.title)}</b><div class="tsub">Generated from ${esc(REQ.data.source)} on this build, so it always matches the code.</div></div>
      <button class="btn sm" data-act="reqrefresh">Refresh</button>
    </div>
    ${REQ.data.sections.map(reqSection).join("")}`;
}
window.EXTRA_VIEWS = Object.assign(window.EXTRA_VIEWS || {}, { requirements: vRequirements });

document.addEventListener("click", e => {
  const b = e.target.closest('[data-act="reqrefresh"]');
  if (b) { REQ.data = null; REQ.err = ""; vRequirements(); }
});
