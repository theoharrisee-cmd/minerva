/* Vector basemap from Protomaps, drawn with MapLibre GL. Falls back to the tile map when there is no key,
   the library cannot load, or WebGL is unavailable. Site pins reuse the same overlay as the tile map. */
const MAPLIBRE = "https://cdn.jsdelivr.net/npm/maplibre-gl@4.7.1/dist/maplibre-gl";
let mlLoad = null;
function loadMapLibre() {
  if (window.maplibregl) return Promise.resolve(true);
  if (mlLoad) return mlLoad;
  mlLoad = new Promise(res => {
    const css = document.createElement("link"); css.rel = "stylesheet"; css.href = MAPLIBRE + ".css"; document.head.append(css);
    const js = document.createElement("script"); js.src = MAPLIBRE + ".js"; js.onload = () => res(!!window.maplibregl); js.onerror = () => res(false); document.head.append(js);
    setTimeout(() => res(!!window.maplibregl), 12000);
  });
  return mlLoad;
}
const pmStyle = dark => `https://api.protomaps.com/styles/v5/${dark ? "dark" : "light"}/en.json?key=${encodeURIComponent(D.maps.key)}`;

class ProtoMap extends MiniMap {
  init(dark) {
    const el = this.el;
    el.innerHTML = '<div class="pm"></div><div class="marks"></div>';
    this.marks = $(".marks", el); this.dark = dark; this.ok = true;
    const box = $(".pm", el), lats = this.pins.map(p => p.lat), lons = this.pins.map(p => p.lon);
    this.gl = new maplibregl.Map({ container: box, style: pmStyle(dark), center: [-1.6, 52.8], zoom: 5.4, minZoom: 4, maxZoom: 18, attributionControl: false, dragRotate: false });
    this.gl.touchZoomRotate.disableRotation();
    this.gl.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
    this.gl.addControl(new maplibregl.AttributionControl({ compact: true }), "bottom-left");
    if (this.pins.length > 1) this.gl.fitBounds([[Math.min(...lons), Math.min(...lats)], [Math.max(...lons), Math.max(...lats)]], { padding: 70, maxZoom: 13, duration: 0 });
    else if (this.pins.length) this.gl.jumpTo({ center: [lons[0], lats[0]], zoom: 13 });
    else el.insertAdjacentHTML("beforeend", '<div class="map-empty">No mapped sites yet.<br>Refresh listings or add a site with a postcode.</div>');
    this.gl.on("move", () => this.draw());
    this.gl.on("resize", () => this.draw());
    this.gl.on("error", e => { if (!this.gl.isStyleLoaded() && !this.styled) { this.styleFailed = (this.styleFailed || 0) + 1; if (this.styleFailed === 3) toast("The map style did not load. Check the Protomaps key."); } });
    this.gl.on("styledata", () => { this.styled = true; });
    this.draw();
  }
  setTheme(d) { if (this.gl && d !== this.dark) { this.dark = d; this.gl.setStyle(pmStyle(d)); } }
  zoom(d) { this.gl?.easeTo({ zoom: this.gl.getZoom() + d, duration: 250 }); }
  focus(pts) { const lo = pts.map(p => p.lon), la = pts.map(p => p.lat); this.gl.fitBounds([[Math.min(...lo), Math.min(...la)], [Math.max(...lo), Math.max(...la)]], { padding: 90, maxZoom: 16, duration: 400 }); if (pts.length && Math.min(...lo) === Math.max(...lo)) this.gl.easeTo({ center: [lo[0], la[0]], zoom: this.gl.getZoom() + 2 }); }
  destroy() { try { this.gl?.remove(); } catch { } }
  draw() {
    if (!this.gl) return;
    const w = this.el.clientWidth, h = this.el.clientHeight; if (!w) return;
    this.drawMarks(w, h, p => { const q = this.gl.project([p.lon, p.lat]); return { X: q.x, Y: q.y }; });
  }
}

/* Returns an object with setTheme and destroy straight away, and swaps in the real map once the library is ready. */
function makeMap(el, pins, onOpen) {
  const dark = document.documentElement.dataset.theme === "dark";
  if (!D.maps?.key) return withTheme(new MiniMap(el, pins, onOpen), dark);
  const host = { inner: null, dead: false, dark, setTheme(d) { this.dark = d; this.inner?.setTheme(d); }, destroy() { this.dead = true; this.inner?.destroy(); } };
  el.innerHTML = '<div class="map-empty">Loading map</div>';
  loadMapLibre().then(ok => {
    if (host.dead) return;
    let m;
    try {
      if (!ok) throw new Error("map library unavailable");
      m = Object.create(ProtoMap.prototype); m.el = el; m.pins = pins; m.onOpen = onOpen; m.init(host.dark);
    } catch (e) { el.innerHTML = ""; m = new MiniMap(el, pins, onOpen); m.setTheme(host.dark); }
    host.inner = m;
  });
  return host;
}
function withTheme(m, dark) { m.setTheme(dark); return m; }
