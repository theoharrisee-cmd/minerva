/* easyDevelopment v0.7: data-driven suggestions, market pricing by home type, planning track record. */
const lsG8 = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const pc = v => v == null ? "n/a" : Math.round(v * 100) + "%";

/* ---------- suggestions from the data pack ---------- */
const SG = { data: null, id: null, busy: false };
async function loadSuggest(soft) {
  const id = drawer.id; SG.busy = true;
  try { const r = await api("/api/suggest/get", { id }); if (drawer?.id !== id) return; SG.data = r; SG.id = id; } catch (e) { toast(e.message); }
  SG.busy = false; if (drawer && (drawer.tab === "appraisal" || drawer.tab === "data")) paintDrawer(true);
}
const KEYLABEL = { external_pct: "External works", contingency_pct: "Contingency", planning_months: "Planning months", s106_per_unit: "S106 per home", fees_pct: "Professional fees" };
const fmtDelta = c => c.key.endsWith("_pct") ? `${c.delta > 0 ? "+" : ""}${(c.delta * 100).toFixed(1)} points` : c.key === "planning_months" ? `${c.delta > 0 ? "+" : ""}${c.delta} months` : `${c.delta > 0 ? "+" : ""}£${c.delta.toLocaleString()}`;
function suggestCard() {
  const s = drawer.site;
  if (SG.id !== drawer.id) { SG.data = null; if (!SG.busy) loadSuggest(); }
  const d = SG.data;
  if (!d) return `<div class="card pad" style="margin-bottom:14px"><div class="tsub">Reading the data checks for appraisal adjustments</div></div>`;
  if (!d.items.length) return d.has_pack ? "" : `<div class="card pad" style="margin-bottom:14px"><b>Suggested adjustments from the data</b><div class="tsub" style="margin-top:4px">Run the data checks on the Data tab and easyDevelopment will suggest allowances for flooding, ground, heritage, ecology and the local planning record.</div></div>`;
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Suggested adjustments from the data</h3><span class="m">${d.profit != null ? "profit now " + money(d.profit) : ""}</span></div>
   ${d.items.map(it => `<div class="flag" style="display:flex;gap:12px;align-items:flex-start"><div style="flex:1"><div class="fh"><span class="chip ${sevClass(it.level)}">${esc(it.level)}</span>${esc(it.title)}${it.accepted ? ' <span class="chip ok">Applied</span>' : ""}</div>
     <p>${esc(it.why)}</p><div class="tsub">${it.changes.map(c => `${esc(KEYLABEL[c.key] || c.key)} ${fmtDelta(c)} (${esc(c.label)})`).join("; ")}${it.impact != null ? `. Effect on profit: <b class="${it.impact < 0 ? "neg" : ""}">${it.impact < 0 ? "-" : "+"}${money(Math.abs(it.impact))}</b>` : ""}</div></div>
     <button class="btn sm ${it.accepted ? "" : "primary"}" data-act="${it.accepted ? "sgrevert" : "sgapply"}" data-r="${esc(it.id)}">${it.accepted ? "Revert" : "Apply"}</button></div>`).join("")}
   <div class="tsub" style="padding:8px 16px 14px">${esc(d.items[0].note)}</div></div>`;
}

/* ---------- market pricing by type ---------- */
const MK = { data: null, id: null, premium: lsG8("ed_prem", 0), busy: false };
async function loadMarket() {
  const id = drawer.id; MK.busy = true;
  try { const r = await api("/api/homes/market", { id, premium: MK.premium }); if (drawer?.id !== id) return; MK.data = r; MK.id = id; } catch (e) { toast(e.message); }
  MK.busy = false; if (drawer?.tab === "homes") paintDrawer(true);
}
function marketCard() {
  if (MK.id !== drawer.id) { MK.data = null; if (!MK.busy) loadMarket(); }
  const d = MK.data;
  if (!d) return "";
  if (!d.units.length) return "";
  const ev = d.evidence, grade = { high: ["ok", "Strong"], medium: ["med", "Fair"], low: ["lo", "Weak"], none: ["hi", "None"] };
  const need = !ev.n && d.units.every(u => u.grade === "none");
  return `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Market value and build cost by home type</h3><span class="m">${ev.n ? `${ev.n} sales in ${esc(ev.sector || "the sector")}${ev.months ? `, last ${ev.months} months` : ""}` : "no sold prices on file"}</span></div>
   <div class="tablewrap" style="max-height:none"><table><thead><tr><th>Type</th><th class="num">Homes</th><th>Sold as</th><th class="num">Suggested £ per sq ft</th><th class="num">Suggested value £</th><th class="num">Now £</th><th>Evidence</th><th class="num">Build £ per sq ft</th><th class="num">Now</th></tr></thead><tbody>
   ${d.units.map(u => `<tr style="cursor:default"><td><b>${esc(u.name)}</b></td><td class="num">${u.count}</td><td>${esc(u.class)}</td><td class="num">${u.sale_psf ?? ""}</td><td class="num"><b>${u.sale_value ? Math.round(u.sale_value).toLocaleString() : ""}</b></td><td class="num">${u.current_value ? Math.round(u.current_value).toLocaleString() : '<span class="tsub">from £/sq ft</span>'}${u.auto_price ? ' <span class="tsub">market</span>' : ""}</td>
     <td style="min-width:200px"><span class="chip ${grade[u.grade][0]}">${grade[u.grade][1]}</span><div class="tsub">${esc(u.basis)}</div></td><td class="num"><b>${u.build_psf ?? ""}</b><div class="tsub">${esc(u.build_class || "")}</div></td><td class="num">${u.current_build ?? '<span class="tsub">site rate</span>'}</td></tr>`).join("")}</tbody></table></div>
   <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;padding:12px 16px"><label class="field" style="flex-direction:row;gap:8px;align-items:center;margin:0"><span>New build premium %</span><input type="number" id="mk_prem" step="1" value="${MK.premium}" style="width:70px"></label>
     <button class="btn sm primary" data-act="mkapply" data-w="both">Apply market pricing and build rates</button><button class="btn sm" data-act="mkapply" data-w="price">Prices only</button><button class="btn sm" data-act="mkapply" data-w="build">Build rates only</button>
     <span class="tsub">${need ? "Run Market > Land Registry sales to bring in sold prices. " : ""}Build rates are the benchmark for each type scaled to the build cost already in the appraisal (£${Math.round(d.assumed_build)} per sq ft, ${esc(d.region)}). Nothing is changed until you apply, and types you have priced by hand are left alone.</span></div></div>`;
}

/* ---------- layout test ---------- */
const LY = { data: null, id: null, busy: false, err: "" };
async function loadLayout(run) {
  const id = drawer.id; LY.busy = true; LY.err = ""; if (run) paintDrawer(true);
  try { const r = await api(run ? "/api/layout/run" : "/api/layout/get", { id }); if (drawer?.id !== id) return; LY.data = r; LY.id = id; if (!r.ok && !r.none) LY.err = r.error || ""; } catch (e) { LY.err = e.message; LY.id = id; }
  LY.busy = false; if (drawer?.tab === "homes") paintDrawer(true);
}
function layoutCard() {
  const s = drawer.site;
  if (LY.id !== drawer.id) { LY.data = null; LY.id = drawer.id; if (s.layout) loadLayout(false); }
  const d = LY.data, hasHouses = (hs().data?.totals?.houses ?? 1) > 0;
  const head = `<div class="h"><h3>Layout test</h3><span class="m">${s.boundary ? `boundary ${s.boundary.area_ha} ha` : s.site_ha ? "no boundary drawn" : "needs a boundary or site area"}</span></div>`;
  const run = `<button class="btn ${d?.ok ? "" : "primary"} sm" data-act="lyrun" ${LY.busy ? "disabled" : ""}>${LY.busy ? "Testing the layout" : d?.ok ? "Run again" : "Test the layout"}</button>`;
  if (!d?.ok) return `<div class="card" style="margin-bottom:14px">${head}<div style="padding:0 16px 16px"><div class="tsub" style="margin-bottom:10px">Lays the houses out in rows on the site boundary to find how many fit, and measures garden lengths, back to back distances, parking and the land left over. Flats are not placed.</div>${run}${!s.boundary ? ` <button class="btn sm" data-act="bdopen">Draw boundary</button>` : ""}${LY.err ? `<div class="notice" style="margin-top:10px">${esc(LY.err)}</div>` : ""}${!hasHouses ? '<div class="tsub" style="margin-top:8px">The current schedule has no houses.</div>' : ""}</div></div>`;
  const stat = { pass: ["ok", "Meets"], warn: ["med", "Check"], fail: ["hi", "Fails"], info: ["lo", "Note"] };
  const short = d.homes < d.wanted;
  return `<div class="card" style="margin-bottom:14px">${head}<div style="padding:0 16px 16px">
   <div style="display:flex;gap:22px;flex-wrap:wrap;margin-bottom:10px">${[["Houses that fit", d.homes], ["In the schedule", d.wanted], ["Density", d.density_dph + " dph"], ["Streets", `${d.streets} (${d.street_m} m)`], ["Shortest garden", d.min_garden_m + " m"], ["Back to back", d.min_back_to_back_m ? d.min_back_to_back_m + " m" : "n/a"], ["Left over", Math.round(d.left_pct * 100) + "%"]].map(([k, v]) => `<div><div class="kl">${k}</div><b style="font-size:16px">${v}</b></div>`).join("")}</div>
   ${d.current ? "" : '<div class="notice" style="margin-bottom:10px">The schedule or boundary has changed since this test. Run it again.</div>'}
   <div class="plan" style="margin:0">${d.svg}</div><div class="tsub" style="margin:6px 0">${esc(d.note)}. Rows are set ${d.angle_deg} degrees from east. Streets ${d.params.street} m wide, front gardens ${d.params.front} m, ${d.params.margin} m kept clear of the boundary. This shows capacity and standards, not a designed scheme.</div>
   <div class="tablewrap" style="max-height:none"><table><thead><tr><th>Type</th><th class="num">Schedule</th><th class="num">Fits</th></tr></thead><tbody>${Object.values(d.by_type).map(v => `<tr style="cursor:default"><td>${esc(v.name)}</td><td class="num">${v.wanted}</td><td class="num"><b>${v.laid}</b></td></tr>`).join("")}</tbody></table></div>
   ${d.checks.map(c => `<div class="flag" style="display:flex;gap:10px"><span class="chip ${stat[c.status][0]}">${stat[c.status][1]}</span><div><b>${esc(c.title)}</b><div class="tsub">${esc(c.detail)}</div></div></div>`).join("")}
   <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">${run}<button class="btn sm" data-act="lyapply" data-p="0">${short ? "Reduce the schedule to what fits" : "Use the layout counts"}</button><button class="btn sm" data-act="lyapply" data-p="1">Use counts and parking</button></div></div></div>`;
}

/* ---------- planning track record ---------- */
const TR = { data: null, id: null, busy: false, err: "" };
async function loadTrack(refresh) {
  const id = drawer.id; TR.busy = true; TR.err = "";
  if (drawer.tab === "planning") paintDrawer(true);
  try { const r = await api("/api/track/get", { id, refresh: !!refresh }); if (drawer?.id !== id) return; TR.data = r; TR.id = id; } catch (e) { TR.err = e.message; TR.id = id; }
  TR.busy = false; if (drawer?.tab === "planning") paintDrawer(true);
}
function trackCard() {
  if (TR.id !== drawer.id) { TR.data = drawer.site.track || null; TR.id = drawer.id; TR.err = ""; if (!TR.data && drawer.site.lat != null && !TR.busy) loadTrack(); }
  const t = TR.data;
  const head = `<div class="sec"><h3>Local planning record, last five years</h3><span class="m">${t?.ok ? `PlanIt, ${t.radius_km} km, fetched ${when(t.fetched)}` : ""}</span></div>`;
  if (TR.busy && !t?.ok) return head + `<div class="card pad empty">Reading five years of applications from PlanIt</div>`;
  if (!t?.ok) return head + `<div class="card pad"><div class="tsub">${esc(TR.err || t?.error || (drawer.site.lat == null ? "Add a postcode so the site can be located." : "No record yet."))}</div>${drawer.site.lat != null ? `<button class="btn sm" style="margin-top:8px" data-act="trrefresh">Try again</button>` : ""}</div>`;
  const tone = t.approval_rate == null ? "" : t.approval_rate >= 0.8 ? "ok" : t.approval_rate >= 0.6 ? "med" : "hi";
  const kp = [["Approval rate", pc(t.approval_rate), `${t.approved} approved, ${t.refused} refused`], ["Last two years", pc(t.recent_rate), t.recent_rate == null ? "too few decisions" : `${t.recent_n} decisions`], ["Median to decide", t.median_days ? Math.round(t.median_days) + " days" : "n/a", t.months_to_decide ? `${t.months_to_decide.toFixed(1)} months` : ""], ["Withdrawn", t.withdrawn, "major residential"]];
  const yrs = t.by_year.length ? `<table><thead><tr><th>Year decided</th><th class="num">Approved</th><th class="num">Refused</th><th class="num">Approval rate</th><th class="num">Median days</th></tr></thead><tbody>${t.by_year.map(y => `<tr style="cursor:default"><td>${y.year}</td><td class="num">${y.approved}</td><td class="num">${y.refused}</td><td class="num">${pc(y.approved + y.refused ? y.approved / (y.approved + y.refused) : null)}</td><td class="num">${y.median_days ?? ""}</td></tr>`).join("")}</tbody></table>` : "";
  const lnk = a => a.url ? `<a href="${esc(a.url)}" target="_blank" rel="noopener">${esc(a.ref)}</a>` : esc(a.ref);
  const list = (xs, cols) => `<table><thead><tr><th>Reference</th><th>Address and proposal</th><th>Decided</th><th class="num">km</th></tr></thead><tbody>${xs.map(a => `<tr style="cursor:default"><td>${lnk(a)}</td><td><b>${esc(a.address)}</b><div class="tsub">${esc((a.description || "").slice(0, 150))}</div></td><td class="tsub">${esc(a.decided || "")}</td><td class="num">${a.distance_km ?? ""}</td></tr>`).join("")}</tbody></table>`;
  return head + `<div class="card pad" style="margin-bottom:14px"><div style="display:flex;gap:26px;flex-wrap:wrap;align-items:flex-start">${kp.map(([k, v, s], i) => `<div><div class="kl">${k}</div><div style="font-size:22px;font-weight:700">${i === 0 && tone ? `<span class="chip ${tone}" style="font-size:18px">${v}</span>` : v}</div><div class="tsub">${s}</div></div>`).join("")}<div class="grow"></div><button class="btn sm" data-act="trrefresh" ${TR.busy ? "disabled" : ""}>${TR.busy ? "Refreshing" : "Refresh"}</button></div>
    ${t.thin ? `<div class="notice" style="margin-top:10px">Only ${t.majors} decided major applications were found, so read the rates as indicative.</div>` : ""}${yrs ? `<div class="tablewrap" style="max-height:none;margin-top:10px">${yrs}</div>` : ""}<div class="tsub" style="margin-top:8px">Major residential schemes decided within ${t.radius_km} km, an approximation of the council area${t.lpas?.length ? " (" + esc(t.lpas.join(", ")) + ")" : ""}. Apply the median time on the Appraisal tab through the suggested adjustments.</div></div>
   ${t.precedents.length ? `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Comparable approvals nearby</h3><span class="m">10 or more homes, within 3 km</span></div><div class="tablewrap" style="max-height:300px">${list(t.precedents)}</div></div>` : ""}
   ${t.refused_nearby.length ? `<div class="card" style="margin-bottom:14px"><div class="h"><h3>Refused nearby</h3><span class="m">${esc(t.note)}</span></div><div class="tablewrap" style="max-height:260px">${list(t.refused_nearby)}</div></div>` : ""}`;
}

/* ---------- land around the site: title polygons, owners, groups, distress ---------- */
const AS = { busy: false, err: "", sel: new Set() };
function polySvg(a, s) {
  const ps = a.polygons.filter(p => p.wkt).slice(0, 60); if (!ps.length) return "";
  const rings = ps.map(p => ({ p, pts: [...p.wkt.matchAll(/(-?\d+\.\d+)\s+(-?\d+\.\d+)/g)].map(m => [+m[1], +m[2]]) })).filter(r => r.pts.length > 2);
  const all = rings.flatMap(r => r.pts), x0 = Math.min(...all.map(p => p[0])), x1 = Math.max(...all.map(p => p[0])), y0 = Math.min(...all.map(p => p[1])), y1 = Math.max(...all.map(p => p[1]));
  const kx = Math.cos(s.lat * Math.PI / 180), W = 640, sc = W / Math.max((x1 - x0) * kx, 1e-6), H = Math.max(120, Math.min(420, (y1 - y0) * sc));
  const X = x => ((x - x0) * kx * sc).toFixed(1), Y = y => (H - (y - y0) * sc).toFixed(1);
  const path = pts => "M" + pts.map(p => X(p[0]) + " " + Y(p[1])).join("L") + "Z";
  const b = s.boundary?.ring;
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-height:420px;background:var(--bg2,#f5f5f5)">${rings.map(({ p, pts }) => `<path d="${path(pts)}" fill="${p.under_site ? "#FF6600" : p.adjoins ? "#FFB37A" : AS.sel.has(p.ref) ? "#4A90D9" : "#fff"}" fill-opacity="${p.under_site ? .55 : .6}" stroke="#555" stroke-width="1"><title>${esc(p.ref)}${p.ha ? ", " + p.ha + " ha" : ""}</title></path>`).join("")}
    ${b ? `<path d="${path(b)}" fill="none" stroke="#000" stroke-width="2" stroke-dasharray="6 3"/>` : ""}<circle cx="${X(s.lon)}" cy="${Y(s.lat)}" r="4" fill="#000"/></svg>`;
}
function assemblyCard() {
  const s = drawer.site; if (s.lat == null) return "";
  const a = s.assembly;
  const head = `<div class="h"><h3>Land around the site</h3><span class="m">${a ? `built ${when(a.built)}, ${a.radius_m} m` : "title polygons and owners"}</span></div>`;
  if (!a) return `<div class="card" style="margin-bottom:14px">${head}<div style="padding:0 16px 16px"><div class="tsub">Reads the registered title polygons around the site and the company owned titles at nearby postcodes, groups holdings by owner and checks the owning companies at Companies House.</div>
    <button class="btn primary" style="margin-top:10px" data-act="asbuild" ${AS.busy ? "disabled" : ""}>${AS.busy ? "Reading land data" : "Map the land around this site"}</button>${AS.err ? `<div class="notice" style="margin-top:8px">${esc(AS.err)}</div>` : ""}</div></div>`;
  const o = a.owners || { titles: [], groups: [] };
  const lvl = { High: "hi", Medium: "med", Low: "lo" };
  return `<div class="card" style="margin-bottom:14px">${head}<div style="padding:0 16px 8px">
    <div style="display:flex;gap:22px;flex-wrap:wrap;margin-bottom:8px">${[["Polygons", a.polygons.length], ["Under the site", a.under_site_ha ? a.under_site_ha + " ha" : "none"], ["Adjoining", a.adjoining], ["Company owners", o.groups.length]].map(([k, v]) => `<div><div class="kl">${k}</div><b style="font-size:16px">${v}</b></div>`).join("")}<div class="grow"></div><button class="btn sm" data-act="asbuild" ${AS.busy ? "disabled" : ""}>${AS.busy ? "Refreshing" : "Refresh"}</button></div>
    <div class="plan" style="margin:0">${polySvg(a, s)}</div><div class="tsub" style="margin:6px 0">Orange is the title under the site, light orange adjoins it, blue is selected, and the dashed line is the site boundary. ${esc(a.caveat)}</div>
    ${a.notes.length ? `<div class="notice" style="margin-bottom:8px">${a.notes.map(esc).join("<br>")}</div>` : ""}</div>
   <div class="tablewrap" style="max-height:280px"><table><thead><tr><th></th><th>Polygon</th><th class="num">Ha</th><th class="num">Distance</th><th>Relation</th></tr></thead><tbody>${a.polygons.slice(0, 40).map(p => `<tr style="cursor:default"><td><input type="checkbox" data-aspoly="${esc(p.ref)}" ${AS.sel.has(p.ref) ? "checked" : ""}></td><td>${esc(p.ref)}</td><td class="num">${p.ha ?? ""}</td><td class="num">${p.distance_m} m</td><td>${p.under_site ? '<span class="chip acc">Under the site</span>' : p.adjoins ? '<span class="chip med">Adjoins</span>' : ""}</td></tr>`).join("")}</tbody></table></div>
   <div style="padding:10px 16px"><button class="btn sm" data-act="asadd">Add ${AS.sel.size || "selected"} to land assembly</button> <span class="tsub">Adds the polygons as parcels on the Landowners tab.</span></div>
   ${o.groups.length ? `<div class="tablewrap" style="max-height:none"><table><thead><tr><th>Owner (company)</th><th class="num">Titles nearby</th><th class="num">Titles held</th><th>Companies House</th></tr></thead><tbody>${o.groups.map(g => `<tr style="cursor:default"><td><b>${esc(g.proprietor)}</b><div class="tsub">${esc(g.company_no || "")} ${esc(g.category || "")}</div>${g.assembler ? '<span class="chip acc">Holds three or more titles here</span>' : ""}</td><td class="num">${g.nearby}</td><td class="num">${g.total ?? ""}</td>
     <td>${g.company ? `<span class="tsub">${esc(g.company.status || "")}${g.company.created ? ", incorporated " + esc(g.company.created) : ""}</span>` : ""}${(g.distress || []).map(x => `<div><span class="chip ${lvl[x.level]}">${esc(x.level)}</span> ${esc(x.text)}</div>`).join("") || (g.company ? '<div class="tsub">No signals</div>' : "")}${g.distress_error ? `<div class="tsub">${esc(g.distress_error)}</div>` : ""}</td></tr>`).join("")}</tbody></table></div>` : (o.loaded ? '<div class="tsub" style="padding:0 16px 14px">No company owned titles found at nearby postcodes.</div>' : "")}</div>`;
}

/* ---------- site boundary ---------- */
function boundaryCard() {
  const s = drawer.site; if (s.lat == null) return "";
  const b = s.boundary;
  return `<div class="card pad" style="margin-bottom:14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="grow"><b>Site boundary</b><div class="tsub">${b ? `Drawn ${esc(b.drawn)}, ${b.area_ha} ha. The layout test on the Homes tab uses this shape.` : "Draw the red line on a map. Its area can set the site area, and the layout test uses its shape."}</div></div><button class="btn ${b ? "" : "primary"}" data-act="bdopen">${b ? "Edit boundary" : "Draw boundary"}</button></div>`;
}

/* ---------- site brief ---------- */
function briefCard() {
  return `<div class="card pad" style="margin-bottom:14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="grow"><b>Site brief</b><div class="tsub">One Word document with the location map, appraisal, planning, constraints, ownership, nearby applications, access, homes and risks. The report, committee paper and deck carry the same data sections.</div></div><button class="btn primary" data-act="briefdl">Create site brief</button></div>`;
}

/* ---------- monthly monitoring ---------- */
function monitorCard() {
  const s = drawer.site, w = s.watch, d = w?.deep;
  if (!w?.on) return `<div class="card pad" style="margin-bottom:14px"><b>Monthly checks</b><div class="tsub" style="margin-top:4px">Add this site to your shortlist to have it re-checked each month for new applications nearby, flood warnings, changes to company owned titles and moves in house prices.</div></div>`;
  return `<div class="card pad" style="margin-bottom:14px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div class="grow"><b>Monthly checks</b><div class="tsub">${d?.last ? `Last run ${when(d.last)}. Findings appear in the site activity and in your alert email.${d.errors?.length ? " Not available: " + esc(d.errors.join("; ")) : ""}` : "Not run yet. The first run records a baseline and later runs report what changed."}</div></div><button class="btn" data-act="rcnow">Check now</button></div>`;
}

/* ---------- ask this deal ---------- */
const AK = { log: {}, busy: false };
const AK_Q = ["What are the main constraints on this site?", "What does the planning record nearby say about approval?", "Which policy checks does the schedule fail?", "Who owns the land and are there any charges?", "What are the biggest risks to the appraisal?"];
function tAsk() {
  const id = drawer.id, log = AK.log[id] ||= [];
  return `<div class="card pad" style="margin-bottom:14px"><b>Ask this deal</b><div class="tsub" style="margin:4px 0 10px">Answers come from the documents, data checks, homes schedule, layout test, planning record, ownership and appraisal held for this site, with the source shown. ${D.has_key ? "" : "There is no Claude API key, so you get the closest passages rather than a written answer."}</div>
   <div style="display:flex;gap:8px"><input type="text" id="ak_q" placeholder="Ask anything about this site" style="flex:1"><button class="btn primary" data-act="akask" ${AK.busy ? "disabled" : ""}>${AK.busy ? "Reading" : "Ask"}</button></div>
   <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px">${AK_Q.map(q => `<button class="btn sm" data-act="akq" data-q="${esc(q)}">${esc(q)}</button>`).join("")}</div></div>
   ${log.slice().reverse().map(m => `<div class="card pad" style="margin-bottom:12px"><div class="tsub">You asked</div><div style="font-weight:600;margin-bottom:8px">${esc(m.q)}</div><div style="white-space:pre-wrap">${esc(m.a)}</div>
     ${m.sources?.length ? `<details style="margin-top:10px"><summary class="tsub" style="cursor:pointer">Sources (${m.sources.length})</summary>${m.sources.map(s => `<div class="flag"><div class="fh"><span class="chip">${esc(s.id)}</span>${esc(s.label)}${s.ref && (drawer.site.docs || []).some(d => d.id === s.ref) ? " " + docChip(s.ref, "Open") : s.ref?.startsWith("http") ? ` <a href="${esc(s.ref)}" target="_blank" rel="noopener">link</a>` : ""}</div><p class="tsub">${esc(s.text.slice(0, 420))}${s.text.length > 420 ? "..." : ""}</p></div>`).join("")}</details>` : ""}</div>`).join("")}`;
}
async function akAsk(q) {
  q = (q || $("#ak_q")?.value || "").trim(); if (!q || AK.busy) return; const id = drawer.id, log = AK.log[id] ||= [];
  AK.busy = true; paintDrawer(true);
  try { const hist = log.slice(-3).flatMap(m => [{ role: "user", content: m.q }, { role: "assistant", content: m.a }]); const r = await api("/api/ask", { id, q, history: hist }); log.push({ q, a: r.answer, sources: r.sources, mode: r.mode }); }
  catch (e) { log.push({ q, a: e.message, sources: [] }); }
  AK.busy = false; if (drawer?.id === id && drawer.tab === "ask") { paintDrawer(true); $("#ak_q")?.focus(); }
}
window.EXTRA_TABS.ask = tAsk;
document.addEventListener("keydown", e => { if (e.target.id === "ak_q" && e.key === "Enter") akAsk(); });

/* ---------- wiring ---------- */
const _tPlanning8 = tPlanning;
tPlanning = function () { return _tPlanning8() + trackCard(); };
const _tHomes8 = window.EXTRA_TABS.homes;
window.EXTRA_TABS.homes = function () { const h = _tHomes8(); return hs().data?.typology || hs().typ ? h + marketCard() + layoutCard() : h; };
const _tApp8 = tAppraisal;
tAppraisal = function () { const h = _tApp8(); return h + `<div style="margin-top:14px">${suggestCard()}</div>`; };
const _tData8 = window.EXTRA_TABS.data;
window.EXTRA_TABS.data = function () { return _tData8() + `<div style="margin-top:14px">${suggestCard()}${boundaryCard()}${assemblyCard()}${monitorCard()}${briefCard()}</div>`; };

document.addEventListener("click", async e => {
  const t = e.target.closest("[data-act]"); if (!t || !drawer) return; const act = t.dataset.act;
  try {
    if (act === "sgapply" || act === "sgrevert") { t.disabled = true; SG.data = await api(act === "sgapply" ? "/api/suggest/apply" : "/api/suggest/revert", { id: drawer.id, rule: t.dataset.r }); await load(false); await refreshDrawer(true); paintDrawer(true); toast(act === "sgapply" ? "Applied to this site's assumptions" : "Reverted"); }
    else if (act === "bdopen") { openBoundary(); }
    else if (act === "akask") { await akAsk(); }
    else if (act === "akq") { await akAsk(t.dataset.q); }
    else if (act === "briefdl") { const st = drawer.ev?.strategy || ""; if (D.hosted) { download(`/download/brief/${encodeURIComponent(drawer.id)}.docx?strategy=${st}`); toast("Building the site brief"); } else { t.disabled = true; const r = await api("/api/brief/save", { id: drawer.id, strategy: st }); t.disabled = false; toast(`Saved to Downloads: ${r.name}`); } }
    else if (act === "lyrun") { await loadLayout(true); }
    else if (act === "lyapply") { const r = await api("/api/layout/apply", { id: drawer.id, parking: t.dataset.p === "1" }); toast(`Schedule set to ${r.totals.units} homes. The appraisal now uses it.`); drawer.homes = null; LY.id = null; MK.id = null; await load(false); await refreshDrawer(true); drawer.tab = "homes"; paintDrawer(); }
    else if (act === "trrefresh") { await loadTrack(true); }
    else if (act === "asbuild") { AS.busy = true; AS.err = ""; paintDrawer(true); try { await api("/api/assembly/get", { id: drawer.id, refresh: true }); await load(false); await refreshDrawer(true); } catch (er) { AS.err = er.message; } AS.busy = false; paintDrawer(true); }
    else if (act === "asadd") {
      const a = drawer.site.assembly, o = {}; for (const ref of AS.sel) { const p = a.polygons.find(x => x.ref === ref); if (p?.under_site && a.owners.titles[0]) o[ref] = a.owners.titles[0]; }
      if (!AS.sel.size) { toast("Tick the polygons to add"); return; } const r = await api("/api/assembly/add", { id: drawer.id, refs: [...AS.sel], owners: o }); AS.sel.clear(); toast(`${r.added} parcel${r.added === 1 ? "" : "s"} added to land assembly`); await load(false); await refreshDrawer(true); paintDrawer(true);
    }
    else if (act === "rcnow") { t.disabled = true; t.textContent = "Checking"; const r = await api("/api/recheck", { id: drawer.id }); toast(r.events ? `${r.events} new finding${r.events === 1 ? "" : "s"}` : "Checked. Nothing new since the last run."); await load(false); await refreshDrawer(true); paintDrawer(true); }
    else if (act === "mkapply") {
      MK.premium = +($("#mk_prem")?.value || 0); try { localStorage.setItem("ed_prem", JSON.stringify(MK.premium)); } catch { }
      const r = await api("/api/homes/market/apply", { id: drawer.id, premium: MK.premium, what: t.dataset.w, overwrite: false });
      toast(r.changed ? `${r.changed} values updated. The appraisal now uses them.` : "Nothing to change: every value was set by hand"); MK.data = null; MK.id = null; drawer.homes = null; await load(false); await refreshDrawer(true); drawer.tab = "homes"; paintDrawer();
    }
  } catch (err) { toast(err.message); if (t.disabled) t.disabled = false; }
});
document.addEventListener("change", e => { const c = e.target.closest?.("[data-aspoly]"); if (c) { c.checked ? AS.sel.add(c.dataset.aspoly) : AS.sel.delete(c.dataset.aspoly); const b = $('[data-act="asadd"]'); if (b) b.textContent = `Add ${AS.sel.size || "selected"} to land assembly`; } });
document.addEventListener("change", e => { if (e.target.id === "mk_prem" && drawer) { MK.premium = +e.target.value || 0; MK.data = null; MK.id = null; loadMarket(); } });
const _pd8 = paintDrawer;
paintDrawer = function (soft) { if (drawer && SG.id && SG.id !== drawer.id) { SG.data = null; } return _pd8.apply(this, arguments); };
