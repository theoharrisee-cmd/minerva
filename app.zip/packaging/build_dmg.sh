#!/usr/bin/env bash
# Build easyDevelopment.dmg on macOS. Usage:  ./packaging/build_dmg.sh
# Produces dist/easyDevelopment.dmg for the architecture of the Mac you run it on.
set -euo pipefail
cd "$(dirname "$0")/.."

PY="${PYTHON:-python3}"
"$PY" -m venv .buildenv
source .buildenv/bin/activate
python -m pip install --quiet --upgrade pip
python -m pip install --quiet pywebview pyinstaller pypdf openpyxl python-docx python-pptx pillow

python run.py --selftest            # fail fast if the source tree is broken

rm -rf build dist
pyinstaller --noconfirm --clean --windowed --name easyDevelopment \
  --icon packaging/easyDevelopment.icns \
  --osx-bundle-identifier com.easydevelopment.app \
  --add-data "ui:ui" --add-data "core/snapshot.json:core" --add-data "core/demo_docs:core/demo_docs" \
  --hidden-import openpyxl --hidden-import docx --hidden-import pptx --hidden-import PIL --hidden-import pypdf \
  --collect-submodules webview \
  run.py

# Ad-hoc sign so Apple Silicon will launch it (no Developer ID needed)
codesign --force --deep --sign - dist/easyDevelopment.app

# Prove the packaged app boots (headless self-test)
dist/easyDevelopment.app/Contents/MacOS/easyDevelopment --selftest

STAGE="$(mktemp -d)"
cp -R dist/easyDevelopment.app "$STAGE/"
ln -s /Applications "$STAGE/Applications"
hdiutil create -volname "easyDevelopment" -srcfolder "$STAGE" -ov -format UDZO "dist/easyDevelopment.dmg"
rm -rf "$STAGE"

echo
echo "Built dist/easyDevelopment.dmg"
echo "First launch: right-click easyDevelopment.app, choose Open (the app is not notarised)."
