# easyDevelopment 0.9

A native Mac app for finding, screening and appraising UK development and investment sites, built around how a developer-investor thinks.

## Running it

**Web version.** See `DEPLOY.md` to host easyDevelopment behind a password on Render with no Terminal needed.

**1. The DMG (recommended).** Build it once on a Mac, then drag easyDevelopment into Applications.

    ./packaging/build_dmg.sh          # produces dist/easyDevelopment.dmg

No Mac to hand? Push this folder to GitHub and run the "Build easyDevelopment DMG" workflow (Actions tab). It produces Apple Silicon and Intel DMGs as downloadable artefacts.

The app is not notarised. The first time, right-click easyDevelopment in Applications and choose Open. If macOS says it is damaged, run `xattr -dr com.apple.quarantine /Applications/easyDevelopment.app`.

**2. Double-click.** `easyDevelopment.command` runs from source using the Python 3 already on your Mac and opens in your browser. Excel export needs `pip3 install openpyxl`; PDF text reading needs `pypdf`.

**3. Terminal.** `python3 run.py` (native window if `pywebview` is installed, otherwise the browser).

Your data lives in `~/Library/Application Support/easyDevelopment`.

## What is new in 0.9

* Tax and net returns: on the Structure tab, stamp duty, VAT that cannot be recovered and tax on profit, for a company and for personal ownership side by side, with profit, margin, levered IRR and multiple after tax. The appraisal itself stays before tax. Your default structure is set in the setup guide or here.
* Council levies: finds a council's CIL charging schedule (from the planning.data.gov.uk dataset) or reads a page or PDF you point at, picks out CIL rates, planning obligations per home and the affordable housing share with the sentence each came from, and lets you choose which figure feeds the appraisal. It can be undone.
* Cost plan: upload a quantity surveyor's cost plan as Excel or CSV. Lines are classified (construction, contingency, fees, excluded), you correct them, and the build cost, contingency and fee percentages are applied to the appraisal, with a warning if externals or abnormals look counted twice.
* Listings: Rightmove, Zoopla and OnTheMarket do not allow scraping, so listings come from their saved-search alert emails (through Outlook) or from a pasted link with the text copied from the page.
* Scenarios side by side: pick up to three saved scenarios and compare them against the first.
* Map sketch: draw access routes, phases, land to acquire and constraints on the site map. Sketches are saved with the site and drawn on the map in the report, committee paper, deck and brief.
* Excel model now also carries a Tax sheet and a Cost Plan sheet (values as at export). A "Test every connection" button lives in the top bar, so it can be run from any screen. `API_REQUIREMENTS.md` lists what needs a key or internet, and the same list is now a page in the app itself (Requirements, in the left rail), generated from that file so the two can never disagree.
* Stamp duty can be worked out on residential rates plus the higher-rates surcharge, as well as the non-residential rates, from the Tax tab.
* Overnight fixes: the planning data slug for public transport nodes was wrong and is corrected; planning news now asks for a small box around the site because applications are stored as points; the Land Registry sold price query falls back to nearby postcodes; area search falls back to planning.data.gov.uk if PlanIt cannot be reached and says so; walking and cycling times no longer use car times. Stress-testing the listing alert reader with messier real emails found and fixed three bugs: a price with no £ symbol ("Offers over 250,000") was dropped, a "Guide price £X" line could be mistaken for the address, and a standalone bed-count line ("3 bed house") could swallow the real address that followed it.
* Floor areas: the old EPC API closed in May 2026, so Settings now takes the certificates file for a council (CSV or ZIP) from the new government service and matches it to sales by address.
* Comparables: the live Land Registry SPARQL endpoint was tested directly and answered with an error on every real query tried (only its vocabulary, not the actual sales, is queryable this way), so Settings now also takes a Price Paid Data CSV (a year at a time, from the government's yearly file download) and comparables use it first when one is loaded.
* London sites show the Mayor of London's CIL (2026 band and rate) alongside the borough rate, with a choice to add it.
* Setup guide on first run (four steps, only for an empty profile), keyboard shortcuts (press ?), and new command bar actions.

Known limits of 0.9: the tax view is a desk comparison. It ignores group relief, losses, allowances, National Insurance and the tax on taking profit out of a company, uses non-residential stamp duty bands, and applies a rule for VAT by strategy. Levy figures are read by pattern from council documents, are not indexed unless you enter an index, and must be checked against the source. The council schedule lookup and live document fetching have not been run against live sites. The cost plan reader is heuristic and has been tried on synthetic plans only. The alert email reader has been tried on fictional emails only, so a real Rightmove or Zoopla layout may need adjusting. An alert carries little detail, so an added listing is a lead to enrich.

## What is new in 0.8

* Programme: a phased timeline for each site (pre-application, planning, pre-construction, build, sales), a monthly cash flow with peak equity and IRR, and the cost of each extra month of planning delay. Only the fields you set are stored. The rest follow the appraisal assumptions, and with no programme the timing is unchanged.
* Funding: a debt package set against the programme, with drawdown method, exit fees, sources and uses, a comparison of packages (no debt, 50%, 60%, 60% with mezzanine, current) and a one-page finance request in Word for a lender, with bracketed borrower details to complete.
* Comparables: sold prices from HM Land Registry on a map, adjusted for time, new build, distance and size, with every factor editable and every sale switchable. The adjusted value per home type can set the sales values in the appraisal.
* Planning strategy: a rule-based complexity score, a recommended route, the arguments to make, likely concerns with responses, and a timeline, drawn from the track record, policy checks and nearby approvals. It is also available as a Word pack.
* History: each saved change to price, scheme, assumptions, programme or funding is recorded with its effect on profit. Any two versions can be compared, with the movement in profit split by group of inputs.
* Deal room and live numbers: a full-page workspace with a summary that stays on the left, and a headline bar showing profit, margin, IRR and peak equity with the change against the last saved version.
* Outputs: the Report tab is now a pack builder. Choose the pack (report, committee paper, brief or deck), switch sections on and off, drag them into order, preview, and set the name and colour used on every output. The report preview is the exact page. For the Word and deck packs the preview is an outline of each section, not a rendering.
* The report, committee paper and deck now carry the programme, funding package and planning strategy.

Known limits of 0.8: comparable adjustments are desk assumptions until you replace them with a valuer's view, and map points are placed at the postcode. The programme residual land value and the funding comparison (which holds the land price fixed) are approximations. The Excel model keeps standard timing and pro rata drawdown. Attribution in History depends on the order the groups are applied. The strategy score is a rule set and is not advice on any council's policy.

## What is new in 0.7

* Suggestions: the data pack proposes appraisal allowances (abnormals, ecology and biodiversity, S106, heritage, flood, contamination, determination time). Each is applied or reverted on its own and shows its effect on profit. Values are indicative desk allowances to be replaced with consultant or contractor figures.
* Market pricing: sale values and build costs by home type from local sold prices, new-build evidence and cost bands, written into the schedule with an auto flag you can override.
* Planning track record: approval rate and time to decide for major applications over the last five years, from PlanIt, within 8 km of the site. It feeds a suggestion and the reply drafts.
* Screening: rank the whole search result by a quick residual land value, then add all viable sites at once. Mandate-driven search and portfolio concentration are included.
* Land assembly: title polygons around the site, grouped holdings, owner candidates from CCOD and OCOD by postcode, Companies House charges and distress flags, and monthly register diffs for watched postcodes.
* Monthly re-check: shortlisted sites are re-checked every 30 days for new applications, flood warnings, title changes, index moves and a shift in the approval rate. The first run records a baseline.
* Map: layers, click to set the search centre, and a drawn site boundary that can set the site area.
* Layout test: a parametric row pattern on the boundary tests garden lengths, back-to-back distances, parking, density and land left over, and feeds the policy checks.
* Outputs: the constraint table, ownership, nearby applications, access, map image and layout appear in the report, committee paper and deck, and a single site brief (docx) is available from the Data tab.
* Ask this deal: a question box over the site's documents, checks, schedule, record and appraisal. With a Claude API key it answers with cited passages; without one it returns the closest passages.

## What is new in 0.6

* Homes: a detailed typology for houses, flats, build to rent, co-living and care schemes, with a default schedule of accommodation that meets the Nationally Described Space Standard and a room-level editor. Schematic unit plans and a typical-floor diagram appear beside the appraisal, and in the site report, committee paper and investor deck. Saving the schedule writes the unit mix, homes and floor area into the appraisal.
* Planning link: policy checks (space, M4(2) and M4(3), dual aspect, outdoor space, parking, density, affordable mix, higher-risk building rules) run against the schedule, and reply drafts quote the scheme facts. Where a check fails the reply carries a bracketed placeholder so you decide what to concede.
* Data sources page: 28 sources in five groups with licence, status and a live test. planning.data.gov.uk datasets are discovered at run time (30 in the registry, any others can be added), and your own ArcGIS, WMS and WFS layers can be checked at every site.
* Site Data tab: one run checks every source switched on for the location, grouped, with PlanIt applications nearby, census and house price context, transport and amenities, registered title area, and links for the checks that have no open API.
* Land ownership: load the free HM Land Registry CCOD and OCOD files by API key, upload or file path, indexed locally for search by postcode, owner, title number or company number. Import a purchased official copy of the register (PDF) to read proprietors, price paid, charges, restrictions and covenants into the site. Companies House lookup and a configurable paid title provider are included.
* Search: ranked candidate sites by map area and criteria (brownfield registers and PlanIt applications, screened against constraint layers, with the workings shown), and a demographic search such as sites within 13 minutes of a city with 200,000 residents or more. Saved searches, CSV export and one-click add to sites.
* Look: sharp edges throughout and the Aptos typeface everywhere. Aptos is installed with Microsoft 365. Where it is not installed, the interface and documents fall back to Segoe UI, Calibri or Arial.
* Smaller changes: planning news uses PlanIt first, "/" focuses search, Cmd+K gains export and search actions, the active tab scrolls into view.

## What is new in 0.5

* **Home screen.** Top opportunities on the left, planning news on the right: decisions and submissions on your sites, consultee positions on file, and live applications within a kilometre of any real site with coordinates. Demo sites stay labelled as illustrative and are never sent to the live feed.
* **Map.** A Protomaps vector map when `PROTOMAPS_KEY` is set (light and dark styles follow the theme). Without a key, or if the library cannot load, the earlier tile map is used.
* **Site report.** A printable one-page-per-section report for each site, from the Report tab. Print or save as PDF from the browser.
* **Investor deck.** A branded PowerPoint from any site, alongside the branded committee paper. It needs `python-pptx`, which the Docker image and the DMG include.
* **Scenarios and break-even.** Named scenarios that move sales values, rents, build cost, exit yield and planning delay. Break-even tables show how far each variable can move before profit reaches zero or falls to the target margin, and the highest land price that still meets the target.
* **Planning replies.** Paste a case officer query, a consultee response, a neighbour or public comment, or a pre-app, S106 or viability request. The app identifies the topics and reference numbers, and drafts a reply with placeholders for anything it cannot know. Drafts follow the published GOV.UK guidance on material considerations, consultation timescales, Regulation 122 and viability. With a Claude key set in Settings the draft is written by Claude, otherwise it is a template. Always read a draft before sending it.
* **Constraints.** Green belt, flood zones, conservation areas, listed buildings, TPOs, Article 4 directions, brownfield register, SSSI, ancient woodland, SPA, SAC, national park and AONB, checked against planning.data.gov.uk. Coverage differs between councils, so an empty result is not proof of no constraint.
* **Notifications.** A bell in the header collects watch events, overdue diligence, open issues, landowner follow-ups, key dates and debt maturities. Seen items are remembered. The email digest from 0.4 is unchanged.
* **Command bar.** Press Cmd+K (Ctrl+K on Windows) to jump to a site or a page.
* **Saved views.** Save any combination of stage, source, strategy, region and minimum units on the Sites page, and reopen it in one click.
* **Deal emails.** The Outlook connection now lists only messages that look like deals from the last 30 days and reads them for deal data. The rest of the mailbox is not shown or stored.

## Added in 0.4

| Feature | Where | What it does |
|---|---|---|
| Committee paper | site header, Compare | A Word document with recommendation, scheme, appraisal, sensitivities, funding, planning, risks and next steps, written from the data on file. Compare sites and export a paper for any of them. |
| Due diligence | site > Diligence | A checklist of 29 items across title, planning, technical, commercial and funding. It is set up from what the file already shows. Status, owner and due date are editable, and you can add your own items. |
| Compare | left rail | Up to four sites side by side. The strongest figure in each row is shaded. |
| Portfolio | left rail | Existing schemes with GDV, equity in and to come, debt drawn, rates and maturities. Capital view against your fund size and equity headroom after commitments and pipeline. |
| Add existing scheme | Portfolio | Enter a live scheme by hand, or import your organisation's workbook. The importer reads portfolio, balance sheet and cash flow sheets, shows what it found for review, then adds it. It matches on column and row names. With a Claude key in Settings it also reads unusual layouts. |
| Structure | site > Structure | Equity waterfall with preferred return and promote tiers for a fund or joint venture, plus lender covenant tests (loan to cost, loan to GDV, interest cover, debt yield, profit on cost) with editable limits. |
| Build costs | site > Appraisal | Indicative build cost per sq ft by type and region. Every figure carries an asterisk because it is a desk estimate, not a BCIS quote. |
| Shortlist and alerts | left rail, star on any site | Follows the sites you care about and checks the agent's listing page, planning applications and key dates. Changes are logged and can be emailed as a digest through your own SMTP account. |
| Nearby schemes | site > Market | A map of built, consented and submitted schemes around the site with units, density and price where the source gives them. You can add schemes by hand. |
| Landowners | left rail, site > Land | Parcels, owners, status, asking and offered price, contact log and an approach letter. Shows the share of the site secured and the blended price per hectare. |
| Model workbooks | site > Model | Simpler layout: grey headers, bold black text, no italics, no colour fills. |

Set the environment variable `PROTOMAPS_KEY` to draw maps with Protomaps vector tiles through MapLibre GL. Without it the app uses the tile map.

Colours and name follow the easyGroup palette. Your data folder is now `~/Library/Application Support/easyDevelopment`. If you had data in the old folder, copy it across.

### Setting up alerts

Open Shortlist, switch on Email alerts, then enter your address and your mail server details. Gmail and Outlook need an app password. Checks run in the background every few hours while easyDevelopment is running, or when you press Check now. On a free Render plan the service sleeps when idle, so checks only run while it is awake.

## Added in 0.3

| Feature | Where | What it does |
|---|---|---|
| My mandate | left rail | Fund size, equity available, ticket and deal size, strategies, regions, planning appetite, exclusions, return targets, cost of equity, senior and mezzanine terms. Scores every site for fit, writes your cost of capital into every appraisal and filters listing refreshes. |
| Agent contact card | site > Overview | Named agent, phone and email where published, otherwise the firm's team or contact page, plus a one-click enquiry draft that opens in your email app. |
| Planning | site > Planning | Council register links, rule-based risk read-out, permission expiry, timeline, application register and consultee matrix (all editable), and a document analysis whose findings link back to the source document. |
| Documents | site > Documents | Per-deal vault. Drop PDFs, brochures, emails. Read in-app, auto-categorised, searchable by the analysis and Q&A. |
| Add deal | top right | Paste an agent's email or brochure, or drop PDFs and `.eml` files. easyDevelopment reads the facts, creates the site and builds the model. |
| Financial model | site > Model | Editable unit mix and cost inputs, live appraisal, and a formula-driven Excel workbook (Inputs, Appraisal, Cash Flow, Summary, Sensitivity, Deal Info) that recalculates. |
| Market evidence | site > Market | HM Land Registry sold prices for the postcode sector, with EPC floor areas (free key) converted to £ per sq ft and one click to apply to the appraisal. |
| Inbox | left rail | Outlook through Microsoft Graph (read-only) with a likely-deal filter and one-click model build. A labelled demo mailbox is included. |
| Illustrative deals | Sites | Four fully fictional deals with 23 planning documents to show every feature. Remove or restore them in Settings. |

### Connecting Outlook

Microsoft requires each app to have an identity, so there is a three-minute one-off step. In Microsoft Entra (portal.azure.com) register an app, turn on **Allow public client flows**, add the delegated permissions **Mail.Read** and **User.Read**, then paste the Application (client) ID into Inbox and press Connect. You sign in on a Microsoft page with a short code. No secret is stored and easyDevelopment never sends, moves or deletes mail. Tokens are saved in your easyDevelopment data folder. Work accounts may need administrator consent. Not tested against a live tenant (see below).

## Existing views

Overview (KPIs, clustered map, ranking, funnel), Sites (sortable table, mandate filter), Pipeline (drag and drop), Sourcing (10 national agents and 2 aggregators, brownfield search, CSV and alert import), Settings (every assumption, scorecard weights, Claude API key, EPC key).

## Listings: how sourcing works

Rightmove and Zoopla are not used. easyDevelopment reads public search pages from Jackson-Stops, Hamptons, Foxtons, Chestertons, Strutt & Parker, Savills, Knight Frank, Carter Jonas, Winkworth and Fine & Country, plus LandSale and OnTheMarket (land). Each source is polite (robots.txt, rate limit, 6 hour cache) and reports an honest status. When a source fails, a bundled snapshot of real listings (21 Sep 2026) is shown and labelled. Refreshes drop sites outside your mandate if you have one.

Contact details: only Hamptons publishes a firm number and land team email that we could confirm. For the rest easyDevelopment links to the firm's contact page and extracts the named agent from each listing page where it is published.

## What has and has not been verified

* Verified by tests: appraisal engine, mandate logic, intake parsing (paste and `.eml`), document vault, planning register, Land Registry response parsing, the Outlook flow against a mocked Microsoft Graph, and every Excel workbook (recalculated in LibreOffice and matched to the engine to four significant figures).
* Also verified in 0.4: the equity waterfall, covenant tests, importer, committee paper (rendered through LibreOffice), shortlist checks and email digest against mocks, and the interface end to end in a browser.
* Also verified in 0.5: scenarios, break-even, reply drafting, notifications, saved views, the site report, the deck (rendered through LibreOffice) and the new screens in a browser.
* Also verified in 0.6: NDSS compliance of every default, floor plan drawing in SVG, PNG and PowerPoint shapes, policy checks, the connectors and enrichment against recorded fixtures, CCOD indexing, the register parser on a synthetic register, area and place search, and the new screens in a browser.
* Not verified in 0.6: any live call to planning.data.gov.uk, PlanIt, Environment Agency, Overpass, Nomis, Companies House, the HM Land Registry API (file listing and download shapes follow its published pattern), and the WMS layers for the Coal Authority and BGS. The Data sources page has a Test button for each so you can confirm on first run. The register parser follows the layout of an official copy but was tested only on a synthetic sample. Place populations are rounded and travel times are estimates.
* Also verified in 0.7 (against fixtures and synthetic data): suggestions and revert, market pricing, track record maths, screening, mandate and concentration, register diffs, assembly, monthly re-check, map layers and boundary, layout test, the new outputs and the ask box, and the screens in a browser.
* Not verified in 0.7: every live call (PlanIt, planning.data.gov.uk, postcodes.io, HPI, Companies House, HM Land Registry download), static map tiles (only the grid fallback was tested), and the OC1 parser on a real register (synthetic only). The track record uses an 8 km circle, not the council boundary, and PlanIt carries no refusal reasons. Screening uses council-wide HPI averages. The layout test is a capacity test on a row pattern and does not place flats. INSPIRE polygons carry no owner or title number, so owners are matched by postcode. Aptos is not bundled.
* Not verified: sending real email, live checks against planning.data.gov.uk (news and constraints) and Land Registry, Protomaps tiles with a real key, live scraping, the Land Registry endpoint and EPC API (parsers are tested on fixtures, but the build environment blocks these hosts), a live Outlook sign-in, and the DMG build itself (it needs a Mac).

## Tests

    python3 tests/test_core.py
    python3 tests/test_scrapers.py
    python3 tests/test_v03.py
    python3 tests/test_v04.py
    python3 tests/test_v05.py
    python3 tests/test_v06.py
    python3 run.py --selftest
