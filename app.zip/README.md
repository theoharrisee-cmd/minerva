# easyDevelopment 0.5

A native Mac app for finding, screening and appraising UK development and investment sites, built around how a developer-investor thinks.

## Running it

**Web version.** See `DEPLOY.md` to host easyDevelopment behind a password on Render with no Terminal needed.

**1. The DMG (recommended).** Build it once on a Mac, then drag easyDevelopment into Applications.

    ./packaging/build_dmg.sh          # produces dist/easyDevelopment.dmg

No Mac to hand? Push this folder to GitHub and run the "Build easyDevelopment DMG" workflow (Actions tab). It produces Apple Silicon and Intel DMGs as downloadable artefacts.

The app is not notarised. The first time, right-click easyDevelopment in Applications and choose Open. If macOS says it is damaged, run `xattr -dr com.apple.quarantine /Applications/easyDevelopment.app`.

**2. Double-click.** `easyDevelopment.command` runs from source using the Python 3 already on your Mac and opens in your browser. Excel export needs `pip3 install openpyxl`; PDF text reading needs `pypdf`.

**3. Terminal.** `python3 run.py` (native window if `pywebview` is installed, otherwise the browser).

Your data lives in `~/Library/Application Support/easyDevelopment`.

## What is new in 0.5

* **Home screen.** Top opportunities on the left, planning news on the right: decisions and submissions on your sites, consultee positions on file, and live applications within a kilometre of any real site with coordinates. Demo sites stay labelled as illustrative and are never sent to the live feed.
* **Map.** A Protomaps vector map when `PROTOMAPS_KEY` is set (light and dark styles follow the theme). Without a key, or if the library cannot load, the earlier tile map is used.
* **Site report.** A printable one-page-per-section report for each site, from the Report tab. Print or save as PDF from the browser.
* **Investor deck.** A branded PowerPoint from any site, alongside the branded committee paper. It needs `python-pptx`, which the Docker image and the DMG include.
* **Scenarios and break-even.** Named scenarios that move sales values, rents, build cost, exit yield and planning delay. Break-even tables show how far each variable can move before profit reaches zero or falls to the target margin, and the highest land price that still meets the target.
* **Planning replies.** Paste a case officer query, a consultee response, a neighbour or public comment, or a pre-app, S106 or viability request. The app identifies the topics and reference numbers, and drafts a reply with placeholders for anything it cannot know. Drafts follow the published GOV.UK guidance on material considerations, consultation timescales, Regulation 122 and viability. With a Claude key set in Settings the draft is written by Claude, otherwise it is a template. Always read a draft before sending it.
* **Constraints.** Green belt, flood zones, conservation areas, listed buildings, TPOs, Article 4 directions, brownfield register, SSSI, ancient woodland, SPA, SAC, national park and AONB, checked against planning.data.gov.uk. Coverage differs between councils, so an empty result is not proof of no constraint.
* **Notifications.** A bell in the header collects watch events, overdue diligence, open issues, landowner follow-ups, key dates and debt maturities. Seen items are remembered. The email digest from 0.4 is unchanged.
* **Command bar.** Press Cmd+K (Ctrl+K on Windows) to jump to a site or a page.
* **Saved views.** Save any combination of stage, source, strategy, region and minimum units on the Sites page, and reopen it in one click.
* **Deal emails.** The Outlook connection now lists only messages that look like deals from the last 30 days and reads them for deal data. The rest of the mailbox is not shown or stored.

## Added in 0.4

| Feature | Where | What it does |
|---|---|---|
| Committee paper | site header, Compare | A Word document with recommendation, scheme, appraisal, sensitivities, funding, planning, risks and next steps, written from the data on file. Compare sites and export a paper for any of them. |
| Due diligence | site > Diligence | A checklist of 29 items across title, planning, technical, commercial and funding. It is set up from what the file already shows. Status, owner and due date are editable, and you can add your own items. |
| Compare | left rail | Up to four sites side by side. The strongest figure in each row is shaded. |
| Portfolio | left rail | Existing schemes with GDV, equity in and to come, debt drawn, rates and maturities. Capital view against your fund size and equity headroom after commitments and pipeline. |
| Add existing scheme | Portfolio | Enter a live scheme by hand, or import your organisation's workbook. The importer reads portfolio, balance sheet and cash flow sheets, shows what it found for review, then adds it. It matches on column and row names. With a Claude key in Settings it also reads unusual layouts. |
| Structure | site > Structure | Equity waterfall with preferred return and promote tiers for a fund or joint venture, plus lender covenant tests (loan to cost, loan to GDV, interest cover, debt yield, profit on cost) with editable limits. |
| Build costs | site > Appraisal | Indicative build cost per sq ft by type and region. Every figure carries an asterisk because it is a desk estimate, not a BCIS quote. |
| Shortlist and alerts | left rail, star on any site | Follows the sites you care about and checks the agent's listing page, planning applications and key dates. Changes are logged and can be emailed as a digest through your own SMTP account. |
| Nearby schemes | site > Market | A map of built, consented and submitted schemes around the site with units, density and price where the source gives them. You can add schemes by hand. |
| Landowners | left rail, site > Land | Parcels, owners, status, asking and offered price, contact log and an approach letter. Shows the share of the site secured and the blended price per hectare. |
| Model workbooks | site > Model | Simpler layout: grey headers, bold black text, no italics, no colour fills. |

Set the environment variable `PROTOMAPS_KEY` to draw maps with Protomaps vector tiles through MapLibre GL. Without it the app uses the tile map.

Colours and name follow the easyGroup palette. Your data folder is now `~/Library/Application Support/easyDevelopment`. If you had data in the old folder, copy it across.

### Setting up alerts

Open Shortlist, switch on Email alerts, then enter your address and your mail server details. Gmail and Outlook need an app password. Checks run in the background every few hours while easyDevelopment is running, or when you press Check now. On a free Render plan the service sleeps when idle, so checks only run while it is awake.

## Added in 0.3

| Feature | Where | What it does |
|---|---|---|
| My mandate | left rail | Fund size, equity available, ticket and deal size, strategies, regions, planning appetite, exclusions, return targets, cost of equity, senior and mezzanine terms. Scores every site for fit, writes your cost of capital into every appraisal and filters listing refreshes. |
| Agent contact card | site > Overview | Named agent, phone and email where published, otherwise the firm's team or contact page, plus a one-click enquiry draft that opens in your email app. |
| Planning | site > Planning | Council register links, rule-based risk read-out, permission expiry, timeline, application register and consultee matrix (all editable), and a document analysis whose findings link back to the source document. |
| Documents | site > Documents | Per-deal vault. Drop PDFs, brochures, emails. Read in-app, auto-categorised, searchable by the analysis and Q&A. |
| Add deal | top right | Paste an agent's email or brochure, or drop PDFs and `.eml` files. easyDevelopment reads the facts, creates the site and builds the model. |
| Financial model | site > Model | Editable unit mix and cost inputs, live appraisal, and a formula-driven Excel workbook (Inputs, Appraisal, Cash Flow, Summary, Sensitivity, Deal Info) that recalculates. |
| Market evidence | site > Market | HM Land Registry sold prices for the postcode sector, with EPC floor areas (free key) converted to £ per sq ft and one click to apply to the appraisal. |
| Inbox | left rail | Outlook through Microsoft Graph (read-only) with a likely-deal filter and one-click model build. A labelled demo mailbox is included. |
| Illustrative deals | Sites | Four fully fictional deals with 23 planning documents to show every feature. Remove or restore them in Settings. |

### Connecting Outlook

Microsoft requires each app to have an identity, so there is a three-minute one-off step. In Microsoft Entra (portal.azure.com) register an app, turn on **Allow public client flows**, add the delegated permissions **Mail.Read** and **User.Read**, then paste the Application (client) ID into Inbox and press Connect. You sign in on a Microsoft page with a short code. No secret is stored and easyDevelopment never sends, moves or deletes mail. Tokens are saved in your easyDevelopment data folder. Work accounts may need administrator consent. Not tested against a live tenant (see below).

## Existing views

Overview (KPIs, clustered map, ranking, funnel), Sites (sortable table, mandate filter), Pipeline (drag and drop), Sourcing (10 national agents and 2 aggregators, brownfield search, CSV and alert import), Settings (every assumption, scorecard weights, Claude API key, EPC key).

## Listings: how sourcing works

Rightmove and Zoopla are not used. easyDevelopment reads public search pages from Jackson-Stops, Hamptons, Foxtons, Chestertons, Strutt & Parker, Savills, Knight Frank, Carter Jonas, Winkworth and Fine & Country, plus LandSale and OnTheMarket (land). Each source is polite (robots.txt, rate limit, 6 hour cache) and reports an honest status. When a source fails, a bundled snapshot of real listings (21 Sep 2026) is shown and labelled. Refreshes drop sites outside your mandate if you have one.

Contact details: only Hamptons publishes a firm number and land team email that we could confirm. For the rest easyDevelopment links to the firm's contact page and extracts the named agent from each listing page where it is published.

## What has and has not been verified

* Verified by tests: appraisal engine, mandate logic, intake parsing (paste and `.eml`), document vault, planning register, Land Registry response parsing, the Outlook flow against a mocked Microsoft Graph, and every Excel workbook (recalculated in LibreOffice and matched to the engine to four significant figures).
* Also verified in 0.4: the equity waterfall, covenant tests, importer, committee paper (rendered through LibreOffice), shortlist checks and email digest against mocks, and the interface end to end in a browser.
* Also verified in 0.5: scenarios, break-even, reply drafting, notifications, saved views, the site report, the deck (rendered through LibreOffice) and the new screens in a browser.
* Not verified: sending real email, live checks against planning.data.gov.uk (news and constraints) and Land Registry, Protomaps tiles with a real key, live scraping, the Land Registry endpoint and EPC API (parsers are tested on fixtures, but the build environment blocks these hosts), a live Outlook sign-in, and the DMG build itself (it needs a Mac).

## Tests

    python3 tests/test_core.py
    python3 tests/test_scrapers.py
    python3 tests/test_v03.py
    python3 tests/test_v04.py
    python3 tests/test_v05.py
    python3 run.py --selftest
